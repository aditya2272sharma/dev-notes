'use strict';

const path = require('path');
const express = require('express');
const bodyParser = require('body-parser');
const ejs = require('ejs');
const app = express();
const PORT = process.env.PORT || 8080;

const index = require('./server/routes/index');
const admin = require('./server/routes/admin');
const about = require('./server/routes/about');
const search = require('./server/routes/search');
const contact = require('./server/routes/contact');
const shell = require('./server/routes/shell');
const __404 = require('./server/routes/error');
const scrape = require('./server/service/scrape');
// const contact = require('./server/routes/contact');

// ejs.registerPartials(__dirname + '/views/partials');


app.set('views', path.join(__dirname, 'server/views'));
// app.set('view engine', 'ejs');
app.engine('html', require('ejs').renderFile);
app.set('view engine', 'html');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
  extended: true
}));


if (process.env.PORT) {
  // If an incoming request uses
  // a protocol other than HTTPS,
  // redirect that request to the
  // same url but with HTTPS
  const forceSSL = function () {
    return function (req, res, next) {
      if (req.headers['x-forwarded-proto'] !== 'https') {
        return res.redirect(['https://', req.get('Host'), req.url].join(''));
      }
      next();
    }
  }

  // Instruct the app
  // to use the forceSSL
  // middleware
  app.use(forceSSL());
}

app
// Redirect all traffic for foobar using this
.use(function domainRedirectMiddleware(req, res, next) {
  if (req.headers.host.indexOf('foobar.com') > -1) {
    app
    .use('/', index)
    .use('/admin', admin)
    .use('/scrape', scrape)
    .use('/search', search)
    .use('/about', about)
    .use('/contact', contact)
    .use('/shell', shell)
    .use('*', __404);
    console.log('req.url', req.url);
    next();
  } else {
    app
    // Run the app by serving the static files
    // in the dist directory
    .use(express.static(__dirname + '/dist'))

    // For all GET requests, send back index.html
    // so that PathLocationStrategy can be used
    .get('/*', function (req, res) {
      res.sendFile(path.join(__dirname + '/dist/index.html'));
    })
    next();
  }
})


// Start the app by listening on the default
// Heroku port
.listen(PORT, function (params) {
  console.log('Listening at: ', PORT);
});
