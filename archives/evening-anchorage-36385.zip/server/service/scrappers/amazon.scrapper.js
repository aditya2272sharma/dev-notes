function amazonScrapper(cheerio, html, data) {
  let $ = cheerio.load(html);

  $('#brand').filter(function (params) {
    data.brand = $(this).text().trim();
  });

  $('#productTitle').filter(function (params) {
    data.productTitle = $(this).text().trim();
  });

  $('#priceblock_dealprice').filter(function (params) {
    data.currencyINR = $(this).text().trim();
  });
  $('#price-shipping-message').filter(function (params) {
    data.shippingMessage = $(this).text().trim();
  });

  data.featureBullets = [];
  $('#feature-bullets li').each(function (i, elem) {
    data.featureBullets.push($(this).text().trim());
  });

  data.lighteningDeal = {};
  $('#LDBuybox').filter(function (params) {
    var text = $(this).text().trim();
    data.lighteningDeal.wasEverOnLighteningDeal = text.indexOf('Lightning Deal') > -1;
    data.lighteningDeal.dealPrice = $('#LDBuybox .currencyINR').parent().text().trim();
    data.lighteningDeal.recordedDate = (+ new Date);
  });

  data.technicalSpecs = [];
  $('#technicalSpecifications_section_1 tr').each(function (i, elem) {
    data.technicalSpecs.push({
      key: $(this).children('th').text().trim(),
      value: $(this).children('td').text().trim()
    })
  });

  data.productDetails = [];
  $("#detail_bullets_id .content ul li").each(function (i, elem) {
    let key = $(this).children('b').text().trim();
    data.productDetails.push({
      key: key,
      value: $(this).text().replace(key, '').trim()
    })
  });
}

module.exports = amazonScrapper;
