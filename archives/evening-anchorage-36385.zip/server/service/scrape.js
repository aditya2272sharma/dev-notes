const express = require('express');
const path = require('path');
const router = express.Router();
let cheerio = require('cheerio');
const cheerioAdv = require('cheerio-advanced-selectors');
const request = require('request-promise');
const fs = require('fs');


const amazonScrapper = require('./scrappers/amazon.scrapper');


cheerio = cheerioAdv.wrap(cheerio);

/* GET scrape */
router.get('/', function (req, res, next) {
  res.send('Nil');
});

/* POST scrape */
router.post('/', function (req, res, next) {
  console.dir(req.params);
  console.dir(req.body);
  const url = '/server/service/tmp/test.html';
  let data = {};
  let scrapper = null;
  let domain = ''
  switch (domain) {
    case 'amazon.com':
      scrapper = amazonScrapper;
      break;
    
    case 'flipkart.com':
      
      break;
    
    case 'flipkart.com':
      
      break;
  
    default:
      break;
  }


  // default assignment
  scrapper = amazonScrapper;

  fs.readFile(path.join(__dirname, '/tmp/test.html'), (err, html) => {
    scrapper(cheerio, html, data);
    res.json(data);
  });
  // .catch(function (err) {
  //   res.send(err);
  // });
});

// request(url)
//   .then(function (html) {
//     console.log('=====================================');
//     console.log(html);
//     console.log('=====================================');

//     fs.writeFile(path.join(__dirname, '/tmp/test.html'), html, 'utf8', (params) => {
//       console.log('writing complete', params);
//     });
//     res.json(data);
//   })
//   .catch(function (err) {
//     res.send(err);
//   });




module.exports = router;
