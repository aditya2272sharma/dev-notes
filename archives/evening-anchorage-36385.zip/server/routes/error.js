const express = require('express');
const router = express.Router();

/* Error 404: requested page not found */

router.get('/', function (req, res, next) {
  res.send('Error 404: requested page not found');
});

module.exports = router;
