const express = require('express');
const request = require('request-promise');
const AWS = require('aws-sdk');
const uuid = require('node-uuid');
const router = express.Router();
const config = require('../config/amazon.config');

// AWS-account-ID
// 683154078146
// https://683154078146.signin.aws.amazon.com/console

// Community Forum: https://forums.aws.amazon.com/forum.jspa?forumID=9

// Set all common request parameters
// Read More:
// https://docs.aws.amazon.com/AWSECommerceService/latest/DG/CommonRequestParameters.html
const AssociateTag = '';
const ContentType = 'application/json'; // response.content format
const MerchantId = ''; // optional
const Operation = 'ItemSearch'; // e.g. ItemLookup
const Validate = false; // boolean
const Version = '2013-08-01'; // default: 2013-08-01
const Service = 'AWSECommerceService'; // valid value: AWSECommerceService
const XMLEscaping = ''; // Single or Double, not required for JSON


// use scratchpad: http://webservices.amazon.com/scratchpad/index.html
// https://drive.google.com/drive/u/0/folders/1xdB4cL8zZvXFZsw2__fEu3U2mo33hhfL
// const AWS_Access_Key_ID = 'AKIAJWYIOS2KPQXCKA6Q';
// const Secret_Access_Key = '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';
const Associate_ID = '683154078146';

// https://docs.aws.amazon.com/general/latest/gr/signing_aws_api_requests.html
// Generate the signature required by the Product Advertising API
// $signature = base64_encode(hash_hmac("sha256", $string_to_sign, $secret_key, true));
const Request_Signature = '';


// 2nd set
const AWS_Access_Key_ID = 'AKIAI6FAHH37CD2OBA2Q';
const Secret_Access_Key = '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';

/* GET search page. */
router.get('/', function (req, res, next) {
  res.render('search', { title: 'Express' });
});

router.post('/', function (req, res, next) {

  let Keywords = 'the%20hunger%20games';
  let SearchIndex = 'Books';
  let Timestamp = (new Date()).toISOString(); // format YYYY-MM-DDThh:mm:ssZ

  let path = 'http://webservices.amazon.com/onca/xml?'
  + `Service=${Service}`
  + `&AWSAccessKeyId=${AWS_Access_Key_ID}`
  + `&AssociateTag=${Associate_ID}`
  + `&Operation=${Operation}`
  + `&Keywords=${Keywords}`
  + `&SearchIndex=${SearchIndex}`
  + `&Timestamp=${Timestamp}`
  + `&Signaturesk=${Request_Signature}`;

  console.log('Requesting at path:', path);

  request(path)
  .then(function(searchResult){
    res.send(searchResult);
  }, function(err){
    res.send(err);
  });
});

module.exports = router;
