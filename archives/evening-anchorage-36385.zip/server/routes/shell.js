const express = require('express');
const router = express.Router();
const util = require('util');
const exec = util.promisify(require('child_process').exec);

/* GET shell page. */
router.get('/', function(req, res, next) {
  res.render('shell', { title: 'Shell' });
});

/* POST to Shell. */
router.post('/', function(req, res, next) {
  let output = '';


  res.render('shell', {
    title: 'Shell',
    output: output
  });
});

module.exports = router;
