'use strict';

function PageNotFoundCtrl($anchorScroll) {
    var vm = this;

    vm.init = function() {
        $anchorScroll();
    };

    vm.init();
}

PageNotFoundCtrl.$inject = ['$anchorScroll'];

(angular
	.module('RelayServicesApp.PageNotFound')
).controller('PageNotFoundCtrl', PageNotFoundCtrl);
