'use strict';

function Configure($stateProvider) {

    $stateProvider.state('page-not-found', {
        url: '/page-not-found',
        controller: 'PageNotFoundCtrl',
        controllerAs: 'PageNotFoundCtrl',
        templateUrl: 'assets/templates/pages/page-not-found/index.html',
        resolve : {
            'sessionStatus': require('../../services/session-status-resolve')
        },
        params: {
            hasHero: true
        }
    });

}

Configure.$inject = ['$stateProvider'];

function Run() {
}

(angular
    .module('RelayServicesApp.PageNotFound', [])
    .config(Configure)
).run(Run);
