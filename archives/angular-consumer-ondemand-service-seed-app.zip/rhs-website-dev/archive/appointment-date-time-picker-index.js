// archive old stable code
// path: dev/app/components/appointment-date-time-picker/index.js
'use strict';

function AppointmentDateTimePicker($filter, moment, SettingsService) {
    var ctrl = this,
    monthNames = SettingsService.DateTime.MonthNamesArray;

    ctrl.mode = {
        step: {days: 7}
    };
    ctrl.enableMoveBtn = true;
    ctrl.formatWeekViewDayHeader = 'EEEE';
    ctrl.formatWeekViewDateHeader = 'd';

    ctrl.timeRanges = SettingsService.DateTime.TimeRanges;

    /**
	* Getting initial info
    */
    ctrl.init = function() {
        //In the date-picker, show days up to 90 days from the current date.
        ctrl.maxDateInMonths = 3;
        var finaldate = moment().startOf('week');//moment().add(2, 'days');
        /*finaldate = finaldate.weekday() && finaldate.weekday() <= 5 ?
                    finaldate : finaldate.add(8 - (finaldate.weekday() || 7), 'days');*/
        var formattedDate = $filter('date')(finaldate._d, 'yyyy-MM-dd');
        ctrl.dates = ctrl.getDates(formattedDate, 7);
        ctrl.disableReschedule = false;
    };

    /**
    * Calculates 5 consecutive days from a startTime
    * @param {Object} startTime - Contains the date object
    * @param {variable} n - Consecutive days limit
    * @returns {Object} - Array of date objects
    */
    ctrl.getDates = function(startTime, n) {
        var dates = new Array(n),
            current = new Date(startTime),
            i = 0,
            month = -1,
            year = 0,
            monthYear = '';
        current.setHours(12); // Prevent repeated dates because of timezone bug
        while (i < n) {
            dates[i++] = {
                date: new Date(current)
            };
            if (month !== current.getMonth()) {
                if (month === -1) {
                    monthYear = monthNames[current.getMonth()];
                } else if (year !== 0 && year !== current.getFullYear()) {
                    monthYear = monthYear + ', ' + year + ' - ' + monthNames[current.getMonth()];
                } else {
                    monthYear = monthYear + ' - ' + monthNames[current.getMonth()];
                }
                month = current.getMonth();
                year = current.getFullYear();
            }
            current.setDate(current.getDate() + 1);
        }
        monthYear = monthYear + ', ' + year;
        ctrl.activeMonthYear = monthYear;
        return dates;
    };

    /**
    * For navigating through calendar view
    * @param {variable} direction - Indicates backward or forward move
    */
    ctrl.move = function(direction) {
        var step = ctrl.mode.step,
        curDay = new Date(ctrl.dates[0].date),
        currentCalendarDate = curDay,
        year = currentCalendarDate.getFullYear() + direction * (step.years || 0),
        month = currentCalendarDate.getMonth() + direction * (step.months || 0),
        date = currentCalendarDate.getDate() + direction * (step.days || 0);
        currentCalendarDate.setFullYear(year, month, date);

        ctrl.dates = ctrl.getDates(currentCalendarDate, 7);
        ctrl.enableMoveButton(ctrl.dates[ctrl.dates.length - 1].date);
    };

    /**
    * For enabling right navigation button
    */
    ctrl.enableMoveButton = function(largestDay) {
        var dayLimit = new Date();
        dayLimit.setMonth(dayLimit.getMonth() + ctrl.maxDateInMonths);

        if (largestDay > dayLimit) {
            ctrl.enableMoveBtn = false;
        } else {
            ctrl.enableMoveBtn = true;
        }
    };

    /**
    * Highlight current timeslot in calendar view
    * @param {Object} date - date from calendarview
    * @param {Object} timeslot - timeslot from calendarview
    * @returns {boolean} - returns true if date and timeslot is same as current date and time
    */
    ctrl.getDefaultData = function(date, timeslot) {
        var formattedDate = $filter('date')(date, 'yyyy-MM-dd');
        var newTimeSlot = ctrl.getNewTimeSlot(ctrl.currentTimeSlot);
        var timeslotParam = ctrl.getNewTimeSlot(timeslot);
        if (formattedDate === ctrl.currentDate && timeslotParam === newTimeSlot) {
            return true;
        }
    };

    ctrl.getNewTimeSlot = function(timeslot) {
        var newTimeSlot;
        if (timeslot === '8:00 AM  -  12:00 PM' || timeslot === '8:00 AM - 12:00 PM') {
            newTimeSlot = '8:00 AM - 12:00 PM';
        } else if (timeslot === '12:00 PM  -  4:00 PM' || timeslot === '12:00 PM - 4:00 PM') {
            newTimeSlot = '12:00 PM - 4:00 PM';
        } else if (timeslot === '4:00 PM  -  8:00 PM' || timeslot === '4:00 PM - 8:00 PM') {
            newTimeSlot = '4:00 PM - 8:00 PM';
        } else {
            newTimeSlot = timeslot;
        }
        return newTimeSlot;
    };

    /**
    * Sets valid new date and time slot
    * @param {Object} timeSlot - timeslot from calendarview
    * @param {Object} date - date from calendarview
    */
    ctrl.setTimeSlot = function(timeSlot, date) {
        var dayLimit = new Date();
        dayLimit.setMonth(dayLimit.getMonth() + ctrl.maxDateInMonths);
        dayLimit = $filter('date')(dayLimit, 'yyyy-MM-dd');

        var formattedDate = $filter('date')(date, 'yyyy-MM-dd');
        var newTimeSlot = ctrl.getNewTimeSlot(ctrl.currentTimeSlot);
        if (ctrl.checkDateValidity(date) || (formattedDate === ctrl.currentDate && timeSlot === newTimeSlot) ||
            (formattedDate > dayLimit)) {
            ctrl.disableReschedule = true;
        } else {
            ctrl.disableReschedule = false;
            ctrl.newTimeSlot = timeSlot;
            ctrl.newDate = date;
            var newDate = {
                date: ctrl.newDate,
                timeSlot: ctrl.newTimeSlot,
                rescheduleBtnStatus: ctrl.disableReschedule
            };
            ctrl.onRescheduleDateChange({RescheduledDate: newDate});
            ctrl.formattedNewDate = formattedDate;
        }
    };

    /**
    * Highlight new timeslot in calendar view
    * @param {Object} date - date from calendarview
    * @param {Object} timeSlot - timeslot from calendarview
    * @returns {boolean} - returns true if selected timeslot is a valid time
    */
    ctrl.getActiveNewDate = function(date, timeSlot) {
        var formattedDate = $filter('date')(date, 'yyyy-MM-dd');
        if (ctrl.newTimeSlot  === timeSlot && ctrl.formattedNewDate === formattedDate &&
            ctrl.newTimeSlot !== ctrl.currentDate) {
            return true;
        }
    };

    /**
    * Checks new date validity
    * @param {Object} date - date from calendarview
    * @returns {Object} isValidDate- returns true if date is a weekday
    */
    ctrl.checkDateValidity = function(date) {
        var dayLimit = new Date();
        dayLimit.setMonth(dayLimit.getMonth() + ctrl.maxDateInMonths);
        dayLimit = $filter('date')(dayLimit, 'yyyy-MM-dd');

        var finaldate = moment().add(0, 'days');
        finaldate = finaldate.weekday() && finaldate.weekday() <= 5 ?
                    finaldate : finaldate.add(8 - (finaldate.weekday() || 7), 'days');
        var newStartDate = $filter('date')(finaldate._d, 'yyyy-MM-dd');
        var newCurrentDate = $filter('date')(date, 'yyyy-MM-dd');
        var isValidDate = (moment(date).weekday() === 0 ||
            (newCurrentDate <= newStartDate));

        if (newCurrentDate > dayLimit) {
            isValidDate = false;
        }
        return isValidDate;
    };

    /**
    * For disabling left navigation arrow
    * @returns {boolean} - returns true if start date in the calendar is current date
    */
    ctrl.checkCurrentStart = function() {
        var startDay = $filter('date')(new Date(ctrl.dates[0].date), 'yyyy-MM-dd');
        var finaldate = moment().add(2, 'days');
        finaldate = finaldate.weekday() && finaldate.weekday() <= 5 ?
                    finaldate : finaldate.add(8 - (finaldate.weekday() || 7), 'days');
        var formattedDate = $filter('date')(finaldate._d, 'yyyy-MM-dd');
        if (startDay === formattedDate) {
            return true;
        }
    };

    ctrl.init();
}

AppointmentDateTimePicker.$inject = ['$filter', 'moment', 'SettingsService'];

(angular
	.module('RelayServicesApp.Components')
).component('appointmentDateTimePicker', {
    templateUrl: 'assets/templates/components/appointment-date-time-picker/index.html',
    controller: AppointmentDateTimePicker,
    bindings: {
        currentDate: '<',
        currentTimeSlot: '<',
        onRescheduleDateChange: '&'
    }
});
