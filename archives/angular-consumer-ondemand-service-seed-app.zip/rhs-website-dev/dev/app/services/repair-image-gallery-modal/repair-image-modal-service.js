'use strict';

/**
* Use this Service to open images on gallery
*/
angular.module('RelayServicesApp.Services').factory('RepairImageGalleryModalService',
    ['$rootScope', '$q', '$state', 'AbstractService', '$uibModal',
    function($rootScope, $q, $state, AbstractService, modal) {

        var factory = {

            /**
             * [signInInit description]
             * @return {[type]}           [description]
             */
            openModal : function(openImageIndex, images, callbackOnOpen, callbackOnClose) {
                var modalInstance = modal.open({
                    animation: true,
                    windowClass: 'photo-detail',
                    controller: 'DetailsGalleryCtrl as DetailsGalleryController',
                    templateUrl: 'assets/templates/pages/account/myBookings/detail-gallery/index.html',
                    resolve: {
                        projectImages: function() {
                            return {
                                'images' : images,
                                'openIndex': openImageIndex
                            };
                        }
                    }
                });

                modalInstance.result.then(function() {
                    if (callbackOnOpen) {
                        callbackOnOpen();
                    }
                }, function(where) {
                    if (callbackOnClose) {
                        callbackOnClose();
                    }
                    switch (where) {
                        case 'home': return $state.go('home.new');
                    }
                });
                return modalInstance;
            }

        };

        //Extends factory with Abstract service
        return angular.extend(factory, AbstractService);
    }]
);
