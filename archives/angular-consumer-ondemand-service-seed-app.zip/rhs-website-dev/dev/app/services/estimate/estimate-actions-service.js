'use strict';

function EstimateActionsService(_, ProjectDateTimeModalService, ProjectsService, modal, $state, CheckoutInfoService, $q) {
    var that = {
        baseUrl: 'https://maps.googleapis.com/maps/api/',
        projectId: '',
        decision: '',
        estimateId: '',
        updatedDate: '',
        updatedTimeSlot: '',
        estimate: '',
        project: '',

        /*
         * Used to handle calls for estimation acceptance & taking the user to
         * payments page when Payments v1 was in place
         *
         */
        acceptRejectEstimate: function(decision, estimate, project, availableDates) {
            that.projectId = project.id;
            that.decision = decision;
            that.estimateId = estimate.bid.estimateId;
            that.project = project;
            that.estimate = estimate;
            that.availableDates = availableDates;
            var deferred = $q.defer();
            if (decision === 'Reject') {
                that.rejectEstimate();
            } else {
                ProjectDateTimeModalService.openModal(that.project, function(serviceDate, serviceTime) {
                    that.updatedDate = serviceDate;
                    that.updatedTimeSlot = serviceTime;
                    that.handleEstimate(decision, that.estimateId, that.acceptEstimateCallback)
                    .then(function() {}, function() {
                        deferred.reject();
                    });
                });
            }
            return deferred.promise;
        },

        /*
         * In Payments v2, we don't ask user for a `date` as we've enabled it on
         * the payments page with a date picker.
         *
         */
        acceptRejectEstimateWithoutDate: function(decision, estimate, project, availableDates) {
            that.projectId = project.id;
            that.decision = decision;
            that.estimateId = estimate.bid.estimateId;
            that.project = project;
            that.estimate = estimate;
            that.availableDates = availableDates;
            var deferred = $q.defer();
            if (decision === 'Reject') {
                that.rejectEstimate();
            } else {
                that.handleEstimate(decision, that.estimateId, that.acceptEstimateCallback)
                .then(function() {}, function() {
                    deferred.reject();
                });
            }
            return deferred.promise;
        },

        handleEstimate: function(decision, estimateId, successCallback) {
            var deferred = $q.defer();
            (ProjectsService
                    .acceptOrRejectProjectEstimation(that.projectId, estimateId, decision)
                ).then(function(result) {
                    //Cancel service
                    if (that.decision === 'Reject') {

                        var cancelService = {
                            projectId: that.projectId,
                            reason: 'Product Damaged',
                            comment: 'Product Damaged'
                        };

                        (ProjectsService.getCancelMessageByProjectId(that.projectId))
                        .then(function(cancelMessage) {
                            cancelService.amount = cancelMessage.charge;
                            (ProjectsService.cancel(cancelService)).then(function() {
                                if (successCallback) {
                                    successCallback();
                                }
                            });
                        });
                    } else {
                        if (successCallback) {
                            successCallback(result);
                        }
                    }
                }, function() {
                    deferred.reject();
                });
            return deferred.promise;
        },

        rejectEstimate: function() {
            var actionsModal = modal.open({
                animation: true,
                controller: 'RejectActionsCtrl as RejectActionsController',
                templateUrl: 'assets/templates/pages/projects/reject-actions/index.html'
            });

            actionsModal.result.then(function(action) {
                //submit actions
                if (action === 'RESELECT') {
                    //actions for reselect
                    that.handleEstimate(that.decision, that.estimateId, that.estimateRejectAndReselect);
                }
                if (action === 'CANCEL') {
                    //actions for cancel
                    that.handleEstimate(that.decision, that.estimateId, that.estimateRejectAndCancel);
                }
            }, function() {
                //closed modal
            });
        },

        estimateRejectAndReselect: function() {
            var project = {
                /*subcategoryid: that.project.category.id,*/
                title: that.project.category.title,
                taskTitle: that.project.title,
                addressline1: that.project.location.addressLine1,
                zipcode: that.project.location.zipCode,
                images: that.project.images,
                description: that.project.taskDescription,
                servicetype: 'NON_STANDARD',
                catalogid: that.project.category.rowid
            };
            ProjectsService.createCustomProject(project).then(function(response) {
                ProjectsService.getProjectEstimatesFirms(response.id).then(function(responseDet) {
                    if (responseDet.items.length > 0) {
                        $state.go('projects.estimates', {id: response.id});
                    }
                });
            });
        },

        estimateRejectAndReselectNew: function(currentProject) {
            var project = {
                title: currentProject.category.title,
                taskTitle: currentProject.title,
                addressline1: currentProject.location.addressLine1,
                zipcode: currentProject.location.zipCode,
                images: currentProject.images,
                description: currentProject.taskDescription,
                servicetype: 'NON_STANDARD',
                catalogid: currentProject.category.rowid
            };
            ProjectsService.createCustomProject(project).then(function(response) {
                ProjectsService.getProjectEstimatesFirms(response.id).then(function(responseDet) {
                    if (responseDet.items.length > 0) {
                        $state.go('projects.estimates', {id: response.id});
                    }
                });
            });
        },

        estimateRejectAndCancel: function() {
            $state.go('account.my-bookings');
        },

        acceptEstimateCallback: function(acceptRejectObject) {
            CheckoutInfoService.setCheckout({
                order: acceptRejectObject,
                project: that.projectId,
                firm: that.estimate,
                zipcode: that.project.location.zipCode,
                selectedTime: that.updatedTimeSlot,
                selectedDate: that.updatedDate,
                isNSFlow: true,
                availableDates: that.availableDates
            });

            $state.go('payment.checkout');
        },

        rejectEstimateAndCreateNewProject: function(project, estimateId) {
            (ProjectsService.acceptOrRejectProjectEstimation
                (project.id, estimateId, 'Reject')).then(function() {
                var cancelService = {
                    projectId: project.id,
                    reason: 'Product Damaged',
                    comment: 'Product Damaged'
                };
                (ProjectsService.getCancelMessageByProjectId(project.id))
                .then(function(cancelMessage) {
                    cancelService.amount = cancelMessage.charge;
                    (ProjectsService.cancel(cancelService)).then(function() {
                        that.estimateRejectAndReselectNew(project);
                    });
                });
            });
        },

        rejectEstimateAndCancelProject: function(projectId, estimateId) {
            (ProjectsService.acceptOrRejectProjectEstimation
                (projectId, estimateId, 'Reject')).then(function() {
                var cancelService = {
                    projectId: projectId,
                    reason: 'Product Damaged',
                    comment: 'Product Damaged'
                };
                (ProjectsService.getCancelMessageByProjectId(projectId))
                .then(function(cancelMessage) {
                    cancelService.amount = cancelMessage.charge;
                    (ProjectsService.cancel(cancelService)).then(function() {
                        $state.go($state.current, {}, {reload: true});
                    });
                });
            });
        },

        rejectTheEstimate: function(projectId, estimateId) {
            (ProjectsService.acceptOrRejectProjectEstimation
                (projectId, estimateId, 'Reject'));
        }
    };
    return that;
}

EstimateActionsService.$inject = ['_', 'ProjectDateTimeModalService', 'ProjectsService', '$uibModal',
'$state', 'CheckoutInfoService', '$q'];

/**
 * Use this service to get information about projects' categories.
 */
(angular
    .module('RelayServicesApp.Services')
).factory('EstimateActionsService', EstimateActionsService);
