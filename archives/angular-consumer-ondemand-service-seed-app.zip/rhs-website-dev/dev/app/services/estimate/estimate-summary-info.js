'use strict';

function EstimateSummaryInfoService() {
    var estimateSummary;

    this.setEstimateSummary = function(value) {
        estimateSummary = value;
    };

    this.getEstimateSummary = function() {
        var _estimateSummary = estimateSummary;
        estimateSummary = undefined;
        return _estimateSummary;
    };

    this.hasEstimateSummary = function() {
        return !!estimateSummary;
    };
}

EstimateSummaryInfoService.$inject = ['_'];

/**
 * Use this service to get information about checkout info.
 */
(angular
    .module('RelayServicesApp.Services')
).service('EstimateSummaryInfoService', EstimateSummaryInfoService);
