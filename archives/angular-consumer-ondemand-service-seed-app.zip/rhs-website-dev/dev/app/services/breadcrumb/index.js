'use strict';

function BreadcrumbService(AbstractService) {
    var _taskDescription = '';

    var factory = {

        setTaskDescription: function(value) {
            _taskDescription = value;
        },

        getTaskDescription: function() {
            return _taskDescription;
        }

    };

    // Extends factory with Abstract service
    return angular.extend(factory, AbstractService);
}

BreadcrumbService.$inject = ['AbstractService'];

(angular
    .module('RelayServicesApp.Services')
).factory('BreadcrumbService', BreadcrumbService);
