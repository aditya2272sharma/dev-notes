'use strict';

/**
 * Allows to check session before any request
 * @return {Object} The promise with response data
 */
module.exports = [
    '$q', '$rootScope', '$cookies', 'AbstractService', 'LoginManagerService',
    function($q, $rootScope, cookies, AbstractService, LoginManagerService) {
    var deferred = $q.defer(),
        resolve = angular.extend({}, AbstractService);

    //http://relayscheduling-stage.us-east-1.elasticbeanstalk.com/api/v1/auth/status
    if (typeof(cookies.get('token')) !== 'undefined') {
        //Creates a clean user
        var user = new LoginManagerService.User();
        resolve.setConfig({
            endpoint: 'profile',
            method: 'GET'
        });
        resolve.call()
        .then(function(response) {
            user = LoginManagerService.setUser(response.data);
        })
        ['finally'](function() {
            deferred.resolve(user);
            $rootScope.$broadcast('user:authentication:change', user);
        });

        return deferred.promise;
    }
}];
