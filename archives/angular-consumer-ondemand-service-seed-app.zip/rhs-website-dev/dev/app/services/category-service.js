'use strict';

function CategoryService(_, $q, $filter, ProjectCategoriesService,
    NewProjectCategoriesService
) {
    var _that = null;
    var _catalogs = null;

    var that = {
        getCategoryByName: function(categoryName) {
            return $q(function(resolve, reject) {
                var category = _.get(_that, categoryName);

                if (category) {
                    resolve(category);
                }

                ProjectCategoriesService.categories(true)
                    .then(function(response) {
                        _that = _.reduce(response, function(result, category) {
                            var categoryName = $filter('safeUrls')(_.get(category, 'title'));
                            result[categoryName] = category;
                            return result;
                        }, {});

                        resolve(_.get(_that, categoryName));
                    })
                    .catch(function(error) {
                        reject(error);
                    });
            });
        },

        getSubcategoryByName: function(categoryName, subcategoryName) {
            return $q(function(resolve, reject) {
                var subcategory = _.get(_that, categoryName + '.subcategories.' + subcategoryName);

                if (subcategory) {
                    resolve(subcategory);
                }

                that.getCategoryByName(categoryName)
                    .then(function(category) {
                        return ProjectCategoriesService.subcategories(category.id);
                    })
                    .then(function(subcategories) {
                        _that[categoryName].subcategories = _.reduce(subcategories.subCategories, function(result, subcategory) {
                            var subcategoryName = $filter('safeUrls')(_.get(subcategory, 'title'));
                            result[subcategoryName] = subcategory;
                            return result;
                        }, {});

                        resolve(_.get(_that, categoryName + '.subcategories.' + subcategoryName));
                    })
                    .catch(function(error) {
                        reject(error);
                    });
            });
        },

        getCatalogByName: function(categoryName) {
            return $q(function(resolve, reject) {
                var category = _.get(_catalogs, categoryName);

                if (category) {
                    resolve(category);
                }

                NewProjectCategoriesService.standardCatalogs()
                    .then(function(response) {
                        _catalogs = _.reduce(response, function(result, category) {
                            var categoryName = $filter('safeUrls')(_.get(category, 'title'));
                            result[categoryName] = category;
                            return result;
                        }, {});

                        resolve(_.get(_catalogs, categoryName));
                    })
                    .catch(function(error) {
                        reject(error);
                    });
            });
        },
    };

    return that;
}

CategoryService.$inject = ['_', '$q', '$filter', 'ProjectCategoriesService',
    'NewProjectCategoriesService'];

angular
    .module('RelayServicesApp.Services')
    .service('CategoryService', CategoryService);
