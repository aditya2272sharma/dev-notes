'use strict';

function DateTimeValidationService(_, moment, $uibModal, ProjectsService, SettingsService) {
    var factory = {
    // expandedValue is used here to bypass a space-character quirk
    // which has double-spaced-hyphenated time slot values
    timeRanges : [{
        label:'8am - 12pm',
        value:'8:00 AM - 12:00 PM',
        expandedValue: '8:00 AM  -  12:00 PM'
    }, {
        label: '12pm - 4pm',
        value:'12:00 PM - 4:00 PM',
        expandedValue: '12:00 PM  -  4:00 PM'
    }, {
        label: '4pm - 8pm',
        value:'4:00 PM - 8:00 PM',
        expandedValue: '4:00 PM  -  8:00 PM'
    }],

    dateFormat: 'YYYY-MM-DD',
    dateTimeFormat: 'YYYY-MM-DD h:m A',
    isModalOpen: false,

    validateDateTime : function(selectedServiceDate, selectedTimeSlot) {
        if (!Boolean(selectedServiceDate && selectedTimeSlot)) {
            return false;
        }

        var isValidDate = factory.validateDate(selectedServiceDate);
        var isValidTime = factory.validateTime(selectedTimeSlot);

        return (isValidDate && isValidTime);
    },

    validateDate : function(selectedServiceDate) {
        return moment(new Date(selectedServiceDate)).weekday() <= 6;
    },

    validateTime : function(selectedTimeSlot) {
        var isValidTime = false;
        // TODO:
        // old validation logic wasn't aligned with a dynamic time range
        // will modify this later
        // this has to validate against the response from Availability API

        // _.forEach(factory.timeRanges, function(timeRange) {
        //     if (selectedTimeSlot === timeRange.value || selectedTimeSlot === timeRange.expandedValue) {
        //         isValidTime = true;
        //     }
        // });
        if (selectedTimeSlot.toLowerCase().indexOf("pm") >= 0 || selectedTimeSlot.toLowerCase().indexOf("am") >= 0) {
            isValidTime = true;
        }
        return isValidTime;
    },

    isDateTimeInvalid : function(selectedServiceDate, selectedTimeSlot) {
        // returning the inverse of validateDateTime()
        return !factory.validateDateTime(selectedServiceDate, selectedTimeSlot);
    },

    getTimeRange : function(selectedTimeSlot) {
        if (!selectedTimeSlot) {
            return;
        }

        var _timeRange;
        _.filter(factory.timeRanges, function(timeRange) {
            if (selectedTimeSlot === timeRange.value ||
              selectedTimeSlot === timeRange.expandedValue ||
              selectedTimeSlot === timeRange.label) {
                _timeRange = timeRange;
            }
        });
        return _timeRange;
    },

    getLabelFromValue : function(selectedTimeSlot) {
        if (!selectedTimeSlot) {
            return;
        }

        var timeRange;
        timeRange = factory.getTimeRange(selectedTimeSlot);

        if (timeRange === undefined) {
            return selectedTimeSlot;
        }

        return timeRange.label;
    },

    /**
     * Checks if the current date is present in the response from Availability API or not
     * Compares this against the selected date in format: moment(...).format('YYYY-MM-DD')
     * Accumulates the matches in an array
     * Returns the timeslots present in the 0th element of the matches
     * Returns an array with only a single string
     *
     * @param  {number} projectId Project Id
     * @return {Object} Response promise
     */
    getTimeRangesFromDate : function(availableDates, selectedDate) {
        var filteredResults,
            timeSlot = [],
            timeSlotsData;
        filteredResults = _.filter(availableDates, function(availableDate) {
            return (selectedDate === availableDate.date);
        });
        timeSlotsData = (angular.isArray(filteredResults)) && (filteredResults.length > 0) && filteredResults[0].timeSlots || [];
        timeSlotsData.reduce(function(timeSlot, item) {
            timeSlot.push({
                value: (item.fromTime + ' - ' + item.toTime),
                label: factory.getLabelFromValue(item.fromTime + ' - ' + item.toTime)
            });
            return timeSlot;
        }, timeSlot);

        if (timeSlot.length === 0) {
            return [{
                value: undefined,
                label: 'No valid time slots found'
            }];
        } // else {...}
        return timeSlot;
    },

    /**
     * Gets today's timeslots from the availability api response
     * @param array availableDates
     * @param string selectedDate
     */
    getTodaysTimeSlots : function(availableDates) {
        var todaysDate = factory.getFormattedCurrentDate();
        var filteredResults,
            timeSlots;
        filteredResults = _.filter(availableDates, function(availableDate) {
            return (todaysDate === availableDate.date);
        });
        timeSlots = (angular.isArray(filteredResults)) && (filteredResults.length > 0) ? filteredResults[0].timeSlots : [];

        return timeSlots;
    },

    /**
     * Checks whether the current time is in the range
     * @param string fromTime
     * @param string toTime
     */
    isValidTimeSlot : function (fromTime, toTime) {
        if (!(factory.validateTime(fromTime) &&
            factory.validateTime(toTime))) {
                return false;
            }
        var format = factory.dateTimeFormat;
        var currentDate = factory.getFormattedCurrentDate();

        // Add 45 mins to avoid overlap
        var currentTimestamp = moment().add(45, 'm').unix();
        var fromTimestamp = moment((currentDate + ' ' + fromTime), format).unix();
        var toTimestamp = moment((currentDate + ' ' + toTime), format).unix();

        return currentTimestamp >= fromTimestamp &&
            currentTimestamp <= toTimestamp;
    },

    /**
     * Checks whether the current time is valid according to
     * the timeslot selected
     * @param string toTime
     */
    isValidTimeSlotSelected : function (toTime) {
        if (!factory.validateTime(toTime)) {
                return false;
            }
        var format = factory.dateTimeFormat;
        var currentDate = factory.getFormattedCurrentDate();


        var currentTimestamp = moment().unix();
         // Subtract 45 mins to avoid overlap
        var toTimestamp = moment((currentDate + ' ' + toTime), format).subtract(45, 'm').unix();

        return currentTimestamp <= toTimestamp;
    },

    /**
     * In case of current time is not in the available timeslots
     * for today, then get the next available date and timeslot
     */
    getNextAvailableDateAndTime : function (availableDates) {
        var todaysDate = factory.getFormattedCurrentDate();
        var todaysDateIndex = -1;

        todaysDateIndex = _.findIndex(availableDates, function(availableDate) {
            return (todaysDate === availableDate.date);
        });
        if (todaysDateIndex > -1) {
            return availableDates[todaysDateIndex+1];
        } else {
            return null;
        }
    },

    getFormattedCurrentDate : function () {
        return moment().format(factory.dateFormat);
    },

    isCurrentDate: function (dateSelected) {
        return moment(dateSelected).isSame(factory.getFormattedCurrentDate());
    },

    /**
     * Fragmentation of timeslot string into
     * from time and to time
     */
    getTimeSlotsFragments : function (timeslot) {
        var fragments = timeslot.split('-');
        if(fragments.length > 0) {
            return {
                'fromTime': fragments[0].trim(),
                'toTime': fragments[1].trim()
            };
        }
        return null;
    },

    /**
     * Check for next available date and timeslot
     */
    getNextValidDateTime : function(availableDates) {
        if (!availableDates) {
            return null;
        }
        var currentDate = factory.getFormattedCurrentDate();

        // Get today's timeslots
        var todaysAvailableTimeSlot = factory.getTodaysAvailableTimeSlot(availableDates);

        // If no available slots for today,
        // then return the next available date and timeslot
        if (todaysAvailableTimeSlot.timeSlotIndex === -1) {
            var nextAvailableDateTime = factory.getNextAvailableDateAndTime(availableDates);
            if(nextAvailableDateTime) {
                var nextAvailableTimeSlots = nextAvailableDateTime.timeSlots[0];
                return {
                    'date': nextAvailableDateTime.date,
                    'timeSlot': [nextAvailableTimeSlots.fromTime, nextAvailableTimeSlots.toTime].join(' - '),
                    'timeSlotIndex': 0
                };
            } else {
                return null;
            }
        } else {
            return {
                'date': currentDate,
                'timeSlot': todaysAvailableTimeSlot.timeSlot,
                'timeSlotIndex': todaysAvailableTimeSlot.timeSlotIndex
            };
        }
    },

    /**
     * Checks whether the current time is less than
     * the first timeslot available
     */
    checkTimeBeforeTimeslot: function(firstTimeSlotStart) {
        if (!factory.validateTime(firstTimeSlotStart)) {
            return false;
        }

        var format = factory.dateTimeFormat;
        var currentDate = factory.getFormattedCurrentDate();
        var currentTimestamp = moment().unix();
        // Subtract 15 mins from starting time of available timeslot to avoid overlap
        var fromTimestamp = moment((currentDate + ' ' + firstTimeSlotStart), format).subtract(15, 'm').unix();

        return currentTimestamp < fromTimestamp;
    },

    /**
     * Get Today's available timeslot
     * for disabling the previous timeslots
     */
    getTodaysAvailableTimeSlot: function(availableDates) {
        var timeSlots = [];
        if(availableDates && angular.isArray(availableDates)) {
            timeSlots = factory.getTodaysTimeSlots(availableDates);
        }

        if(timeSlots.length === 0) {
            return {
                'timeSlot': '',
                'timeSlotIndex': -1
            };
        }

        // check for current time earlier than first timeslot
        if (factory.checkTimeBeforeTimeslot(timeSlots[0].fromTime)) {
            // return first timeslot as available
            return {
                'timeSlot': [timeSlots[0].fromTime, timeSlots[0].toTime].join(' - '),
                'timeSlotIndex': 0
            };
        } else {
            for (var i = 1; i < timeSlots.length; i++) {
                if (factory.isValidTimeSlot(timeSlots[i].fromTime,timeSlots[i].toTime)) {
                    return {
                        'timeSlot': [timeSlots[i].fromTime, timeSlots[i].toTime].join(' - '),
                        'timeSlotIndex': i
                    };
                } else if (factory.isFutureTimeSlot(timeSlots[i].fromTime)) {
                    return {
                        'timeSlot': [timeSlots[i].fromTime, timeSlots[i].toTime].join(' - '),
                        'timeSlotIndex': i
                    };
                }
            }
        }

        // In case of no available timeslots
        // return timeslot index as -1
        return {
            'timeSlot': '',
            'timeSlotIndex': -1
        };
    },

    /**
     * In case of timeslots are non-sequential in availability response
     * then we need to check whether the current time is less
     * than any valid timeslots available
     */
    isFutureTimeSlot: function(fromTime) {
        if (!factory.validateTime(fromTime)) {
            return false;
        }
        var format = factory.dateTimeFormat;
        var currentDate = factory.getFormattedCurrentDate();

        // Add 45 mins to avoid overlap
        var currentTimestamp = moment().add(45, 'm').unix();
        var fromTimestamp = moment((currentDate + ' ' + fromTime), format).unix();

        return currentTimestamp <= fromTimestamp;
    },

    /**
     * Show TT Validation message popup
     * incase of the selected timeslot is invalid
     */
    showTTValidityCheckModal: function(skuCode, zipcode) {
        if (!factory.isModalOpen) {
            var modalInstance = $uibModal.open({
                animation: true,
                ariaLabelledBy: 'modal-title',
                ariaDescribedBy: 'modal-body',
                templateUrl: [
                    'assets/templates/components/tt-validity-check-modal/',
                    'tt-validity-check-modal-view.html'
                ].join(''),
                controller: 'TTValidityCheckModal',
                controllerAs: 'TTValidityCheckModal',
                keyboard: false,
                backdrop: 'static',
                size: 'sm',
                resolve: {
                    availableDates: function() {
                        return ProjectsService.checkAvailability(
                            skuCode,
                            zipcode,
                            SettingsService.ServiceTypes.TECHTALK
                        ).then(
                            function(response) {
                                return (response && response.data) || [];
                            },
                            function(error) {
                                return [];
                            }
                        );
                    }
                }
            });

            modalInstance.opened.then(function() {
                factory.isModalOpen = true;
            });

            modalInstance.closed.then(function() {
                factory.isModalOpen = false;
            });

            return modalInstance.result;
        }
    }
    };

    return factory;
}

DateTimeValidationService.$inject = ['_', 'moment', '$uibModal', 'ProjectsService', 'SettingsService'];

/**
 * Use this service to validate Date and Time Slots
 */
(angular
    .module('RelayServicesApp.Services')
).service('DateTimeValidationService', DateTimeValidationService);
