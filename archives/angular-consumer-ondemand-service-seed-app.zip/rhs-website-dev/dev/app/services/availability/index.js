'use strict';

function availabilityService ($q, AbstractService) {
    var factory = {
        getAvailability: function(mcode, zipcode, servicetype) {
            var deferred = $q.defer(),

                config = {
                    endpoint : 'serviceability?details=false&servicecode=' + mcode + '&zipcode=' + zipcode +
                    '&servicetype=' + servicetype,
                    method: 'GET',
                    requestBody: 'form',
                    preloadInclude: true
                };

            factory
            .setConfig(config)
            .call()
            .success(function(response) {
                deferred.resolve(response);
            })
            .error(function(response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }
    };
    return angular.extend(factory, AbstractService);
}

availabilityService.$inject = ['$q', 'AbstractService'];
(angular
    .module('RelayServicesApp.Services')
).factory('availabilityService', availabilityService);
