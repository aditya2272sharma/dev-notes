'use strict';

function CookieManager($cookies, $rootScope) {

    this.setNavigationBarContactNumber = function(value) {
        var now = new Date();
        var exp = new Date(now.getTime() + (60 * 60 * 24 * 365 * 1000));
        $cookies.put('navBarContact', value, {'expires' : exp});

        $rootScope.$broadcast('contact-number-in-cookie-updated-notification', {}); // send contact number in cookie updated notification

        return this;
    };

    this.getNavigationBarContactNumber = function() {
        var navBarContactNumber = $cookies.get('navBarContact');
        return (angular.isString(navBarContactNumber) && navBarContactNumber.length > 0) ? navBarContactNumber : '1-800-497-6154';
    };
}

CookieManager.$inject = ['$cookies', '$rootScope'];

/**
 * Use this service to get information about checkout info.
 */
(angular
    .module('RelayServicesApp.Services')
).service('CookieManager', CookieManager);
