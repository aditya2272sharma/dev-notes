'use strict';

angular.module('RelayServicesApp.Services')
.service('AuthorizationService', ['CONFIGURATION', 'UtilsService', 'localStorageService',
    function(config, UtilsService, localStorageService) {

        var service,
            _sessionKey,
            _userId,
            userType;

        /**
         * Gets the session key from secured local cookie
         */
        function getSessionKey() {

            //Temporary for hardcode operations
            // if (!_sessionKey) {
            //   _sessionKey = '56af944d-0fb6-11e5-a30f-001a4a2d8d85';
            // }

            //return _sessionKey;
            return localStorageService.cookie.get('sessionKey');
        }

        /**
         * Sets the session cookie (when secured, this function can be deprecated)
         * @param {[type]} value [description]
         */
        function setSessionKey(value) {
            _sessionKey = value;
            localStorageService.cookie.set('sessionKey', value);
            return service;
        }

        /**
         * Gets the current user ID
         * @return {string} The user id
         */
        function getUserId() {
            return _userId;
        }

        /**
         * Sets the user id
         * @param {string} value The user id
         */
        function setUserId(value) {
            _userId = value;
            return service;
        }

        /**
         * Gets the user type
         * @param {string} value The user type
         */
        function setUserType(value) {
            userType = value;
            return service;
        }

        /**
         * Gets the session data
         * @return {Object} The session object
         */
        function getSession() {
            var session =
            {
                'guid' : 0,
                'emailId' : '',
                //'sessionKey' : '3cc3bf22-0459-11e5-9470-001a4a2d8d85',
                'sessionKey' : getSessionKey(),
                'userId' : getUserId(),
                'appId': config.appId
            };

            return session;
        }

        /**
         * Gets the security object
         * @return {Object} The security object
         */
        function getSecurity() {

            var today = new Date();

            var security = {
                //'src': config.appId,
                'src' : 'web',
                //yyyy-MM-dd'T'HH:mm:ss'Z'"
                'ts' : UtilsService.getISOString(today),
                'authToken' : ''
            };

            return security;
        }

        service = {
            //login: login,
            //generateGuestSALSessionId : generateGuestSALSessionId,
            //isLogged: isLogged,
            //getLoginId: getLoginId,
            //getGlobalId: getGlobalId,
            //getProfile:getProfile,
            getSession : getSession,
            getSessionKey : getSessionKey,
            getSecurity : getSecurity,
            setUserId : setUserId,
            setUserType : setUserType,
            setSessionKey : setSessionKey
        };

        return service;
    }
]);
