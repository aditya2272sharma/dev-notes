'use strict';

function ZipcodeInfoService($window, $cookies, $rootScope, locationService, SettingsService) {

    this.setZipcode = function(value, params) {
        var previousZipCode = $cookies.get('zipCode');

        if (previousZipCode) {
            previousZipCode = previousZipCode.toString();
            value = value.toString();
            if (value === previousZipCode) {
                return;
            }
        }

        var now = new Date();
        var exp = new Date(now.getTime() + (60 * 60 * 24 * 365 * 1000));
        $cookies.put('zipCode', value, {'expires' : exp});
        if(params === undefined || (angular.isObject(params) && params.checkServiceability))   
            this.validateZipcodeServiceability({'zipCode' : value});
        return this;
    };

    this.getZipcode = function() {
        return $cookies.get('zipCode');
    };

    this.validateZipcodeServiceability = function(params) {
        var zipCode = params.zipCode || $cookies.get('zipCode');
        if (angular.isString(zipCode) && zipCode.length === 5)
        {
            locationService.getServiceability(zipCode, SettingsService.ServiceTypes.STANDARDV3).then(function(response)
            {
                this.setServiceability(true);  
            }.bind(this), function(error) {
                this.setServiceability(false);
            }.bind(this));
        }
    }

    this.setServiceability = function(serviceability) {
         var now = new Date();
        var exp = new Date(now.getTime() + (60 * 60 * 24 * 365 * 1000));
        $cookies.put('isServiceAvailableForZipCode', serviceability, {'expires' : exp}); // store service is availability for zipcode in browser cookies.

        $rootScope.$broadcast('zipcode-service-updated-notification', {}); // send zipcode service updated notification
    };

    // return service ability for zipcode from browser cookies.
    this.getServiceAvailabilityForZipcode = function() {
        var isServiceAvailableForZipcodeFromCookie = $cookies.get('isServiceAvailableForZipCode');
        return ( angular.isString(isServiceAvailableForZipcodeFromCookie) && isServiceAvailableForZipcodeFromCookie === 'true' ) ? true : false;
    };
}

ZipcodeInfoService.$inject = ['$window', '$cookies', '$rootScope', 'locationService', 'SettingsService'];

/**
 * Use this service to get information about checkout info.
 */
(angular
    .module('RelayServicesApp.Services')
).service('ZipcodeInfoService', ZipcodeInfoService);
