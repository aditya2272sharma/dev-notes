'use strict';

/**
 * Preloader module
 * Include these properties within config for your service ($http) calls
 *
 * ------------------------ API ------------------------------------
 *
 * Name             | Type      | Default | Description:
 * -----------------|-----------|---------|-------------------------
 * preloadInclude   | boolean   | false   | enables preload screen
 * preloadContainer | string    | 'body'  | query selector where preloader should be prepended
 * preloadTemplate  | string    | ''      | content of the preloader (Can be HTML)
 * preloadZIndex    | number    | 1000    | Used to override default preloader z-index
 *
 * @author Andrés Zorro <andres.zorro@zemoga.com>
 * @module Preload
 */

// Module exports
angular.module('Preloader', [])
.config(['$httpProvider',
function($httpProvider) {
    var interceptor = [
        '$log',
        '$q',
        '$cacheFactory',
        '$timeout',
        'preloadProvider',
        function PreloadInterceptor ($log, $q, $cacheFactory, $timeout, preloadProvider) {
            var _totalReqs = {},
                _completedReqs = {},
                _preloaders = {};

            /**
            * Determine if the response has already been cached
            * @param  {Object}  config the config option from the request
            * @return {boolean} retrns true if cached, otherwise false
            */
            function isCached(config) {
                var defaults = $httpProvider.defaults,
                cache,
                cached;

                if (config.method !== 'GET' || config.cache === false) {
                    config.cached = false;
                    return false;
                }

                if (config.cache === true && defaults.cache === undefined) {
                    cache = $cacheFactory.get('$http');
                } else if (defaults.cache !== undefined) {
                    cache = defaults.cache;
                } else {
                    cache = config.cache;
                }

                cached = cache !== undefined ?
                cache.get(config.url) !== undefined : false;

                if (config.cached !== undefined && cached !== config.cached) {
                    return config.cached;
                }
                config.cached = cached;
                return cached;
            }

            /**
            * Check if requests are complete in given module
            * @param  {string} selector  Selector to look for preloader if complete
            * @param  {number} completed No. Of completed requests
            * @param  {number} total     No. of total requests
            */
            function checkIfComplete(selector, completed, total) {
                var preloader = _preloaders[selector];
                if (completed >= total) {
                    if (preloader) {
                        $timeout(function() {
                            preloader.remove().then(function() {
                                delete _preloaders[preloader.id];
                            });
                        });
                    }
                    _totalReqs[selector] = 0;
                    _completedReqs[selector] = 0;
                }
            }

            /**
            * Interceptor register
            */
            return {
                'request': function(config) {
                    var cntr = config.preloadContainer,
                    preloader;
                    if (config.preloadInclude && !isCached(config)) {
                        if (!_preloaders[cntr] && angular.element(cntr).length > 0) {
                            _preloaders[cntr] = preloadProvider(
                                config.preloadContainer,
                                config.preloadTemplate,
                                (config.preloadZIndex + 3000),
                                config.url
                                /* overrided to set waiter over modal popup as it z-index is very high*/
                            );
                        }

                        preloader = _preloaders[cntr];
                        if (!_totalReqs[cntr]) {
                            if (preloader) {
                                $timeout(function() {
                                    preloader.display();
                                });
                            }
                        }
                        _totalReqs[cntr] = (_totalReqs[cntr] || 0) + 1;
                    }

                    return config;
                },
                'response': function(response) {
                    var cntr = response.config.preloadContainer;
                    if (response.config.preloadInclude && !isCached(response.config)) {
                        _completedReqs[cntr] = (_completedReqs[cntr] || 0) + 1;
                        checkIfComplete(cntr, _completedReqs[cntr], _totalReqs[cntr]);
                    }

                    return response;
                },
                'responseError': function(rejection) {
                    var cntr = rejection.config.preloadContainer;
                    if (rejection.config.preloadInclude && !isCached(rejection.config)) {
                        _completedReqs[cntr] = (_completedReqs[cntr] || 0) + 1;
                        checkIfComplete(cntr, _completedReqs[cntr], _totalReqs[cntr]);
                    }

                    return $q.reject(rejection);
                }
            };
        }];

    $httpProvider.interceptors.push(interceptor);
}]);
