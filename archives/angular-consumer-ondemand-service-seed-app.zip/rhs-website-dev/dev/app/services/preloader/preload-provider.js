'use strict';

/**
 * Creates and deletes preloader screens inside containers
 *
 * @author Andrés Zorro <andres.zorro@zemoga.com>
 * @module Preload
 */

// Module exports
angular.module('Preloader')
.provider('preloadProvider', [function() {
    var _template =
        '<div class="preloader">' +
            '{{content}}' +
        '</div>',

        $ = angular.element;

    this.$get = [
        '$timeout',
        '$q',
        function($timeout, $q) {
            /**
            * Creates a preloader
            * @param  {string} selector  DOM Selector
            * @param  {string} tmpl      Template to be used
            * @param  {number} overrideZ Override default z-index
            * @return {Object}           Preloader instance
            */
            return function(selector, tmpl, overrideZ, url) {
                var template, timeout, _delay, _failsafeTimer;

                // a nominal delay beyond which we'll remove the preloader
                _delay = 30000;
                template = _template.replace(/\{\{content\}\}/gi, tmpl);

                // console.trace('Preloader: Creating new preloader...', selector);
                if (typeof selector !== 'string') {
                    throw new Error('Preload selector must be a query selector string.');
                }

                return {
                    id: selector,
                    display: function() {
                        var $item = $('body'),
                            preloader = $item.find('.preloader');

                        if (/charge|update/gi.test(url)) {
                            _delay = 18e4;
                        }

                        if (timeout) {
                            // console.trace('Preloader: Timeout cancelled from display', selector);
                            $timeout.cancel(timeout);
                        }

                        // console.trace('Preloader: Displaying...', selector);
                        console.log('Preload Provider: Preloader initiated for: ', url);

                        timeout = $timeout(function() {
                            // console.trace('Preloader: Display Timeout', selector);
                            // Append new preloader DOM element if it doesn't exists
                            if (preloader.length === 0) {
                                $item.prepend(template);
                                preloader = $item.find('.preloader');
                            }
                            preloader
                                .width($item.outerWidth())
                                .height($item.outerHeight())
                                .stop()
                                .fadeIn('fast', function() {
                                    // console.trace('Preloader: Preloader displayed', selector);
                                    preloader
                                        .css({
                                        position: 'absolute',
                                        display: 'block',
                                        'z-index': overrideZ
                                    });
                                });
                            $item.css({
                                position: $item.css('position') === 'absolute' ? 'absolute' : 'relative',
                                overflow: 'hidden'
                            });
                        });
                        _failsafeTimer = $timeout(function () {
                            var preloader = $('body').find('.preloader');
                            preloader.remove();
                            $('body').removeAttr('style');
                            throw 'Request timed out: ' + url;
                        }, _delay);
                    },
                    remove: function() {
                        var $item = $('body'),
                            preloader = $item.find('.preloader'),
                            q = $q.defer();

                        // console.trace('Preloader: Removing...', selector);

                        if (timeout) {
                            // console.trace('Preloader: Timeout cancelled from remove', selector);
                            $timeout.cancel(timeout);
                        }

                        if (_failsafeTimer) {
                            $timeout.cancel(_failsafeTimer);
                        }

                        if (preloader.length > 0) {
                            // console.trace('Preloader: Preloader exists', selector);

                            timeout = $timeout(function() {
                                // console.trace('Preloader: Remove Timeout', selector);
                                preloader.stop().fadeOut('fast', function() {
                                    // console.trace('Preloader: Preloader Removed', selector);
                                    q.resolve(true);
                                });
                                preloader.remove();
                                $item.removeAttr('style');
                            });

                        } else {
                            // console.trace('Preloader: Preloader doesnt exist', selector);
                            q.resolve(false);
                        }
                        return q.promise;
                    }
                };

            };
        }];
}]);
