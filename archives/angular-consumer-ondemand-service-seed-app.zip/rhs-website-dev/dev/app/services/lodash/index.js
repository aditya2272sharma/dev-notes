'use strict';

var _ = require('lodash');

function Lodash() {
    return _;
}

(angular
    .module('RelayServicesApp.Services')
).service('_', Lodash);
