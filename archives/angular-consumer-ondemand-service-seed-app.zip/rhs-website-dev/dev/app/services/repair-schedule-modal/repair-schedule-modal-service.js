'use strict';

/**
* Use this manager to get different operations for login
*/
angular.module('RelayServicesApp.Services').factory('RepairScheduleModalService',
    ['$rootScope', '$q', '$state', 'AbstractService', '$uibModal',
    function($rootScope, $q, $state, AbstractService, modal) {

        var factory = {

            /**
             * [signInInit description]
             * @return {[type]}           [description]
             */
            openModal : function(project, selectedFirm, callbackOnOpen, callbackOnClose) {

                var modalInstance = modal.open({
                    animation: true,
                    size: 'md',
                    controller: 'AppointmentScheduler',
                    controllerAs: 'AppointmentScheduler',
                    windowClass: 'modal-repair-schedule',
                    templateUrl: [
                        'assets/templates/pages/repair/schedule-appointment/',
                        'index.html'
                    ].join(''),
                    resolve: {
                        project: function() {
                            return project;
                        },
                        selectedFirm: function() {
                            return selectedFirm;
                        }
                    }
                });

                modalInstance.result.then(function() {
                    if (callbackOnOpen) {
                        callbackOnOpen();
                    }
                }, function(where) {
                    if (callbackOnClose) {
                        callbackOnClose();
                    }
                    switch (where) {
                        case 'home': return $state.go('home.new');
                    }
                });
                return modalInstance;
            }

        };

        //Extends factory with Abstract service
        return angular.extend(factory, AbstractService);
    }]
);
