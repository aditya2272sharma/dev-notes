'use strict';

function addressesService(_, $q, AbstractService, $filter) {
    /**
     * User Object allows to normalize data
     * @param {Object} [data={}] - The raw json response
     */
    var Address = function(data) {

        var addressline1 = data.addressLine1;
        if (!addressline1) {
            addressline1 = data.addressline1;
        }
        var addressline2 = data.addressLine2;
        if (!addressline2) {
            addressline2 = data.addressline2;
        }
        var model = {
            id: data.id || '',
            firstname: data.firstname,
            lastname: data.lastname,
            title: data.title || data.firstname + ' ' + data.lastname,
            addressline1: addressline1,
            addressline2: addressline2,
            contactNo: data.contactNo || data.phone,
            city: data.city,
            state: data.state,
            zipcode: data.zipcode || data.zipCode,
            completeAddress: [addressline1, addressline2, data.city, data.state].join(' ')
        };

        return model;
    };

    var sanitizeAddress = function(address) {
        address.addressLine1 = address.addressline1;
        address.addressLine2 = address.addressline2;
        address = _.omit(address, ['addressline1', 'addressline2']);
        address.contactNo = $filter('bcTelephone')(address.contactNo, 'clean');
        
        return address;
    };

    var factory = {
        //Expose user model
        Address: Address,
        /**
         * Gets a cards list
         * @return {Promise} A Promise containing the active user's cards list
         */
        list: function() {
            var deferred = $q.defer();
            var config = {
                endpoint : 'me/addresses',
                method: 'GET',
                preloadInclude: true,
                preloadContainer: '.address-list-container',
                preloadZIndex: 1
            };

            factory.setConfig(config);

            factory.call().success(function(response) {
                deferred.resolve(_.map(response.data, function(address) {
                    return new Address(address);
                }));
            }).error(function(response) {
                deferred.reject(response && response.error || response);
            });

            return deferred.promise;
        },
        /**
         * Inserts a card
         * @return {Promise} A Promise containing the inserted card
         */
        insert: function(card) {
            var deferred = $q.defer();
            card = sanitizeAddress(card);
            var config = {
                endpoint : 'me/addresses',
                method: 'POST',
                data: card,
                requestBody: 'form'
            };

            factory.setConfig(config);

            factory.call().success(function(response) {
                deferred.resolve(new Address(response));
            }).error(function(response) {
                deferred.reject(response);
            });

            return deferred.promise;
        },
        /**
         * Update a card
         * @return {Promise} A Promise containing the inserted card
         */
        edit: function(id, card) {
            var deferred = $q.defer();
            card = sanitizeAddress(card);
            var config = {
                endpoint : 'me/addresses/' + id,
                method: 'POST',
                data: card,
                requestBody: 'form'
            };

            factory.setConfig(config);

            factory.call().success(function(response) {
                deferred.resolve(new Address(response));
            }).error(function(response) {
                deferred.reject(response);
            });

            return deferred.promise;
        },
        /**
         * Delete a card
         * @return {Promise} A Promise containing the inserted card
         */
        remove: function(id) {
            var deferred = $q.defer();
            var config = {
                endpoint : 'me/addresses/' + id,
                method: 'DELETE',
                requestBody: 'form'
            };

            factory.setConfig(config);

            factory.call().success(function(response) {
                deferred.resolve(new Address(response));
            }).error(function(response, status, headers, config, statusText, xhrStatus) {
                var error = {
                    response: response,
                    status: status,
                    headers: headers,
                    config: config,
                    statusText: statusText,
                    xhrStatus: xhrStatus
                };
                deferred.reject(error);
            });

            return deferred.promise;
        }
    };

    // Extends factory with Abstract service
    return angular.extend(factory, AbstractService);
}

addressesService.$inject = ['_', '$q', 'AbstractService', '$filter'];

/**
 * Use this service to get information about projects' categories.
 */
(angular
    .module('RelayServicesApp.Services')
).factory('addressesService', addressesService);
