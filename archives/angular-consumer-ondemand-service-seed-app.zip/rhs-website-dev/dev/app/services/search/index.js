'use strict';

function SearchService($q, AbstractService) {

    var factory = {

        searchProByKeyAndZip: function(keyword, zipcode) {
            var deferred = $q.defer();
            var config = {
                endpoint: 'search?keyword=' + keyword + '&zipcode=' + zipcode,
                method: 'GET',
                preloadInclude: true
            };
            factory.setConfig(config)
                .call()
                .success(function(response) {
                    deferred.resolve(response);
                }).error(function(response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }

    };

    // Extends factory with Abstract service
    return angular.extend(factory, AbstractService);
}

SearchService.$inject = ['$q', 'AbstractService'];

/**
 * Use this service to get information about projects.
 */
(angular
    .module('RelayServicesApp.Services')
).factory('SearchService', SearchService);
