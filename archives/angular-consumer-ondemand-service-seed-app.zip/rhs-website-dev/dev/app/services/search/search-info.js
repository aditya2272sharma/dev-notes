'use strict';

function SearchInfoService() {
    var searchInfo;

    this.setSearchInfo = function(value) {
        searchInfo = value;
    };

    this.getSearchInfo = function() {
        var _searchInfo = searchInfo;
        searchInfo = undefined;
        return _searchInfo;
    };

    this.hasSearchInfo = function() {
        return !!searchInfo;
    };
}

SearchInfoService.$inject = ['_'];

/**
 * Use this service to get information about checkout info.
 */
(angular
    .module('RelayServicesApp.Services')
).service('SearchInfoService', SearchInfoService);
