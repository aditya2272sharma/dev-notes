'use strict';

function UploadsService(_, $q, AbstractService) {
    var factory = {
        /**
         * Uploads a file
         * @param {File} file A file to be uploaded
         * @return {Promise} A Promise containing the uploaded file url
         */
        uploadFile: function(file) {
            var config = {
                endpoint : 'uploads',
                method: 'POST',
                data: {file: file},
                preloadInclude: true
            };

            return factory.setConfig(config).upload();
        },
        /**
         * Delete a card
         * @return {Promise} A Promise containing the inserted card
         */
        DeleteImgs: function(id, projectId) {
            var deferred = $q.defer();
            var config = {
                endpoint : 'projects/' + projectId + '/images/' + id,
                method: 'DELETE',
                preloadInclude: true
            };

            factory.setConfig(config);

            factory.call().success(function(response) {
                deferred.resolve(response);
            }).error(function(response) {
                deferred.reject(response.error);
            });

            return deferred.promise;
        },

        UploadImages: function(images, projectId) {
            var config = {
                endpoint : 'projects/' + projectId + '/images',
                method: 'POST',
                data: {images: images},
                preloadInclude: true
            };

            return factory.setConfig(config).upload();
        }
    };

    // Extends factory with Abstract service
    return angular.extend(factory, AbstractService);
}

UploadsService.$inject = ['_', '$q', 'AbstractService'];

/**
 * Use this service to get information about projects' categories.
 */
(angular
    .module('RelayServicesApp.Services')
).factory('UploadsService', UploadsService);
