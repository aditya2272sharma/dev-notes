'use strict';

/**
 * Place here cons like image paths, texts, genaral info
 * @module Services
 */

angular.module('RelayServicesApp.Services')
    .service('SettingsService', [
    function SettingsService() {
        return {
            /**
            * Web site constants
            */
            AssetsPaths : {
                DEFAULT_AVATAR_IMAGE : 'assets/img/avatar_1.jpg',
                DEFAULT_PROJECT_IMAGE : 'assets/img/NewProjectImage.jpg',
                DEFAULT_PROVIDER_IMAGE : 'assets/img/provider_default.svg'
            },

            Error: {
                DEFAULT_ERROR : 'Unknown error, please try again.',
                NO_CARD_ERROR: 'Please add credit card information and try again.',
                INVALID_ADDRESS_ERROR: 'Invalid address, please try again',
                PAYMENT_ERROR: 'We are unable to process your payment at this time, please try again.',
                BILLING_ADDRESS_ERROR: 'Please enter billing address.',
                CANCEL_ERROR : 'Service already got cancelled.',
                SERVICE_UNAVAILABLE_ERROR : 'This service is currently unavailable. Please try again later.',
                CANCELLATION_ERROR : 'Not able to cancel service at this moment. Please try again.',
                NO_PROS_FOR_ZIPCODE_ERROR : 'Sorry, there are no pros available in your area, who offer the service you require.',
                SIGNUP_PASSWORD_STD_ERROR : 'Password doesn\'t meet minimum requirements, please try again.',
                ADDRESS_NOT_FOUND_FOR_ZIP: 'Address not found for zipcode',
                NO_TIME_SLOTS_AVAILABLE: 'No time slots available for this zipcode.',
                ADDRESS_DELETE_ERROR: 'Not able to delete the address at this moment. Please try again later.',
                PAYMENT_MODE_DELETE_ERROR: 'Not able to delete the address at this moment. Please try again later.',
                NON_SERVICEABLE_ZIP_CODE: 'We\'re Sorry. We currently do not have providers in your area. ' +
                    'We are coming soon so please try us again later.',
                INVALID_ZIP_CODE: 'Please enter a valid zip code.',
                NO_RESPONSE: 'We are unable to fetch the response. Please try again later.'
            },

            ServiceError: {
                INVALID_CVV : 'Gateway rejected cvv'
            },

            Success: {
                RATINGS_SUCCESS : 'Your reviews have been sent. Thank You!',
                CONTACT_US_SUCCESS : 'Your inquiry has been sent. Thank you!',
                // BOOK_A_PRO_SUCCESS : 'You have successfully registered as a PRO. Thank you!',
                BOOK_A_PRO_SUCCESS : 'Thank you for your submission to become a ServiceLive pro. We are actively seeking qualified professionals and will reach out to you soon!',
                PRO_REGISTER_SUBMITTED: 'Thank you. Our team will get in touch with you shortly.'
            },

            ProjetStatus: {
                PROJECT_ACCEPTED : 'ACCEPTED',
                PROJECT_REJECTED : 'REJECTED',
                PROJECT_DECLINED : 'DECLINED',
                PROJECT_FIXED : 'FIXED',
                PROJECT_NEW : 'NEW',
                PROJECT_CANCELLED : 'CANCELLED',
                PROJECT_WAITING : 'WAITING',
                PROJECT_COMPLETE : 'COMPLETE',
                COMPLETE_PENDING_CLAIM : 'COMPLETE_PENDING_CLAIM',
                PROJECT_COMPLETE_FAIL : 'COMPLETE_FAIL',
                ESTIMATE_ACCEPTED : 'ESTIMATE_ACCEPTED',
                RESCHEDULE_INITIATED : 'RESCHEDULE_INITIATED',
                RESCHEDULE_CANCELLED : 'RESCHEDULE_CANCELLED',
                RESCHEDULE_INITIATED_BY_PROVIDER : 'RESCHEDULE_INITIATED_BY_PROVIDER',
                PROJECT_EXPIRED : 'EXPIRED',
                PROJECT_CONFIRMED : 'CONFIRMED',
                PROJECT_UPCOMING : 'UPCOMING',
                ESTIMATE_RECEIVED : 'ESTIMATE_RECEIVED',
                ESTIMATE_UPDATED : 'ESTIMATE_UPDATED',
                ESTIMATE_REJECTED : 'ESTIMATE_REJECTED',
                PROVIDER_CHECK_IN : 'PROVIDER_CHECK_IN',
                PROVIDER_REVISIT_NEEDED : 'PROVIDER_REVISIT_NEEDED',
                PROVIDER_CHECK_IN_ESTIMATE_UPDATED: 'UPDATED',
            },

            ProjectStatusMessages: {
                WAITING: 'Waiting for estimates',
                CONFIRMED: 'Confirmed',
                CANCELLED: 'Cancelled',
                ESTIMATE_RECEIVED: 'New estimate received',
                COMPLETE: 'Completed',
                COMPLETE_PENDING_CLAIM: 'Complete Pending Claim',
                ESTIMATE_UPDATED: 'Estimate Updated',
                ESTIMATE_ACCEPTED: 'Estimate Accepted',
                RESCHEDULE_INITIATED: 'Reschedule Initiated by Customer',
                RESCHEDULE_CANCELLED: 'Reschedule Request Cancelled By Consumer',
                RESCHEDULE_INITIATED_BY_PROVIDER: 'Reschedule Initiated By Provider',
                EXPIRED: 'Expired',
                ESTIMATE_REJECTED: 'Estimate Rejected',
                PROVIDER_CHECK_IN: 'Provider Checked In',
                PROVIDER_REVISIT_NEEDED: 'Order Revisit Needed By Provider'
            },

            ServiceTypes: {
                STANDARD : 'STANDARD',
                STANDARD_FIXED_PRICE: 'STANDARD_FIXED_PRICE',
                NON_STANDARD : 'NON_STANDARD',
                REPAIR : 'REPAIR',
                STANDARDV3: 'STANDARD_V3',
                TECHTALK: 'TECH_TALK'
            },

            URLS: {
                SEARS_HOME_MAINTAIN_PAGE_URL : 'https://www.searshomeservices.com/scheduler/partners/relay/maintain',
                SEARS_HOME_REPAIR_PAGE_URL : 'https://www.searshomeservices.com/scheduler/partners/relay/repair',
                SEARS_TERMS_OF_USE_URL : 'http://www.sears.com/en_us/customer-service/policies/terms-of-use.html',
                SEARS_PRIVACY_POLICY_URL : 'http://www.sears.com/en_us/customer-service/policies/privacy-policy.html',
                SYW_PROGRAM_TERMS_URL : 'https://www.shopyourway.com/help/policies/about-shop-your-way'
            },

            EstimateSummary: {
                COMPUTER_GENERATED_PAGE_TXT : 'This is a computer/electronically generated ' +
                    'invoice and does not require signature.'
            },

            EstimateRejectDropdownOptions: [
                {
                    Label: 'Reject this estimate',
                    Value: 'Reject'
                },
                {
                    Label: 'Reject this estimate and cancel the order',
                    Value: 'Cancel'
                },
                {
                    Label: 'Reject this estimate, cancel the order and create a new project',
                    Value: 'Create'
                }
            ],
            EstimateRejectOptions: {
                REJECT: 'Reject',
                CANCEL: 'Cancel',
                CREATE: 'Create'
            },

            RescheduleRejectDropdownOptions: [{
                Label: 'Reject',
                Action: 'Reject'
            }, {
                Label: 'Propose New Appointment',
                Action: 'Propose'
            }],

            Keys: {
                RECAPTCHA_API_KEY:'6LeIxAcTAAAAAJcZVRqyHh71UMIEGNQ_MXjiZKhI', // Google's dummy key for signin
                // RECAPTCHA_API_KEY: '6LdvH1IUAAAAADOWX-Q-RO_7Fn5dcU-3AUf4Gb1S', // whitelisted key provided by security team
                RECAPTCHA_PROD_API_KEY : '6LcnvA4TAAAAACKCimngB1b_MGBJ48qjtaErqqkd'
            },

            Templates: {
            },

            DateTime : {
                MonthNamesArray : ['January', 'February', 'March', 'April', 'May', 'June',
                                   'July', 'August', 'September', 'October', 'November', 'December'],
                TimeRanges : [{label:'8am - 12pm', value:'8:00 AM - 12:00 PM'},
                              {label: '12pm - 4pm', value:'12:00 PM - 4:00 PM'},
                              {label: '4pm - 8pm', value:'4:00 PM - 8:00 PM'}]
            },
            Countries: {
                AMERICA: 'US'
            },
            APIConstants: {
                ACCEPT: 'Accept'
            },
            BreadCrumbSection: {
                ACCOUNT: 'account',
                REPAIR: 'repair'
            },
            Constants: {
                NO_HOURLY_RATE_FOUND : 'No Rate Found',
                HOURLY_RATE_LABEL : 'Hourly Rate: '
            },
            RegEx: {
                CURRENCY_DOLLAR : /[$,]+/g,
                HTML_TAGS: /<[^>]+>/gm
            },

            ProjectMinStatus: {
                PROJECT_CREATED : {
                    eventId : 'project_created',
                    desc : 'We have submitted your {0} request {1} {2}. We will get back to you soon.'
                },
                ESTIMATE_RECEIVED : {
                    eventId : 'hook_order_estimate_added_by_provider',
                    desc : 'Your provider {0} has reverted back with an estimate of {1}.'
                },
                AUTHORIZE_PAYMENT : {
                    eventId : 'order_authorize_payment',
                    desc : 'Your payment has been authorized.'
                },
                ORDER_UPDATED : {
                    eventId : 'order_updated',
                    desc : 'The order has been updated.'
                },
                ESTIMATE_ACCEPTED : {
                    eventId : 'project_estimate_accepted',
                    desc : 'You have accepted the estimate of {0}.'
                },
                ESTIMATE_CONFIRMED : {
                    eventId : 'project_estimate_confirmed',
                    desc : 'Estimate has been confirmed.'
                },
                ESTIMATE_REJECTED : {
                    eventId : 'project_estimate_rejected',
                    desc : 'The estimate has been rejected.'
                },
                ORDER_CREATED : {
                    eventId : 'order_created',
                    desc : 'Your Order has been created.'
                },
                PROJECT_CONFIRMED : {
                    eventId : 'project_confirmed',
                    desc : 'Service request & schedule have been shared with {0}.'
                },
                PROCESS_PAYMENT : {
                    eventId : 'order_process_payment',
                    desc : 'Your payment has been processed.'
                },
                RESCHEDULE_INITIATED : {
                    eventId : 'project_reschedule_initiated',
                    desc : 'We are reviewing your request to reschedule your appointment to {0} ' +
                    'and will respond within 24-hours. Thank you!'
                },
                RESCHEDULE_CANCELLED : {
                    eventId : 'project_reschedule_cancelled',
                    desc : 'You requested cancellation of reschedule request'
                },
                RESCHEDULE_INITIATED_PRO : {
                    eventId : 'hook_order_reschedule_initiated_by_provider',
                    desc : 'Provider initiated a reschedule, kindly review details.'
                },
                PROJECT_CLOSED : {
                    eventId : 'project_closed',
                    desc : 'The project is closed'
                },
                PROJECT_CANCELLED : {
                    eventId : 'project_cancelled',
                    desc : 'The project is cancelled'
                },
                ORDER_COMPLETED : {
                    eventId : 'hook_order_completed_by_provider',
                    desc : 'Your order has been completed by {0}'
                },
                ESTIMATE_UPDATED : {
                    eventId : 'hook_order_estimate_updated_by_provider',
                    desc : 'Your provider {0} has updated the estimate from {1} to {2}.'
                },
                ESTIMATE_UPDATED_PRICE : {
                    eventId : 'hook_order_estimate_price_updated_by_provider',
                    desc : 'Your provider {0} has updated the estimate from {1} to {2}.'
                },
                ESTIMATE_UPDATED_DETAILS : {
                    eventId : 'hook_order_estimate_details_updated_by_provider',
                    desc : 'Your provider {0} has updated the estimate.'
                },
                RESCHEDULE_ACCEPTED_PRO : {
                    eventId : 'hook_order_reschedule_accepted_by_provider',
                    desc : 'Provider accepted your reschedule.'
                },
                RESCHEDULE_REJECTED_PRO : {
                    eventId : 'hook_order_reschedule_rejected_by_provider',
                    desc : 'Provider rejected your reschedule.'
                },
                RESCHEDULE_CANCELLED_PRO : {
                    eventId : 'hook_order_reschedule_cancelled_by_provider',
                    desc : 'Provider cancelled reschedule initiated.'
                },
                RESCHEDULE_REJECTED : {
                    eventId : 'project_reschedule_rejected',
                    desc : 'You have rejected the reschedule request.'
                },
                RESCHEDULE_ACCEPTED : {
                    eventId : 'project_reschedule_accepted',
                    desc : 'You have accepted the reschedule request.'
                },
                ORDER_EXPIRED : {
                    eventId : 'hook_order_expired',
                    desc : 'The project is expired.'
                },
                ORDER_REJECTED_BY_FIRM : {
                    eventId : 'hook_order_rejected_by_firm',
                    desc : 'The order is rejected by firm.'
                },
                ORDER_RELEASED_BY_FIRM : {
                    eventId : 'hook_order_released_by_firm',
                    desc : 'The order was released by {0}.'
                },
                ORDER_ACCEPTED_BY_PROVIDER : {
                    eventId : 'hook_order_accepted_by_provider',
                    desc : 'The order has been accepted by {0}.'
                },
                ORDER_REVISIT_NEEDED_BY_PROVIDER : {
                    eventId : 'hook_order_revisit_needed_by_provider',
                    desc : 'Provider has indicated that a revisit is needed. Revisit is scheduled on {0}.'
                },
                ORDER_REPOSTED_TO_NEW_FIRM : {
                   eventId : 'hook_order_reposted_to_new_firm',
                   desc : 'The order is reposted to {0}.'
               },
                PROVIDER_CHECKED_IN : {
                    eventId : 'hook_order_checked_in_by_provider',
                    desc : 'The order is checked in by Provider.'
                },
                PROVIDER_CANCELLED_PROJECT : {
                    eventId : 'hook_order_cancellation_requested_by_provider',
                    desc : 'The project is cancelled by the Provider.'
                }
            },
            ProjectMinActions : {
                ACCEPT_ESTIMATE : 'ACCEPT_ESTIMATE',
                REJECT_ESTIMATE : 'REJECT_ESTIMATE',
                VIEW_ESTIMATE : 'VIEW_ESTIMATE',
                BOOK_PRO : 'BOOK',
                ACCEPT_RESCHEDULE : 'ACCEPT_RESCHEDULE_REQUEST',
                REJECT_RESCHEDULE : 'REJECT_RESCHEDULE_REQUEST',
                NEW_APPOINTMENT : 'NEW_APPOINTMENT',
                VIEW_INVOICE : 'VIEW_INVOICE',
                SHOW_AVAILABLE_PROS: 'SHOW_AVAILABLE_PROS'
            },
            SearchKeysList : [
            {
                name: 'Pitched roof bedroom',
                isCustom: true
            },
            {
                name: 'Wells kitchen sinks',
                isCustom: true
            },
            {
                name: 'How to paint concrete patio floor',
                isCustom: true
            },
            {
                name: 'Milestone kitchen and bath',
                isCustom: true
            },
            {
                name: 'How to fit a wall hung basin',
                isCustom: true
            },
            {
                name: 'Cabinets design',
                isCustom: true
            },
            {
                name: 'Cordless drill not working',
                isCustom: true
            },
            {
                name: 'Brick fireplaces for wood burning stoves',
                isCustom: true
            },
            {
                name: 'Home services blinds',
                isCustom: true
            },
            {
                name: 'Home services cleaning',
                isCustom: true
            },
            {
                name: 'Home services drywall',
                isCustom: true
            },
            {
                name: 'Home services furniture assembly',
                isCustom: true
            },
            {
                name: 'Home services grill',
                isCustom: true
            },
            {
                name: 'Home services handyman',
                isCustom: true
            },
            {
                name: 'Home services lawn',
                isCustom: true
            },
            {
                name: 'Home services moving',
                isCustom: true
            },
            {
                name: 'Home services organizer',
                isCustom: true
            },
            {
                name: 'Home services painting',
                isCustom: true
            },
            {
                name: 'Home services yard',
                isCustom: true
            },
            {
                name: 'Home services dishwasher',
                isCustom: true
            },
            {
                name: 'Home services estimates',
                isCustom: true
            },
            {
                name: 'Home services flooring',
                isCustom: true
            },
            {
                name: 'Home services garage',
                isCustom: true
            },
            {
                name: 'Home services kitchen',
                isCustom: true
            },
            {
                name: 'Home services locksmith',
                isCustom: true
            },
            {
                name: 'Home services masonry',
                isCustom: true
            },
            {
                name: 'Home services roofing',
                isCustom: true
            },
            {
                name: 'Home services tree removal',
                isCustom: true
            },
            {
                name: 'Home services wall hanging',
                isCustom: true
            },
            {
                name: 'Home services assembly',
                isCustom: true
            },
            {
                name: 'Home services carpet cleaning',
                isCustom: true
            },
            {
                name: 'Home services drywall door installation',
                isCustom: true
            },
            {
                name: 'Home services exterminator',
                isCustom: true
            },
            {
                name: 'Home services furniture',
                isCustom: true
            },
            {
                name: 'Home services house cleaning',
                isCustom: true
            },
            {
                name: 'Home services landscaping',
                isCustom: true
            },
            {
                name: 'Home services marble flooring',
                isCustom: true
            },
            {
                name: 'Home services play set assembly',
                isCustom: true
            },
            {
                name: 'Home services request',
                isCustom: true
            },
            {
                name: 'Home services staging',
                isCustom: true
            },
            {
                name: 'Home services tag',
                isCustom: true
            },
            {
                name: 'Home services window repair',
                isCustom: true
            },
            {
                name: 'Home services pest control',
                isCustom: true
            },
            {
                name: 'Home services pest control',
                isCustom: true
            },
            {
                name: 'Home services mattress removal',
                isCustom: true
            },
            {
                name: 'Home services windows',
                isCustom: true
            },
            {
                name: 'Home services carpet installation',
                isCustom: true
            },
            {
                name: 'Home services faqs',
                isCustom: true
            },
            {
                name: 'Home services tree',
                isCustom: true
            },
            {
                name: 'Home services auto',
                isCustom: true
            },
            {
                name: 'Home services lawn care',
                isCustom: true
            },
            {
                name: 'Home services deck',
                isCustom: true
            },
            {
                name: 'Home services Seattle',
                isCustom: true
            },
            {
                name: 'Home services mulch',
                isCustom: true
            },
            {
                name: 'Home services contractor',
                isCustom: true
            },
            {
                name: 'Home services picture hanging',
                isCustom: true
            },
            {
                name: 'Home services laundry',
                isCustom: true
            },
            {
                name: 'Home services trash removal',
                isCustom: true
            },
            {
                name: 'Home services wood floors',
                isCustom: true
            },
            {
                name: 'Home services critter',
                isCustom: true
            },
            {
                name: 'Home services tree trimming',
                isCustom: true
            },
            {
                name: 'Home services arborist',
                isCustom: true
            },
            {
                name: 'Home services caulk',
                isCustom: true
            },
            {
                name: 'Home services trampoline assembly',
                isCustom: true
            },
            {
                name: 'Home services pest',
                isCustom: true
            },
            {
                name: 'Home services pool',
                isCustom: true
            },
            {
                name: 'Home services closet',
                isCustom: true
            },
            {
                name: 'Home services tile',
                isCustom: true
            }],

            DeleteAdress: {
                CONFIRMATION_MESSAGE: 'Are you sure you want to permanently delete this address?'
            },

            FormValidation: {
                'ADDRESS_LINE_1_REQUIRED': 'Address Line 1 is required',
                'BUSINESS_NAME_REQUIRED': 'Business Name is required',
                'CARD_NUMBER_INVALID': 'Invalid card number',
                'CARD_NUMBER_REQUIRED': 'Card Number is required',
                'CVV_INVALID': 'CVV/CVV2 invalid',
                'CVV_REQUIRED': 'CVV/CVV2 is required',
                'EXPIRY_DATE_INVALID': 'Invalid expiration date',
                'FIRST_NAME_REQUIRED': 'First Name is required',
                'LAST_NAME_REQUIRED': 'Last Name is required',
                'NAME_ON_CARD_REQUIRED': 'Name on Card is required',
                'PHONE_NUMBER_REQUIRED': 'Please enter your phone number',
                'PHONE_NUMBER_SIZE': 'Your phone number must have 10 digits',
                'SERVICE_REQUIRED': 'Service is required',
                'ZIPCODE_REQUIRED': 'Please enter a valid zipcode',
            },

            CancelServiceMessages: {
                'UNDER_PROCESS': 'Your order is being processed',
                'PROCESS_CANCELLED': 'Your service has been cancelled',
                'NO_EXTRA_CANCELLATION_FEE': 'Should you need to cancel your order there will be no fee.',
            },

            Messages: {
                DISCLAIMER: 'ServiceLive is not an employer, but simply connects' +
                ' independent service professionals with customers.',
                DELETE_ADDRESS_CONFIRMATION_MESSAGE: 'Are you sure you want to permanently delete this address?',
                DELETE_PAYMENT_MODE_CONFIRMATION_MESSAGE: 'Are you sure you want to permanently delete this payment mode?',
                LOADING: 'Loading...',
                NO_PROJECTS_CREATED: 'You have not created any projects yet.' +
                ' To create one, please click on the See All Services' +
                ' or Create a Custom Project button.',
                REJECT_RESCHEDULE_CONFIRMATION: 'You\'re about to Reject this Rescheduling Request',
                TT_SCHEDULE_SELECTED: 'A technician will call you $DATE_SELECTED between <b>$TIME_SELECTED</b>.' +
                '<br />Your appointment must be confirmed at least 15 minutes before the start time.'
            },

            AppliaceTypes: [
                {label: 'Free Standing', value: 'free standing'},
                {label: 'Built In', value: 'builtin'}
            ]
        };
    }]);
