'use strict';

angular.module('RelayServicesApp.Services').factory('repairProductModalService',
    ['$rootScope', '$q', '$state', 'AbstractService', '$uibModal', '$window',
    function($rootScope, $q, $state, AbstractService, modal, $window) {
        var factory = {
            openModal : function(productDetails, selectedProduct) {
                var modalInstance = modal.open({
                    animation: true,
                    size: 'md',
                    controller: 'RepairProductController',
                    controllerAs: 'RepairProductController',
                    windowClass: 'modal-repair-product',
                    templateUrl: [
                        'assets/templates/pages/repair/repair-product/index.html'
                    ].join(''),
                    resolve: {
                        productDetails: function() {
                            return productDetails;
                        },
                        selectedProduct: function() {
                            return selectedProduct;
                        }
                    }
                });
                modalInstance.result.then(function() {
                    $window.location.reload();
                });
                return modalInstance;
            }
        };
        return angular.extend(factory, AbstractService);
    }]
);
