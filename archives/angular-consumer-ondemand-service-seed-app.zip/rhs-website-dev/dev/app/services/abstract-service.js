'use strict';

angular.module('RelayServicesApp.Services')
    .service('AbstractService', ['$location', '$log', '$http',
    'Upload', 'CONFIGURATION', 'ENVIRONMENT', '_',
    function($location, $log, $http, Upload, Config, Env, _) {

        return {

            /**
             * Enum for error type values.
             * @readonly
             * @enum {string}
             */
            ResponseStatusFlag: {
                SUCCESS : 'SUCCESS',
                ERROR : 'ERROR'
            },

            /**
             * Assign configuration
             * @param {Object} config The configuration object
             */
            setConfig: function(config) {
                this.config = config;
                return this;
            },

            /**
             * Sets local flag indicating is a local API request. i.e mockup
             * @param {boolean} isLocal Is local request i.e dummy data
             */
            setLocal: function(isLocal) {
                this.isLocal = isLocal;
            },

            /**
             * Sets the API protocol i.e http or https
             * @param {string} protocol The protocol string
             */
            setProtocol: function(protocol) {
                this.protocol = protocol;
            },

            /**
             * Sets the API domain
             * @param {string} domain The domain string
             */
            setDomain: function(domain) {
                this.domain = domain;
            },

            /**
             * Sets the API port
             * @param {string} port The port i.e 9000 parr empty string if no port
             */
            setPort: function(port) {
                this.port = port;
            },

            /**
             * Sets the API context path
             * @param {string} context The context portion of the API path
             */
            setContext: function(context) {
                this.context = context;
            },

            /**
             * Gets the context API path
             * @return {string} The context portion of the API path
             */
            getContext: function() {
                return this.context ? this.context : Env.api.context;
            },

            /**
             * Sets the CMS API context path
             * @param {string} context [description]
             */
            setCmsContext: function(context) {
                this.context = context;
            },

            /**
             * Gets the CMS API context path
             * @return {string} The CMS API context path
             */
            getCmsContext: function() {
                return this.context ? this.context : Env.cms.context;
            },

            /**
             * Gets the API domain
             * @return {string} The API domain string
             */
            getDomain: function() {
                return this.domain ? this.domain : Env.name === 'prod' ? $location.host() : Env.api.domain;
            },

            /**
             * Getss the API protocol
             * @return {string} The protocol string
             */
            getProtocol: function() {
                //return this.protocol ? this.protocol : Env.api.protocol;
                //This needed to be changed to current protocl as APP needs to work in both http and https protocols!!!
                //Remove protocol from config
                return this.protocol || $location.protocol();
            },

            /**
             * Gets the API port
             * @return {string} The API port string
             */
            getPort: function() {
                return this.port ? this.port : Env.api.port;
            },

            /**
             * Sets the store ID
             * @param {string} storeId The store ID
             */
            setStoreId: function(storeId) {
                this.storeId = storeId;
            },

            /**
             * Sets the store unit number
             * @param {string} unitNumber The store unit number
             */
            setUnitNumber: function(unitNumber) {
                this.unitNumber = unitNumber;
            },

            /**
             * Calls the service and logs response or error
             * @return {Object} promise
             */
            callLogged: function() {
                var args = _.toArray(arguments);

                return this.call.apply(this, args)
                .then(function(res) {
                    $log.debug('SERVICE LOG: %o', res);
                    return res;
                })
                ['catch'](function(err) {
                    $log.debug('SERVICE ERROR: %o', err);
                    return err;
                });
            },

            /**
             * Returns the actual API endpoint
             */
            getBaseUrl: function() {
                var url = '';
                var isLocal = this.config.local;
                var isCms = this.config.cms || false;

                if (!isLocal) {
                    url = this.getProtocol() + '://' + this.getDomain() + ':' + this.getPort() + '/' + this.getContext();
                    //url = this.getProtocol() + '://' + this.getDomain() +  '/' + this.getContext();
                    if (isCms) {
                        url = this.getProtocol() + '://' + this.getDomain() +  '/' + this.getCmsContext();
                    }
                }

                return url + this.config.endpoint;
            },

            /**
             * Makes an HTTP request, uploading a file
             * @return {Promise} A promise containing the response of the upload
             * request
             */
            upload: function() {
                return Upload.upload({
                    url: this.getBaseUrl(),
                    withCredentials: true,
                    data: this.config.data
                });
            },

            /**
            * Calls the REST API
            * @return {Object} The promise containing the response
            */
            call: function() {

                var reqConfig;
                var url = this.getBaseUrl();

                reqConfig = {
                    method: this.config.method || 'GET',
                    cache: this.config.cache || false,
                    url: url
                };

                //temporary session key while login is defined

                if (angular.isDefined(this.config.params)) {
                    reqConfig.params = this.config.params;
                }

                if (angular.isDefined(this.config.withCredentials)) {
                    reqConfig.withCredentials = this.config.withCredentials;
                } else {
                    //_.noop();
                    //Default credentials set to true
                    reqConfig.withCredentials = true;
                }
                if (angular.isDefined(this.config.data)) {
                    reqConfig.data = this.config.data;
                }

                if (angular.isDefined(this.config.headers)) {
                    reqConfig.headers = this.config.headers;
                }

                if (angular.isDefined(this.config.timeout)) {
                    reqConfig.timeout = this.config.timeout;
                }

                //If type is passed as form, send params as x-www-form-urlencoded
                if (angular.isDefined(this.config.requestBody) && this.config.requestBody === 'form') {
                    var currentHeaders = reqConfig.headers || {};
                    currentHeaders['Content-Type'] = 'application/x-www-form-urlencoded';

                    reqConfig.headers = currentHeaders;

                    reqConfig.transformRequest = function(obj) {
                        var str = [];
                        for (var p in obj) {
                            str.push(encodeURIComponent(p) + '=' + encodeURIComponent(obj[p]));
                        }
                        return str.join('&');
                    };
                }

                // Preload configuration (please override locally in each call)
                reqConfig.preloadInclude = this.config.preloadInclude || false;
                reqConfig.preloadContainer = this.config.preloadContainer || 'body';
                reqConfig.preloadTemplate = this.config.preloadTemplate || '';
                reqConfig.preloadZIndex = this.config.preloadZIndex || 9;
                // reqConfig.preloadLatency = this.config.preloadLatency || 500;

                $log.debug('Request from Abstract Service' + JSON.stringify(reqConfig));
                return $http(reqConfig);
            }
        };
    }]);
