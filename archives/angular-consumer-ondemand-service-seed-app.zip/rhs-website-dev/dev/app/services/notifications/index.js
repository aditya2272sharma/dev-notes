'use strict';

function Notifications(_, moment, $q, AbstractService) {

    /**
     * Notifications model
     * @param {Object} data Raw json
     */
    var UserNotifications = function(data) {
        var model = data;
        _.forEach(model.data, function(item) {
            // if (item.event === 'CREATE_PROJECT') {
            //     item.eventName = 'Create Project';
            // }
            //item.eventName = _.capitalize(_.replace(item.type, '_', ' '));
            item.eventName = item.name;
            item.date = moment(item.receivedOn).fromNow();
        });

        return model;
    };

    var factory = {
        /**
         * Gets provider by id
         * @return {Promise} A Promise containing the provider info.
         */
        getNotificationsByUser: function(page) {
            var pageNumber = page || 1;
            var deferred = $q.defer();
            var config = {
                endpoint : 'notifications?pageNo=' + pageNumber,
                method: 'GET'
            };

            factory
            .setConfig(config)
            .call()
            .success(function(response) {
                deferred.resolve(new UserNotifications(response));
            }).error(function(response) {
                deferred.reject(response);
            });

            return deferred.promise;
        },
        unread: function() {
            var deferred = $q.defer();
            var config = {
                endpoint : 'notifications/unread',
                method: 'GET'
            };

            factory
            .setConfig(config)
            .call()
            .success(function(response) {
                deferred.resolve(new UserNotifications(response));
            }).error(function(response) {
                deferred.reject(response);
            });

            return deferred.promise;
        },
        readNotification: function(notificationId) {
            var deferred = $q.defer();
            var config = {
                endpoint : 'notifications/' + notificationId,
                method: 'POST'
            };

            factory
            .setConfig(config)
            .call()
            .success(function(response) {
                deferred.resolve(response);
            }).error(function(response) {
                deferred.reject(response);
            });

            return deferred.promise;
        },
        getNotificationsSummary: function() {
            var deferred = $q.defer();
            var config = {
                endpoint : 'notifications/summary',
                method: 'GET'
            };

            factory
            .setConfig(config)
            .call()
            .success(function(response) {
                deferred.resolve((response));
            }).error(function(response) {
                deferred.reject(response);
            });

            return deferred.promise;
        }
    };

    // Extends factory with Abstract service
    return angular.extend(factory, AbstractService);
}

Notifications.$inject = ['_', 'moment', '$q', 'AbstractService'];

(angular
    .module('RelayServicesApp.Services')
).service('Notifications', Notifications);
