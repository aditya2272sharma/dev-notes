'use strict';

angular.module('RelayServicesApp.Services').factory('SelectCategoryModalService',
    ['$rootScope', '$q', '$state', 'AbstractService', '$uibModal',
    function($rootScope, $q, $state, AbstractService, modal) {

        var factory = {

            openModal : function(catalogs, createProject, callbackOnOpen, callbackOnClose) {
                var modalInstance = modal.open({
                    animation: true,
                    size: 'md',
                    controller: 'SelectCategoryModalCtrl',
                    controllerAs: 'SelectCategoryModalCtrl',
                    windowClass: 'modal-select-category',
                    templateUrl: [
                        'assets/templates/pages/search/select-category-modal/',
                        'index.html'
                    ].join(''),
                    resolve: {
                        catalogs: function() {
                            return catalogs;
                        },
                        createProject: function() {
                            return createProject;
                        }
                    }
                });
                modalInstance.result.then(function() {
                    if (callbackOnOpen) {
                        callbackOnOpen();
                    }
                }, function() {
                    if (callbackOnClose) {
                        callbackOnClose();
                    }
                });
                return modalInstance;
            }

        };

        //Extends factory with Abstract service
        return angular.extend(factory, AbstractService);
    }]
);
