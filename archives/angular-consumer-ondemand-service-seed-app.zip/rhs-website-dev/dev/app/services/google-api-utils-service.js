'use strict';

function googleApiUtilsService($http, $q, _) {
    var that = {
        baseUrl: 'https://maps.googleapis.com/maps/api/',
        baseUrlCurrentPosition: 'https://www.googleapis.com/geolocation/v1/geolocate',
        endpoint: 'geocode/json?latlng=',
        postalCodeEndpoint: 'geocode/json?components=postal_code:',
        params: '&sensor=true',
        key: 'AIzaSyCs7-KxOOm-G6Kz3pTZjVaODb_L9QldEZQ',

        googleParameters: {
            addressComponents: 'address_components',
            shortName: 'short_name',
            formattedAddress: 'formatted_address'
        },

        getCurrentPositionEndpoint: function() {
            return that.baseUrlCurrentPosition + '?key=' + that.key;
        },

        getCurrentPosition: function() {
            return $q(function(resolve, reject) {
                var endpoint = that.getCurrentPositionEndpoint();
                $http.post(endpoint)
                    .then(function(response) {
                        resolve(response.data.location);
                    }, function(response) {
                        reject(response);
                    });
            });
        },

        getGeocodeEndpoint: function(lat, long) {
            return that.baseUrl + that.endpoint + lat + ',' + long + that.params;
        },

        getPostalCodeEndpoint: function(postalcode) {
            return that.baseUrl + that.postalCodeEndpoint + postalcode + that.params + '&key=' + that.key;
        },

        getFinalAddress: function(geoParts) {
            var placeParts = geoParts[that.googleParameters.addressComponents],
                finalAddress = {
                    'firstLoad': false
                },
                acceptableTypes = {
                    'street_number': 'streetNumber',
                    'route': 'street',
                    'locality': 'city',
                    'administrative_area_level_1': 'state',
                    'postal_code': 'zipcode'
                };

            if(angular.isArray(placeParts))
            {
                _.forEach(placeParts, function(item) {
                    var type = _.first(item.types);
                    var key = acceptableTypes[type];

                    if (key) {
                        finalAddress[key] = item[that.googleParameters.shortName];
                    }
                });
            }

            return finalAddress;
        },

        getAddressByLatLong: function(lat, long) {
            return $q(function(resolve, reject) {
                $http
                    .get(that.getGeocodeEndpoint(lat, long))
                    .then(function(response) {
                        var address = _.first(response.data.results);
                        if(angular.isObject(address))
                        {
                            var finalAddress = that.getFinalAddress(address);

                            resolve({
                                address: address[that.googleParameters.formattedAddress],
                                finalAddress: finalAddress
                            });
                        }
                        else
                        {
                            resolve({});
                        }
                    }, function(response) {
                        reject(response);
                    });
            });
        },

        getAddressByPostalCode: function(postalCode) {
            return $q(function(resolve, reject) {
                $http
                    .get(that.getPostalCodeEndpoint(postalCode))
                    .then(function(response) {
                        var address = _.first(response.data.results);
                        if(angular.isObject(address))
                        {
                            var finalAddress = that.getFinalAddress(address);

                            resolve({
                                address: address[that.googleParameters.formattedAddress],
                                finalAddress: finalAddress
                            });
                        }
                        else
                        {
                            resolve({});
                        }

                    }, function(response) {
                        reject(response);
                    });
            });
        }
    };

    return that;
}

googleApiUtilsService.$inject = ['$http', '$q', '_'];

angular
    .module('RelayServicesApp.Services')
    .service('googleApiUtilsService', googleApiUtilsService);
