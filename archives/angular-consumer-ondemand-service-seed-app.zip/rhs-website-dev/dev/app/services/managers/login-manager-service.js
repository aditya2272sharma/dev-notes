'use strict';

/**
* Use this manager to get different operations for login
*/
angular.module('RelayServicesApp.Services').factory('LoginManagerService',
    ['$rootScope', '$q', '$state', 'AbstractService', '$uibModal',
    function($rootScope, $q, $state, AbstractService, $uibModal) {

        /**
         * User Object allows to normalize data
         * @param {Object} [data={}] - The raw json response
         */
        var User = function(data) {
            //Defaults
            var model = {
                isRegistered: false,
                firstName: '',
                lastName: '',
                profileImage: ''
            };

            if (data && data.email) {
                model.isRegistered = true;
                model.firstName = data.firstName;
                model.lastName = data.lastName;
                model.email = data.email;
                model.contact = data.contact;
                model.profileImage = data.profileImageSrc;
                model.isAnonymous = false;
                model.isGuest = data.isGuest || (data.salSessionId === null && data.userType !== 'SAL_USER') || false;
            }
            if (data && (data.userType !== 'SAL_USER' && (data.isGuest || data.salSessionId === null))) {
                model.isRegistered = false;
                model.isAnonymous = true;
            }
            return model;
        };

        //_user is an intrnal var to cache user, so you can get the current user info at any moment
        //You can get cached user by using LoginManagerService.getUser()
        var _user = new User();

        var factory = {

            //Expose user model
            User: User,

            /**
             * Logins the user
             * @param  {Object} loginData Contains username and password properties
             * @return {Object}           Promise with reponse data
             */
            login : function(loginData) {

                var deferred = $q.defer(),

                    config = {
                        //http://relay-homeservices-1892420759.us-east-1.elb.amazonaws.com/api/v1/login
                        endpoint : 'login',
                        method: 'POST',
                        data : loginData,
                        requestBody: 'form'
                    };

                factory.setConfig(config);
                factory.call()
                .success(function(response) {
                    var userData = {
                        firstName: response.firstName,
                        lastName: response.lastName,
                        userType: response.userType,
                        email: response.email,
                        contact: response.contact,
                        salSessionId: response.salSessionId,
                        profileImageSrc: response.profileImageSrc
                    };
                    _user = new User(userData);
                    $rootScope.$broadcast('user:authentication:change', _user);
                    $rootScope.$broadcast('user:loggedin');
                    deferred.resolve();
                })
                .error(function(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },

            /**
             * Logins the user as anonymous
             * @return {Object}           Promise with reponse data
             */
            anonymousLogin : function() {

                var deferred = $q.defer(),

                    config = {
                        endpoint : 'init',
                        method: 'POST',
                        requestBody: 'form'
                    };

                factory.setConfig(config);
                factory.call()
                .success(function(response) {
                    deferred.resolve(response);
                })
                .error(function(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },

            loginTest : function(loginData) {

                var deferred = $q.defer(),

                    config = {
                        //http://relay-homeservices-1892420759.us-east-1.elb.amazonaws.com/api/v1/login
                        endpoint : 'login',
                        method: 'POST',
                        data : loginData,
                        requestBody: 'form'
                    };

                factory.setConfig(config);
                factory.call()
                .success(function(response) {
                    deferred.resolve(response);
                })
                .error(function(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },

            /**
             * Logs outh the user and redirects to the home screen
             */
            logout: function() {
                var deferred = $q.defer(),

                    config = {
                        //http://relay-homeservices-1892420759.us-east-1.elb.amazonaws.com/api/v1/logout
                        endpoint : 'logout',
                        method: 'POST'
                    };

                factory
                .setConfig(config)
                .call()
                ['finally'](function() {
                    //Cleans cached user
                    _user = new User();
                    deferred.resolve();
                    $rootScope.$broadcast('user:authentication:change', _user);
                    $state.go('home');
                });
                return deferred.promise;
            },

            /**
             * Logs outh the user and redirects to the home screen
             */
            logoutTest: function() {
                var deferred = $q.defer(),

                    config = {
                        //http://relay-homeservices-1892420759.us-east-1.elb.amazonaws.com/api/v1/logout
                        endpoint : 'logout',
                        method: 'POST'
                    };

                factory
                .setConfig(config)
                .call()
                ['finally'](function() {
                    deferred.resolve();
                });

                return deferred.promise;
            },

            /**
             * Regiters the user
             * @param  {Object} registerData Contains username and password properties
             * @return {Object}           Promise with reponse data
             */
            register : function(registerData) {
                var deferred = $q.defer();

                var config = {
                    //http://relay-homeservices-1892420759.us-east-1.elb.amazonaws.com/api/v1/signup
                    endpoint : 'signup',
                    method: 'POST',
                    data : registerData,
                    requestBody: 'form'
                };
                factory.setConfig(config);
                factory.call()
                .success(function(response) {
                    /*var userData = {
                        firstname: response.firstname,
                        lastname: response.lastname,
                        profileImageSrc: response.profileImageSrc
                    };
                    _user = new User(userData);
                    deferred.resolve(response);
                    $rootScope.$broadcast('user:authentication:change', _user);*/
                    var userData = {
                        firstName: response.firstName,
                        lastName: response.lastName,
                        userType: response.userType,
                        email: response.email,
                        contact: response.contact,
                        salSessionId: response.salSessionId,
                        profileImageSrc: response.profileImageSrc
                    };
                    _user = new User(userData);
                    $rootScope.$broadcast('user:authentication:change', _user);
                    deferred.resolve();
                })
                .error(function(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },

             /**
             * Registers the user as guest
             * @param {Object} registerData Contains username and password properties
             * @return {Object} Promise with reponse data
             */
            registerGuest : function(registerData) {
                var deferred = $q.defer();

                var config = {
                    endpoint : 'guest',
                    method: 'POST',
                    data : registerData,
                    requestBody: 'form'
                };
                factory.setConfig(config);
                factory.call()
                .success(function(response) {
                    var userData = {
                        firstName: response.firstName,
                        lastName: response.lastName,
                        email: response.email,
                        contact: response.contact,
                        isGuest: true,
                        userType: response.userType,
                        salSessionId: response.salSessionId,
                        profileImageSrc: response.profileImageSrc
                    };
                    _user = new User(userData);                  
                    $rootScope.$broadcast('user:authentication:change', _user);
                    deferred.resolve();
                })
                .error(function(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
             /**
             * Validates if the User is a pre-eisting registered User i.e. SAL_USER
             * or, a guest user
             * @param {Object} username required
             * @return {Boolean} `true` if email is of a SAL_USER, false otherwise 
             */
            isSALUser : function(username) {
                var deferred = $q.defer();

                var config = {
                    endpoint : 'guest',
                    method: 'GET',
                    params : {
                      'username': username
                    }
                };
                factory.setConfig(config);
                factory.call()
                .success(function(response) {              
                    deferred.resolve(response);
                })
                .error(function(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },

            /**
             * Request to recover password
             * @param  {Object} recoverData Contains username and captcha token properties
             * @return {Object}          Promise with reponse data
             */
            recoverPassword: function(recoverData) {
                var deferred = $q.defer(),
                    config = {
                    endpoint : 'login/recover',
                    method: 'POST',
                    data : recoverData,
                    requestBody: 'form'
                };

                factory
                .setConfig(config)
                .call()
                .success(function(response) {
                    deferred.resolve(response);
                })
                .error(function(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },

            /**
             * Request to validate change password link
             * @param  {Object} validateLinkData Contains username and token
             * @return {Object}          Promise with reponse data
             */
            validateLink: function(validateLinkData) {
                var deferred = $q.defer(),
                    config = {
                    endpoint : 'login/validateLink',
                    method: 'POST',
                    data : validateLinkData,
                    requestBody: 'form'
                };

                factory
                .setConfig(config)
                .call()
                .success(function() {
                    deferred.resolve();
                })
                .error(function(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },

            /**
             * Request to change password
             * @param  {Object} newPasswordData Contains username, token and new password
             * @return {Object}          Promise with reponse data
             */
            changePassword: function(newPasswordData) {
                var deferred = $q.defer(),
                    config = {
                    endpoint : 'login/changepass',
                    method: 'POST',
                    data : newPasswordData,
                    requestBody: 'form'
                };

                factory
                .setConfig(config)
                .call()
                .success(function() {
                    deferred.resolve();
                })
                .error(function(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },

            /**
             * Get cached user
             * @return {[type]} [description]
             */
            getUser: function() {
                return _user;
            },

            /**
             * Sets the user to internal app cache
             * @param {Object} userData Raw json data
             */
            setUser: function(userData) {
                _user = new User(userData);
                return _user;
            },

            /**
             * Triggering Login popup
             */
            getLoginWindow: function() {
                //var modalInstance = $uibModal.open({
                $uibModal.open({
                    animation: true,
                    controller: 'AccountSignInCtrl as AccountSignInController',
                    templateUrl: 'assets/templates/pages/account/signin/index.html'
                });

                /*modalInstance.result.then(function() {
                    // TODO: Insert sign-in logic here
                }, function(where) {
                    switch (where) {
                        case 'signup': return ctrl.signUpInit();
                        case 'recover': return ctrl.recoverInit();
                    }
                });*/
            }

        };

        //Extends factory with Abstract service
        return angular.extend(factory, AbstractService);
    }]
);
