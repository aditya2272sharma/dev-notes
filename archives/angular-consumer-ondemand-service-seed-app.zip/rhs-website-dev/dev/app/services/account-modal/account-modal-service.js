'use strict';

/**
* Use this manager to get different operations for login
*/
angular.module('RelayServicesApp.Services').factory('accountModalService',
    ['$rootScope', '$q', '$state', 'AbstractService', '$uibModal',
    function($rootScope, $q, $state, AbstractService, modal) {

        var factory = {

            /**
             * [signInInit description]
             * @return {[type]}           [description]
             */
            signInInit : function(callbackOnOpen, callbackOnClose, guestCheckoutFlow, customGuestProjectFlow) {

                var flow = 'normal';
                if (guestCheckoutFlow) {
                    flow = 'guest-checkout';
                }
                if (customGuestProjectFlow) {
                    flow = 'guest-custom';
                }

                var modalInstance = modal.open({
                    animation: true,
                    controller: 'AccountSignInCtrl as AccountSignInController',
                    templateUrl: 'assets/templates/pages/account/signin/index.html',
                    resolve: {
                        selectFlow: function() {
                            return flow;
                        }
                    }
                });

                modalInstance.result.then(function() {
                    // TODO: Insert sign-in logic here
                    if (callbackOnOpen) {
                        callbackOnOpen();
                    }
                }, function(where) {
                    if (callbackOnClose) {
                        callbackOnClose();
                    }
                    switch (where) {
                        case 'signup': return factory.signUpInit(callbackOnOpen, callbackOnClose, guestCheckoutFlow, customGuestProjectFlow);
                        case 'recover': return factory.recoverInit(callbackOnOpen, callbackOnClose, guestCheckoutFlow, customGuestProjectFlow);
                        // case 'home': return $state.go('home.main');
                    }
                });
                return modalInstance;
            },
            /**
             * [signInInit description]
             * @return {[type]}           [description]
             */
            signUpInit : function(callbackOnOpen, callbackOnClose, guestCheckoutFlow, customGuestProjectFlow) {

                var modalInstance = modal.open({
                    animation: true,
                    controller: 'AccountSignUpCtrl as AccountSignUpController',
                    templateUrl: 'assets/templates/pages/account/signup/index.html'
                });

                modalInstance.result.then(function() {
                    // TODO: Insert sign-up logic here

                    if (callbackOnOpen) {
                        callbackOnOpen();
                    }

                }, function(where) {

                    if (callbackOnClose) {
                        callbackOnClose();
                    }

                    switch (where) {
                        case 'signin': return factory.signInInit(callbackOnOpen, callbackOnClose, guestCheckoutFlow, customGuestProjectFlow);
                    }
                });

                return modalInstance;
            },
            /**
             * [signInInit description]
             * @return {[type]}           [description]
             */
            recoverInit : function(callbackOnOpen, callbackOnClose, guestCheckoutFlow, customGuestProjectFlow) {

                var modalInstance = modal.open({
                    animation: true,
                    controller: 'AccountRecoverCtrl as AccountRecoverController',
                    templateUrl: 'assets/templates/pages/account/recover/index.html'
                });

                modalInstance.result.then(function() {
                    // TODO: Insert recover logic here
                }, function(where) {
                    switch (where) {
                        case 'home': return $state.go('home.new');
                        case 'signin': return factory.signInInit(callbackOnOpen, callbackOnClose, guestCheckoutFlow, customGuestProjectFlow);
                    }
                });
                return modalInstance;
            },
            /**
             * [signInInit description]
             * @return {[type]}           [description]
             */
            changePasswordInit : function() {

                var modalInstance = modal.open({
                    animation: true,
                    controller: (
                        'AccountChangePasswordCtrl as ChangePasswordCtrl'
                        ),
                    templateUrl: (
                        'assets/templates/pages/account/changePassword/index.html'
                        )
                });

                modalInstance.result.then(function() {
                    // TODO: Insert change-password logic here
                }, function(where) {
                    switch (where) {
                        case 'signin': return factory.signInInit();
                    }
                });
                return modalInstance;
            }

        };

        //Extends factory with Abstract service
        return angular.extend(factory, AbstractService);
    }]
);
