'use strict';

function locationService ($q, AbstractService) {
    var factory = {
        /**
        * Gets a state and city from zipcode
        * Checks serviceability of a location if the flag is specified
        * Responds with '404' if location isn't serviceable
        * API: api/v1/swagger-ui.html#!/location-controller/getLocationByZipCode
        * @params {zipcode} 5-digit USA zipcode
        * @params {checkServiceability} boolean value true|false
        * @return {Promise} A Promise containing the state,city and zipcode
        */
        getlocationLegacy: function(zipcode, checkServiceability) {
            checkServiceability = checkServiceability || false;
            var deferred = $q.defer(),
                config = {
                    endpoint : 'location',
                    method: 'GET',
                    requestBody: 'form',
                    preloadInclude: true,
                    params: {
                        zipcode: zipcode,
                        check_serviceability: checkServiceability
                    }
                };

            factory
            .setConfig(config)
            .call()
            .success(function(response) {
                deferred.resolve(response);
            })
            .error(function(response, status, headers, config, statusText, xhrStatus) {
                var error = {
                    response: response,
                    status: status,
                    headers: headers,
                    config: config,
                    statusText: statusText,
                    xhrStatus: xhrStatus
                };
                deferred.reject(error);
            });
            return deferred.promise;
        },

        // new implementation
        getlocation: function(zipcode) {
            var deferred = $q.defer(),
                config = {
                    endpoint : 'location/' + zipcode,
                    method: 'GET',
                    requestBody: 'form',
                    preloadInclude: true,
                };

            factory
            .setConfig(config)
            .call()
            .success(function(response) {
                deferred.resolve(response);
            })
            .error(function(response, status, headers, config, statusText, xhrStatus) {
                var error = {
                    response: response,
                    status: status,
                    headers: headers,
                    config: config,
                    statusText: statusText,
                    xhrStatus: xhrStatus
                };
                deferred.reject(error);
            });
            return deferred.promise;
        },

        /**
        * End Point Details:
        * api/v1/swagger-ui.html#!/serviceability-controller/serviceability
        * Checks serviceability of a location
        * Responds with '404' if location isn't serviceable
        * @params {zipcode} 5-digit USA zipcode
        * @params {serviceType} string 'STANDARD' | 'NON_STANDARD' | 'STANDARD_FIXED_PRICE'
        * @return {Promise} A Promise containing the state,city and zipcode
        */
        getServiceability: function(zipcode, serviceType) {
            var deferred = $q.defer(),
                config = {
                    endpoint : 'serviceability',
                    method: 'GET',
                    requestBody: 'form',
                    preloadInclude: true,
                    params: {
                        zipcode: zipcode,
                        servicetype: serviceType
                    }
                };

            factory
            .setConfig(config)
            .call()
            .success(function(response) {
                deferred.resolve(response);
            })
            .error(function(response, status, headers, config, statusText, xhrStatus) {
                var error = {
                    response: response,
                    status: status,
                    headers: headers,
                    config: config,
                    statusText: statusText,
                    xhrStatus: xhrStatus
                };
                deferred.reject(error);
            });
            return deferred.promise;
        },
        /**
        * End Point:
        * api/v1/swagger-ui.html#!/location-controller/getLocationByPosition
        *
        * Determines city & state from lat, lng e.g. 35.113281, -106.6056 
        * @params {lat} float representing lattitude
        * @params {lng} float representing longitude
        * @return {Promise} A Promise containing the state,city and zipcode
        */
        getAddressByLatLong: function(latitude, longitude) {
            var deferred = $q.defer(),
                config = {
                    endpoint : 'location/latlng',
                    method: 'GET',
                    requestBody: 'form',
                    preloadInclude: true,
                    params: {
                        latitude: latitude,
                        longitude: longitude
                    }
                };

            factory
            .setConfig(config)
            .call()
            .success(function(response) {
                deferred.resolve(response);
            })
            .error(function(error) {
                deferred.reject(error);
            });
            return deferred.promise;
        }
    };
    return angular.extend(factory, AbstractService);
}

locationService.$inject = ['$q', 'AbstractService'];
(angular
    .module('RelayServicesApp.Services')
).factory('locationService', locationService);
