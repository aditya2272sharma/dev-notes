'use strict';

function BecomeAProService($http, $q, _, AbstractService) {

    var factory = {

        submitBecomeAPro: function(becomeAProForm) {
            var deferred = $q.defer(),

            config = {
                endpoint : 'provider',
                method: 'POST',
                data: becomeAProForm,
                requestBody: 'form',
                preloadInclude: true
            };

            factory
            .setConfig(config)
            .call()
            .success(function(response) {
                deferred.resolve(response);
            })
            .error(function(response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }
    };

    // Extends factory with Abstract service
    return angular.extend(factory, AbstractService);
}

BecomeAProService.$inject = ['$http', '$q', '_', 'AbstractService'];

angular
    .module('RelayServicesApp.Services')
    .service('BecomeAProService', BecomeAProService);
