'use strict';

function ProjectsService($q, AbstractService, _, UtilsService, SettingsService, moment, Environment) {

    var _firms;

    var _projectData;

    var FirmCollection = function(data) {
        var allFirms = '';
        _firms = data;
        this.items = data;
        _.forEach(this.items, function(item) {
            item.selected = false;
            allFirms += item.id + ',';
            if (item.hourlyRate) {
                item.hourlyRate = UtilsService.hourlyRateFormat(item.hourlyRate);
            }
        });
        this.allFirms = allFirms.slice(0, -1);
    };

    /**
     * Project model
     * @param {Object} data Raw json
     */
    var Project = function(data) {
        var model = data;
        model.taskType = data.category.subCategory + ' - ' + data.category.title;
        model.completeAddress = data.location.street + ' ' + data.location.zipCode;
        model.formattedStartDate = moment(model.startDate).startOf('day').format('ddd, MMM D, YYYY');
        if (data.availability && data.availability.length > 0) {
            model.firms = new FirmCollection(data.availability);
        }
        return model;
    };

    /**
     * ProjectHistory model
     * @param {Object} data Raw json
     */
    var ProjectHistory = function(data) {
        var model = data;
        return model;
    };

    /**
     * Gets an array of items selected
     * @return {Array} Array of items selected
     */
    FirmCollection.prototype.getSelectedItems = function() {
        return _.filter(this.items, {'selected': true});
    };

    /**
     * Returns a comma sepparated list of selected ids
     * @return {string} A comma separated list of selected ids i.e 2365,4789,...
     */
    FirmCollection.prototype.getSelectedIds = function() {
        return _.map(this.getSelectedItems(), function(item) {
            return item.id;
        }).join(',');
    };

    /**
     * Gets an object with firm data
     * @return {Object} Object of firm data
     */
    FirmCollection.prototype.getFirmById = function(id) {
        return _.find(this.items, {'id' : id});
    };

    /**
     * List of estimates with price
     * @param {data} data Raw json data
     */
    var EstimatesPriceCollection = function(data) {
        var estimates = data;
        _.forEach(estimates.estimates.data, function(item) {
            item.id = _.find(estimates.firms.data, {'id' : item.firmId}).id;
            item.overview = _.find(estimates.firms.data, {'id' : item.firmId}).overview;
            item.rating = _.find(estimates.firms.data, {'id' : item.firmId}).rating;
            item.reviews = _.find(estimates.firms.data, {'id' : item.firmId}).reviews;
            item.title = _.find(estimates.firms.data, {'id' : item.firmId}).title;
            item.projectId = estimates.project.id;
            item.location = estimates.project.location;
            item.projectTitle = estimates.project.title;
            item.reviewCount = _.find(estimates.firms.data, {'id' : item.firmId}).reviewCount;
        });
        // Hourly Rate
        _.forEach(estimates.firms.data, function(item) {
            if (item.hourlyRate) {
                item.hourlyRate = UtilsService.hourlyRateFormat(item.hourlyRate);
            }
        });

        if (estimates.project.startDate === null) {
            estimates.project.formattedStartDate = _.each(estimates.project.preferredStartDates, function(date) {
                return moment(date).startOf('day').format('ddd, MMM D, YYYY');
            });
            estimates.project.formattedStartDate = estimates.project.formattedStartDate.join(', ');
        } else {
            estimates.project.formattedStartDate = moment(estimates.project.startDate).startOf('day').format('ddd, MMM D, YYYY');
        }
        if (estimates.project.rescheduleStartDate) {
            estimates.project.formattedRescheduleStartDate = moment(estimates.project.rescheduleStartDate)
            .startOf('day').format('ddd, MMM D, YYYY');
            estimates.project.formattedRescheduleTimeSlot =
            estimates.project.rescheduleTimeSlotBegin + ' - ' + estimates.project.rescheduleTimeSlotEnd;
        }
        return estimates;
    };

    var EstimatesCollection = function(data, projectId) {
        var estimates = data;
        _.forEach(estimates.data, function(item) {
            item.projectId = projectId;
        });

        return estimates;
    };

    /**
     * User Projects model
     * @param {Object} data Raw json
     */
    var UserProjects = function(data) {
        var model = data.data;
        //console.log(model);
        _.forEach(model, function(item) {
            if (item.images[0]) {
                item.mainImage = item.images[0];
            } else {
                item.mainImage = SettingsService.AssetsPaths.DEFAULT_PROJECT_IMAGE;
            }

            if (item.title) {
                item.mainTitle = item.title;
            } else {
                item.mainTitle = item.category.title;
            }
            item.formattedStartDate = moment(item.startDate).startOf('day').format('ddd, MMM D, YYYY');
        });
        return model;
    };

    var factory = {
        /**
         * Creates a new project
         * @return {Promise} A Promise containing the newly created project.
         */
        create: function(project, showPreloader) {
            var deferred = $q.defer();
            var config = {
                endpoint : 'projects',
                method: 'POST',
                data: project,
                requestBody: 'form',
                preloadInclude: showPreloader || true
            };

            factory
            .setConfig(config)
            .call()
            .success(function(response) {
                deferred.resolve(new Project(response));
            }).error(function(response) {
                deferred.reject(response);
            });

            return deferred.promise;
        },

        createCustomProject: function(project) {
            var deferred = $q.defer();
            var config = {
                endpoint : 'projects',
                method: 'POST',
                data: project,
                requestBody: 'form',
                preloadInclude: true
            };

            factory
            .setConfig(config)
            .call()
            .success(function(response) {
                deferred.resolve(new Project(response));
            }).error(function(response) {
                deferred.reject(response);
            });
            return deferred.promise;
        },

        /**
         * Update a project
         * @return {Promise} A Promise containing the newly created project.
         */
        update: function(project, showPreloader) {
            var deferred = $q.defer();
            var config = {
                endpoint : 'projects/' + project.id + '/update',
                method: 'POST',
                data: project,
                requestBody: 'form',
                preloadInclude: showPreloader || true
            };

            factory
            .setConfig(config)
            .call()
            .success(function(response) {
                deferred.resolve(new Project(response));
            }).error(function(response) {
                deferred.reject(response);
            });

            return deferred.promise;
        },

        updateCustomProject: function(project) {
            var projectId = project.id;
            var key = 'id';
            delete project[key];
            var deferred = $q.defer();
            var config = {
                endpoint : 'projects/' + projectId + '/update',
                method: 'POST',
                data: project,
                requestBody: 'form',
                preloadInclude: true
            };

            factory
            .setConfig(config)
            .call()
            .success(function(response) {
                deferred.resolve(new Project(response));
            }).error(function(response) {
                deferred.reject(response);
            });

            return deferred.promise;
        },

        /**
         * reschedule a project
         * @return {Promise} A Promise containing the newly rescheduled project.
         */
        reschedule: function(project) {
            var deferred = $q.defer();
            var config = {
                endpoint : 'projects/' + project.id + '/reschedule',
                method: 'POST',
                data: project,
                requestBody: 'form',
                preloadInclude: true
            };

            factory
            .setConfig(config)
            .call()
            .success(function(response) {
                deferred.resolve(response);
            }).error(function(response) {
                deferred.reject(response);
            });

            return deferred.promise;
        },

        /**
         * accept / Reject Pro-Reschedule a project
         * @return {Promise} A Promise.
         */
        acceptRejectProReschedule: function(project) {
            var deferred = $q.defer();
            var config = {
                endpoint : 'projects/' + project.id + '/reschedule/provider',
                method: 'POST',
                data: project,
                requestBody: 'form',
                preloadInclude: true
            };
            factory
            .setConfig(config)
            .call()
            .success(function(response) {
                deferred.resolve(response);
            }).error(function(response) {
                deferred.reject(response);
            });
            return deferred.promise;
        },

        /**
         * accept / Reject Pro-Reschedule a project
         * @return {Promise} A Promise.
         */
        cancelReschedule: function(project) {
            var deferred = $q.defer();
            var config = {
                endpoint : 'projects/' + project.id + '/reschedule/cancel',
                method: 'POST',
                data: project,
                requestBody: 'form',
                preloadInclude: true
            };
            factory
            .setConfig(config)
            .call()
            .success(function(response) {
                deferred.resolve(response);
            }).error(function(response) {
                deferred.reject(response);
            });
            return deferred.promise;
        },

        /**
         * Cancel a project
         * @return {Promise} A Promise after cancelling project.
         */
        cancel: function(project) {
            var deferred = $q.defer();
            var config = {
                endpoint : 'projects/' + project.projectId + '/cancel',
                method: 'POST',
                data: project,
                requestBody: 'form',
                preloadInclude: true
            };
            factory
            .setConfig(config)
            .call()
            .success(function(response) {
                deferred.resolve(response);
            }).error(function(response) {
                deferred.reject(response);
            });
            return deferred.promise;
        },

        /**
         * Ask for project estimations
         * @param  {number} projectId Project Id
         * @param  {string} firmIds   Firm Id
         * @param  {string} startDate Task Start Date (yyyy-MM-dd)
         * @return {Object} Response promise
         */
        askForProjectEstimations: function(projectId, firmIds, startDate) {
            var deferred = $q.defer(),

                config = {
                    endpoint : 'projects/' + projectId + '/estimates',
                    method: 'POST',
                    data : {firmIds: firmIds, startDate: startDate},
                    requestBody: 'form',
                    preloadInclude: true
                };

            factory
            .setConfig(config)
            .call()
            .success(function(response) {
                var estimates = new EstimatesPriceCollection(response);
                deferred.resolve(estimates);
            })
            .error(function(response) {
                deferred.reject(response);
            });
            return deferred.promise;
        },

        /**
         * Find project Estimates by Project Id
         * @param  {number} projectId Project Id
         * @return {Object} Response promise
         */
        getProjectEstimatesByProjectId: function(projectId, preloadContainer) {
            var deferred = $q.defer(),

                config = {
                    endpoint : 'projects/' + projectId + '/estimates',
                    method: 'GET'
                    //preloadInclude: true,
                    //preloadContainer: preloadContainer
                };

            factory
            .setConfig(config)
            .call()
            .success(function(response) {
                /*var project = new Project(response.project),
                    firms = new FirmCollection(response.firms.data),
                    estimates = new EstimateCollection(response.estimates.data);*/

                var estimates = new EstimatesPriceCollection(response);
                deferred.resolve(estimates);
                /*deferred.resolve({
                    project: project,
                    firms: firms,
                    estimates: estimates
                });*/
            })
            .error(function(response) {
                deferred.reject(response);
            });
            return deferred.promise;
        },

        /**
         * Find unified project estimates by Project Id
         * For Projects where the `serviceType` is `STANDARD_FIXED_PRICE`
         * @param {number} projectId ProjectId
         * @return {Object} Response promise
         */
        getUnifiedEstimatesByProjectId: function(projectId) {
            var deferred = $q.defer();
            var config;
            config = {
                endpoint: 'projects/' + projectId + '/firms',
                method: 'GET',
                preloadInclude: true
            };
            factory
            .setConfig(config)
            .call()
            .success(function(response) {
                var estimates = new EstimatesCollection(response, projectId);
                deferred.resolve(estimates);
            })
            .error(function(response, status, headers, config, statusText, xhrStatus) {
                var error = {
                    response: response,
                    status: status,
                    headers: headers,
                    config: config,
                    statusText: statusText,
                    xhrStatus: xhrStatus
                };
                deferred.reject(error);
            });
            return deferred.promise;
        },
        /**
         * Find unified project estimates by Project Id
         * @param {number} projectId ProjectId
         * @return {Object} Response promise
         */
        getUnifiedFixedPriceEstimatesByProjectId: function(projectId) {
            var deferred = $q.defer();
            var config;
            config = {
                endpoint: 'projects/' + projectId + '/firms/package',
                method: 'GET',
                preloadInclude: true,
            };
            factory
            .setConfig(config)
            .call()
            .success(function(response) {
                var estimates = new EstimatesCollection(response, projectId);
                deferred.resolve(estimates);
            })
            .error(function(response, status, headers, config, statusText, xhrStatus) {
                var error = {
                    response: response,
                    status: status,
                    headers: headers,
                    config: config,
                    statusText: statusText,
                    xhrStatus: xhrStatus
                };
                deferred.reject(error);
            });
            return deferred.promise;
        },

        /**
         * Accept/Reject an estimate
         * @param  {number} projectId Project Id
         * @param  {string} estimateId   estimate Id
         * @param  {boolean} decision
         * @return {Object} Response promise
         */
        acceptOrRejectProjectEstimation: function(projectId, estimateId, decision) {
            //Accept|Reject
            //var _decision = decision ? 'Accept' : 'Reject';

            var deferred = $q.defer(),

                config = {
                    endpoint : 'projects/' + projectId + '/estimates/' + estimateId,
                    method: 'POST',
                    data : {decision: decision},
                    requestBody: 'form'
                };

            factory
            .setConfig(config)
            .call()
            .success(function(response) {
                deferred.resolve(response);
            })
            .error(function(response) {
                deferred.reject(response);
            });
            return deferred.promise;
        },

        /**
         * Get estimate info
         * @param  {number} projectId Project Id
         * @param  {string} estimateId   estimate Id
         * @return {Object} Response promise
         */
        getEstimateSummary: function(projectId, estimateId) {

            var deferred = $q.defer(),

                config = {
                    endpoint : 'projects/' + projectId + '/estimates/' + estimateId,
                    method: 'GET',
                    requestBody: 'form',
                    preloadInclude: true
                };

            factory
            .setConfig(config)
            .call()
            .success(function(response) {
                deferred.resolve(response);
            })
            .error(function(response) {
                deferred.reject(response);
            });
            return deferred.promise;
        },
        /**
         * Get invoice info
         * @param  {number} projectId Project Id
         * @return {Object} Response promise
         */
        getInvoiceSummary: function(projectId) {

            var deferred = $q.defer(),

                config = {
                    endpoint : 'projects/' + projectId + '/invoice',
                    method: 'GET',
                    requestBody: 'form',
                    preloadInclude: true
                };

            factory
            .setConfig(config)
            .call()
            .success(function(response) {
                deferred.resolve(response);
            })
            .error(function(response) {
                deferred.reject(response);
            });
            return deferred.promise;
        },

        /**
         * Get available project estimates firms
         * @param  {number} projectId Project Id
         * @return {Object} Response promise
         */
        getProjectEstimatesFirms: function(projectId) {

            var deferred = $q.defer(),

                config = {
                    endpoint : 'projects/' + projectId + '/firms',
                    method: 'GET',
                    preloadInclude: true
                };

            factory
            .setConfig(config)
            .call()
            .success(function(response) {
                if (response.data) {
                    var firms = new FirmCollection(response.data);
                    deferred.resolve(firms);
                } else {
                    deferred.reject('Empty data');
                }
            })
            .error(function(response) {
                deferred.reject(response);
            });
            return deferred.promise;
        },

        /**
         * Find all projects by user
         * @return {Object} Response promise
         */
        getProjectsByUser: function() {

            var deferred = $q.defer(),

                config = {
                    endpoint : 'projects?details=true',
                    method: 'GET',
                    requestBody: 'form',
                    preloadInclude: true
                };

            factory
            .setConfig(config)
            .call()
            .success(function(response) {
                var userProjects = new UserProjects(response);
                deferred.resolve(userProjects);
            })
            .error(function(response) {
                deferred.reject(response);
            });
            return deferred.promise;
        },

        /**
         * Get available project cancellation message
         * @param  {number} projectId Project Id
         * @return {Object} Response promise
         */
        getCancelMessageByProjectId: function(projectId) {

            var deferred = $q.defer(),

                config = {
                    endpoint : 'projects/' + projectId + '/cancel/charge',
                    method: 'GET',
                    preloadInclude: true
                };

            factory
            .setConfig(config)
            .call()
            .success(function(response) {
                deferred.resolve(response);
            })
            .error(function(response) {
                deferred.reject(response);
            });
            return deferred.promise;
        },

        /**
         * Get list of cancel reasons
         * @return {Object} Response promise
         */
        getCancelReasons: function(projectId) {

            var deferred = $q.defer(),

                config = {
                    endpoint : 'projects/' + projectId + '/cancel/reasons',
                    method: 'GET',
                    preloadInclude: true
                };

            factory
            .setConfig(config)
            .call()
            .success(function(response) {
                deferred.resolve(response);
            })
            .error(function(response) {
                deferred.reject(response);
            });
            return deferred.promise;
        },

        /**
         * Find project by project id
         * @param  {number} projectId Project Id
         * @param  {string} preloadContainer default 'body'
         * query selector where preloader should be prepended
         * @return {Object} Response promise
         */
        getProjectByProjectId: function(projectId, preloadContainer) {

            var deferred = $q.defer(),
                config = {
                    endpoint : 'projects/' + projectId,
                    method: 'GET',
                    //preloadInclude: true,
                    //preloadContainer: preloadContainer,
                    //preloadZIndex: 1
                };
            factory
            .setConfig(config)
            .call()
            .success(function(response) {
                deferred.resolve(new Project(response));
            })
            .error(function(response) {
                deferred.reject(response);
            });
            return deferred.promise;
        },

        /**
         * Find project min history by project id
         * @param  {number} projectId Project Id
         * @return {Object} Response promise
         */
        getProjectMinHistory: function(projectId) {

            var deferred = $q.defer(),

                config = {
                    endpoint : 'projects/' + projectId + '/minhistory',
                    method: 'GET'
                };
            factory
            .setConfig(config)
            .call()
            .success(function(response) {
                deferred.resolve(new ProjectHistory(response));
            })
            .error(function(response) {
                deferred.reject(response);
            });
            return deferred.promise;
        },

        setProjectInfo: function(data) {
            _projectData = data;
        },
        getProjectInfo: function() {
            return _projectData || {};
        },
        getRescheduleReasons: function(projectId) {
            var deferred = $q.defer(),
                config = {
                    endpoint : 'projects/' + projectId + '/reschedule/reasons',
                    method: 'GET'
                };
            factory
            .setConfig(config)
            .call()
            .success(function(response) {
                deferred.resolve(response);
            })
            .error(function(response) {
                deferred.reject(response);
            });
            return deferred.promise;
        },

        /**
         * Meant for creating Draft Projects
         * Updates a transient project to a draft project
         * @param  {number} projectId Project Id
         * @return {Object} Response promise
         */
        waitForEstimates: function(projectId) {
            var deferred = $q.defer(),
                config = {
                    endpoint : _.template('projects/${projectId}/estimates/update')({projectId: projectId}),
                    method: 'POST',
                    preloadInclude: true
                };
            factory
            .setConfig(config)
            .call()
            .success(function(response) {
                deferred.resolve(response);
            })
            .error(function(response) {
                deferred.reject(response);
            });
            return deferred.promise;
        },

        /**
         * Gets all available Dates & Time Slots
         * Response excludes weekly & federal holidays
         * CatalogID === SKU === Sub-Category ID
         * @param  {number} servicecode SKU
         * @param  {number} zipcode 5-digit US zipcode
         * @param  {string constant} servicetype ss/ns/ssv2
         * @return {Object} Response promise
         */
        checkAvailability: function(servicecode, zipcode, servicetype) {
            var deferred = $q.defer(),
                params = {
                    servicecode: servicecode,
                    servicetype: servicetype,
                    zipcode: zipcode
                },
                config = {
                    endpoint : 'availability',
                    params: params,
                    method: 'GET',
                    requestBody: 'form',
                    //preloadInclude: true,
                    headers: {
                        'Accept': 'application/json'
                    }
                };
            factory
            .setConfig(config)
            .call()
            .success(function(response) {
                deferred.resolve(response);
            })
            .error(function(response) {
                deferred.reject(response);
            });
            return deferred.promise;
        },
        /**
         * Gets all available Dates & Time Slots when
         * a user attempts to reschedule a project
         * Response excludes weekly & federal holidays
         * Swagger: /api/v1/swagger-ui.html#!/project-reschedule-controller/availabilityUsingGET_1
         * @param  {number} Project ID
         * @return {Object} Response promise
         */
        checkRescheduleAvailability: function(projectId) {
            var deferred = $q.defer(),
                config = {
                    endpoint : 'projects/' + projectId + '/reschedule/availability',
                    method: 'GET',
                    preloadInclude: true,
                    headers: {
                        'Accept': 'application/json'
                    }
                };
            factory
            .setConfig(config)
            .call()
            .success(function(response) {
                deferred.resolve(response.data);
            })
            .error(function(response) {
                deferred.reject(response);
            });
            return deferred.promise;
        },
        /**
         * Changes a Project into a tech talk project
         * POST /api/v1/projects/{projectId}/techtalk
         * Swagger: /api/v1/swagger-ui.html#!/project-controller/changeProject
         * @param  {number} Project ID
         * @return {Object} Response promise
         */
        changeProjectToTechTalk: function(projectId) {
            var deferred = $q.defer(),
                config = {
                    endpoint : 'projects/' + projectId + '/techtalk',
                    method: 'POST',
                    preloadInclude: true,
                    headers: {
                        'Accept': 'application/json'
                    }
                };
            factory
            .setConfig(config)
            .call()
            .success(function(response) {
                deferred.resolve(response);
            })
            .error(function(response) {
                deferred.reject(response);
            });
            return deferred.promise;
        },
        /**
         * Find liquidity for a given service code, zip code and service type
         * Bascially, finds price for a particular service
         * GET /api/v1/liquidity/package
         * Swagger: /api/v1/swagger-ui.html#!/project-controller/changeProject
         * @param  {number} servicecode Based on the type of service,
         * this could be Merchandise Code, SKU or the CategoryId
         * @param  {number} zipcode
         * @param  {String} servicetype Type of Service
         * @return {Object} Response promise
         */
        getPrice: function(servicecode, zipcode, servicetype) {
            var deferred = $q.defer(),
                config = {
                    endpoint : 'liquidity/package',
                    method: 'GET',
                    preloadInclude: true,
                    params: {
                        servicecode: servicecode,
                        zipcode: zipcode,
                        servicetype: servicetype
                    },
                    headers: {
                        'Accept': 'application/json'
                    }
                };
            factory
            .setConfig(config)
            .call()
            .success(function(response) {
                deferred.resolve(response);
            })
            .error(function(response) {
                deferred.reject(response);
            });
            return deferred.promise;
        },
        prepareProjectData: function(project) {
            // commented values are either not required
            // or, they pre-exist in the object in the desirable json schema
            project = angular.extend(project, {
                catalogid: project.category.rowid,
                servicetype: project.serviceType,
                timechoice: '',
                timeslot: '',
                // title: project.title,
                addressid: project.location.addressId,
                zipcode: project.location.zipCode,
                // size: project.size,
                addressline1: project.location.addressLine1,
                addressline2: project.location.addressLine2,
                description: project.taskDescription,
                // images: project.images,
                // brand: project.brand,
                // problem: project.problem,
                warrantytype: project.warrantyType,
                modelnumber: project.modelNumber,
                location: '',
                internal: '',
                category: ''
            });
            return project;
        }
    };

    // Extends factory with Abstract service
    return angular.extend(factory, AbstractService);
}

ProjectsService.$inject = ['$q', 'AbstractService', '_', 'UtilsService', 'SettingsService', 'moment', 'ENVIRONMENT'];

/**
 * Use this service to get information about projects.
 */
(angular
    .module('RelayServicesApp.Services')
).factory('ProjectsService', ProjectsService);

