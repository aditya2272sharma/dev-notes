'use strict';

function NewProjectCategoriesService(
  $q,
  $location,
  Env,
  ProjectCategoriesService,
  SettingsService,
  _
) {

  /**
   * Popular model
   * @param {Object} data Raw json
   */
  var Popular = function(data) {
    var model = data;
    _.forEach(model.maincategories, function(item) {
      item.imgUrlHttps = item.imageurl.replace('http', 'https');
    });
    return model;
  };

  /**
   * All popular subcategories model
   * @param {Object} data Raw json
   */
  var AutoCompleteCategories = function (data) {
    var model = data.maincategories,
      newModel = [];
    _.forEach(model, function (item) {
      var mainCatTitle = item.title;
      var categories = item.categories;
      _.forEach(categories, function (category) {
        newModel.push({
          'parentCategory': mainCatTitle,
          'name': category.title,
          'id': category.catalogid
        });
      });
    });
    return newModel;
  };

  var factory = angular.extend({}, ProjectCategoriesService);
  factory = angular.extend(factory, {
    /**
     * Gets the context API path
     * @return {string} The context portion of the API path
     */
    getContext: function() {
      return this.context ? this.context : Env.apiCatalog.context;
    },

    /**
     * Gets the API domain
     * @return {string} The API domain string
     */
    getDomain: function() {
      return this.domain
        ? this.domain
        : Env.apiCatalog.domain;
    },

    /**
     * Gets the API port
     * @return {string} The API port string
     */
    getPort: function() {
      return this.port ? this.port : Env.apiCatalog.port;
    },

    /**
     * Getss the API protocol
     * @return {string} The protocol string
     */
    getProtocol: function() {
      return this.protocol
        ? this.protocol
        : Env.apiCatalog.protocol || $location.protocol();
    },

    /* Catalog API calls for Non-Standard Services */
    /**
     * End point:
     * api/v1/swagger-ui.html#!/catalog-controller/listNonStandardCatalog
     * This API will return NonStandard Service Catalog records
     * based on following conditions:
     * Return MainCategory records if we are not passing any parameter.
     * Return Category records if we pass mainCatId only.
     * Return SubCategory records if we pass mainCatId and catId
     * @return {Promise} on resolution, gives the above
     */
    nonStandardCatalog: function (mainCategoryId, categoryId) {
      var deferred = $q.defer();
      var config = {
        endpoint : 'catalog/nonstandard',
        method: 'GET',
        requestBody: 'form',
        preloadInclude: true,
        params: {
          'maincategoryid': mainCategoryId || '',
          'categoryid': categoryId || ''
        }
      };
      factory.setConfig(config);
      factory.call().success(function(response) {
        deferred.resolve(response);
      }).error(function(error) {
        deferred.reject(error);
      });
      return deferred.promise;
    },
    mainCategories: function () {
      return this.nonStandardCatalog();
    },
    categorieslist: function (mainCategoryId) {
      return this.nonStandardCatalog(mainCategoryId);
    },
    subCategorieslist: function (mainCategoryId, categoryId) {
      return this.nonStandardCatalog(mainCategoryId, categoryId);
    },
    /**
     * Gets popular categories with sub-categories list
     * @return {Promise} A Promise containing the popular categories list
     */
    popularCategoriesWithSubcategories: function() {
      var deferred = $q.defer();
      var config = {
        endpoint: 'catalog/standard/popular',
        method: 'GET',
        requestBody: 'form',
        preloadInclude: true
      };

      factory.setConfig(config);

      factory.call().success(function(response) {
        deferred.resolve(new Popular(response));
      }).error(function(error) {
        deferred.reject(error);
      });

      return deferred.promise;
    },
    /**
     * Gets the SSV3 related SKUs
     * @return {Promise} A Promise containing SSV3 SKUs
     */
    getRepairServiceOfferings: function() {
      var deferred = $q.defer();
      var config = {
        method: 'GET',
        endpoint: 'catalog/standardv3',
        requestBody: 'form',
        preloadInclude: true
      };
      factory.setConfig(config);
      factory
        .call()
        .success(function(response) {
          deferred.resolve({
            topProducts: response
          });
        })
        .error(function(error) {
          deferred.reject(error);
        });
      return deferred.promise;
    },
    /**
     * Gets the SSV3 related SKUs
     * @return {Promise} A Promise containing SSV3 SKUs
     */
    getTTRepairServiceOfferings: function() {
      var deferred = $q.defer();
      var config = {
        method: 'GET',
        endpoint: 'catalog/techtalk',
        requestBody: 'form',
        preloadInclude: true
      };
      factory.setConfig(config);
      factory
        .call()
        .success(function(response) {
          deferred.resolve({
            topProducts: response
          });
        })
        .error(function(error) {
          deferred.reject(error);
        });
      return deferred.promise;
    },
    /*
     * GET /apiNew/v1/catalog/repair/warrantystatus
     * Gets the list of available warranties
     * @params NONE
     * @return Promise object
     */
    getWarrantiesInfo: function() {
      var deferred = $q.defer();
      var config = {
        endpoint: 'catalog/standardv3/warranties',
        method: 'GET',
        requestBody: 'form',
        preloadInclude: true
      };
      factory.setConfig(config);
      factory
        .call()
        .success(function(response) {
          deferred.resolve(response);
        })
        .error(function(error) {
          deferred.reject(error);
        });
      return deferred.promise;
    },
    getSSV3ProductType: function(merchcode, servicetype) {
      var deferred = $q.defer();
      servicetype = (servicetype === SettingsService.ServiceTypes.TECHTALK) ?
                    'techtalk' : 'standardv3';
      var config = {
        endpoint: 'catalog/' + servicetype + '/' + merchcode,
        method: 'GET',
        requestBody: 'form',
        preloadInclude: true
      };
      factory.setConfig(config);
      factory
        .call()
        .success(function(response) {
          deferred.resolve(response);
        })
        .error(function(error) {
          deferred.reject(error);
        });
      return deferred.promise;
    },


    /* CATALOG APIs for Standard Services */
    /**
     * Gets all standard catalogs
     * @return {Promise} A Promise containing standard catalogs
     */
    standardCatalogs: function () {
      var deferred = $q.defer();
      var config = {
        endpoint: 'catalog/standard',
        method: 'GET',
        requestBody: 'form',
        preloadInclude: true
      };

      factory.setConfig(config);

      factory.call().success(function (response) {
        deferred.resolve(response.maincategories);
      }).error(function (error) {
        deferred.reject(error);
      });

      return deferred.promise;
    },
    /**
     * Gets all categories with sub-categories list
     * Note: It's a duplicate declaration of the previous
     * Will remove when find out the purpose behind duplication
     * @return {Promise} A Promise containing the categories list
     */
    autocompleteCategories: function () {
      var deferred = $q.defer();

      var config = {
        endpoint: 'catalog/standard',
        method: 'GET',
        requestBody: 'form'
      };

      factory.setConfig(config);

      factory.call().success(function (response) {
        deferred.resolve(new AutoCompleteCategories(response));
      }).error(function (error) {
        deferred.reject(error);
      });

      return deferred.promise;
    },
    /**
     * Gets a categories list
     * @return {Promise} A Promise containing the categories list
     */
    getcategoriesbyid: function (categoryId) {
      var deferred = $q.defer();
      var config = {
        endpoint: 'catalog/standard/' + categoryId,
        method: 'GET',
        requestBody: 'form',
        preloadInclude: true
      };

      factory.setConfig(config);

      factory.call().success(function (response) {
        deferred.resolve(response.categories);
      }).error(function (error) {
        deferred.reject(error);
      });

      return deferred.promise;
    },

    standardCatalogsById: function (mainCategoryId) {
      var deferred = $q.defer();
      var params = {
        maincategoryid: mainCategoryId,
        hierarchy: true
      };
      var config = {
        endpoint: 'catalog/standard',
        method: 'GET',
        params: params,
        requestBody: 'form',
        preloadInclude: true
      };
      factory.setConfig(config);
      factory.call().success(function (response) {
        if (response) {
          deferred.resolve(response);
        }
      }).error(function (error) {
        deferred.reject(error);
      });
      return deferred.promise;
    }
  });
  return factory;
}

NewProjectCategoriesService.$inject = [
  '$q',
  '$location',
  'ENVIRONMENT',
  'ProjectCategoriesService',
  'SettingsService',
  '_'
];

/**
 * Use this service to get information about projects' categories.
 */
(angular
  .module('RelayServicesApp.Services'))
  .factory('NewProjectCategoriesService', NewProjectCategoriesService);