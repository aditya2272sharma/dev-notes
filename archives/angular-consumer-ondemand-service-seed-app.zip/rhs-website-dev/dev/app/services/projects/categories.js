'use strict';

function ProjectCategoriesService($q, AbstractService, _) {
    var _taskDescription = '';

    /**
     * Categories model
     * @param {Object} data Raw json
     */
    var Categories = function(data) {
        var model = data;
        _.forEach(model, function(item) {
            item.imgUrlHttps = item.imgUrl.replace('http', 'https');
        });
        return model;
    };

    /**
     * SplitedCategories model (categories and popularCategories)
     * @param {Object} data Raw json
     */
    var SplitedCategories = function(data) {
        var model = data,
            categories = model.categories,
            popularCategories = model.popularcategories;

        _.forEach(categories, function(item) {
            item.imgUrlHttps = item.imgUrl.replace('http', 'https');
        });

        _.forEach(popularCategories, function(item) {
            item.imgUrlHttps = item.imgUrl.replace('http', 'https');
        });

        return model;
    };

    /**
     * Popular model
     * @param {Object} data Raw json
     */
    var Popular = function(data) {
        var model = data;
        _.forEach(model.maincategories, function(item) {
            item.imgUrlHttps = item.imageurl.replace('http', 'https');
        });
        return model;
    };

    /**
     * All popular subcategories model
     * @param {Object} data Raw json
     */
    var AutoCompleteCategories = function(data) {
        var model = data.maincategories,
            newModel = [];
        _.forEach(model, function(item) {
            var mainCatTitle = item.title;
            var categories = item.categories;
            _.forEach(categories, function(category) {
                newModel.push({
                    'parentCategory': mainCatTitle,
                    'name': category.title,
                    'id': category.catalogid
                });
            });
        });
        return newModel;
    };

    var factory = {
        /**
         * Gets a categories list
         * @return {Promise} A Promise containing the categories list
         */
        categories: function(standard, popular) {
            var standardQs = '',
                categoryList = [];
            if (standard) {
                standardQs = '?servicetype=STANDARD';
            }
            var deferred = $q.defer();
            var config = {
                endpoint : 'categories' + standardQs,
                method: 'GET',
                requestBody: 'form',
                preloadInclude: true
            };

            factory.setConfig(config);

            factory.call().success(function(response) {
                //deferred.resolve(response.categories);
                if (popular) {
                    deferred.resolve(new SplitedCategories(response));
                } else {
                    categoryList = _.concat(response.popularcategories, response.categories);
                    deferred.resolve(new Categories(categoryList));
                }
            }).error(function(error) {
                deferred.reject(error);
            });

            return deferred.promise;
        },

        mainCategories: function() {
            var deferred = $q.defer();
            var config = {
                endpoint : 'catalog/nonstandard',
                method: 'GET',
                requestBody: 'form',
                preloadInclude: true
            };
            factory.setConfig(config);
            factory.call().success(function(response) {
                if (response) {
                    deferred.resolve(response);
                }
            }).error(function(error) {
                deferred.reject(error);
            });
            return deferred.promise;
        },
        categorieslist: function(mainCategoryId) {
            var deferred = $q.defer();
            var config = {
                endpoint : 'catalog/nonstandard?maincategoryid=' + mainCategoryId,
                method: 'GET',
                requestBody: 'form',
                preloadInclude: true
            };
            factory.setConfig(config);
            factory.call().success(function(response) {
                if (response) {
                    deferred.resolve(response);
                }
            }).error(function(error) {
                deferred.reject(error);
            });
            return deferred.promise;
        },
        subCategorieslist: function(mainCategoryId, categoryId) {
            var deferred = $q.defer();
            var config = {
                endpoint : 'catalog/nonstandard?maincategoryid=' + mainCategoryId + '&categoryid=' + categoryId,
                method: 'GET',
                requestBody: 'form',
                preloadInclude: true
            };
            factory.setConfig(config);
            factory.call().success(function(response) {
                if (response) {
                    deferred.resolve(response);
                }
            }).error(function(error) {
                deferred.reject(error);
            });
            return deferred.promise;
        },

        /**
         * Gets a categories list
         * @return {Promise} A Promise containing the categories list
         */
        subcategories: function(category) {
            var deferred = $q.defer();
            var config = {
                endpoint : 'categories/' + category,
                method: 'GET',
                requestBody: 'form',
                preloadInclude: true
            };

            factory.setConfig(config);

            factory.call().success(function(response) {
                deferred.resolve(response);
            }).error(function(error) {
                deferred.reject(error);
            });

            return deferred.promise;
        },

        /**
         * Gets a categories list
         * @return {Promise} A Promise containing the categories list
         */
        getcategoriesbyid: function(categoryId) {
            var deferred = $q.defer();
            var config = {
                endpoint : 'catalog/standard/' + categoryId,
                method: 'GET',
                requestBody: 'form',
                preloadInclude: true
            };

            factory.setConfig(config);

            factory.call().success(function(response) {
                deferred.resolve(response.categories);
            }).error(function(error) {
                deferred.reject(error);
            });

            return deferred.promise;
        },

        /**
         * Gets a subcategory details
         * @return {Promise} A Promise containing the categories list
         */
        subcategoriesDetails: function(subcategory) {
            var deferred = $q.defer();
            var config = {
                endpoint : 'categories/subcategories/' + subcategory,
                method: 'GET',
                requestBody: 'form'
            };

            factory.setConfig(config);

            factory.call().success(function(response) {
                deferred.resolve(response);
            }).error(function(error) {
                deferred.reject(error);
            });

            return deferred.promise;
        },

        setTaskDescription: function(value) {
            _taskDescription = value;
        },

        getTaskDescription: function() {
            return _taskDescription;
        },

        /**
         * Gets popular sub-categories list
         * @return {Promise} A Promise containing the popular sub-categories list
         */
        popularSubCategories: function(category) {
            var deferred = $q.defer();
            var config = {
                endpoint : 'categories/subcategories/popular/' + category,
                method: 'GET',
                requestBody: 'form',
                preloadInclude: true
            };

            factory.setConfig(config);

            factory.call().success(function(response) {
                deferred.resolve(response);
            }).error(function(error) {
                deferred.reject(error);
            });

            return deferred.promise;
        },

        /**
         * Gets popular categories with sub-categories list
         * @return {Promise} A Promise containing the popular categories list
         */
        popularCategoriesWithSubcategories: function() {
            var deferred = $q.defer();
            var config = {
                endpoint : 'catalog/standard/popular',
                method: 'GET',
                requestBody: 'form',
                preloadInclude: true
            };

            factory.setConfig(config);

            factory.call().success(function(response) {
                deferred.resolve(new Popular(response));
            }).error(function(error) {
                deferred.reject(error);
            });

            return deferred.promise;
        },

        /**
         * Gets all categories with sub-categories list
         * @return {Promise} A Promise containing the categories list
         */
        allCategoriesWithSubcategories: function(standard) {
            var deferred = $q.defer();
            var serviceType = standard ? 'STANDARD' : 'NON_STANDARD';
            var params = {
              all: false,
              hierarchy: true,
              servicetype: serviceType,
            };
            var config = {
                endpoint : 'categories/subcategories',
                params: params,
                method: 'GET',
                requestBody: 'form',
                preloadInclude: true
            };

            factory.setConfig(config);

            factory.call().success(function(response) {
                deferred.resolve(new Popular(response));
            }).error(function(error) {
                deferred.reject(error);
            });

            return deferred.promise;
        },

        /**
         * Gets all categories with sub-categories list
         * @return {Promise} A Promise containing the categories list
         */
        autocompleteCategories: function() {
            var deferred = $q.defer();

            var config = {
                endpoint : 'catalog/standard',
                method: 'GET',
                requestBody: 'form'
            };

            factory.setConfig(config);

            factory.call().success(function(response) {
                deferred.resolve(new AutoCompleteCategories(response));
            }).error(function(error) {
                deferred.reject(error);
            });

            return deferred.promise;
        },

        /*
         * CATALOG APIs **** BEGIN *************
         */
        /**
         * Gets all standard catalogs
         * @return {Promise} A Promise containing standard catalogs
         */
        standardCatalogs: function() {
            var deferred = $q.defer();
            var config = {
                endpoint : 'catalog/standard',
                method: 'GET',
                requestBody: 'form',
                preloadInclude: true
            };

            factory.setConfig(config);

            factory.call().success(function(response) {
                deferred.resolve(response.maincategories);
            }).error(function(error) {
                deferred.reject(error);
            });

            return deferred.promise;
        },
        standardCatalogsById: function(mainCategoryId) {
            var deferred = $q.defer();
            var params = {
                maincategoryid: mainCategoryId,
                hierarchy: true
            };
            var config = {
                endpoint : 'catalog/standard',
                method: 'GET',
                params: params,
                requestBody: 'form',
                preloadInclude: true
            };
            factory.setConfig(config);
            factory.call().success(function(response) {
                if (response) {
                    deferred.resolve(response);
                }
            }).error(function(error) {
                deferred.reject(error);
            });
            return deferred.promise;
        },
        getRepairServiceOfferings: function() {
            throw 'API has been deprecated: catalog2/standardv3';
        },
        getWarrantiesInfo: function() {
            throw 'API has been deprecated: catalog2/standardv3/warranties';
        },
        getSSV3ProductType: function(merchcode) {
            throw 'API has been deprecated: catalog2/standardv3/${merchcode}';
        }
    };

    // Extends factory with Abstract service
    return angular.extend(factory, AbstractService);
}

ProjectCategoriesService.$inject = ['$q', 'AbstractService', '_'];

/**
 * Use this service to get information about projects' categories.
 */
(angular
    .module('RelayServicesApp.Services')
).factory('ProjectCategoriesService', ProjectCategoriesService);
