'use strict';

function CustomProjectService($q, AbstractService, modal, $window) {
    // Extends factory with Abstract service
    var factory = {
            openModal : function(Details) {
                var modalInstance = modal.open({
                    animation: true,
                    size: 'md',
                    controller: 'CustomProjectCategoryCtrl',
                    controllerAs: 'CustomProjectCategoryCtrl',
                    windowClass: 'modal-custom-project',
                    templateUrl: [
                        'assets/templates/pages/projects/custom-project/category/index.html'
                    ].join(''),
                    resolve: {
                        Details: function() {
                            return Details;
                        }
                    }
                });
                modalInstance.result.then(function() {
                    $window.location.reload();
                });
                return modalInstance;
            },
            openCategoryModal : function(Details) {
                var modalInstance = modal.open({
                    animation: true,
                    size: 'lg',
                    controller: 'CustomProjectSubCategoryCtrl',
                    controllerAs: 'CustomProjectSubCategoryCtrl',
                    templateUrl: [
                        'assets/templates/pages/projects/custom-project/sub-category/index.html'
                    ].join(''),
                    resolve: {
                        Details: function() {
                            return Details;
                        }
                    }
                });
                modalInstance.result.then(function() {
                    $window.location.reload();
                });
                return modalInstance;
            },
            openSubCategoryModal : function(Details) {
                var modalInstance = modal.open({
                    animation: true,
                    size: 'lg',
                    controller: 'CustomProjectSubSubCategoryCtrl',
                    controllerAs: 'CustomProjectSubSubCategoryCtrl',
                    templateUrl: [
                        'assets/templates/pages/projects/custom-project/sub-sub-category/index.html'
                    ].join(''),
                    resolve: {
                        Details: function() {
                            return Details;
                        }
                    }
                });
                modalInstance.result.then(function() {
                    $window.location.reload();
                });
                return modalInstance;
            },
            openCreateProjectModal : function(Details) {
                var modalInstance = modal.open({
                    animation: true,
                    size: 'md',
                    controller: 'CustomProjectCreateProjectCtrl',
                    controllerAs: 'CustomProjectCreateProjectCtrl',
                    windowClass: 'modal-special-project',
                    templateUrl: [
                        'assets/templates/pages/projects/custom-project/create-project/index.html'
                    ].join(''),
                    resolve: {
                        Details: function() {
                            return Details;
                        }
                    }
                });
                modalInstance.result.then(function() {
                    $window.location.reload();
                });
                return modalInstance;
            }
        };
    return angular.extend(factory, AbstractService);
}

CustomProjectService.$inject = ['$q', 'AbstractService', '$uibModal', '$window'];
(angular
    .module('RelayServicesApp.Services')
).factory('CustomProjectService', CustomProjectService);
