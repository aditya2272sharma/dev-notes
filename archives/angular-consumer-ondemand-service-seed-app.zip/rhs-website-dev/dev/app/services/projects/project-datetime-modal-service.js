'use strict';

/**
* Use this manager to get modal to update date/time for project
*/
angular.module('RelayServicesApp.Services').factory('ProjectDateTimeModalService',
    ['$rootScope', '$q', '$state', 'AbstractService', '$uibModal',
    function($rootScope, $q, $state, AbstractService, modal) {

        var factory = {

            openModal : function(project, callbackToProceed, callbackOnOpen, callbackOnClose) {

                var modalInstance = modal.open({
                    animation: true,
                    size: 'sm',
                    controller: 'ProjectDateTimeCtrl',
                    controllerAs: 'ProjectDateTimeCtrl',
                    windowClass: 'modal-date-time-project',
                    templateUrl: [
                        'assets/templates/pages/projects/date-time-modal/',
                        'index.html'
                    ].join(''),
                    resolve: {
                        project: function() {
                            return project;
                        },
                        proceed: function() {
                            return callbackToProceed;
                        }
                    }
                });

                modalInstance.result.then(function() {
                    if (callbackOnOpen) {
                        callbackOnOpen();
                    }
                }, function() {
                    if (callbackOnClose) {
                        callbackOnClose();
                    }
                });
                return modalInstance;
            }

        };

        //Extends factory with Abstract service
        return angular.extend(factory, AbstractService);
    }]
);
