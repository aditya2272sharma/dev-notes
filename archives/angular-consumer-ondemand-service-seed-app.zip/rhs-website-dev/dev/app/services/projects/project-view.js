'use strict';

function ProjectViewService($q, AbstractService, _, SettingsService, moment) {

    /**
     * User Projects model
     * @param {Object} data Raw json
     */
    var UserProjects = function(data) {
        var model = data.data;
        _.forEach(model, function(item) {
            if (item.category.image) {
                item.mainImage = item.category.image;
            } else {
                item.mainImage = SettingsService.AssetsPaths.DEFAULT_PROJECT_IMAGE;
            }

            if (item.title) {
                item.mainTitle = item.title;
            } else {
                item.mainTitle = item.category.title;
            }
            if (item.location.addressLine1 === 'Address will be shared once user accepts estimates') {
                item.location.addressLine1 = '';
                item.location.propertyAddress = '';
                item.location.street = '';
                item.location.fullAddress = '';
            }
            item.formattedStartDate = moment(item.startDate).startOf('day').format('ddd, MMM D, YYYY');
        });
        if (data.totalCount) {
            model.totalCount = data.totalCount;
        } else {
            model.totalCount = data.count;
        }
        model.count = data.count;
        return model;
    };

    var factory = {
        /**
         * Get project list of user
         * @return {Promise} A Promise containing the projects of user.
         */
        projectview: function(pageNo) {
            var deferred = $q.defer();
            var config = {
                endpoint : 'projectview?pageNo=' + pageNo,
                method: 'GET',
                requestBody: 'form',
                preloadInclude: true
            };

            factory
            .setConfig(config)
            .call()
            .success(function(response) {
                var userProjects = new UserProjects(response);
                deferred.resolve(userProjects);
            }).error(function(response) {
                deferred.reject(response);
            });

            return deferred.promise;
        }
    };

    // Extends factory with Abstract service
    return angular.extend(factory, AbstractService);
}

ProjectViewService.$inject = ['$q', 'AbstractService', '_', 'SettingsService', 'moment'];

/**
 * Use this service to get information about projects.
 */
(angular
    .module('RelayServicesApp.Services')
).factory('ProjectViewService', ProjectViewService);
