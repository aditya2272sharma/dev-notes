'use strict';

/**
 * Common-use angular utility functions
 * Place here utilities that can be applied throughout the application
 * @author Andrés Zorro <andres.zorro@zemoga.com>
 * @author Andrés García <andres.garcia@zemoga.com>
 * @module Services
 */

angular.module('RelayServicesApp.Services')
    .service('UtilsService', ['ENVIRONMENT', 'PRODUCTION', '_',
    function UtilsService(env, prod, _) {
        return {
            /**
            * Converts a string into an escaped formatted url string
            * @param   {string} str
            * @returns {string}        url-safe string
            */
            friendlyUrl : function(str) {
                var url;

                if (!str || typeof str !== 'string') {
                    str = '';
                }

                url = str.toLowerCase()
                .replace(/\s|\.|\//g, '-')
                .replace(/[^\w\d-\/]/g, '')
                .replace(/[-]{2,}/g, '-');

                return url;
            },

            /**
            * Render proper querystring for image URL
            * @param  {string} url    Original image Path
            * @param  {string|number} width  Image width
            * @param  {string|number} [heigth=width] - Image height, defaults to width
            * @return {string}        proper image URL
            */
            getImagePath : function(url, width, heigth) {
                // Remove the protocol of the images
                // so the browser selects the appropiate one
                url = url ? url.split('http://').join('//') : false;

                var output = '',
                    _heigth = heigth || width;

                if (url) {
                    output = url + ((url.indexOf('?') > -1) ? '&' : '?');
                    output += 'wid=' + width + '&hei=' + _heigth + '&op_sharpen=0&qlt=80';
                }
                return output;
            },

            /**
             * Gets project image
             * @param  {string} url Image url
             * @return {string}     Appropriate image url
             */
            getProjectImage: function(url) {
                var imgOutput = url;
                if (env.name === 'local') {
                    imgOutput = prod.api.protocol + '://' + prod.api.domain + url;
                }
                return imgOutput;
            },

            /**
            * Search for the first match of a regex in a string
            * @param  {string} str      target string
            * @param  {Object} regex    Regex to search
            * @param  {number} startpos Optional: position to start looking for
            * @return {number}          Index of search or -1
            */
            regexIndexOf : function(str, regex, startpos) {
                var indexOf = str.substring(startpos || 0).search(regex);

                return (indexOf >= 0) ? (indexOf + (startpos || 0)) : indexOf;
            },

            /**
            * IE8 doesn't support isoString data function, so this helper allows to validate first
            * @param  {Date} theDate Date for iso output
            * @return {string}         - ISO Date string
            */
            getISOString : function(theDate) {

                var output = '';

                function pad(number) {
                    var r = String(number);
                    if (r.length === 1) {
                        r = '0' + r;
                    }
                    return r;
                }

                if (Date.prototype.toISOString) {
                    output = theDate.toISOString();
                } else {
                    output = theDate.getUTCFullYear() + '-' +
                    pad(theDate.getUTCMonth() + 1) + '-' +
                    pad(theDate.getUTCDate()) + 'T' + pad(theDate.getUTCHours()) + ':' +
                    pad(theDate.getUTCMinutes()) + ':' + pad(theDate.getUTCSeconds()) + '.' +
                    String((theDate.getUTCMilliseconds() / 1000).toFixed(3)).slice(2, 5) + 'Z';
                }

                return output;
            },

            /**
            * Format any string Date comming as '20150214' to
            * @param  {string} dateString String containing the date
            * @return {Object}            Return's a Date object
            */
            formatDate: function(dateString) {
                var pattern = /(\d{4})(\d{2})(\d{2})/,
                convertedDate = new Date(dateString.replace(pattern, '$1-$2-$3'));
                return new Date (convertedDate.getUTCFullYear(), convertedDate.getUTCMonth(), convertedDate.getUTCDate());
            },

            /**
            * Checks if given object contains all required params and params are not falsy
            * @param  {Object} data    target
            * @param  {Array}  params  required keys
            * @return {boolean|string} Param missing or false
            */
            containsRequired : function(data, params) {
                var p;

                params = params || [];
                p = params.length;

                while (p--) {
                    if (!data.hasOwnProperty(params[p])) {
                        return params[p];
                    }
                }

                return false;
            },

            /**
            * Adds leading zero before numbers < 10
            * @param  {number} number target
            * @return {string}        result
            */
            leadingZero: function(number) {
                if (number < 10) {
                    return '0' + number;
                }

                return number.toString();
            },

            /**
            * Convert seconds in object Date
            * @param  {number | string} seconds
            * @return {Date} date
            */
            getDateBySeconds: function(seconds) {
                var _today = new Date();
                if (typeof seconds === 'string') {
                    seconds = parseInt(seconds, 10);
                }

                return (new Date(_today.getFullYear(), _today.getMonth(), _today.getDay(), 0, 0, seconds));
            },

            /**
             * Retrieve the list of US states
             * @return {Array.<Object>} The list of US states
             */
            getStatesList: function() {
                return [
                    {
                        'name': 'Alabama',
                        'abbreviation': 'AL'
                    },
                    {
                        'name': 'Alaska',
                        'abbreviation': 'AK'
                    },
                    {
                        'name': 'American Samoa',
                        'abbreviation': 'AS'
                    },
                    {
                        'name': 'Arizona',
                        'abbreviation': 'AZ'
                    },
                    {
                        'name': 'Arkansas',
                        'abbreviation': 'AR'
                    },
                    {
                        'name': 'California',
                        'abbreviation': 'CA'
                    },
                    {
                        'name': 'Colorado',
                        'abbreviation': 'CO'
                    },
                    {
                        'name': 'Connecticut',
                        'abbreviation': 'CT'
                    },
                    {
                        'name': 'Delaware',
                        'abbreviation': 'DE'
                    },
                    {
                        'name': 'District Of Columbia',
                        'abbreviation': 'DC'
                    },
                    {
                        'name': 'Federated States Of Micronesia',
                        'abbreviation': 'FM'
                    },
                    {
                        'name': 'Florida',
                        'abbreviation': 'FL'
                    },
                    {
                        'name': 'Georgia',
                        'abbreviation': 'GA'
                    },
                    {
                        'name': 'Guam',
                        'abbreviation': 'GU'
                    },
                    {
                        'name': 'Hawaii',
                        'abbreviation': 'HI'
                    },
                    {
                        'name': 'Idaho',
                        'abbreviation': 'ID'
                    },
                    {
                        'name': 'Illinois',
                        'abbreviation': 'IL'
                    },
                    {
                        'name': 'Indiana',
                        'abbreviation': 'IN'
                    },
                    {
                        'name': 'Iowa',
                        'abbreviation': 'IA'
                    },
                    {
                        'name': 'Kansas',
                        'abbreviation': 'KS'
                    },
                    {
                        'name': 'Kentucky',
                        'abbreviation': 'KY'
                    },
                    {
                        'name': 'Louisiana',
                        'abbreviation': 'LA'
                    },
                    {
                        'name': 'Maine',
                        'abbreviation': 'ME'
                    },
                    {
                        'name': 'Marshall Islands',
                        'abbreviation': 'MH'
                    },
                    {
                        'name': 'Maryland',
                        'abbreviation': 'MD'
                    },
                    {
                        'name': 'Massachusetts',
                        'abbreviation': 'MA'
                    },
                    {
                        'name': 'Michigan',
                        'abbreviation': 'MI'
                    },
                    {
                        'name': 'Minnesota',
                        'abbreviation': 'MN'
                    },
                    {
                        'name': 'Mississippi',
                        'abbreviation': 'MS'
                    },
                    {
                        'name': 'Missouri',
                        'abbreviation': 'MO'
                    },
                    {
                        'name': 'Montana',
                        'abbreviation': 'MT'
                    },
                    {
                        'name': 'Nebraska',
                        'abbreviation': 'NE'
                    },
                    {
                        'name': 'Nevada',
                        'abbreviation': 'NV'
                    },
                    {
                        'name': 'New Hampshire',
                        'abbreviation': 'NH'
                    },
                    {
                        'name': 'New Jersey',
                        'abbreviation': 'NJ'
                    },
                    {
                        'name': 'New Mexico',
                        'abbreviation': 'NM'
                    },
                    {
                        'name': 'New York',
                        'abbreviation': 'NY'
                    },
                    {
                        'name': 'North Carolina',
                        'abbreviation': 'NC'
                    },
                    {
                        'name': 'North Dakota',
                        'abbreviation': 'ND'
                    },
                    {
                        'name': 'Northern Mariana Islands',
                        'abbreviation': 'MP'
                    },
                    {
                        'name': 'Ohio',
                        'abbreviation': 'OH'
                    },
                    {
                        'name': 'Oklahoma',
                        'abbreviation': 'OK'
                    },
                    {
                        'name': 'Oregon',
                        'abbreviation': 'OR'
                    },
                    {
                        'name': 'Palau',
                        'abbreviation': 'PW'
                    },
                    {
                        'name': 'Pennsylvania',
                        'abbreviation': 'PA'
                    },
                    {
                        'name': 'Puerto Rico',
                        'abbreviation': 'PR'
                    },
                    {
                        'name': 'Rhode Island',
                        'abbreviation': 'RI'
                    },
                    {
                        'name': 'South Carolina',
                        'abbreviation': 'SC'
                    },
                    {
                        'name': 'South Dakota',
                        'abbreviation': 'SD'
                    },
                    {
                        'name': 'Tennessee',
                        'abbreviation': 'TN'
                    },
                    {
                        'name': 'Texas',
                        'abbreviation': 'TX'
                    },
                    {
                        'name': 'Utah',
                        'abbreviation': 'UT'
                    },
                    {
                        'name': 'Vermont',
                        'abbreviation': 'VT'
                    },
                    {
                        'name': 'Virgin Islands',
                        'abbreviation': 'VI'
                    },
                    {
                        'name': 'Virginia',
                        'abbreviation': 'VA'
                    },
                    {
                        'name': 'Washington',
                        'abbreviation': 'WA'
                    },
                    {
                        'name': 'West Virginia',
                        'abbreviation': 'WV'
                    },
                    {
                        'name': 'Wisconsin',
                        'abbreviation': 'WI'
                    },
                    {
                        'name': 'Wyoming',
                        'abbreviation': 'WY'
                    }
                ];
            },

            allowNumbersOnly: function($event) {
                if (isNaN(String.fromCharCode($event.keyCode))) {
                    $event.preventDefault();
                }
            },

            /**
             * Business rules for pro hourly rate
             * @return {string} formated hourly rate
             */
            hourlyRateFormat: function(hourlyRate) {
                var formattedHourlyRate = hourlyRate,
                    charLimit = 5;

                formattedHourlyRate = formattedHourlyRate.replace(/ /g, '').replace(new RegExp('\\$', 'g'), '').split('-');
                formattedHourlyRate = _.uniq(formattedHourlyRate);

                for (var i = 0; i < formattedHourlyRate.length; i++) {
                    formattedHourlyRate[i] = Number(formattedHourlyRate[i].split('.')[0]);
                }
                if ((formattedHourlyRate[0] < charLimit && formattedHourlyRate[1] === undefined) ||
                    (formattedHourlyRate[0] < charLimit && formattedHourlyRate[1] < charLimit)) {
                    formattedHourlyRate.shift();
                    formattedHourlyRate[0] = 'Not available';
                } else if (formattedHourlyRate[0] === 1) {
                    formattedHourlyRate.shift();
                    formattedHourlyRate[0] = 'Up to $60.00';
                }
                return formattedHourlyRate;
            }

        };
    }]);
