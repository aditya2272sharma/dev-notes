'use strict';

function Configure() {
}

function Run() {
}

(angular
    .module('RelayServicesApp.Services', [])
    .config(Configure)
).run(Run);
