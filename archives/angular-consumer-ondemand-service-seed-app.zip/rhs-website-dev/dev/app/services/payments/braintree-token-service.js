'use strict';

function braintreeValue(_, $q, AbstractService) {

    var factory = {

        token : '',

        /**
         * [getToken description]
         * @param  {boolean} isDefault [description]
         * @return {[type]}      [description]
         */
        requestToken: function(isDefault) {
            var deferred = $q.defer();
            var config = {
                endpoint : 'cards/add/token?default=' + isDefault,
                method: 'GET'
            };

            factory.setConfig(config);

            factory.call().success(function(response) {
                deferred.resolve(response);
            }).error(function(response) {
                deferred.reject(response.error);
            });

            return deferred.promise;
        },
        getToken: function() {
            this.requestToken().then(function() {
                return this.token;
            }, function(err) {
                console.log('Error getting Token:', err);
            });
        },
        setToken: function(res) {
            this.token = res.token;
        }
    };

    // Extends factory with Abstract service
    return angular.extend(factory, AbstractService);
}

braintreeValue.$inject = ['_', '$q', 'AbstractService'];

/**
 * Use this service to get information about checkout info.
 */
(angular
    .module('RelayServicesApp.Services')
).factory('braintreeValue', braintreeValue);
