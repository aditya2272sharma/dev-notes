'use strict';

function NewServiceLocation() {
    var address = {
        firstname: '',
        lastname: '',
        addressLine1: '',
        addressLine2: '',
        country: 'US',
        phone: '',
        contactNo: ''
    };

    var LocationList = {
        firstname: '',
        lastname: '',
        addressLine1: '',
        addressLine2: '',
        country: 'US',
        phone: '1234567890',
        city: '',
        state: '',
        email: '',
        contactNo: ''
    };

    var serviceLocationStatus = false;

    this.setServiceLocation = function(data) {
        address.firstname = data.firstname;
        address.lastname = data.lastname;
        address.addressLine1 = data.addressline1;
        address.addressLine2 = data.addressline2;
        address.zipcode = data.zipcode;
        address.city = data.city;
        address.state = data.state;
        address.email = data.email;
        address.phone = data.phone || data.contactNo;
        address.contactNo = data.phone || data.contactNo;
    };

    this.setServiceLocationList = function(data) {
        LocationList.addressid = data.id;
        LocationList.firstname = data.firstname;
        LocationList.lastname = data.lastname;
        LocationList.addressLine1 = data.addressline1;
        LocationList.addressLine2 = data.addressline2;
        LocationList.zipcode = data.zipcode;
        LocationList.city = data.city;
        LocationList.state = data.state;
        /*LocationList.email = data.email;
        LocationList.phone = data.phone || data.contactNo;
        LocationList.contactNo = data.phone || data.contactNo;*/
    };

    this.setServiceLocationValidity = function(data) {
        serviceLocationStatus = data;
    };

    this.getServiceLocation = function() {
        return address;
    };

    this.getServiceLocationList = function() {
        return LocationList;
    };

    this.getServiceLocationValidity = function() {
        return serviceLocationStatus;
    };

    this.resetServiceLocationStatus = function() {
        serviceLocationStatus = false;
    };

    this.resetServiceLocation = function() {
        address.addressLine1 = '';
        address.addressLine2 = '';
        address.phone = '';
        address.contactNo = '';
    };
    this.resetServiceLocationList = function() {
        address.addressLine1 = '';
        address.addressLine2 = '';
        address.addressid = '';
    };
}

NewServiceLocation.$inject = ['_'];

/**
 * Use this service to get information about projects' categories.
 */
(angular
    .module('RelayServicesApp.Services')
).service('NewServiceLocation', NewServiceLocation);
