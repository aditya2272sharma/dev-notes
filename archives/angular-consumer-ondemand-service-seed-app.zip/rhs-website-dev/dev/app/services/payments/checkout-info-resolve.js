'use strict';

/**
* Allows to check session before any request
* @return {Object} The promise with response data
*/
function CheckoutInfoResolve($q, $timeout, $state, CheckoutInfoService) {
    if (CheckoutInfoService.hasCheckout()) {
        return $q.resolve(CheckoutInfoService.getCheckout());
    }
    $timeout(function() {
        $state.go('home.new');
    }, 0);
    return $q.reject();
}

CheckoutInfoResolve.$inject = [
    '$q', '$timeout', '$state', 'CheckoutInfoService'
];

module.exports = CheckoutInfoResolve;
