'use strict';

/**
* Callback function when scroll to get order summary fixed no footer overlapped
* @return {Object} The promise with response data
*/
function OrderSummaryFixed($window) {
    return {
        scrollCallback: function() {
            var orderSummary = document.getElementsByClassName('page-sidebar')[0];
            var footer = document.getElementsByClassName('main-footer')[0];
            var topToChange = Math.max(0, 200 - $window.pageYOffset);
            if (footer instanceof HTMLElement && orderSummary instanceof HTMLElement) {
                if ($window.pageYOffset > (footer.offsetTop - orderSummary.offsetHeight) && $window.innerWidth >= 600) {
                    topToChange = (footer.offsetTop - orderSummary.offsetHeight) - $window.pageYOffset;
                }
            }
            angular.element(orderSummary).css('top', topToChange + 'px');
        }
    };
}

OrderSummaryFixed.$inject = ['$window'];

(angular
    .module('RelayServicesApp.Services')
).factory('OrderSummaryFixed', OrderSummaryFixed);
