'use strict';

function PaymentAddressesService(_, $q, AbstractService) {
    /**
     * User Object allows to normalize data
     * @param {Object} [data={}] - The raw json response
     */
    var Address = function(data) {
        /*if (data.fullname) {
            var fullname = data.fullname.split(' ');
            data.firstName = fullname.splice(0, 1).join(' ');
            data.lastName = fullname.join(' ');
        }*/
        data.firstName = (data.firstName === undefined) ? data.firstname : data.firstName;
        data.lastName = (data.lastName === undefined) ? data.lastname : data.lastName;
        var zipcode = data.zipCode;
        if (!zipcode) {
            zipcode = data.zipcode;
        }
        var addressline1 = data.addressline1;
        if (!addressline1) {
            addressline1 = data.addressLine1;
        }
        var addressline2 = data.addressline2;
        if (!addressline2 && addressline2 !== '') {
            addressline2 = data.addressLine2;
        }

        var model = {
            id: data.id || '',
            title: data.firstName + ' ' + data.lastName,
            firstname: data.firstName,
            lastname: data.lastName,
            addressline1: addressline1,
            addressline2: addressline2,
            city: data.city,
            state: data.state,
            zipcode: zipcode,
            country: data.country
        };

        return model;
    };

    var factory = {
        //Expose user model
        Address: Address,
        /**
         * Gets a cards list
         * @return {Promise} A Promise containing the active user's cards list
         */
        list: function() {
            var deferred = $q.defer();
            var config = {
                endpoint : 'cards/addresses',
                method: 'GET'
            };

            factory.setConfig(config);

            factory.call().success(function(response) {
                deferred.resolve(_.map(response.data, function(address) {
                    return new Address(address);
                }));
            }).error(function(response) {
                deferred.reject(response.error);
            });

            return deferred.promise;
        },
        /**
         * Inserts a card
         * @return {Promise} A Promise containing the inserted card
         */
        insert: function(card) {
            var deferred = $q.defer();
            var config = {
                endpoint : 'cards/addresses',
                method: 'POST',
                data: card,
                requestBody: 'form'
            };

            factory.setConfig(config);

            factory.call().success(function(response) {
                deferred.resolve(new Address(response));
            }).error(function(response) {
                deferred.reject(response.error);
            });

            return deferred.promise;
        },
        /**
         * Update a card
         * @return {Promise} A Promise containing the inserted card
         */
        edit: function(id, card) {
            var deferred = $q.defer();
            var config = {
                endpoint : 'cards/addresses/' + id,
                method: 'POST',
                data: card,
                requestBody: 'form'
            };

            factory.setConfig(config);

            factory.call().success(function(response) {
                deferred.resolve(new Address(response));
            }).error(function(response) {
                deferred.reject(response.error);
            });

            return deferred.promise;
        },
        /**
         * Delete a card
         * @return {Promise} A Promise containing the inserted card
         */
        remove: function(id) {
            var deferred = $q.defer();
            var config = {
                endpoint : 'cards/addresses/' + id,
                method: 'DELETE',
                requestBody: 'form'
            };

            factory.setConfig(config);

            factory.call().success(function(response) {
                deferred.resolve(response);
            }).error(function(response, status, headers, config, statusText, xhrStatus) {
                var error = {
                    response: response,
                    status: status,
                    headers: headers,
                    config: config,
                    statusText: statusText,
                    xhrStatus: xhrStatus
                };
                deferred.reject(error);
            });

            return deferred.promise;
        }
    };

    // Extends factory with Abstract service
    return angular.extend(factory, AbstractService);
}

PaymentAddressesService.$inject = ['_', '$q', 'AbstractService'];

/**
 * Use this service to get information about projects' categories.
 */
(angular
    .module('RelayServicesApp.Services')
).factory('PaymentAddressesService', PaymentAddressesService);
