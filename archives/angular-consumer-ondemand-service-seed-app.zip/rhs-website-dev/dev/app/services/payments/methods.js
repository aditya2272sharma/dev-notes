'use strict';

function PaymentMethodsService(_, $q, AbstractService) {

    /**
     * User Object allows to normalize data
     * @param {Object} [data={}] - The raw json response
     */
    var Card = function(data) {
        //Defaults
        var model = (!data.isNew) && {
            id: data.id,
            name: data.name,
            expiry: data.expiry,
            expiremonth: data.expiry.split('/')[0],
            expireyear: data.expiry.split('/')[1],
            default: data.default,
            lastNumbers: data.number.slice(-4),
            type: ({
                'Visa': {
                    id: 'visa',
                    name: 'VISA'
                },
                'American Express': {
                    id: 'amex',
                    name: 'AMEX'
                },
                'JCB': {
                    id: 'jcb',
                    name: 'JCB'
                },
                'Discover': {
                    id: 'discover',
                    name: 'Discover'
                },
                'Diners Club': {
                    id: 'diners',
                    name: 'Diners Club'
                },
                'Maestro': {
                    id: 'maestro',
                    name: 'Maestro'
                },
                'MasterCard': {
                    id: 'mc',
                    name: 'MasterCard'
                }
            })[data.cardType]
        } || {
            nonce: data.nonce,
            number: data.number,
            name: data.cardholderName,
            securitycode: data.cvv,
            expiremonth: data.expirationMonth,
            expireyear: data.expirationYear
        };

        return model;
    };

    var YearList = function() {
        var list = [];
        var year = new Date().getFullYear();

        for (var i = year; i < year + 10; i++) {
            list.push(i.toString());
        }

        return list;
    };

    var MonthList = function() {
        var list = [];

        for (var i = 0; i < 12; i++) {
            list.push(((i + 1)));
        }

        return list;
    };

    var factory = {
        //Expose user model
        Card: Card,
        YearList: YearList,
        MonthList: MonthList,
        /**
         * Gets a cards list
         * @return {Promise} A Promise containing the active user's cards list
         */
        list: function() {
            var deferred = $q.defer();
            var config = {
                endpoint : 'cards',
                method: 'GET',
                preloadInclude: true,
                preloadContainer: '.page-section-payment-method .table-responsive',
                preloadZIndex: 1
            };

            factory.setConfig(config);

            factory.call().success(function(response) {
                deferred.resolve(_.map(response.data, function(card) {
                    return new Card(card);
                }));
            }).error(function(response) {
                deferred.reject(response.error);
            });

            return deferred.promise;
        },
        /**
         * Inserts a payment method using
         * @return {Promise} A Promise containing the inserted card
         */
        insert: function(card) {
            var deferred = $q.defer();
            var config = {
                endpoint : 'cards',
                method: 'POST',
                data: card,
                requestBody: 'form',
                preloadInclude: true,
                preloadContainer: '.page-section-payment-method .add-credit-card-block',
                preloadZIndex: 1
            };

            factory.setConfig(config);

            factory.call().success(function(response) {
                deferred.resolve(new Card(response));
            }).error(function(response) {
                deferred.reject(response);
            });

            return deferred.promise;
        },
        /**
         * [register description]
         * @param  {[type]} nonce [description]
         * @return {[type]}       [description]
         */
        register: function(nonce) {
            var deferred = $q.defer();
            var config = {
                endpoint : 'cards',
                method: 'POST',
                data: {nonce: nonce},
                requestBody: 'form'
            };

            factory.setConfig(config);

            factory.call().success(function(response) {
                deferred.resolve(response);
            }).error(function(response) {
                deferred.reject(response);
            });

            return deferred.promise;
        },
        /**
         * Removes a payment method
         * @param  {string} id The ID of the payment method
         * @return {Object}    The Promise of the request sent
         */
        remove: function(id) {
            var deferred = $q.defer();
            var config = {
                endpoint : 'cards/delete',
                method: 'POST',
                data: {
                    cardid: id
                },
                requestBody: 'form',
                preloadInclude: true,
                preloadContainer: '.page-section-payment-method .table-responsive',
                preloadZIndex: 1
            };

            factory.setConfig(config);

            factory.call().success(function(response) {
                deferred.resolve(response);
            }).error(function(response) {
                deferred.reject(response);
            });

            return deferred.promise;
        },
        /**
         * Sets a payment method as default
         * @param  {string} id The ID of the payment method
         * @return {Object}    The Promise of the request sent
         */
        editDefault: function(id, isDefault) {
            var deferred = $q.defer();
            var config = {
                endpoint : 'cards/default',
                method: 'POST',
                data: {
                    cardid: id,
                    default: isDefault
                },
                requestBody: 'form',
                preloadInclude: true,
                preloadContainer: '.page-section-payment-method .add-credit-card-block',
                preloadZIndex: 1
            };

            factory.setConfig(config);

            factory.call().success(function(response) {
                deferred.resolve(response);
            }).error(function(response) {
                deferred.reject(response);
            });

            return deferred.promise;
        }
    };

    // Extends factory with Abstract service
    return angular.extend(factory, AbstractService);
}

PaymentMethodsService.$inject = ['_', '$q', 'AbstractService'];

/**
 * Use this service to get information about projects' categories.
 */
(angular
    .module('RelayServicesApp.Services')
).factory('PaymentMethodsService', PaymentMethodsService);
