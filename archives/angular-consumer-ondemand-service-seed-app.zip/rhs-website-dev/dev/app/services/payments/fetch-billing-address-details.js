'use strict';

function NewBillingAddress() {
    var address = {
        firstname: '',
        lastname: '',
        addressLine1: '',
        addressLine2: '',
        zipcode: '',
        city: '',
        state: '',
        country: 'US'
    };

    var billingAddressStatus = false;

    this.setBillingAddress = function(data) {
        address.firstname = data.firstname;
        address.lastname = data.lastname;
        address.addressLine1 = data.addressline1;
        address.addressLine2 = data.addressline2;
        address.zipcode = data.zipcode;
        address.city = data.city;
        address.state = data.state;
    };

    this.setBillingAddressValidity = function(data) {
        billingAddressStatus = data;
    };

    this.getBillingAddress = function() {
        return address;
    };

    this.getBillingAddressValidity = function() {
        return billingAddressStatus;
    };

    this.resetBillingAddressStatus = function() {
        billingAddressStatus = false;
    };

    this.resetBillingAddress = function() {
        address.firstname = '';
        address.lastname = '';
        address.addressLine1 = '';
        address.addressLine2 = '';
        address.zipcode = '';
        address.city = '';
        address.state = '';
    };
}

NewBillingAddress.$inject = ['_'];

/**
 * Use this service to get information about projects' categories.
 */
(angular
    .module('RelayServicesApp.Services')
).service('NewBillingAddress', NewBillingAddress);
