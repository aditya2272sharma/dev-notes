var braintreeValue = {
    token : ''
};

module.exports = braintreeValue;
