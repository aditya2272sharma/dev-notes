'use strict';

function NewPaymentMethod() {

    var card = {
        isNew: true,
        number: '',
        cardholderName: '',
        expirationMonth: '',
        expirationYear: '',
        cvv: '',
        isDefault: false
    };

    var paymentMethodStatus = false;

    this.setPaymentMethod = function(data) {
        if (data) {
            card.isNew = data.isNew;
            card.number = data.number;
            card.cardholderName = data.cardholderName;
            card.expirationMonth = data.expirationMonth;
            card.expirationYear = data.expirationYear;
            card.cvv = data.cvv;
            card.isDefault = data.isDefault;
        }
    };

    this.setPaymentMethodValidity = function(data) {
        paymentMethodStatus = data;
    };

    this.getPaymentMethod = function() {
        return card;
    };

    this.getPaymentMethodValidity = function() {
        return paymentMethodStatus;
    };

    this.resetpaymentMethodStatus = function() {
        paymentMethodStatus = false;
    };

    this.resetpaymentMethod = function() {
        card.isNew = true;
        card.number = '';
        card.cardholderName = '';
        card.expirationMonth = '';
        card.expirationYear = '';
        card.cvv = '';
        card.isDefault = false;
    };
}

NewPaymentMethod.$inject = ['_'];

/**
 * Use this service to get information about projects' categories.
 */
(angular
    .module('RelayServicesApp.Services')
).service('NewPaymentMethod', NewPaymentMethod);
