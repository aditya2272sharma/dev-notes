'use strict';

function PaymentProcessService(_, $q, AbstractService) {

    var factory = {
        /**
         * Charges a card with a payment
         * @return {Promise} A Promise containing the inserted card
         */
        charge: function(data) {
            var deferred = $q.defer();
            var config = {
                endpoint : 'cards/charge',
                method: 'POST',
                data: data,
                requestBody: 'form',
                preloadInclude: true
            };

            factory.setConfig(config);

            factory.call().success(function(response) {
                deferred.resolve(response);
            }).error(function(response) {
                deferred.reject(response);
            });

            return deferred.promise;
        }
    };

    // Extends factory with Abstract service
    return angular.extend(factory, AbstractService);
}

PaymentProcessService.$inject = ['_', '$q', 'AbstractService'];

/**
 * Use this service to get information about projects' categories.
 */
(angular
    .module('RelayServicesApp.Services')
).factory('PaymentProcessService', PaymentProcessService);
