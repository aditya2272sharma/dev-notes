'use strict';

function CheckoutInfoService() {
    var checkout;

    this.setCheckout = function(value) {
        checkout = value;
    };

    this.getCheckout = function() {
        var _checkout = checkout;
        checkout = undefined;
        return _checkout;
    };

    this.hasCheckout = function() {
        return !!checkout;
    };
}

CheckoutInfoService.$inject = ['_'];

/**
 * Use this service to get information about checkout info.
 */
(angular
    .module('RelayServicesApp.Services')
).service('CheckoutInfoService', CheckoutInfoService);
