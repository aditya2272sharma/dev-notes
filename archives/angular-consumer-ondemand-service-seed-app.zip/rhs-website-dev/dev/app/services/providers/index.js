'use strict';

function Provider(_, $q, AbstractService, SettingsService) {
    var _list = [
        {
            id: 'smartplumbing',
            name: 'Smart Plumbing',
            image: 'assets/img/pro-card-smartplumbing.png',
            type: {
                id: 'plumber',
                name: 'Plumber',
                largeName: 'Plumber'
            },
            zip: 60601,
            startingPrice: 124.00,
            feedback: 0.94,
            reviews: 26,
            description: [
                'I believe that a business build on personal attention ',
                'and exceptional service while focusing on superior ',
                'quality and timely completion, it can only succeed. ',
                'The amount of this success has to be re-measured every ',
                'day based...'
            ].join('')
        },
        {
            id: 'completehomerepair',
            name: 'Complete Home Repair',
            image: 'assets/img/pro-card-completehomerepair.png',
            type: {
                id: 'handyman',
                name: 'Handyman',
                largeName: 'Handy Man'
            },
            zip: 60601,
            startingPrice: 124.00,
            feedback: 0.94,
            reviews: 26,
            description: [
                'I believe that a business build on personal attention ',
                'and exceptional service while focusing on superior ',
                'quality and timely completion, it can only succeed. ',
                'The amount of this success has to be re-measured every ',
                'day based...'
            ].join('')
        }
    ];

    /**
     * Firm model
     * @param {Object} data Raw json
     */
    var FirmCollection = function(data) {
        var model = data.data[0];
        model.logo = model.logo ? model.logo : SettingsService.AssetsPaths.DEFAULT_PROVIDER_IMAGE;
        if (model.policy) {
            model.policy.warranty = model.policy.warrantyLaborMonths + ' Months';
            if (model.policy.freeEstimates) {
                model.policy.consultation = 'Free';
            } else {
                model.policy.consultation = 'Fee';
            }
        }
        /*if (model.hourlyRate) {
            model.hourlyRate = UtilsService.hourlyRateFormat(model.hourlyRate);
        }*/
        if (model.providerFirmKPI) {
            if (model.providerFirmKPI.arriveInWindow === '0.00 %') {
                model.providerFirmKPI.arriveInWindow = 'Data Not Available';
            } else {
                model.providerFirmKPI.arriveInWindow = parseInt(model.providerFirmKPI.arriveInWindow) + '% of time';
            }
            if (model.providerFirmKPI.averageTimeToAccept === '1') {
                model.providerFirmKPI.averageTimeToAccept = model.providerFirmKPI.averageTimeToAccept + 'hours on average';
            } else if (model.providerFirmKPI.averageTimeToAccept === 'NA') {
                model.providerFirmKPI.averageTimeToAccept = 'Data Not Available';
            } else {
                model.providerFirmKPI.averageTimeToAccept = model.providerFirmKPI.averageTimeToAccept + 'hours on average';
            }
        }
        _.forEach(model.insurances, function(item) {
            item.verified = item.isVerified ? 'Yes' : 'No';
        });
        if (model.reviews) {
            _.forEach(model.reviews.review, function(item) {
                item.photo = item.photo ? item.photo : SettingsService.AssetsPaths.DEFAULT_AVATAR_IMAGE;
            });
        }
        return model;
    };

    var factory = {
        /**
         * Gets provider by id
         * @return {Promise} A Promise containing the provider info.
         */
        getProviderById: function(firmId, serviceType) {
            var deferred = $q.defer();
            var config = {
                endpoint : 'firms?ids=' + firmId + '&details=true' + '&serviceType=' + serviceType,
                method: 'GET',
                preloadInclude: true
            };
            factory
            .setConfig(config)
            .call()
            .success(function(response) {
                var firms = new FirmCollection(response);
                deferred.resolve(firms);
            }).error(function(response) {
                deferred.reject(response);
            });

            return deferred.promise;
        },

        list: function() {
            return $q.resolve(_list);
        },

        get: function(id) {
            return $q.resolve(_.find(_list, ['id', id]));
        },
        getProviderReviewsById: function() {
            var deferred = $q.defer();
            var config = {
                endpoint : 'reviews/firms?limit=10&offset=1',
                method: 'GET',
                preloadInclude: true
            };
            factory
            .setConfig(config)
            .call()
            .success(function(bvResponse) {
                deferred.resolve(bvResponse);
            }).error(function(response) {
                deferred.reject(response);
            });

            return deferred.promise;
        }
    };

    // Extends factory with Abstract service
    return angular.extend(factory, AbstractService);
}

Provider.$inject = ['_', '$q', 'AbstractService', 'SettingsService'];

(angular
    .module('RelayServicesApp.Services')
).service('Provider', Provider);
