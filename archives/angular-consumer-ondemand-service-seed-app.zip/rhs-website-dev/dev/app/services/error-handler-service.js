'use strict';

function ErrorHandler(SettingsService) {
    return {
        /**
        * Dummy description
        * @param  {number} param1 dummy param
        * @param  {boolean} param2 dummy param
        * @param  {Object} param3 dummy param
        */
        displayZipCodeErrorMessage: function(error, ctrl, form) {
            if (form) {
                // setting the form to invalid, so that error messages can appear
                // and submit button gets disabled (if present)
                form.$invalid = true;
            }
            switch (error.status) {
              case 404:
              case '404':
                  ctrl.nonServiceableZipCodeErrorMessage = SettingsService.Error.NON_SERVICEABLE_ZIP_CODE;
                  // re-direction no longer used
                  // $state.go('wearegrowing');
                  break;
              case 400:
              case '400':
                  ctrl.nonServiceableZipCodeErrorMessage = SettingsService.Error.INVALID_ZIP_CODE;
                  break;
              case -1:
                  ctrl.nonServiceableZipCodeErrorMessage = error.message;
                  break;
    
              default:
                  // case 'matches none':
                  // the location error shows an error message in <h3> tag
                  // in case of a non-serviceable zipcode it is desirable to
                  // not show that message and instead show an error that'd
                  // look more like a form-validation error
                  ctrl.locationError = true;
                  ctrl.nonServiceableZipCodeErrorMessage = error && error.message || 'Unknown error occured';
            }
            // in future we can add more error-code specific handling
            // right now, for all failures, the following will be the
            // default behaviour
            // ctrl.locationError = false;
            // ctrl.messageLabel.NO_PROS_MSG = error.response && error.response.message || '';
        },

        /**
        * Primarily meant for dev/app/pages/standard-services/results/index.js
        * But should be customizable to be plugged anywhere & re-purposed
        * Handles estimates error callbacks
        * @param  {object} error eror message or object received in callback
        * @param  {object} ctrl controller of the original route/component/form
        * @param  {object} form to validate/in-validate inputs in the end
        */
        displayEstimatesErrorMessage: function(error, ctrl, form) {
            if (form) {
                // setting the form to invalid, so that error messages can appear
                // and submit button gets disabled (if present)
                form.$invalid = true;
            }

            switch (ctrl.project.serviceType) {
                case SettingsService.ServiceTypes.STANDARD:
                    ctrl.isCardEstimateExist = false;
                    break;

                case SettingsService.ServiceTypes.NON_STANDARD:
                break;

                case SettingsService.ServiceTypes.STANDARD_FIXED_PRICE:
                  if (error && (error.status === 404 || error.status === -1)) {
                      ctrl.messageLabel.NO_PROS_MSG = error.response && error.response.message || '';
                      ctrl.card = false;
                      // Handle showing Draft Projects in SSv2
                      if (ctrl.feautreDraftProject) {
                          ctrl.showDraftProjectsCard = true;
                      }
                  }
                break;

                case SettingsService.ServiceTypes.REPAIR:
                case SettingsService.ServiceTypes.STANDARDV3:
                case SettingsService.ServiceTypes.TECHTALK:
                break;
                default:
            }

            ctrl.messageLabel.CURRENT = error && error.message ? error.message : ctrl.messageLabel.DEFAULT;
        },


        displayAddressDeleteError: function(error, ctrl) {
          console.log('Error while deleting address');
          angular.noop(error, ctrl);
          switch (error.status) {
            case 403:
            case '403':
            case -1:
                // separate because we intend to show a new message later, other than DEFAULT_ERROR
                ctrl.messageLabel.CURRENT = error && error.message ? error.message : SettingsService.Error.DEFAULT_ERROR;
                console.log('Error: Failed to delete address', error);
            break;
            default:
                ctrl.messageLabel.CURRENT = error && error.message ? error.message : SettingsService.Error.DEFAULT_ERROR;
                console.log('Error:', error);
          }
        }
    };
}

ErrorHandler.$inject = ['SettingsService'];

/**
 * Use this service to handle all common error messages
 */
angular
.module('RelayServicesApp.Services')
.service('ErrorHandler', ErrorHandler);
