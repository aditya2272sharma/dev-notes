'use strict';

/**
* Use this manager to get different operations for login
*/
angular.module('RelayServicesApp.Services').factory('RepairLastStepModalService',
    ['$rootScope', '$q', '$state', 'AbstractService', '$uibModal',
    function($rootScope, $q, $state, AbstractService, modal) {

        var factory = {

            /**
             * [signInInit description]
             * @return {[type]}           [description]
             */
            openModal : function(project, selectedFirm, callbackOnOpen, callbackOnClose) {

                var modalInstance = modal.open({
                    animation: true,
                    size: 'md',
                    controller: 'RepairLastStepCtrl',
                    controllerAs: 'RepairLastStepCtrl',
                    windowClass: 'modal-repair-last-step',
                    templateUrl: [
                        'assets/templates/pages/repair/repair-last-step-modal/',
                        'index.html'
                    ].join(''),
                    resolve: {
                        project: function() {
                            return project;
                        },
                        selectedFirm: function() {
                            return selectedFirm;
                        }
                    }
                });

                modalInstance.result.then(function() {
                    if (callbackOnOpen) {
                        callbackOnOpen();
                    }
                }, function(where) {
                    if (callbackOnClose) {
                        callbackOnClose();
                    }
                    switch (where) {
                        case 'home': return $state.go('home.main');
                    }
                });
                return modalInstance;
            }

        };

        //Extends factory with Abstract service
        return angular.extend(factory, AbstractService);
    }]
);
