'use strict';

function ContactUsService($http, $q, _, AbstractService) {

    var factory = {
        getContactRequestData: function(contactForm, imageURL) {
            var data = {
                firstname : contactForm.firstname,
                lastname : contactForm.lastname,
                contactno : contactForm.phone,
                email : contactForm.email,
                zipcode: contactForm.zipcode,
                reasonId : contactForm.contactUsReason,
                message : contactForm.message,
            };
            if (imageURL && imageURL !== '') {
                data.imageurl = imageURL;
            }
            return data;
        },

        submitContact: function(contactForm, imageURL) {
            var deferred = $q.defer(),

            config = {
                endpoint : 'contactus',
                method: 'POST',
                data: factory.getContactRequestData(contactForm, imageURL),
                requestBody: 'form',
                preloadInclude: true
            };

            factory
            .setConfig(config)
            .call()
            .success(function(response) {
                deferred.resolve(response);
            })
            .error(function(response) {
                deferred.reject(response);
            });
            return deferred.promise;
        },

        getContactReasons: function() {
            var deferred = $q.defer(),

            config = {
                endpoint : 'contactus',
                method: 'GET',
                requestBody: 'form',
                preloadInclude: true
            };

            factory
            .setConfig(config)
            .call()
            .success(function(response) {
                deferred.resolve(response);
            })
            .error(function(response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }
    };

    // Extends factory with Abstract service
    return angular.extend(factory, AbstractService);
}

ContactUsService.$inject = ['$http', '$q', '_', 'AbstractService'];

angular
    .module('RelayServicesApp.Services')
    .service('ContactUsService', ContactUsService);
