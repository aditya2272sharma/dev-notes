'use strict';

angular.module('RelayServicesApp.Services').factory('estimateRejectConfirmationService',
    ['$rootScope', '$q', '$state', 'AbstractService', '$uibModal',
    function($rootScope, $q, $state, AbstractService, modal) {
        var factory = {
            openModal : function(callback, projectDetails, estimateDetails, callbackOnOpen, callbackOnClose) {
                var modalInstance = modal.open({
                    animation: true,
                    size: 'md',
                    controller: 'RejectConfirmationController',
                    controllerAs: 'RejectConfirmationController',
                    templateUrl: [
                        'assets/templates/pages/account/myBookings/estimate-reject-confirmation/index.html'
                    ].join(''),
                    resolve: {
                        callback: function() {
                            return callback;
                        },
                        projectDetails: function() {
                            return projectDetails;
                        },
                        estimateDetails : function() {
                            return estimateDetails;
                        }
                    }
                });
                modalInstance.result.then(function() {
                    if (callbackOnOpen) {
                        callbackOnOpen();
                    }
                }, function() {
                    if (callbackOnClose) {
                        callbackOnClose();
                    }
                });
                return modalInstance;
            }
        };
        return angular.extend(factory, AbstractService);
    }]
);
