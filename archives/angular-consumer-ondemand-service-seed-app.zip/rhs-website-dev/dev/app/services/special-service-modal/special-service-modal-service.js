'use strict';

/**
* Use this manager to get different operations for login
*/
angular.module('RelayServicesApp.Services').factory('specialServiceModalService',
    ['$rootScope', '$q', '$state', 'AbstractService', '$uibModal',
    function($rootScope, $q, $state, AbstractService, modal) {

        var factory = {

            /**
             * [signInInit description]
             * @return {[type]}           [description]
             */
            openModal : function(callbackOnOpen, callbackOnClose, categoryId) {

                var modalInstance = modal.open({
                    animation: true,
                    size: 'md',
                    controller: 'SpecialProjectCtrl',
                    controllerAs: 'SpecialProjectCtrl',
                    windowClass: 'modal-special-project',
                    templateUrl: [
                        'assets/templates/pages/projects/create/special-service-modal/',
                        'index.html'
                    ].join(''),
                    resolve: {
                        category: function() {
                            return categoryId;
                        }
                    }
                });

                modalInstance.result.then(function() {
                    // TODO: Insert sign-in logic here
                    if (callbackOnOpen) {
                        callbackOnOpen();
                    }
                }, function(where) {
                    if (callbackOnClose) {
                        callbackOnClose();
                    }
                    switch (where) {
                        case 'home': return $state.go('home.main');
                    }
                });
                return modalInstance;
            }

        };

        //Extends factory with Abstract service
        return angular.extend(factory, AbstractService);
    }]
);
