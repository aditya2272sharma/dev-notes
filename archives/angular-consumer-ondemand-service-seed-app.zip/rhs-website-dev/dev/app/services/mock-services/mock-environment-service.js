'use strict';
/**
 * Place here cons like image paths, texts, genaral info
 * @module Services
 */
angular.module('RelayServicesApp.Services').service('MockEnvironmentService',
        [function MockEnvironmentService() {
            return {
                /**
                 * Web site constants
                 */
                mockEnvironmentLocal : {
                    'name' : 'local',
                    'features' : {
                        'featureReschedule' : 'true',
                        'portableScheduler' : 'true',
                        'bookAServiceBanner' : 'true',
                        'guaranteeBanner' : 'true',
                        'earnPointsBanner' : 'true',
                        'customProject' : 'true',
                        'proSearchService' : 'true'
                    },
                    'api' : {
                        'protocol' : 'http',
                        'domain' : 'localhost',
                        'context' : 'api/v1/',
                        'port' : '9090'
                    },
                    'autofill' : {
                        'protocol' : 'http',
                        'domain' : 'af.ch4.sears.com',
                        'context' : 'autofill/',
                        'port' : ''
                    },
                    'cas' : {
                        'domain' : 'ssoqa.shld.net',
                        'context' : 'usr/QA'
                    },
                    'BTsignalId' : '22NwHMc',
                    'cms' : {
                        'context' : 'lpcms/'
                    },
                    'admin' : {
                        'portal' : 'apitest.servicelive.com'
                    }
                }
            };
        }]);
