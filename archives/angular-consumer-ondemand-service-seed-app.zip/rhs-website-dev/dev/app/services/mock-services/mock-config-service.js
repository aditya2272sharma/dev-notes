'use strict';
/**
 * Place here cons like image paths, texts, genaral info
 * @module Services
 */
angular.module('RelayServicesApp.Services').service('MockConfigService',
        [function MockConfigService() {
            return {
                /**
                 * Web site constants
                 */
                mockAppConfiguration : {
                    'appId' : 'RELAY_SERVICES',
                    'appSID' : '24',
                    'storeName' : 'RelayServices',
                    'paramsSpots' : {
                        'pageType' : 'relayServicesHome'
                    }
                }
            };
        }]);
