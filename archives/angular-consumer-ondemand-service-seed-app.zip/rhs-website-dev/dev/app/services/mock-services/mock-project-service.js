'use strict';

/**
 * Place here cons like image paths, texts, genaral info
 * @module Services
 */

angular
        .module('RelayServicesApp.Services')
        .service(
                'MockProjectService',
                [function MockProjectService() {
                    return {
                        /**
                         * Web site constants
                         */
                        mockProject : [
                                {
                                    'estimate' : {
                                        'firmId' : '10202',
                                        'status' : 'FIXED'
                                    },
                                    'orderId' : '13384',
                                    'serviceType' : 'STANDARD',
                                    'title' : 'Toilet - Install / Replace',
                                    'status' : 'CONFIRMED',
                                    'id' : 24151,
                                    'category' : {
                                        'subCategoryDescription' : '<p>Sample. <strong>test</strong></p>'
                                    }
                                },
                                {
                                    'estimate' : {
                                        'firmId' : '10202',
                                        'status' : 'NEW'
                                    },
                                    'orderId' : '13364',
                                    'serviceType' : 'NON_STANDARD',
                                    'title' : 'leakSMART Water Shutoff Install',
                                    'status' : 'WAITING',
                                    'id' : 24087,
                                }],

                        mockEstimate : {
                            'project' : {
                                'title' : 'Faucet - Install / Replace',
                                'userId' : '6243086',
                                'statusCode' : 6000,
                                'category' : {
                                    'image' : '',
                                    'subCategory' : 'Faucet - Install / Replace',
                                    'serviceCode' : '9000105',
                                    'id' : '1000',
                                    'title' : 'General Plumbing & Bathrooms',
                                    'subCategoryDescription' : 'Faucet - Install / Replace',
                                    'rowid' : '30'
                                },
                                'taskDescription' : 'Faucet - Install / Replace',
                                'images' : [''],
                                'createdOn' : '2017-01-19',
                                'startDate' : '2017-01-23',
                                'timeSlot' : '12:00 PM  -  4:00 PM',
                                'internal' : {
                                    'soId' : 'STANDARD_T_9000105_60169_10202_548-1466-0079-73'
                                },
                                'rescheduleStartDate' : null,
                                'rescheduleEndDate' : null,
                                'serviceOrderId' : '548-1466-0079-73',
                                'rescheduleTimeSlotBegin' : null,
                                'rescheduleTimeSlotEnd' : null,
                                'orderId' : '13511',
                                'brand' : null,
                                'problem' : null,
                                'warrantyType' : null,
                                'modelNumber' : null,
                                'serviceType' : 'STANDARD',
                                'contact' : {
                                    'title' : '',
                                    'phone' : '4938798743',
                                    'emailId' : 'manumjose@gmail.com',
                                    'name' : 'Manu Jose'
                                },
                                'status' : 'CONFIRMED',
                                'location' : {
                                    'addressId' : '1063',
                                    'addressLine1' : '#657467',
                                    'addressLine2' : 'Ettumanoor',
                                    'city' : 'Hoffman Estates',
                                    'state' : 'IL',
                                    'zipCode' : '60169',
                                    'street' : '#657467',
                                    'country' : 'US',
                                    'propertyAddress' : '#657467 Ettumanoor',
                                    'fullAddress' : '#657467 Ettumanoor Hoffman Estates IL 60169'
                                },
                                'id' : 25124,
                                'size' : 'SMALL'
                            },
                            'firms' : {
                                'data' : [{
                                    'id' : '10202',
                                    'title' : 'Home Sweet Home Theatre',
                                    'overview' : 'This is a dummy business description              ',
                                    'owner' : 'Brian Schluter',
                                    'rating' : 4.083,
                                    'reviewCount' : 6,
                                    'logo' : 'https://provider.servicelive.com/sl_image/logo/2016/12/21/89/11885789_icon.png',
                                    'numberOfEmployees' : 5,
                                    'yearsOfService' : 12,
                                    'hourlyRate' : '$1.0 - $65.0',
                                    'location' : {
                                        'street1' : 'PO ServiceLive Ave.',
                                        'street2' : 'Suite 123',
                                        'city' : 'Grayslake',
                                        'state' : 'IL',
                                        'zip' : '60030',
                                        'zipExt' : null
                                    },
                                    'services' : null,
                                    'reviews' : null,
                                    'lastCompletedProject' : {
                                        'soId' : '524-0871-8179-21',
                                        'title' : 'title1',
                                        'overview' : 'ojhygcycufd',
                                        'city' : 'Hoffman Estates',
                                        'state' : 'IL',
                                        'zip' : '60179',
                                        'closedDate' : '2016-12-22'
                                    },
                                    'insurances' : null,
                                    'policy' : null,
                                    'warranties' : null,
                                    'license' : null,
                                    'providerFirmKPI' : {
                                        'averageTimeToAccept' : '0.12 ',
                                        'arriveInWindow' : '96.08 %'
                                    },
                                    'active' : true
                                }],
                                'count' : 1
                            },
                            'estimates' : {
                                'data' : [{
                                    'firmId' : '10202',
                                    'bid' : {
                                        'id' : 'STANDARD_T_9000105_60169_10202_548-1466-0079-73',
                                        'price' : 164,
                                        'tax' : 0,
                                        'discount' : 0,
                                        'estimateId' : 'STANDARD_T_9000105_60169_10202_548-1466-0079-73',
                                        'displayPrice' : '164.00',
                                        'displayTax' : '0.00'
                                    },
                                    'status' : 'FIXED'
                                }],
                                'count' : 1
                            }
                        },
                        mockProjectView : {
                            'data' : [{
                                'estimate' : {
                                    'firmId' : '10202',
                                    'status' : 'FIXED'
                                },
                                'orderId' : '13384',
                                'serviceType' : 'STANDARD',
                                'title' : 'Toilet - Install / Replace',
                                'status' : 'CONFIRMED',
                                'id' : 24151
                            }, {
                                'estimate' : {
                                    'firmId' : '10202',
                                    'status' : 'NEW'
                                },
                                'orderId' : '13364',
                                'serviceType' : 'NON_STANDARD',
                                'title' : 'leakSMART Water Shutoff Install',
                                'status' : 'WAITING',
                                'id' : 24087,
                            }],
                            'totalCount' : 2,
                            'count' : 2
                        }
                    };
                }]);
