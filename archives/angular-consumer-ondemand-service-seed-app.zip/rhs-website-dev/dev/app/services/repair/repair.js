'use strict';

function RepairService($q, AbstractService) {

    var factory = {

        getAllProduct: function() {
            var deferred = $q.defer();
            var config = {
                endpoint : 'catalog/repair/products',
                method: 'GET',
                requestBody: 'form',
                preloadInclude: true
            };

            factory
            .setConfig(config)
            .call()
            .success(function(response) {
                deferred.resolve(response);
            }).error(function(response) {
                deferred.reject(response);
            });
            return deferred.promise;
        },

        getProductType: function(merchadiseCode) {
            var deferred = $q.defer();
            var config = {
                endpoint : 'catalog/repair/product/' + merchadiseCode,
                method: 'GET',
                requestBody: 'form',
                preloadInclude: true
            };

            factory
            .setConfig(config)
            .call()
            .success(function(response) {
                deferred.resolve(response);
            }).error(function(response) {
                deferred.reject(response);
            });
            return deferred.promise;
        },

        getAvailableDates: function(data) {
            var deferred = $q.defer();
            var config = {
                endpoint : 'availability?servicecode=' + data.category.serviceCode + '&zipcode=' +
                data.location.zipCode + '&servicetype=' + data.serviceType,
                method: 'GET',
                requestBody: 'form',
                preloadInclude: true
            };

            factory
            .setConfig(config)
            .call()
            .success(function(response) {
                deferred.resolve(response);
            }).error(function() {
                deferred.reject();
            });
            return deferred.promise;
        }
    };

    return angular.extend(factory, AbstractService);
}

RepairService.$inject = ['$q', 'AbstractService'];

/**
 * Use this service to get information about projects.
 */
(angular
    .module('RelayServicesApp.Services')
).factory('RepairService', RepairService);
