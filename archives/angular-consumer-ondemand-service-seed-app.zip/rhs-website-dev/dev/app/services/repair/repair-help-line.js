'use strict';

angular.module('RelayServicesApp.Services').factory('repairHelpLineModalService',
    ['AbstractService', '$uibModal', '$window',
    function(AbstractService, modal, $window) {
        var factory = {
            openModal : function(productDetails) {
                var modalInstance = modal.open({
                    animation: true,
                    size: 'sm',
                    controller: 'RepairHelpLineController',
                    controllerAs: 'RepairHelpLineController',
                    windowClass: 'modal-help-line',
                    templateUrl: [
                        'assets/templates/pages/repair/repair-help-line/index.html'
                    ].join(''),
                    resolve: {
                        productDetails: function() {
                            return productDetails;
                        }
                    }
                });
                modalInstance.result.then(function() {
                    $window.location.reload();
                });
                return modalInstance;
            }
        };
        return angular.extend(factory, AbstractService);
    }]
);
