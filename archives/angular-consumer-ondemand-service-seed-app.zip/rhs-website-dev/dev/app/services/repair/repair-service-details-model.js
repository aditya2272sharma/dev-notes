'use strict';

function RepairDetailsModel() {
    var productDetails = {
        product: '',
        productName: '',
        topProduct: '',
        productFromAll: '',
        brand: '',
        address: '',
        warrantyType: ''
    };

    this.setProductDetails = function(data) {
        productDetails.product = data.product;
        productDetails.productName = data.productName;
        productDetails.topProduct = data.topProduct;
        productDetails.productFromAll = data.productFromAll;
        productDetails.brand = data.brand;
        productDetails.address = data.address;
        productDetails.warrantyType = data.warrantyType;
    };

    this.getProductDetails = function() {
        return productDetails;
    };

    this.resetProductDetails = function() {
        productDetails.product = '';
        productDetails.productName = '';
        productDetails.topProduct = '';
        productDetails.productFromAll = '';
        productDetails.brand = '';
        productDetails.address = '';
        productDetails.warrantyType = '';
    };
}

RepairDetailsModel.$inject = ['_'];

/**
 * Use this service to get information about projects' categories.
 */
(angular
    .module('RelayServicesApp.Services')
).service('RepairDetailsModel', RepairDetailsModel);
