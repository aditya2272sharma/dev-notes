'use strict';

angular.module('RelayServicesApp.Services').factory('repairDetailsModalService',
    ['AbstractService', '$uibModal', '$window',
    function(AbstractService, modal, $window) {
        var factory = {
            openModal : function(productDetails) {
                var modalInstance = modal.open({
                    animation: true,
                    size: 'md',
                    controller: 'RepairServiceDetails',
                    controllerAs: 'RepairServiceDetails',
                    windowClass: 'modal-custom-project',
                    templateUrl: [
                        'assets/templates/pages/repair/repair-service-details/index.html'
                    ].join(''),
                    resolve: {
                        productDetails: function() {
                            return productDetails;
                        }
                    }
                });
                modalInstance.result.then(function() {
                    $window.location.reload();
                });
                return modalInstance;
            }
        };
        return angular.extend(factory, AbstractService);
    }]
);
