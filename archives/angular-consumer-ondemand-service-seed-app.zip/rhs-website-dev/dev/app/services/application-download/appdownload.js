'use strict';

function appdownloadService ($q, AbstractService) {
    var factory = {
        sendEmail: function(email) {
            var deferred = $q.defer();
            var config = {
                endpoint : 'appdownload',
                method: 'POST',
                data: email,
                requestBody: 'form',
                preloadInclude: true
            };

            factory
            .setConfig(config)
            .call()
            .success(function(response) {
                deferred.resolve(response);
            }).error(function(response) {
                deferred.reject(response);
            });

            return deferred.promise;
        }
    };
    return angular.extend(factory, AbstractService);
}

appdownloadService.$inject = ['$q', 'AbstractService'];
(angular
    .module('RelayServicesApp.Services')
).factory('appdownloadService', appdownloadService);
