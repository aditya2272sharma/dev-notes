'use strict';

angular.module('RelayServicesApp.Services').factory('ProjectUpdateModalService',
    ['$rootScope', '$q', '$state', 'AbstractService', '$uibModal',
    function($rootScope, $q, $state, AbstractService, modal) {

        var factory = {

            openModal : function(project, dateInfo, callback, callbackOnOpen, callbackOnClose, config) {
                var modalInstance = modal.open({
                    animation: true,
                    size: 'md',
                    controller: 'ProjectUpdateModalCtrl',
                    controllerAs: 'ProjectUpdateModalCtrl',
                    windowClass: 'modal-update-project',
                    templateUrl: [
                        'assets/templates/pages/projects/project-update-modal/',
                        'index.html'
                    ].join(''),
                    resolve: {
                        project: function() {
                            return project;
                        },
                        dateInfo: function() {
                            return dateInfo;
                        },
                        callback: function() {
                            return callback;
                        },
                        config: function() {
                            if (typeof config === 'object') {
                                return config;
                            }
                            return undefined;
                        }
                    }
                });
                modalInstance.result.then(function() {
                    if (callbackOnOpen) {
                        callbackOnOpen();
                    }
                }, function() {
                    if (callbackOnClose) {
                        callbackOnClose();
                    }
                });
                return modalInstance;
            }

        };

        //Extends factory with Abstract service
        return angular.extend(factory, AbstractService);
    }]
);
