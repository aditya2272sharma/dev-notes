'use strict';

function Reviews($q, AbstractService, _, SettingsService) {
    var _proTech = [];
    /**
     * Questionnaire model
     * @param {Object} data Raw json
     */
    var Questionnaire = function(data) {
        var model = data;
        model.provider = model.companyDetails[0].name;
        _.forEach(model.companyDetails, function(item) {
            item.logo = item.logo ? item.logo : SettingsService.AssetsPaths.DEFAULT_PROVIDER_IMAGE;
        });
        return model;
    };

    var factory = {

        getQuestionnaire: function(params) {
            var deferred = $q.defer();
            var config = {
                endpoint: 'reviews/questionnaire',
                method: 'GET',
                preloadInclude: true,
                params: params
            };
            factory.setConfig(config)
                .call()
                .success(function(response) {
                    var questionnaire = new Questionnaire(response);
                    _proTech = response.companyDetails;
                    deferred.resolve(questionnaire);
                }).error(function(response) {
                deferred.reject(response);
            });
            return deferred.promise;
        },

        getProTechById: function(id) {
            var proTech = [],
                provider = _.find(_proTech, ['id', id]),
                technician = {};
            if (provider) {
                proTech = provider;
                proTech.firmId = provider.id;
            }
            _.forEach(_proTech, function(item) {
                technician = _.find(item.resourceDetails, ['id', id]);
                if (technician) {
                    proTech = technician;
                    proTech.firmId = item.id;
                    proTech.providerId = _.find(item.resourceDetails, ['id', id]).id;
                }
            });

            return proTech;
        },

        addProReview: function(reviewToken, reviewRequest) {
            var deferred = $q.defer();
            var config = {
                endpoint: 'reviews',
                method: 'POST',
                data: JSON.stringify(reviewRequest),
                preloadInclude: true,
                params: {
                    reviewToken: reviewToken
                }
            };
            factory.setConfig(config)
                .call()
                .success(function(response) {
                    deferred.resolve(response);
                }).error(function(response) {
                deferred.reject(response);
            });
            return deferred.promise;
        },

        getReview: function(projectId) {
            var deferred = $q.defer();
            var config = {
                endpoint: 'reviews/getreview?projectId=' + projectId ,
                method: 'GET',
                preloadInclude: true
            };
            factory.setConfig(config)
                .call()
                .success(function(response, status) {
                    if (status === '200') {
                        deferred.resolve(null);
                    } else {
                        deferred.resolve(response);
                    }
                }).error(function(response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }

    };

    // Extends factory with Abstract service
    return angular.extend(factory, AbstractService);
}

Reviews.$inject = ['$q', 'AbstractService', '_', 'SettingsService'];
(angular
	.module('RelayServicesApp.Services')
).factory('Reviews', Reviews);
