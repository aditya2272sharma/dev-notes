'use strict';

/**
 * Application run
 */
function RelayServicesAppRun($rootScope, $state, LoginManagerService, accountModalService) {
    /**
     * Application route state succeed
     */
    $rootScope.$on('$stateChangeSuccess', function(event, toState) {
        if (toState.requiresLogin &&
            !LoginManagerService.getUser().isRegistered &&
            !LoginManagerService.getUser().isAnonymous) {
            if (!toState.dismissDestination) {
                accountModalService.signInInit(false, $state.reload);
            } else {
                accountModalService.signInInit($state.reload, function() {$state.go(toState.dismissDestination);});
            }
        }
        $rootScope.hasHero = toState && toState.params && toState.params.hasHero;

        // Show the header pbx if its hidden
        $rootScope.$emit('show-hide-header-pbx', false);

        // By Default enables the user location edit popup
        $rootScope.$emit('disable-zipcode-updation', false);

        // By Default guest checkout is false
        $rootScope.$emit('guest-checkout', false);
    });
}

RelayServicesAppRun.$inject = [
    '$rootScope',
    '$state',
    'LoginManagerService',
    'accountModalService'
];

module.exports = RelayServicesAppRun;
