'use strict';

global.jQuery = global.$ = require('jquery');
global.angular = require('angular');

require('angular-ui-router');
require('angular-ui-bootstrap');
require('angular-local-storage');
require('angular-password');
require('ng-file-upload');
require('angular-credit-cards');
require('braintree-angular-alpine');
require('angular-cookies');
require('angular-recaptcha');
