'use strict';

function homeCarousel($sce) {
    /* jshint validthis: true */
    var vm = this;
    vm.myInterval = 5000;
    vm.active = 0;
    vm.slides = [
        {
            image: 'assets/img/home-carousel/home-carousel-02.jpg',
            heading: 'Let\'s Get It Fixed',
            copy: $sce.trustAsHtml(
                    'Over the Phone or in your Home.'
                  ),
            id: 0
        },
        {
            image: 'assets/img/home-carousel/home-carousel-03.jpg',
            heading: 'Get a Tech to Your Home',
            copy: $sce.trustAsHtml(
                    'With straight-forward pricing and at your convenience. Book and pay online.'
                  ),
            id: 1
        }
    ];
}

homeCarousel.$inject = ['$sce'];

(angular
    .module('RelayServicesApp.Components')
).component('homeCarousel', {
    // Note: The original template has been archived
    // Instead, a script block has been used to improve the performance
    templateUrl: 'home-carousel.template',
    controller: homeCarousel,
    controllerAs: 'homeCarousel'
});
