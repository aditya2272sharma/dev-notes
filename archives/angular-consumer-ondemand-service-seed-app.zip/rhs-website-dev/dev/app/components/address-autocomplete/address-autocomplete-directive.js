'use strict';
/* global google */
angular
.module('RelayServicesApp.Components')
.directive('googleplace', ['_',
function(_) {
    return {
        require: 'ngModel',
        scope: {
            ngModel: '=',
            details: '=details'
        },
        link: function(scope, element, attrs, model) {
            var options = {
                types: ['address'],
                componentRestrictions: {country: 'us'}
            };

            var googleParameters =  {
                addressComponents: 'address_components',
                //longName: 'long_name',
                shortName: 'short_name'
            };

            scope.gPlace = new google.maps.places.Autocomplete(element[0], options);

            google.maps.event.addListener(scope.gPlace, 'place_changed', function() {
                var geoParts = scope.gPlace.getPlace(),
                    //latitude = geoParts.geometry.location.lat(),
                    //longitude = geoParts.geometry.location.lng(),
                    placeParts = geoParts[googleParameters.addressComponents],
                    finalAddress = {
                        'firstLoad': false,
                        'streetNumber': '',
                        'street': '',
                        'city': '',
                        'state': '',
                        'zipcode': ''
                    };

                _.forEach(placeParts, function(item) {
                    switch (item.types[0]) {
                        case 'street_number': // street number
                            finalAddress.streetNumber = item[googleParameters.shortName];
                            break;
                        case 'route': // address
                            finalAddress.street = item[googleParameters.shortName];
                            break;
                        case 'locality': // city
                            finalAddress.city = item[googleParameters.shortName];
                            break;
                        case 'administrative_area_level_1': // state
                            finalAddress.state = item[googleParameters.shortName];
                            break;
                        case 'postal_code': // zipcode
                            finalAddress.zipcode = item[googleParameters.shortName];
                            break;
                    }
                });

                scope.$apply(function() {
                    scope.details = finalAddress;
                    model.$setViewValue(element.val());
                });
            });
        }
    };
}]);
