'use strict';

angular
.module('RelayServicesApp.Components')
.directive('radioPanel', [
    function() {
        return {
            restrict: 'E',
            scope: {
                panelData: '=',
                selected: '='
            },
            templateUrl: 'assets/templates/components/radio-panel/radio-panel.html',
            link: function(scope) {
                scope.selected = scope.selected || scope.panelData[0].value || null;
                scope.panelData = scope.panelData || [];

                scope.setActive = function(data) {
                    scope.selected = data.value;
                };

                scope.isActive = function(value) {
                    return value === scope.selected;
                };
            }
        };
    }
]);
