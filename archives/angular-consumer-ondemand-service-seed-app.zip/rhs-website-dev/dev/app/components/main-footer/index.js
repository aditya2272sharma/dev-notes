'use strict';

function MainFooter($uibModal) {
    var ctrl = this;
    ctrl.pathName = window.location.pathname;
    ctrl.hidenavigationbar = true;
    if (ctrl.pathName === '/mobile-login' || ctrl.pathName === '/mobile-signup' || ctrl.pathName === '/mobile-recover') {
        ctrl.hidenavigationbar = false;
    }

    ctrl.openAppsModal = function() {

        var modalInstance = $uibModal.open({
            animation: true,
            size: 'md',
            controller: 'ComingAppsModal',
            controllerAs: 'ComingAppsModalCtrl',
            templateUrl: 'assets/templates/components/coming-apps-modal/index.html'
        });

        modalInstance.result.then();
    };
}

MainFooter.$inject = ['$uibModal'];

(angular
    .module('RelayServicesApp.Components')
).component('mainFooter', {
    templateUrl: 'assets/templates/components/main-footer/index.html',
    controller: MainFooter
});
