'use strict';

function ProCard(provider, ProjectsService, CheckoutInfoService,
    $state, $scope, moment,
    LoginManagerService, accountModalService, _,
    $filter, RepairScheduleModalService, SettingsService,
    $rootScope) {

    var ctrl = this;
    $scope.isNumber = angular.isNumber;
    $scope.isCardSelected = true;
    ctrl.timeRanges = SettingsService.DateTime.TimeRanges;
    ctrl.timeRangeSelected = false;
    // ctrl.selectedDate = new Date();
    ctrl.invalidTimeSelected = false;
    ctrl.shouldShowEstimateTime = true;
    ctrl.shouldShowEstimatePrice = (ctrl.provider.packageDetails.serviceType === 'STANDARD_V3') ? false : true;

    // No proce popover
    ctrl.popover = {
        url: 'assets/templates/pages/standard-services/results/no-price.html'
    };

    ctrl.init = function() {
        ctrl.providerName = $filter('safeUrls')(ctrl.provider.title);
        ctrl.shouldShowEstimateTime = (function () {
            return ctrl.provider.packageDetails.supportsPackage &&
                ctrl.provider.packageDetails.serviceType !== 'REPAIR' &&
                ctrl.provider.packageDetails.serviceType !== 'STANDARD_V3' &&
                ctrl.provider.packageDetails.serviceType !== 'STANDARD';
        })();
        if (!ctrl.provider) {
            ctrl.viewMoreLength = ctrl.viewMoreLength || 210;

            ctrl.isValidDate = moment(ctrl.selectedDate).weekday() <= 5;

            return provider.getProviderById(
                ctrl.providerId,
                ctrl.serviceType
            ).then(function(_provider) {
                ctrl.provider = _provider;
                ctrl.viewMoreBtn(ctrl.provider.overview.length);
            });
        }
        $scope.$watch('$ctrl.selectedDate', function() {
            ctrl.isValidDate = moment(ctrl.selectedDate).weekday() <= 5;
        });

        $scope.$watch('$ctrl.alreadySelected', function() {
            if (ctrl.alreadySelected !== ctrl.provider.id) {
                ctrl.removeSelection();
            }
        });

        // restore timeRange & selectedProvider upon re-init() by date-picker
        if ($rootScope.selectedProvider && ctrl.provider.id === $rootScope.selectedProvider.id) {
            ctrl.selectedProvider = $rootScope.selectedProvider;
            if ($rootScope.selectedProvider.selectedTimeRange) {
                ctrl.provider.selectedTimeRange = $rootScope.selectedProvider.selectedTimeRange;
            }
        }
    };

    /**
     * Remove time range selection
     */
    ctrl.removeSelection = function() {
        _.forEach(ctrl.timeRanges, function(timeRange) {
            timeRange.selected = false;
        });
        ctrl.timeRangeSelected = false;
    };

    /**
     * User Object allows to normalize data
     * @param {string} timeRangeSelected - Time rage selected by User
     */
    ctrl.selectTimeRange = function(timeRangeSelected) {
        var clickOnSelected = false;
        ctrl.alreadySelected = ctrl.provider.id;

        if (timeRangeSelected.selected) {
            clickOnSelected = true;
        }
        ctrl.removeSelection();
        if (!clickOnSelected) {
            ctrl.timeRangeSelected = timeRangeSelected;
            timeRangeSelected.selected = true;
        } else {
            ctrl.alreadySelected = '';
        }
        ctrl.invalidTimeSelected = false;
    };

    ctrl.selectTimeRangeForPro = function(timeRange, provider) {
        $rootScope.$broadcast('ProCard:removeSelection', {});
        if (provider === $rootScope.selectedProvider) {
            if (timeRange === $rootScope.selectedProvider.selectedTimeRange) {
                // Clear Provider & Clear Time Range
                $rootScope.selectedProvider = undefined;
                ctrl.provider.selectedTimeRange = undefined;
            } else {
                // only change timeRange
                $rootScope.selectedProvider.selectedTimeRange = timeRange;
                ctrl.provider.selectedTimeRange = timeRange;
            }
        } else {
            $rootScope.selectedProvider = provider;
            $rootScope.selectedProvider.selectedTimeRange = timeRange;
            ctrl.provider.selectedTimeRange = timeRange;
        }
        ctrl.invalidTimeSelected = false;
    };

    ctrl.select = function() {
        ctrl.provider.selected = !ctrl.provider.selected;
        if (!LoginManagerService.getUser().isRegistered) {
            ctrl.onChange({provider: ctrl.provider});
        } else {
            ctrl.onChange({provider: ctrl.provider});
        }
    };

    ctrl.viewMoreBtn = function(descriptionLength) {
        if (descriptionLength > ctrl.viewMoreLength) {
            ctrl.provider.overview = ctrl.provider.overview.substring(0, ctrl.viewMoreLength);
            ctrl.viewMore = true;
        }
    };

    ctrl.performAcceptEstimateOld = function() {
        var projectId = $rootScope.selectedProvider.projectId,
            estimateId = $rootScope.selectedProvider.packageDetails.bid.estimateId,
            decision = 'Accept';
        ProjectsService.acceptOrRejectProjectEstimation(projectId, estimateId, decision)
        .then(function(acceptRejectObject) {
            CheckoutInfoService.setCheckout({
                order: acceptRejectObject,
                project: projectId,
                firm: $rootScope.selectedProvider,
                selectedDate: ctrl.selectedDate,
                selectedTime: $rootScope.selectedProvider.selectedTimeRange.value,
                zipcode: ctrl.zipcode,
                availableDates: $rootScope.availableDates
            });
            if (ctrl.guestCheckout) {
                $state.go('payment.guestCheckout');
            } else {
                $state.go('payment.checkout');
            }
        }, function(error) {
            $scope.messageLabel.CURRENT = error && error.message ? error.message : $scope.messageLabel.DEFAULT;
        });
    };

    ctrl.performAcceptEstimate = function() {
        CheckoutInfoService.setCheckout({
            estimateId: $rootScope.selectedProvider.packageDetails.bid.estimateId,
            project: $rootScope.selectedProvider.projectId,
            firm: $rootScope.selectedProvider,
            selectedDate: ctrl.selectedDate,
            selectedTime: $rootScope.selectedProvider.selectedTimeRange.value,
            zipcode: ctrl.zipcode,
            availableDates: $rootScope.availableDates
        });
        
        $state.go('payment.checkout');
    }

    ctrl.performCheckout = function(provider) {
        if (provider != null) {
            $rootScope.selectedProvider = provider;
            if(!ctrl.shouldShowEstimateTime && ctrl.provider.packageDetails.serviceType === 'STANDARD') {
                $rootScope.selectedProvider.selectedTimeRange = {value:"-"};
            }
            if ($rootScope.selectedProvider.selectedTimeRange) {
                ctrl.performAcceptEstimate();
            } else {
                ctrl.invalidTimeSelected = true;
            }
        } else {
            ctrl.invalidTimeSelected = true;
        }
    };

    ctrl.gotoCheckout = function() {
        if (ctrl.alreadySelected !== ctrl.provider.id) {
            ctrl.invalidTimeSelected = true;
        } else {
            ctrl.invalidTimeSelected = false;
            CheckoutInfoService.setCheckout({
                estimateId: ctrl.provider.packageDetails.bid.estimateId,
                project: ctrl.provider.projectId,
                firm: ctrl.provider,
                selectedDate: ctrl.selectedDate,
                selectedTime: ctrl.timeRangeSelected.value,
                zipcode: ctrl.zipcode,
                availableDates: $rootScope.availableDates
            });
            $state.go('payment.checkout');
        }
    };

    ctrl.gotoCheckoutDemo = function() {
        ProjectsService.create(ctrl.projectData).then(function(response) {
            ctrl.provider.projectId = response.id;
            //If user name starts with Anomymous, please add anonymous field of profile
            if (response.contact.name.split(' ')[0] === 'Anonymous') {
                ctrl.guestCheckout = true;
            }
            ctrl.acceptEstimate();
        }, function(error) {
            ctrl.messageLabel.CURRENT = error && error.message ? error.message : ctrl.messageLabel.DEFAULT;
        });
    };

    ctrl.acceptEstimate = function() {

        var projectId = ctrl.provider.projectId,
            estimateId = ctrl.provider.packageDetails.bid.estimateId,
            decision = 'Accept';
        ProjectsService.acceptOrRejectProjectEstimation(projectId, estimateId, decision)
        .then(function(acceptRejectObject) {
            //console.log(acceptRejectObject);
            CheckoutInfoService.setCheckout({
                order: acceptRejectObject,
                project: projectId,
                firm: ctrl.provider,
                selectedDate: ctrl.selectedDate,
                selectedTime: ctrl.timeRangeSelected.value,
                zipcode: ctrl.zipcode,
                availableDates: $rootScope.availableDates
            });
            if (ctrl.guestCheckout) {
                $state.go('payment.guestCheckout');
            } else {
                $state.go('payment.checkout');
            }
        }, function(error) {
            $scope.messageLabel.CURRENT = error && error.message ? error.message : $scope.messageLabel.DEFAULT;
        });
    };

    ctrl.diagnosticPopover = {
        url: 'assets/templates/pages/repair/repair-provider/diagnosticFeeTemplate.html'
    };

    /** Modal to show images in separate popup **/
    ctrl.scheduleAppointment = function(projectData, selectedProCard) {
        if (projectData && selectedProCard) {
            RepairScheduleModalService.openModal(projectData, selectedProCard);
        }
    };
    
    ctrl.firmSelectionChanged = function() {
        $scope.isCardSelected = !$scope.isCardSelected;
        ctrl.onChange()(ctrl.provider, ctrl.index, $scope.isCardSelected);
    };

    ctrl.init();

    $rootScope.$on('$stateChangeStart', function(event, toState, toParams, fromState) {
        if (toState !== fromState) {
            $rootScope.selectedProvider = null;
        }
    });
}

ProCard.$inject = [
    'Provider', 'ProjectsService', 'CheckoutInfoService',
    '$state', '$scope', 'moment',
    'LoginManagerService', 'accountModalService', '_',
    '$filter', 'RepairScheduleModalService', 'SettingsService',
    '$rootScope'
];

(angular
    .module('RelayServicesApp.Components')
).component('proCard', {
    templateUrl: (
        'assets/templates/components/pro-card/index.html'
    ),
    controller: ProCard,
    bindings: {
        providerId: '<',
        onChange: '&',
        viewDescription: '<',
        hasEstimate: '<',
        selectButton: '<',
        isServiceResult: '<',
        viewMoreLength: '<',
        selectTime: '<',
        provider: '<',
        providerInfo: '<',
        selectedDate: '=',
        zipcode: '=',
        projectData: '<',
        alreadySelected: '=',
        removeSelection: '<',
        isRepairResult: '<',
        startDate: '<',
        serviceType: '<',
        currentProject: '<',
        index: '<'
    }
});
