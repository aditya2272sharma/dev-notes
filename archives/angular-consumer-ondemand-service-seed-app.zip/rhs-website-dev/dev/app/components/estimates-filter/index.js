'use strict';

function EstimatesFilterCtrl(moment) {
    var vm = this;

    vm.isOpen = {
        one: false,
        two: false,
        three: false
    };

    vm.dateOptions = {
        //dateDisabled: disabled,
        // formatYear: 'yy',
        maxDate: new Date(2020, 5, 22),
        minDate: moment().add(1, 'days'),
        startingDay: 0,
        showWeeks: false
    };

    vm.open = function(which) {
        vm.isOpen[which] = !vm.isOpen[which];
    };
}

EstimatesFilterCtrl.$inject = ['moment'];

(angular
    .module('RelayServicesApp.Components')
).component('estimatesFilter', {
    templateUrl: 'assets/templates/components/estimates-filter/index.html',
    controllerAs: 'estimatesFilterCtrl',
    controller: EstimatesFilterCtrl,
    bindings: {
        estimatesData: '=',
        ratingFilter: '<',
        dateFilter: '<'
    }
});
