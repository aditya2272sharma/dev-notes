'use strict';

function ProRegister(BecomeAProService, SettingsService, _) {
    var vm = this;

    vm.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR,
        DISCLAIMER: SettingsService.Messages.DISCLAIMER,
        SUBMITTED: SettingsService.Success.PRO_REGISTER_SUBMITTED,
        SUCCESS: SettingsService.Success.BOOK_A_PRO_SUCCESS
    };

    _.extend(vm.messageLabel, SettingsService.FormValidation);

    vm.submitted = false;
    vm.submitBecomeAPro = function() {
        vm.messageLabel.CURRENT = '';
        BecomeAProService.submitBecomeAPro(vm.registerPro)
        .then(function() {
            vm.messageLabel.SUBMITTED = vm.messageLabel.SUCCESS;
            vm.submitted = true;
            vm.clearBecomeAPro();
        }, function(error) {
            vm.messageLabel.CURRENT = error.message ? error.message : vm.messageLabel.DEFAULT;
        });
    };

    vm.clearBecomeAPro = function() {
        vm.registerPro = {
            businessName : '',
            firstName : '',
            lastName : '',
            email: '',
            phoneNumber: '',
            zipCode: '',
            service: ''
        };
    };

}

ProRegister.$inject = ['BecomeAProService', 'SettingsService', '_'];

(angular
    .module('RelayServicesApp.Components')
).component('proRegister', {
    templateUrl: 'assets/templates/components/pro-register/index.html',
    controller: ProRegister,
    controllerAs: 'ProRegister'
});
