'use strict';

function editProjectCtrl($scope, $uibModalInstance, project,
    UploadsService, ProjectsService, SettingsService) {

    var editProject = {},
        maxImages = 1;

    $scope.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR
    };
    /**
    * Getting initial info
    */
    $scope.init = function() {
        $scope.images = project.images;
        editProject.id = project.id;

        if ($scope.images.length === maxImages) {
            $scope.disabledSelect = true;
        }
    };

    $scope.close = function() {
        $uibModalInstance.dismiss();
    };

    $scope.upload = function(file) {
        if (file !== undefined) {
            $scope.loadingFile = true;
            UploadsService.uploadFile(file).then(function(response) {
                $scope.loadingFile = false;
                $scope.images.push(response.data.url);
            }, function(error) {
                $scope.messageLabel.CURRENT = error && error.message ? error.message : $scope.messageLabel.DEFAULT;
            });
        }
    };

    /**
    * Validates more than 5 images are uploaded at the same time
    */
    $scope.validateImage = function() {
        $scope.disabledSelect = false;
        if ($scope.images.length === maxImages) {
            $scope.disabledSelect = true;
        }
    };

    /**
     * Removes image from images array and remove DOM element
     * @param  {number} index Image index
     * @param  {Object} event click event
     */
    $scope.deleteImage = function(index, event) {
        event.target.parentElement.remove();
        $scope.images.splice(index, 1);
        $scope.disabledSelect = false;
    };

    $scope.submit = function() {
        if ($scope.images.length) {
            editProject.images = $scope.images;
            ProjectsService.update(editProject).then(function() {
                //console.log(project);
                $uibModalInstance.close();
            }, function(error) {
                $uibModalInstance.dismiss();
                $scope.messageLabel.CURRENT = error && error.message ? error.message : $scope.messageLabel.DEFAULT;
            });
        }
    };

    /**
    ******************Init****************
    */
    $scope.init();

}

editProjectCtrl.$inject = ['$scope', '$uibModalInstance', 'project',
    'UploadsService', 'ProjectsService', 'SettingsService'];

(angular
    .module('RelayServicesApp.Components')
).controller('editProjectCtrl', editProjectCtrl);
