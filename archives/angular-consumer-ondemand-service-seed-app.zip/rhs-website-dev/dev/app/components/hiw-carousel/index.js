'use strict';

function HiwCarousel($sce) {
    var vm = this;

    vm.myInterval = 5000;
    vm.active = 0;

    vm.slides = [
        {
            image: 'assets/img/hiw-carousel-01.jpg',
            heading: 'Expert Service You Can Trust',
            copy: $sce.trustAsHtml(
                    'Whether you need an appliance repair, a home improvement, or appliance maintenance, ' +
                    'our thousands of licensed experts, based throughout the U.S., deliver ' +
                    'guaranteed quality and workmanship.'
                  ),
            id: 0
        },
        {
            image: 'assets/img/hiw-carousel-02.jpg',
            heading: 'Know When To Expect Your Pro',
            copy: $sce.trustAsHtml(
                    'We take the guess-work out of when your ServiceLive Pro will arrive. ' +
                    'Our pros have been specifically trained and instructed to respect your time. ' +
                    'We even have a real-time tracking mechanism, in our ServiceLive app, ' +
                    'which helps you track your pro in real time and estimate his/her arrival time.'
                  ),
            id: 1
        },
        {
            image: 'assets/img/hiw-carousel-03.jpg',
            heading: 'Nobody Likes Surprises, Especially When It Comes To Their Bills',
            copy: $sce.trustAsHtml(
                    'We’ve taken the guess-work out of how much you will pay for a ' +
                    'project; simply, by being honest and upfront with you when we ' +
                    'return quotes from multiple pros – be the project a custom or ' +
                    'standard/pre-packaged one.'
                  ),
            id: 2
        }
    ];

}

HiwCarousel.$inject = ['$sce'];

(angular
    .module('RelayServicesApp.Components')
).component('hiwCarousel', {
    templateUrl: 'assets/templates/components/hiw-carousel/index.html',
    controller: HiwCarousel,
    controllerAs: 'hiwCarousel'
});
