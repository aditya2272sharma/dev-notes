'use strict';

function RescheduleReqModalCtrl($scope, $uibModalInstance, $state) {

    var vm = this;
    vm.messageLabel = {
        CURRENT: ''
    };

    vm.init = function() {
    };

    vm.BackToBookings = function() {
        $uibModalInstance.dismiss();
        $state.go('account.my-bookings');
    };

    vm.backToOrder = function() {
        $uibModalInstance.dismiss();
        $state.go($state.current, {}, {reload: true});
    };

    vm.close = function() {
        $uibModalInstance.dismiss();
    };

    vm.init();
}

RescheduleReqModalCtrl.$inject = ['$scope', '$uibModalInstance', '$state'];
(angular
    .module('RelayServicesApp.Components')
).controller('RescheduleReqModalCtrl', RescheduleReqModalCtrl);
