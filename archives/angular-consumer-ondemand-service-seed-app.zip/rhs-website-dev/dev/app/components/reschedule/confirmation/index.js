'use strict';

function rescheduleCtrl($scope, $uibModalInstance, project, $window, modal) {

    $scope.messageLabel = {
        CURRENT: ''
    };

    $scope.init = function() {
    };

    $scope.close = function() {
        $uibModalInstance.dismiss();
    };

    $scope.submit = function() {
        $uibModalInstance.dismiss();
        var modalInstance = modal.open({
            animation: true,
            size: 'md',
            controller: 'RescheduleYourAppointment',
            controllerAs: 'RescheduleYourAppointment',
            resolve: {
                project: function() {
                    return project;
                }
            },
            templateUrl: [
                'assets/templates/components/reschedule/reschedule-your-appointment/',
                'index.html'
            ].join('')
        });

        modalInstance.result.then(function() {
            $window.location.reload();
        });
    };

    $scope.init();
}

rescheduleCtrl.$inject = ['$scope', '$uibModalInstance', 'project', '$window', '$uibModal'];
(angular
    .module('RelayServicesApp.Components')
).controller('rescheduleCtrl', rescheduleCtrl);
