'use strict';

function RescheduleYourAppointment($uibModalInstance, project,
    ProjectsService, SettingsService, _, moment, $filter, modal, $window, $state,
    availableDates) {

    var vm = this;
    vm.estimate = project.estimateObject;
    vm.project = project.projectObject;
    vm.firms = project.firms;
    vm.showComments = false;
    vm.displayFirmAndEstimate = false;
    vm.availableDates = availableDates || [];

    vm.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR
    };

    vm.init = function() {
        vm.enableRescheduleBtn = true;
        if (vm.estimate && vm.firms && vm.firms.data && vm.firms.data.length > 0) {
            vm.displayFirmAndEstimate = false;
        }
        ProjectsService.getRescheduleReasons(vm.project.id).then(function(response) {
            vm.selectedReasonsList = response.data;
        }, function(error) {
            vm.messageLabel.CURRENT = error && error.message ? error.message : vm.messageLabel.DEFAULT;
        });
        vm.invalidDateTime = false;
        if (vm.estimate && vm.estimate.bid) {
            vm.estimate.bid.total = parseFloat(vm.estimate.bid.price) + parseFloat(vm.estimate.bid.tax);
        }
    };

    vm.closeModal = function(path) {
        $uibModalInstance.dismiss();
        $state.go(path, {id: vm.estimate.id});
    };

    vm.close = function() {
        $uibModalInstance.dismiss();
    };
    vm.updateProjectData = function() {
        //1. Reject the pro initiated reschedule
        /*var rejectInfo = {
            'id': vm.estimate.projectId,
            'decision' : 'Reject'
        };
        var promise1 = ProjectsService.acceptRejectProReschedule(rejectInfo);*/
        //2. User - Initiate new reschedule request
        //promise1.then(function() {
        var updatedInfo = {

            // Warning: `vm.project.id` might not be the best way to determine
            // the projectId here, as it tells nothing about the state of the project.
            // Using `vm.estimate.projectId` is a more definitive approach to ensure
            // that only accepted projects get rescheduled.
            'id': vm.project.id,

            'reasoncode' : vm.selectedReason.code,

            // The model value for the <input> remains `undefined` if left unassinged on UI
            // The JSON stringify logic changes that value-type into string.
            // To prevent that, we should pass an empty quote if the value is `undefined`
            'comment': vm.rescheduleComment || ''
        };

        if (vm.project.startDate === null) {
            updatedInfo.startdates = vm.rescheduleDates.join(", ");
            updatedInfo.timeslots = vm.selectedTimeSlots.join(", ");
            ProjectsService.update(updatedInfo).then(function () {
                $window.location.reload();
            }, function (error) {
                vm.messageLabel.CURRENT = error && error.message ? error.message : vm.messageLabel.DEFAULT;
            });
        } else {
            updatedInfo.startdate = vm.rescheduleDate;
            updatedInfo.timeslot = vm.selectedTimeSlot;
            ProjectsService.reschedule(updatedInfo).then(function () {
                $window.location.reload();
            }, function (error) {
                vm.messageLabel.CURRENT = error && error.message ? error.message : SettingsService.Error.DEFAULT_ERROR;
            });
        }
    };

    vm.onReasonChange = function() {
    };

    vm.showRequestModal = function() {
        $uibModalInstance.dismiss();
        var modalInstance = modal.open({
            animation: true,
            size: 'md',
            controller: 'RescheduleReqModalCtrl',
            controllerAs: 'RescheduleReqModalCtrl',
            resolve: {
                project: function() {
                    return project;
                },
                availableDates: function() {
                    return vm.availableDates;
                }
            },
            templateUrl: [
                'assets/templates/components/reschedule/request-modal/',
                'index.html'
            ].join('')
        });

        modalInstance.result.catch(function() {
            $window.location.reload();
        });

        modalInstance.result.then(function() {
            $window.location.reload();
        });
    };

    vm.setRescheduledDate = function(RescheduledDate) {
        vm.rescheduleDate = $filter('date')(RescheduledDate.date, 'yyyy-MM-dd');
        vm.selectedTimeSlot = RescheduledDate.timeSlot;
        vm.rescheduleDates = RescheduledDate.dates;
        vm.selectedTimeSlots = RescheduledDate.timeSlots;
        vm.enableRescheduleBtn = RescheduledDate.rescheduleBtnStatus;
    };

    vm.checkRescheduleStatus = function() {
        return (vm.enableRescheduleBtn || vm.selectedReason === undefined);
    };

    vm.init();
}

RescheduleYourAppointment.$inject = ['$uibModalInstance', 'project',
    'ProjectsService', 'SettingsService', '_', 'moment', '$filter', '$uibModal', '$window', '$state',
    'availableDates'];
(angular
    .module('RelayServicesApp.Components')
).controller('RescheduleYourAppointment', RescheduleYourAppointment);
