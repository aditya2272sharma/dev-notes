'use strict';

function ProReschedule($uibModalInstance, project,
    ProjectsService, SettingsService, modal, $window, $state, $filter, $rootScope,
    availableDates) {

    var vm = this;
    vm.estimate = project.estimate;
    vm.project = project.project;

    vm.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR
    };

    vm.dayHeaderFormat = 'MMMM, EEEE';
    vm.dayFormat = 'd';

    vm.init = function() {
        vm.currentDate = $filter('date')(vm.project.startDate, 'yyyy-MM-dd');
        vm.currentTime = vm.project.timeSlot;
        vm.newDate = $filter('date')(vm.project.rescheduleStartDate, 'yyyy-MM-dd');
        vm.newTime = vm.project.rescheduleTimeSlotBegin + ' - ' + vm.project.rescheduleTimeSlotEnd;
        if (vm.estimate && vm.estimate.bid) {
            vm.estimate.bid.total = parseFloat(vm.estimate.bid.price) + parseFloat(vm.estimate.bid.tax);
        }
    };

    vm.close = function(path) {
        $uibModalInstance.dismiss();
        $state.go(path, {id: vm.estimate.id});
    };

    vm.closeDiv = function() {
        $uibModalInstance.dismiss();
    };

    vm.submit = function(type) {
        if (type === 'Accept' || type === 'Reject') {
            vm.acceptRejectProjectData(type);
        } else if (type === 'Propose') {
            vm.proposeProjectData('Reject');
        }
    };

    vm.acceptRejectProjectData = function(type) {
        var updatedInfo = {
            'id': vm.project.id,
            'decision' : type
        };
        ProjectsService.acceptRejectProReschedule(updatedInfo).then(function() {
            $uibModalInstance.dismiss();
            $state.go($state.current, {}, {reload: true});
        }, function(error) {
            vm.messageLabel.CURRENT = error && error.message ? error.message : vm.messageLabel.DEFAULT;
        });
    };

    vm.proposeProjectData = function(type) {
        var updatedInfo = {
            'id': vm.project.id,
            'decision' : type
        };
        ProjectsService.acceptRejectProReschedule(updatedInfo).then(function() {
            $uibModalInstance.dismiss();
            var projectDetails = {
                estimateObject: vm.estimate,
                projectObject: vm.project
            };
            var modalInstance = modal.open({
                animation: true,
                size: 'md',
                controller: 'RescheduleYourAppointment',
                controllerAs: 'RescheduleYourAppointment',
                resolve: {
                    project: function() {
                        return projectDetails;
                    },
                    availableDates: function() {
                        return availableDates;
                    },
                },
                templateUrl: [
                    'assets/templates/components/reschedule/reschedule-your-appointment/index.html'
                ].join('')
            });
            modalInstance.result.then(function() {
                $window.location.reload();
            });
        }, function(error) {
            vm.messageLabel.CURRENT = error && error.message ? error.message : vm.messageLabel.DEFAULT;
        });
    };

    vm.init();
}

ProReschedule.$inject = ['$uibModalInstance', 'project',
    'ProjectsService', 'SettingsService', '$uibModal', '$window', '$state', '$filter', '$rootScope',
    'availableDates'];
(angular
    .module('RelayServicesApp.Components')
).controller('ProReschedule', ProReschedule);
