'use strict';

function CancelReschedule($uibModalInstance, project, $window, ProjectsService,
    SettingsService, modal, $state) {

    var vm = this;

    vm.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR
    };

    vm.init = function() {
    };

    vm.close = function() {
        $uibModalInstance.dismiss();
    };

    vm.submit = function() {
        vm.cancelReschedule();
    };

    vm.cancelReschedule = function() {
        var updatedInfo = {
            'id': project
        };
        ProjectsService.cancelReschedule(updatedInfo).then(function() {
            $uibModalInstance.dismiss();
            $state.go($state.current, {}, {reload: true});
        }, function(error) {
            vm.messageLabel.CURRENT = error && error.message ? error.message : vm.messageLabel.DEFAULT;
        });
    };

    vm.init();
}

CancelReschedule.$inject = ['$uibModalInstance', 'project', '$window', 'ProjectsService',
'SettingsService', '$uibModal', '$state'];
(angular
    .module('RelayServicesApp.Components')
).controller('CancelReschedule', CancelReschedule);
