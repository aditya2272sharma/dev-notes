'use strict';

function deletePaymentModeCtrl($scope, $uibModalInstance, SettingsService) {
    $scope.message = SettingsService.Messages.DELETE_PAYMENT_MODE_CONFIRMATION_MESSAGE;
    $scope.errorMessage = SettingsService.Error.PAYMENT_MODE_DELETE_ERROR;

    $scope.yesDeleteAddress = function() {
        $uibModalInstance.close(true);
    };

    $scope.dismissPopup = function() {
        $uibModalInstance.dismiss(false);
    };
}

deletePaymentModeCtrl.$inject = ['$scope', '$uibModalInstance', 'SettingsService',
    '$window', '$state'];
(angular
    .module('RelayServicesApp.Components')
).controller('deletePaymentModeCtrl', deletePaymentModeCtrl);
