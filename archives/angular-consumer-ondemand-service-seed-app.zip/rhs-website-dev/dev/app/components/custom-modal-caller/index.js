'use strict';

angular
.module('RelayServicesApp.Components')
.directive('customModalCaller', [
	'CustomProjectService',
	function(CustomProjectService) {
    return {
        restrict:'A',
        link: function(scope) {
            scope.openCustomModal = CustomProjectService.openModal;
        }
    };
	}
]);
