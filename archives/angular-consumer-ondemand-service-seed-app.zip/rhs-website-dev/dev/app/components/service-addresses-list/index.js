'use strict';

function ServiceAddressesList($scope, _, paymentAddressesService, addressesService,
SettingsService, NewServiceLocation, $rootScope, locationService, LoginManagerService) {
    var ctrl = this;

    ctrl.messageLabel = {
        EDIT_ADDRESS: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR,
        SERVICE_UNAVAILABLE_ERROR: SettingsService.Error.SERVICE_UNAVAILABLE_ERROR,
        INVALID_ADDRESS: SettingsService.Error.INVALID_ADDRESS_ERROR
    };
    _.extend(ctrl.messageLabel, SettingsService.FormValidation);

    ctrl.init = function() {
        ctrl.isEditing = false;
        ctrl.serviceLocationNew = undefined;
        ctrl.serviceLocationList = undefined;
        ctrl.serviceLocation = true;
        ctrl.messageLabel.EDIT_ADDRESS = '';
        ctrl.today = new Date();
        ctrl.disableRadioButton = false;
        ctrl.getZipcodeDetails(ctrl.zipcode);
        ctrl.isRegistered = LoginManagerService.getUser().isRegistered;
        addressesService.list().then(function(response) {
            var newFilterList = response;
            if (ctrl.zipcode) {
                newFilterList = _.filter(response, {zipcode: ctrl.zipcode});
            }
            
            ctrl.model = (ctrl.model && (_.find(newFilterList, ctrl.model) || 
                _.find(newFilterList, function(serviceLoc) {
                    return (
                        serviceLoc.addressLine1 === ctrl.model.addressLine1 &&
                        serviceLoc.addressLine2 === ctrl.model.addressLine2 &&
                        serviceLoc.city === ctrl.model.city &&
                        serviceLoc.contactNo === ctrl.model.contactNo &&
                        serviceLoc.zipCode === ctrl.model.zipCode &&
                        serviceLoc.state === ctrl.model.state
                    );
                }))) ||
                _.find(newFilterList, function(serviceLoc) {
                      return (serviceLoc.id == ctrl.currentAddressId);
                }) || _.first(newFilterList);
            ctrl.onLocationChange({serviceLocationList: ctrl.model});

            // For Guest checkout, display only one address
            if(ctrl.isGuest && ctrl.isGuest === true) {
                ctrl.list = (newFilterList.length > 0) ? [ctrl.model] : [];
                ctrl.serviceLocationList = ctrl.model;
            } else {
                ctrl.list = newFilterList;
                ctrl.serviceLocationList = _.first(newFilterList);
            }
            if (ctrl.serviceLocationList) {
                NewServiceLocation.setServiceLocationList(ctrl.serviceLocationList);
            } else {
                if (response.length > 0) {
                    NewServiceLocation.setServiceLocationList(response[0]);
                }
            }

            if (ctrl.list.length > 0) {
                ctrl.trackFormChanges({newAddrReqInitiated: false, isFormValid: false, setServiceLocation: true});
            } else if (ctrl.showAddNew === true) {
                ctrl.initNew();
            }

            if (ctrl.createNonStandard && ctrl.nsServiceLocation) {
                ctrl.setServiceLocationForNS(response);
            }

        });
        $scope.$watch('$ctrl.form.$valid', function(newVal) {
            if (newVal) {
                ctrl.trackFormChanges({newAddrReqInitiated: false, isFormValid: true, setServiceLocation: false});
            } else {
                ctrl.trackFormChanges({newAddrReqInitiated: false, isFormValid: false, setServiceLocation: false});
            }
        });

        $scope.$watch('$ctrl.cancelForm', function() {
            if (ctrl.cancelForm) {
                ctrl.cancelNew();
                ctrl.showCancel = false;
            }
        });

        $rootScope.$on('user:loggedin', function () {
            addressesService.list().then(function(response) {
                var newFilterList = response;
                if (ctrl.zipcode) {
                    newFilterList = _.filter(response, {zipcode: ctrl.zipcode});
                }
                ctrl.list = newFilterList;
                ctrl.model = (ctrl.model && _.find(newFilterList, ctrl.model)) ||
                    _.find(newFilterList, function(serviceLoc) {
                          return (serviceLoc.id == ctrl.currentAddressId);
                    }) || _.first(newFilterList);
                ctrl.onLocationChange({serviceLocationList: ctrl.model});
                ctrl.serviceLocationList = _.first(newFilterList);
                if (ctrl.serviceLocationList) {
                    NewServiceLocation.setServiceLocationList(ctrl.serviceLocationList);
                } else {
                    if (response.length > 0) {
                        NewServiceLocation.setServiceLocationList(response[0]);
                    }
                }
    
                if (ctrl.list.length > 0) {
                    ctrl.trackFormChanges({newAddrReqInitiated: false, isFormValid: false, setServiceLocation: true});
                } else if (ctrl.showAddNew === true) {
                    ctrl.initNew();
                }
    
                if (ctrl.createNonStandard && ctrl.nsServiceLocation) {
                    ctrl.setServiceLocationForNS(response);
                }
    
            });
        });

        //Listen for authenticated user
        $rootScope.$on('user:authentication:change', function(event, user) {
            //Assign authenticated data if exists
            ctrl.isRegistered = user.isRegistered;
        });
    };

    ctrl.selectAddress = function(selectedAddress) {
        if (selectedAddress) {
            NewServiceLocation.setServiceLocationList(selectedAddress.serviceLocationList);
        }
    };

    ctrl.setServiceLocationForNS = function(addresslist) {
        var serviceLoc = ctrl.nsServiceLocation;
        if (serviceLoc.addressId) {
            var addressId = parseInt(serviceLoc.addressId);
            ctrl.selectedLocationNS = _.find(addresslist, {id : addressId});
        } else {
            ctrl.selectedLocationNS = _.find(addresslist, {addressline1 : serviceLoc.addressLine1, zipcode : serviceLoc.zipCode});
        }
        if (ctrl.selectedLocationNS) {
            NewServiceLocation.setServiceLocationList(ctrl.selectedLocationNS);
        }
    };

    ctrl.initNew = function() {
        if (ctrl.isRegistered !== true && !ctrl.isGuest) {
            ctrl.unregisteredUserAction();
            return;
        }
        ctrl.isEditing = false;
        ctrl.messageLabel.CURRENT = '';
        ctrl.disableRadioButton = true;
        ctrl.serviceLocationNew = {
            firstname: '',
            lastname: '',
            addressline1: '',
            addressline2: '',
            city: ctrl.city,
            state: ctrl.state,
            zipcode: ctrl.zipcode,
            country: 'US',
            email: ctrl.email,
            phone: '',
            contactNo: ''
        };
        ctrl.trackFormChanges({newAddrReqInitiated: true, isFormValid: false, setServiceLocation: false});
        ctrl.cancelForm = false;
        ctrl.showCancel = true;
    };

    /*ctrl.initEdit = function() {
        ctrl.address = {
            id: ctrl.model.id,
            fullname: ctrl.model.firstname + ' ' + ctrl.model.lastname,
            addressline1: ctrl.model.addressline1,
            addressline2: ctrl.model.addressline2,
            city: ctrl.model.city,
            state: ctrl.model.state,
            zipcode: ctrl.model.zipcode,
            country: 'US'
        };
    };*/

    ctrl.initEdit = function(address) {
        ctrl.isEditing = true;
        ctrl.messageLabel.CURRENT = '';
        ctrl.serviceLocationNew = {
            id: address.id,
            // title: address.title,
            firstname: address.firstname,
            lastname: address.lastname,
            addressline1: address.addressline1,
            addressline2: address.addressline2,
            contactNo: address.phone || address.contactNo,
            city: address.city,
            state: address.state,
            zipcode: address.zipcode,
            country: 'US',
            email: address.email,
            phone: address.phone || address.contactNo
        };
    };

    ctrl.remove = function(addressId) {
        ctrl.messageLabel.EDIT_ADDRESS = '';
        return addressesService.remove(addressId).then(function() {
            ctrl.new = undefined;
            ctrl.init();
        }, ctrl.requestError);
    };

    ctrl.editAddress = function() {
        // Added error until API is implemented in BE
        ctrl.messageLabel.EDIT_ADDRESS = ctrl.messageLabel.SERVICE_UNAVAILABLE_ERROR;

        // @TODO: Apply token when API allows it.
        if (!ctrl.serviceLocationNew.addressline2) {
            ctrl.serviceLocationNew.addressline2 = '';
        }
        return paymentAddressesService.edit(
            ctrl.serviceLocationNew.id,
            new paymentAddressesService.Address(ctrl.serviceLocationNew)
        ).then(function() {
            ctrl.serviceLocationNew = undefined;
            ctrl.init();
        });
    };

    ctrl.editAddressFn = function() {
        if (!ctrl.serviceLocationNew.addressline2) {
            ctrl.serviceLocationNew.addressline2 = '';
        }
        return addressesService.edit(
            ctrl.serviceLocationNew.id,
            new addressesService.Address(ctrl.serviceLocationNew)
        ).then(function() {
            ctrl.init();
            $rootScope.$broadcast('address:change');
        }, angular.noop)
        .finally(function() {
            ctrl.cancelNew();
            NewServiceLocation.resetServiceLocation();
        });
    };

    ctrl.fetchNewAddress = function() {
        if (ctrl.form.$valid) {
            NewServiceLocation.setServiceLocationValidity(ctrl.form.$valid);
            ctrl.serviceLocationNew.name = ctrl.serviceLocationNew.firstname + ' ' + ctrl.serviceLocationNew.lastname;
            NewServiceLocation.setServiceLocation(ctrl.serviceLocationNew);
            ctrl.trackFormChanges({newAddrReqInitiated: false, isFormValid: true, setServiceLocation: false});
        } else {
            NewServiceLocation.resetServiceLocationStatus();
            ctrl.trackFormChanges({newAddrReqInitiated: false, isFormValid: false, setServiceLocation: false});
        }
    };

    ctrl.addNew = function() {
        // @TODO: Apply token when API allows it.
        if (!ctrl.serviceLocationNew.addressline2) {
            ctrl.serviceLocationNew.addressline2 = '';
        }
        return addressesService.insert(
            new addressesService.Address(ctrl.serviceLocationNew)
        ).then(function(newAddress) {
            ctrl.serviceLocationNew = newAddress;
            ctrl.init();
            $rootScope.$broadcast('address:change');
        }, function(error){
            if(ctrl.isGuest && ctrl.isGuest === true && error && error.message === 'Address already exist') {
                ctrl.model = ctrl.serviceLocationNew;
                ctrl.init();
                $rootScope.$broadcast('address:change');
            } else {
                ctrl.messageLabel.CURRENT = error && error.message ? error.message : ctrl.messageLabel.INVALID_ADDRESS;
            }
        })
        .finally(function() {
            ctrl.cancelNew();
            NewServiceLocation.resetServiceLocation();
        });
    };

    ctrl.getZipcodeDetails = function(zipcode) {
        //if (zipcode.length === 5) {
        if (zipcode) {
            locationService.getlocation(zipcode).then(function(response) {
                ctrl.city = response.city;
                ctrl.state = response.state;
            });
        }
    };

    ctrl.cancelNew = function() {
        ctrl.messageLabel.EDIT_ADDRESS = '';
        ctrl.serviceLocationNew = undefined;
        ctrl.disableRadioButton = false;
        ctrl.addressInsertError = undefined;
        if (ctrl.list && ctrl.list.length > 0) {
            ctrl.newServiceLocationValid = true;
        }else {
            ctrl.newServiceLocationValid = false;
        }
        ctrl.onNewServiceLocationCancelled({serviceAddressCancelEvent: true});
    };

    ctrl.cancelEdit = function() {
        ctrl.isEditing = false;
        ctrl.serviceLocationNew = undefined;
        ctrl.messageLabel.CURRENT = '';
        ctrl.disableRadioButton = false;
        $rootScope.$broadcast('address:change');
    };

    ctrl.isAddressLine2Exist = function(addressline2) {
        return (addressline2 !== undefined);
    };

    ctrl.init();
}

ServiceAddressesList.$inject = ['$scope', '_', 'PaymentAddressesService', 'addressesService',
                                'SettingsService', 'NewServiceLocation', '$rootScope', 'locationService', 'LoginManagerService'];

(angular
    .module('RelayServicesApp.Components')
).component('serviceAddressesList', {
    templateUrl: (
        'assets/templates/components/service-addresses-list/index.html'
    ),
    controller: ServiceAddressesList,
    bindings: {
        onLocationChange: '&',
        hideTitle: '<',
        editView: '<',
        showEdit: '<',
        email: '<',
        city: '<',
        state: '<',
        zipcode: '<',
        isGuest: '<',
        enableDeleteButton: '<',
        createNonStandard: '<',
        nsServiceLocation: '<',
        cancelForm: '=',
        showCancel: '=',
        onNewServiceLocationCancelled: '&',
        showAddNew: '<',
        trackFormChanges: '&',
        addressInsertError: '<',
        nsUpdateModal: '<',
        currentAddressId: '<',
        checkoutFlow: '<',
        unregisteredUserAction: '&'
    }
});
