'use strict';

function PaymentAddressesList($rootScope, $scope, _, paymentAddressesService, addressesService,
SettingsService, NewBillingAddress, modal, ErrorHandler, locationService, LoginManagerService) {
    var ctrl = this;

    ctrl.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR,
        SERVICE_UNAVAILABLE_ERROR: SettingsService.Error.SERVICE_UNAVAILABLE_ERROR,
        INVALID_ADDRESS: SettingsService.Error.INVALID_ADDRESS_ERROR
    };
    _.extend(ctrl.messageLabel, SettingsService.FormValidation);

    ctrl.init = function() {
        ctrl.messageLabel.CURRENT = '';
        ctrl.isEditing = false;
        ctrl.address = undefined;
        ctrl.billingAddress = true;
        ctrl.editAddress = undefined;
        ctrl.today = new Date();
        ctrl.disableRadioButton = false;
        ctrl.isRegistered = LoginManagerService.getUser().isRegistered;
        ctrl.city = '';
        paymentAddressesService.list().then(function(response) {
            ctrl.list = response;
            ctrl.model = (
                ctrl.model && (_.find(ctrl.list, ctrl.model) ||
                _.find(ctrl.list, function(billingLoc) {
                    return (
                        billingLoc.addressLine1 === ctrl.model.addressLine1 &&
                        billingLoc.addressLine2 === ctrl.model.addressLine2 &&
                        billingLoc.city === ctrl.model.city &&
                        billingLoc.zipCode === ctrl.model.zipCode &&
                        billingLoc.state === ctrl.model.state
                    );
                })))
            || _.find(ctrl.list, function(billingLoc) {
                    return (billingLoc.id == ctrl.currentAddressId);
            }) || _.first(response);

            // For Guest checkout, display only one address
            if(ctrl.isGuest && ctrl.isGuest === true) {
                ctrl.list = (ctrl.list.length > 0) ? [ctrl.model] : [];
            }
            ctrl.onAddressChange({address: ctrl.model});
        });
        $scope.$watch('$ctrl.form.$valid', function(newVal) {
            if (newVal) {
                $scope.$emit('valid:billing:address:form');
            } else {
                $scope.$emit('invalid:billing:address:form');
            }
        });

        $rootScope.$on('user:loggedin', function () {
            paymentAddressesService.list().then(function(response) {
                ctrl.list = response;
                ctrl.model = (
                    ctrl.model && _.find(response, ctrl.model)
                ) || _.first(response);
                ctrl.onAddressChange({address: ctrl.model});
            });
        });

         //Listen for authenticated user
        $rootScope.$on('user:authentication:change', function(event, user) {
            //Assign authenticated data if exists
            ctrl.isRegistered = user.isRegistered;
        });
    };

    ctrl.initNew = function() {
        if (ctrl.isRegistered !== true && !ctrl.isGuest) {
            ctrl.unregisteredUserAction();
            return;
        }
        ctrl.reset();
        ctrl.disableRadioButton = true;
        ctrl.address = {
            firstname: '',
            lastname: '',
            addressline1: '',
            addressline2: '',
            city: '',
            state: '',
            zipcode: '',
            country: 'US'
        };
        $scope.$emit('new:billing:address');
    };

    /*ctrl.initEdit = function() {
        ctrl.address = {
            id: ctrl.model.id,
            fullname: ctrl.model.firstname + ' ' + ctrl.model.lastname,
            addressline1: ctrl.model.addressline1,
            addressline2: ctrl.model.addressline2,
            city: ctrl.model.city,
            state: ctrl.model.state,
            zipcode: ctrl.model.zipcode,
            country: 'US'
        };
    };*/

    ctrl.initEdit = function(address) {
        ctrl.reset();
        ctrl.isEditing = true;
        ctrl.editAddress = {
            id: address.id,
            // title: address.title,
            firstname: address.firstname,
            lastname: address.lastname,
            addressline1: address.addressline1,
            addressline2: address.addressline2,
            city: address.city,
            state: address.state,
            zipcode: address.zipcode,
            country: 'US'
        };
    };

    ctrl.remove = function(addressId) {
        ctrl.messageLabel.CURRENT = '';
        // @TODO: Apply token when API allows it.

        var modalInstance = modal.open({
            animation: true,
            size: 'sm',
            controller: 'deleteAddressServiceCtrl',
            controllerAs: 'deleteAddressServiceCtrl',
            templateUrl: [
                'assets/templates/components/delete-address/',
                'index.html'
            ].join('')
        });
        modalInstance.result
        .then(function(shouldDelete) {
            if (shouldDelete === true) {
                return paymentAddressesService
                .remove(addressId)
                .then(function() {
                    ctrl.new = undefined;
                    ctrl.init();
                }, function(error) {
                  ctrl.messageLabel.CURRENT = error && error.message ? error.message : ctrl.messageLabel.INVALID_ADDRESS;
                  ErrorHandler.displayAddressDeleteError(error, ctrl);
                });
            }
        });
    };

    ctrl.editAddressFn = function() {
        // @TODO: Apply token when API allows it.
        if (!ctrl.editAddress.addressline2) {
            ctrl.editAddress.addressline2 = '';
        }
        return paymentAddressesService.edit(
            ctrl.editAddress.id,
            new paymentAddressesService.Address(ctrl.editAddress)
        ).then(function() {
            ctrl.editAddress = undefined;
            ctrl.init();
        }, function(error) {
            ctrl.messageLabel.CURRENT = error && error.message ? error.message : ctrl.messageLabel.DEFAULT;
        });
    };

    ctrl.fetchNewAddress = function() {
        if (ctrl.form.$valid) {
            NewBillingAddress.setBillingAddress(ctrl.address);
        } else {
            NewBillingAddress.resetBillingAddressStatus();
        }
    };

    ctrl.addNew = function() {
        // @TODO: Apply token when API allows it.
        //ctrl.address.fullname = ctrl.address.name;
        if (!ctrl.address.addressline2) {
            ctrl.address.addressline2 = '';
        }
        return paymentAddressesService.insert(
            new paymentAddressesService.Address(ctrl.address)
        ).then(function() {
            if(ctrl.isGuest && ctrl.isGuest === true) {
                ctrl.model = ctrl.address;
            }
            ctrl.address = undefined;
            ctrl.init();
        }, function(error) {
            ctrl.messageLabel.CURRENT = error && error.message ? error.message : ctrl.messageLabel.DEFAULT;
        });
    };

    ctrl.getZipcodeDetails = function(zipcode) {
        var ctl = this;
        ctrl.city = '';
        if(ctrl.isEditing) {
            ctl.editAddress.city = '';
            ctl.editAddress.state = '';
        } else {
            ctl.address.city = '';
            ctl.address.state = '';
        }
        if (zipcode && zipcode.length === 5) {
            ctrl.invalidZipcode = false;
            locationService.getlocation(zipcode).then(function(response) {
                if (response) {
                    ctrl.city = response.city;
                    if (ctrl.isEditing) {
                        ctl.editAddress.city = ctrl.city;
                        ctl.editAddress.state = response.state;
                    } else {
                        ctl.address.city = ctrl.city;
                        ctl.address.state = response.state;
                    }
                }
            }, function() {
                ctrl.city = '';
                if (ctrl.isEditing) {
                    ctl.editAddress.city = '';
                    ctl.editAddress.state = '';
                } else {
                    ctl.address.city = '';
                    ctl.address.state = '';
                }
                ctrl.invalidZipcode = true;
            });
        }
    };

    ctrl.cancelNew = function() {
        ctrl.reset();
        ctrl.onAddressChange({address: ctrl.model});
        $scope.$emit('new:billing:address:canceled');
    };

    ctrl.reset = function() {
        ctrl.messageLabel.CURRENT = '';
        ctrl.address = undefined;
        ctrl.editAddress = undefined;
        ctrl.disableRadioButton = false;
        ctrl.invalidZipcode = false;
        ctrl.isEditing = false;
    };


    ctrl.isAddressLine2Exist = function(addressline2) {
        return (addressline2 !== undefined);
    };

    ctrl.init();

    $rootScope.$on('billing:address:added', function() {
        ctrl.billingAddress = false;
        ctrl.address = undefined;
        NewBillingAddress.resetBillingAddress();
        ctrl.init();
    });
}

PaymentAddressesList.$inject = ['$rootScope', '$scope', '_', 'PaymentAddressesService', 'addressesService',
                                'SettingsService', 'NewBillingAddress', '$uibModal', 'ErrorHandler',
                                'locationService', 'LoginManagerService'];
(angular
    .module('RelayServicesApp.Components')
).component('paymentAddressesList', {
    templateUrl: (
        'assets/templates/components/payment-addresses-list/index.html'
    ),
    controller: PaymentAddressesList,
    bindings: {
        onAddressChange: '&',
        hideTitle: '<',
        editView: '<',
        showEdit: '<',
        isGuest: '<',
        enableDeleteButton: '<',
        myAccoutFlow: '<',
        checkoutFlow: '<',
        unregisteredUserAction: '&'
    }
});
