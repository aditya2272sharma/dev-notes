'use strict';

function deleteAddressServiceCtrl($scope, $uibModalInstance, SettingsService) {
    $scope.message = SettingsService.DeleteAdress.CONFIRMATION_MESSAGE;
    $scope.errorMessage = SettingsService.Error.ADDRESS_DELETE_ERROR;

    $scope.yesDeleteAddress = function() {
        $uibModalInstance.close(true);
    };

    $scope.dismissPopup = function() {
        $uibModalInstance.dismiss(false);
    };
}

deleteAddressServiceCtrl.$inject = ['$scope', '$uibModalInstance', 'SettingsService',
    '$window', '$state'];
(angular
    .module('RelayServicesApp.Components')
).controller('deleteAddressServiceCtrl', deleteAddressServiceCtrl);
