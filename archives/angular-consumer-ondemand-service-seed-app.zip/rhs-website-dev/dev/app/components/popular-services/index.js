'use strict';

function PopularServices(ProjectCategories, $scope, SettingsService) {

    $scope.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR
    };
    $scope.errorProImage = SettingsService.AssetsPaths.DEFAULT_PROVIDER_IMAGE;

    $scope.init = function() {
        (ProjectCategories
            .categories(true)
        ).then(function(response) {
            $scope.categories = response;
            //console.log($scope.categories);
        }, function() {
            //$scope.categoryError(error);
        });
    };

    $scope.categoryError = function(error) {
        $scope.messageLabel.CURRENT = error && error.message ? error.message : $scope.messageLabel.DEFAULT;
    };
    $scope.init();
}

PopularServices.$inject = ['ProjectCategoriesService', '$scope', 'SettingsService'];

(angular
    .module('RelayServicesApp.Components')
).component('popularServices', {
    templateUrl: (
        'assets/templates/components/popular-services/index.html'
    ),
    controller: PopularServices
});
