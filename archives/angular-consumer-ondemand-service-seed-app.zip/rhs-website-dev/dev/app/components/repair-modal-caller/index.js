'use strict';

angular
.module('RelayServicesApp.Components')
.directive('repairModalCaller', [
	'repairProductModalService',
	function(repairProductModalService) {
    return {
        restrict:'A',
        link: function(scope) {
            scope.openRepairModal = repairProductModalService.openModal;
        }
    };
	}
]);
