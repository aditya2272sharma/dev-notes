'use strict';

function PaymentMethodsList($scope, _, paymentMethodsService, settingsService,
$braintree, braintreeValue, NewPaymentMethod, modal, $rootScope, $state, LoginManagerService) {
    var ctrl = this;
    //var Card = paymentMethodsService.Card;
    var paymentModeDeleteEvent = 'paymentmode:delete';

    ctrl.messageLabel = {
        CURRENT: '',
        DEFAULT: settingsService.Error.DEFAULT_ERROR
    };
    _.extend(ctrl.messageLabel, settingsService.FormValidation);

    ctrl.init = function() {
        ctrl.isEditing = false;
        ctrl.today = new Date();
        ctrl.messageLabel.CURRENT = '';
        ctrl.disableRadioButton = false;
        ctrl.isRegistered = LoginManagerService.getUser().isRegistered;
        ctrl.isGuest = ctrl.isGuest || false;
        paymentMethodsService.list().then(function(response) {
            ctrl.list = response;
            ctrl.model = (
                ctrl.model && (_.find(response, ctrl.model) ||
                _.find(ctrl.list, function(cardDetails) {
                    return (
                        +cardDetails.expiremonth === ctrl.model.expirationMonth &&
                        +cardDetails.expireyear === ctrl.model.expirationYear &&
                        cardDetails.name === ctrl.model.cardholderName &&
                        cardDetails.lastNumbers === ctrl.model.number.substring(ctrl.model.number.length-4)
                    );
                })
            ) || _.find(response, {default: true}));
            if ($state.current.name.indexOf('checkout') > -1) {
                ctrl.onCardChanged({card: ctrl.model});

                 // For Guest checkout, display only one address
                if(ctrl.isGuest && ctrl.isGuest === true) {
                    ctrl.list = (ctrl.list.length > 0) ? [ctrl.model] : [];
                }
            }
        });
        ctrl.yearList = paymentMethodsService.YearList();
        ctrl.monthList = paymentMethodsService.MonthList();

        $scope.$watch('$ctrl.form.$valid', function(newVal) {
            if (newVal) {
                ctrl.fetchNewCard();
                ctrl.trackFormChanges({newInitiated: true, formValid: true});
            } else {
                ctrl.trackFormChanges({newInitiated: true, formValid: false});
                if (!ctrl.disableRadioButton) {
                    ctrl.trackFormChanges({newInitiated: false, formValid: false});
                }
            }
        });

        $rootScope.$on('user:loggedin', function () {
            ctrl.isRegistered = true;
            paymentMethodsService.list().then(function (response) {
                ctrl.list = response;
                ctrl.model = (
                    ctrl.model && _.find(response, ctrl.model)
                ) || _.find(response, { default: true });
                if ($state.current.name.indexOf('checkout') > -1) {
                    ctrl.onCardChanged({ card: ctrl.model });
                }
            });
        });

         //Listen for authenticated user
        $rootScope.$on('user:authentication:change', function(event, user) {
            //Assign authenticated data if exists
            ctrl.isRegistered = user.isRegistered;
        });
    };

    ctrl.initNew = function() {
        if (ctrl.isRegistered !== true && !ctrl.isGuest) {
            ctrl.unregisteredUserAction();
            return;
        }
        ctrl.isEditing = false;
        ctrl.messageLabel.CURRENT = '';
        ctrl.disableRadioButton = true;
        ctrl.new = {
            isNew: true,
            nonce: Date.now(),
            number: '',
            cardholderName: '',
            expirationMonth: parseInt(ctrl.monthList[0]),
            expirationYear: parseInt(ctrl.yearList[1]),
            cvv: '',
            isDefault: false
        };
        ctrl.trackFormChanges({newInitiated: true, formValid: false});
    };

    ctrl.initEdit = function(card) {
        ctrl.isEditing = true;
        ctrl.messageLabel.CURRENT = '';
        ctrl.new = {
            id: card.id,
            number: '**** **** ****' + card.lastNumbers,
            cardholderName: card.name,
            expirationMonth: parseInt(card.expiremonth),
            expirationYear: card.expireyear,
            cvv: '****',
            isDefault: card.default
        };
    };

    ctrl.fetchNewCard = function() {
        if (ctrl.form.$valid) {
            NewPaymentMethod.setPaymentMethodValidity(ctrl.form.$valid);
            NewPaymentMethod.setPaymentMethod(ctrl.new);
            ctrl.trackFormChanges({newInitiated: true, formValid: true});
        } else {
            NewPaymentMethod.resetpaymentMethodStatus();
            ctrl.trackFormChanges({newInitiated: true, formValid: false});
        }
    };

    ctrl.addNew = function() {
        braintreeValue.requestToken(ctrl.new.isDefault).then(function(res) {
            braintreeValue.setToken(res);
            $braintree.getClientToken().then(function(token) {
                var client = new $braintree.api.Client({
                    clientToken: token
                });
                client.tokenizeCard({
                    number: ctrl.new.number,
                    cardholderName: ctrl.new.cardholderName,
                    // You can use either expirationDate
                    // expirationDate: ctrl.new.expiration,
                    // or expirationMonth and expirationYear
                    expirationMonth: ctrl.new.expirationMonth,
                    expirationYear: ctrl.new.expirationYear,
                    // CVV if required
                    cvv: ctrl.new.cvv
                }, function(err, nonce) {
                    // Send nonce to your server
                    console.log(err, nonce);

                    paymentMethodsService.register(nonce).then(function() {
                        if(ctrl.isGuest) {
                            ctrl.model = ctrl.new;
                        }
                        ctrl.new = undefined;
                        ctrl.init();
                    }).catch(function(error) {
                        ctrl.messageLabel.CURRENT = (error &&
                            error.message
                        ) || ctrl.messageLabel.DEFAULT;
                    });
                });

            }).catch(function(error) {
                console.log(error);
            });
        });
    };

    ctrl.editDefault = function() {
        return paymentMethodsService.editDefault(
            ctrl.new.id,
            ctrl.new.isDefault
        ).then(function() {
            ctrl.init();
        }).catch(function(error) {
            ctrl.messageLabel.CURRENT = (error &&
                error.message
            ) || ctrl.messageLabel.DEFAULT;
        });
    };

    ctrl.remove = function(cardId) {
        var modalInstance = modal.open({
            animation: true,
            size: 'sm',
            controller: 'deletePaymentModeCtrl',
            controllerAs: 'deletePaymentModeCtrl',
            templateUrl: [
                'assets/templates/components/delete-payment-mode/',
                'index.html'
            ].join('')
        });
        modalInstance.result.then(function(shouldDelete) {
            if (shouldDelete === true) {
                return paymentMethodsService.remove(cardId).then(function() {
                    ctrl.init();
                    $rootScope.$broadcast(paymentModeDeleteEvent);
                }).catch(function(error) {
                    ctrl.messageLabel.CURRENT = (error &&
                        error.message
                    ) || ctrl.messageLabel.DEFAULT;
                });
            }
        });
    };

    ctrl.cancelNew = function() {
        ctrl.disableRadioButton = false;
        ctrl.isEditing = false;
        ctrl.new = undefined;
        ctrl.messageLabel.CURRENT = '';
        ctrl.trackFormChanges({newInitiated: false, formValid: false});
    };

    ctrl.showCVVForCard = function(card) {
        if (!ctrl.enableCardCvv({card: card}) || ctrl.disableRadioButton) {
            card.cvv = '';
            return false;
        } else {
            if (ctrl.trackFormChanges({newInitiated: false, formValid: true})) {
                ctrl.validCVVPresent = true;
            } else {
                ctrl.validCVVPresent = false;
            }
            return true;
        }
    };

    $rootScope.$on('PaymentMethodsService:onCardChanged', function() {
        ctrl.init();
    });

    ctrl.init();

}

PaymentMethodsList.$inject = ['$scope', '_', 'PaymentMethodsService', 'SettingsService',
                            '$braintree', 'braintreeValue', 'NewPaymentMethod', '$uibModal', '$rootScope', '$state','LoginManagerService'];
(angular
    .module('RelayServicesApp.Components')
    // .value('braintreeValue', require('../../services/payments/token-service'))
).component('paymentMethodsList', {
    templateUrl: (
        'assets/templates/components/payment-methods-list/index.html'
    ),
    controller: PaymentMethodsList,
    bindings: {
        onCardChanged: '&',
        hideTitle: '<',
        editView: '<',
        checkOutFlow: '<',
        isGuest: '<',
        enableDeleteButton: '<',
        trackFormChanges: '&',
        enableCardCvv: '&',
        unregisteredUserAction: '&'
    }
});
