'use strict';

function TTValidityCheckModal(
    $uibModalInstance,
    $sce,
    availableDates,
    moment,
    DTService
) {
    var vm = this;
    var newMessage = 'Time you selected is no longer available. The next available appointment is ';
    vm.nextAvailableDateTime = {};

    vm.init = function() {
        var currentDate = DTService.getFormattedCurrentDate();
        vm.nextAvailableDateTime = DTService.getNextValidDateTime(availableDates);
        if(vm.nextAvailableDateTime.date === currentDate) {
            newMessage += ' <b>today</b> at ';
        } else {
            var dateAvailable = "";
            dateAvailable = moment(vm.nextAvailableDateTime.date, DTService.dateFormat).format("MM/DD");
            newMessage += ' on <b>' + dateAvailable + '</b> at ';
        }

        newMessage += '<b>' + vm.nextAvailableDateTime.timeSlot + '</b>';
        vm.message = $sce.trustAsHtml(newMessage);
    };

    vm.selectNextAvailableTime = function() {
        $uibModalInstance.close(vm.nextAvailableDateTime);
    };

    vm.cancel = function() {
        $uibModalInstance.dismiss();
    };

    vm.init();
}

TTValidityCheckModal.$inject = [
    '$uibModalInstance',
    '$sce',
    'availableDates',
    'moment',
    'DateTimeValidationService'
];

angular
    .module('RelayServicesApp.Components')
    .controller('TTValidityCheckModal', TTValidityCheckModal);
