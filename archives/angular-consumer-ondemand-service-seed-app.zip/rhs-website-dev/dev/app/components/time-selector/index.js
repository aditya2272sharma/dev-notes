'use strict';
function timeSelCtrl($scope, modalInstance, $filter,
    CheckoutInfoService, $state, providerEstimate,
    ProjectsService, SettingsService, moment) {

    $scope.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR
    };

    $scope.close = function() {
        modalInstance.dismiss();
    };

    $scope.onCreateProjectTimeSelect = function() {
        $scope.isOpen = false;
        $scope.creationDate = $filter('date')(new Date($scope.creationDate), 'yyyy-MM-dd');
    };

    $scope.dateHour = {
        model: '8:00 am - 12:00 pm'
    };

    $scope.gotoCheckout = function() {
        var projectId = providerEstimate.projectId,
            estimateId = providerEstimate.bid.estimateId,
            decision = 'Accept';
        ProjectsService.acceptOrRejectProjectEstimation(projectId, estimateId, decision)
        .then(function(acceptRejectObject) {
            //console.log(acceptRejectObject);
            CheckoutInfoService.setCheckout({
                order: acceptRejectObject,
                project: projectId,
                firm: providerEstimate
            });
            modalInstance.close();
            $state.go('payment.checkout');
        }, function(error) {
            $scope.messageLabel.CURRENT = error && error.message ? error.message : $scope.messageLabel.DEFAULT;
        });
    };

    // Date picker Options
    $scope.today = function() {
        var finaldate = moment().add(2, 'days');
        $scope.dt = finaldate._d;
    };

    $scope.today();

    $scope.firstAvailableDate = function() {
        return moment().add(2, 'days');
    };

    $scope.clear = function() {
        $scope.dt = null;
    };

    $scope.inlineOptions = {
        minDate: new Date(),
        showWeeks: true
    };

    // Disable weekend selection
    function disabled(data) {
        var date = data.date,
            mode = data.mode;
        return mode === 'day' && (date.getDay() === 0 || date.getDay() === 6);
    }

    $scope.dateOptions = {
        dateDisabled: disabled,
        formatYear: 'yy',
        maxDate: new Date(2020, 5, 22),
        minDate: moment().add(2, 'days'),
        startingDay: 0,
        showWeeks: false
    };

    $scope.open2 = function() {
        $scope.popup2.opened = true;
    };

    $scope.setDate = function(year, month, day) {
        $scope.dt = new Date(year, month, day);
    };

    $scope.popup2 = {
        opened: false
    };

}

timeSelCtrl.$inject = ['$scope', '$uibModalInstance', '$filter',
    'CheckoutInfoService', '$state', 'providerEstimate',
    'ProjectsService', 'SettingsService', 'moment'
];

(angular
    .module('RelayServicesApp.Components')
).controller('timeSelCtrl', timeSelCtrl);
