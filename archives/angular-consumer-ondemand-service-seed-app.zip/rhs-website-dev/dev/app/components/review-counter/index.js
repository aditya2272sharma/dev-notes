'use strict';

function ReviewCounter() {
    var ctrl = this;
    ctrl.item = '';

    ctrl.init = function() {
        if (ctrl.number > 1) {
            ctrl.item = 'Reviews';
        } else {
            ctrl.item = 'Review';
        }
    };

    ctrl.init();
}

ReviewCounter.$inject = [
];

(angular
    .module('RelayServicesApp.Components')
        ).component('reviewCounter', {
            templateUrl: 'assets/templates/components/review-counter/index.html',
            controller: ReviewCounter,
            bindings: {
                number: '<'
            }
        });
