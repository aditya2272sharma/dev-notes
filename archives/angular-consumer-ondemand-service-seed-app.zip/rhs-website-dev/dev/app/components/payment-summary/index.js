'use strict';

function PaymentSummary(SettingsService, DTService, moment) {

    var ctrl = this;

    ctrl.init = function() {
        ctrl.isTechTalk =
            ctrl.projectData.serviceType === SettingsService.ServiceTypes.TECHTALK;

        if(ctrl.isTechTalk) {
            var selectedDate = ctrl.projectData.preferredStartDates[0];
            ctrl.schedule = (DTService.isCurrentDate(selectedDate))
            ? 'Today' : moment(selectedDate).format(
                'MMM D[,] YYYY'
            );
            ctrl.schedule += ' ' + ctrl.projectData.preferredSlots[0];
        }
    }
    ctrl.init();
}

PaymentSummary.$inject = ['SettingsService', 'DateTimeValidationService', 'moment'];

(angular
    .module('RelayServicesApp.Components')
).component('paymentSummary', {
    templateUrl: (
        'assets/templates/components/payment-summary/index.html'
    ),
    controller: PaymentSummary,
    bindings: {
        shouldDisableCheckoutBtn: '&',
        bookService: '&',
        cost: '=',
        projectData: '=',
        contact: '='
    }
});
