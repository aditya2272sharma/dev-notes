'use strict';

function GuaranteeBanner() {

}

GuaranteeBanner.$inject = [];

(angular
    .module('RelayServicesApp.Components')
).component('guaranteeBanner', {
    templateUrl: (
        'assets/templates/components/guarantee-banner/index.html'
    )
});
