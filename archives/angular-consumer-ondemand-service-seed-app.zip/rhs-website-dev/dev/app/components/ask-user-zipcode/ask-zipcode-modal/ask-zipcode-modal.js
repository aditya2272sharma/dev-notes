'use strict';

function AskZipcodeModal($uibModalInstance, ZipcodeInfoService,
    zipcode, locationService) {

    var vm = this;
    vm.zipCode = (angular.isString(zipcode) && zipcode.length === 5) ? zipcode : '';
    vm.isShowZipCodeError = false;

    vm.init = function() {

    };

    vm.changedUserLocation = function() {
        vm.isShowZipCodeError = false; // hide zipcode error
        locationService
        .getlocation(vm.zipCode)
        .then(function(response) {
            if(angular.isObject(response)) {
                ZipcodeInfoService.setZipcode(vm.zipCode);
                $uibModalInstance.close(response);
            } else {
                vm.isShowZipCodeError = true; // show zipcode error
            }
        }, function(error){
            console.log('Error: locationService.getlocation', error);
            vm.isShowZipCodeError = true; // show zipcode error
        });
    };

    vm.cancelUserLocationPopover = function() {
        if (vm.zipCode.length === 5) {
            $uibModalInstance.dismiss();
        } else {
            vm.isShowZipCodeError = true; // show zipcode error
        }
    };

    vm.init();
}

AskZipcodeModal.$inject = ['$uibModalInstance', 'ZipcodeInfoService',
    'zipcode', 'locationService'];

(angular
    .module('RelayServicesApp.Components')
).controller('AskZipcodeModalController', AskZipcodeModal);
