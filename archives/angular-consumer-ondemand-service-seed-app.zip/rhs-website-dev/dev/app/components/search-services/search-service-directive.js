'use strict';
angular
    .module('RelayServicesApp.Components')
    .directive('ngFocusClass',
        function() {
            return ({
                restrict: 'A',
                link: function(scope, element) {
                    element.focus(function() {
                        element.addClass('focus');
                    });
                    element.blur(function() {
                        element.removeClass('focus');
                    });
                }
            });
        }
    );
