'use strict';

function SearchServices($state, $scope, _, Env, SearchInfoService, CustomProjectService,
    specialServiceModalService, $filter, ProjectCategoriesService, SettingsService,
    NewProjectCategoriesService) {
    var ctrl = this,
        _selected;

    $scope.selected = undefined;

    /**
     * Getting all categories and subcategories to populate autocomplete
     */
    ctrl.customProject = Env.features.customProject;
    ctrl.proSearchService = Env.features.proSearchService;

    ctrl.init = function() {
        /*ctrl.initSearch = [
            {
                id: '21',
                name: 'Drain - Diagnosis / Minor Repair',
                parentCategory: 'Plumbing'
            },
            {
                id: '33',
                name: 'Honeywell Thermostat Install',
                parentCategory: 'Heating & Cooling'
            },
            {
                id: '20',
                name: 'Heating & Cooling System - Maintenance',
                parentCategory: 'Heating & Cooling'
            },
            {
                id: '31',
                name: 'Nest Smoke Alarm Install',
                parentCategory: 'Handyman'
            },
            {
                id: '9',
                name: 'LeakSMART Water Shutoff Install',
                parentCategory: 'Plumbing'
            }
        ];*/

        NewProjectCategoriesService.autocompleteCategories()
        .then(function(response) {
            ctrl.subCategories = response;
            ctrl.addMoreServices();
        }, function() {
            ctrl.subCategories = [];
            ctrl.addMoreServices();
        });

    };
    /**
     * Adding categories and custom keys to autocomplete
     */
    ctrl.addMoreServices = function() {
        /*ctrl.searchKeysList = [
            {
                parentCategory: 'Heating & Cooling',
                name: 'Home services air conditioner installation',
                parentCategoryId: 4
            },
            {
                parentCategory: 'Electrical',
                name: 'Home services electrical',
                parentCategoryId: 1
            },
            {
                parentCategory: 'Electrical',
                name: 'Home services refrigerator',
                parentCategoryId: 1
            },
            {
                parentCategory: 'Electrical',
                name: 'Home services tv mounting',
                parentCategoryId: 1
            },
            {
                parentCategory: 'Plumbing',
                name: 'Home services installation washing',
                parentCategoryId: 2
            },
            {
                parentCategory: 'Plumbing',
                name: 'Home services window installation',
                parentCategoryId: 2
            },
            {
                parentCategory: 'Heating & Cooling',
                name: 'Home services air conditioner repair',
                parentCategoryId: 4
            },
            {
                parentCategory: 'Heating & Cooling',
                name: 'Home services hvac',
                parentCategoryId: 4
            },
            {
                parentCategory: 'Electrical',
                name: 'Home services computer',
                parentCategoryId: 1
            },
            {
                parentCategory: 'Electrical',
                name: 'home services insulation',
                parentCategoryId: 1
            },
            {
                parentCategory: 'Plumbing',
                name: 'Home services plumbing',
                parentCategoryId: 2
            },
            {
                parentCategory: 'Plumbing',
                name: 'Home services bathroom',
                parentCategoryId: 2
            },
            {
                parentCategory: 'Plumbing',
                name: 'Home services sink',
                parentCategoryId: 2
            },
            {
                parentCategory: 'Heating & Cooling',
                name: 'Home services ac',
                parentCategoryId: 4
            },
            {
                parentCategory: 'Heating & Cooling',
                name: 'Home services water heater',
                parentCategoryId: 4
            },
            {
                parentCategory: 'Plumbing',
                name: 'Home services power wash',
                parentCategoryId: 2
            },
            {
                parentCategory: 'Plumbing',
                name: 'Home services toilet',
                parentCategoryId: 2
            },
            {
                parentCategory: 'Plumbing',
                name: 'Open shower room',
                parentCategoryId: 2
            },
            {
                parentCategory: 'Plumbing',
                name: 'Why is dishwasher leaking',
                parentCategoryId: 2
            },
            {
                parentCategory: 'Plumbing',
                name: 'Toilet clogged bathtub backing up',
                parentCategoryId: 2
            },
            {
                parentCategory: 'Plumbing',
                name: 'How to unclog a toilet',
                parentCategoryId: 2
            },
            {
                parentCategory: 'Plumbing',
                name: 'Water line repair kit',
                parentCategoryId: 2
            },
            {
                parentCategory: 'Plumbing',
                name: 'Sump and pump drainage system',
                parentCategoryId: 2
            },
            {
                parentCategory: 'Plumbing',
                name: 'How to build a gas fire table',
                parentCategoryId: 2
            },
            {
                parentCategory: 'Plumbing',
                name: 'Auto hose rewinder',
                parentCategoryId: 2
            },
            {
                parentCategory: 'Electrical',
                name: 'Picture frame light switch',
                parentCategoryId: 1
            },
            {
                parentCategory: 'Electrical',
                name: 'Water purifier fittings',
                parentCategoryId: 1
            },
            {
                parentCategory: 'Heating & Cooling',
                name: 'Hvac repair',
                parentCategoryId: 4
            },*/
        ctrl.searchKeysList = SettingsService.SearchKeysList;

        //Adding more keys to subcat array
        ctrl.searchServicesList = ctrl.subCategories.concat(ctrl.searchKeysList);
    };

    /* Go to page on autocomplete Match */
    $scope.ngModelOptionsSelected = function(value) {
        if (arguments.length) {
            _selected = value;
            if (_.isObject(_selected)) {
                if (_selected.id) {
                    $state.go('services.results', {
                        categoryId: _selected.id,
                        id: '',
                        category: $filter('safeUrls')(_selected.parentCategory),
                        subcategory: $filter('safeUrls')(_selected.name)
                    });
                } else if (_selected.parentCategoryId) {
                    var categoryName = $filter('safeUrls')(_selected.parentCategory);
                    $state.go('services.category', {
                        category: categoryName
                    });
                } else if (_selected.isCustom) {
                    //console.log('isCustom');
                    ctrl.openNSProjectModal();
                }
            }
        } else {
            return _selected;
        }
    };

    ctrl.openNSProjectModal = function() {
        if (ctrl.customProject === 'true') {
            CustomProjectService.openModal();
        } else {
            specialServiceModalService.openModal();
        }
    };

    $scope.modelOptions = {
        debounce: {
            default: 200,
            blur: 100
        },
        getterSetter: true
    };

    ctrl.submitSearch = function() {
        if (!arguments.length) {
            ctrl.openNSProjectModal();
        }
    };

    ctrl.triggerNewSearch = function() {
        var keyword = _selected;
        if (_selected && _selected.name) {
            keyword = _selected.name;
        }
        SearchInfoService.setSearchInfo({keyword : keyword});
        $state.go('search');
    };

    $scope.selectedKey = function(value) {
        if (arguments.length) {
            _selected = value;
        } else {
            return _selected;
        }
    };
    ctrl.init();
}

SearchServices.$inject = [
    '$state', '$scope', '_', 'ENVIRONMENT', 'SearchInfoService', 'CustomProjectService',
    'specialServiceModalService', '$filter', 'ProjectCategoriesService', 'SettingsService',
    'NewProjectCategoriesService'];

(angular
    .module('RelayServicesApp.Components')
).component('searchServices', {
    templateUrl: (
        'assets/templates/components/search-services/index.html'
    ),
    controller: SearchServices,
    controllerAs: 'SearchServicesCtrl',
});
