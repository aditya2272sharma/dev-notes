'use strict';

function BookServices() {
    var ctrl = this;

    ctrl.init = function() {
    };

    ctrl.init();
}

BookServices.$inject = [];

(angular
    .module('RelayServicesApp.Components')
).component('bookServices', {
    templateUrl: (
        'assets/templates/components/book-services/index.html'
    ),
    controller: BookServices,
    bindings: {
        customProject: '<'
    }
});
