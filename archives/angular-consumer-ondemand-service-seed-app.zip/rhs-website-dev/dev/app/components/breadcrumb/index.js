'use strict';

function BreadCrumbCtrl(location, $scope, $state, BreadcrumbService, SettingsService) {
    var vm = this;
    vm.currentPath = location.path().slice(1).split('/');
    vm.section = {
        item: vm.currentPath[0],
        count: vm.currentPath.length,
        state: {
            name: 'services.categories'
        }
    };

    $scope.goToState = function(path) {
        if (path.disabled) {
            return;
        }
        if (path.state.params) {
            path.state.params.mainCategoryId = path.state.params.id;
        } else {
            path.state.params = {};
        }
        $state.go(path.state.name, path.state.params);
    };

    $scope.$watch('$ctrl.pathItems', function() {
        vm.pathItems = vm.pathItems || [];
        if (!vm.isCheckout && vm.section.item !== 'account') {
            vm.pathItems.unshift(vm.section);
        } else if (vm.pathItems.length === 0) {
            vm.sectionParent = {
                item: 'Services',
                count: vm.currentPath.length,
                state: {
                    name: 'services.categories'
                }
            };
            vm.pathItems.push(vm.sectionParent);
        } else if (vm.section.item !== SettingsService.BreadCrumbSection.ACCOUNT &&
         vm.section.item !== SettingsService.BreadCrumbSection.REPAIR) {
            vm.pathItems.push(vm.section);
        }
        BreadcrumbService.setTaskDescription(vm.pathItems);
    });
}

BreadCrumbCtrl.$inject = ['$location', '$scope', '$state', 'BreadcrumbService', 'SettingsService'];

(angular
	.module('RelayServicesApp.Components')
).component('breadcrumb', {
    templateUrl: 'assets/templates/components/breadcrumb/index.html',
    controller: BreadCrumbCtrl,
    bindings: {
        isCheckout: '<',
        pathItems: '=',
        noBorder: '<'
    }
});
