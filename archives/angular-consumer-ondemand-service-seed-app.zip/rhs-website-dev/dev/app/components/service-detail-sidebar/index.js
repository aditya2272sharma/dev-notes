'use strict';

function ServiceDetailSidebar(SettingsService, _, ZipcodeInfoService,
    locationService, $scope, $uibModal, state) {
    var ctrl = this;

    ctrl.messageLabel = {
        EDIT_ADDRESS: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR,
        SERVICE_UNAVAILABLE_ERROR: SettingsService.Error.SERVICE_UNAVAILABLE_ERROR
    };

    ctrl.init = function () {
        $scope.$watch('$ctrl.projectData', function(){
            if (ctrl.projectData) {
                ctrl.applianceName = ctrl.projectData.appliance;
                var appType = _.find(SettingsService.AppliaceTypes, function (obj) {
                    return obj.value === ctrl.projectData.appliancetype || obj.value === ctrl.projectData.applianceType;
                });
                ctrl.applianceType = appType && appType.label;
            }
        });

    };

    // SLT-398 Code Revert
    // ctrl.gotoTechTalk = function() {
    //     state.go("tech-talk-static-landing");
    // }

    // ctrl.learnMoreAboutTechTalk = function() {
    //     var size = "md";
    //     var modalInstance = $uibModal.open({
    //       animation: true,
    //       ariaLabelledBy: "modal-title",
    //       ariaDescribedBy: "modal-body",
    //       templateUrl:
    //         "assets/templates/components/tech-talk/learn-more-modal/learn-more-modal.html",
    //       controller: "TechTalkLearnMoreModal",
    //       controllerAs: "$ctrl",
    //       size: size,
    //       resolve: {}
    //     });

    //     modalInstance.result.then(
    //       function(result) {
    //           if(result)
    //             ctrl.gotoTechTalk();
    //       },
    //       function() {
    //         console.log("Modal dismissed at: " + new Date());
    //       }
    //     );
    //   };

    ctrl.init();
}

ServiceDetailSidebar.$inject = ['SettingsService', '_', 'ZipcodeInfoService',
'locationService', '$scope', '$uibModal', '$state'];

(angular
    .module('RelayServicesApp.Components')
).component('serviceDetailSidebar', {
    templateUrl: (
        'assets/templates/components/service-detail-sidebar/index.html'
    ),
    controller: ServiceDetailSidebar,
    bindings: {
        projectData: '<',
        location: '<',
        showOrderId: '<',
        showImages: '<',
        costEstimate: '<'
    }
});
