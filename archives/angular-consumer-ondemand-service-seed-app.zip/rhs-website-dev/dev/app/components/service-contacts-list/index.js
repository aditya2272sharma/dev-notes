'use strict';

function ServiceContactsList($scope, _, SettingsService, $rootScope) {
    var ctrl = this;

    ctrl.messageLabel = {
        EDIT_ADDRESS: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR,
        SERVICE_UNAVAILABLE_ERROR: SettingsService.Error.SERVICE_UNAVAILABLE_ERROR
    };
    _.extend(ctrl.messageLabel, SettingsService.FormValidation);

    ctrl.init = function() {
        ctrl.serviceContact = {}
        ctrl.trackFormChanges({isFormValid: false});

        $scope.$watch('$ctrl.form.$valid', function(newVal) {
            if (newVal) {
                ctrl.trackFormChanges({isFormValid: true});
            } else {
                ctrl.trackFormChanges({isFormValid: false});
            }
        });
    };
    ctrl.init();
}

ServiceContactsList.$inject = ['$scope', '_',
                                'SettingsService', '$rootScope'];

(angular
    .module('RelayServicesApp.Components')
).component('serviceContactsList', {
    templateUrl: (
        'assets/templates/components/service-contacts-list/index.html'
    ),
    controller: ServiceContactsList,
    bindings: {
        email: '<',
        projectContact: '=',
        trackFormChanges: '&'
    }
});
