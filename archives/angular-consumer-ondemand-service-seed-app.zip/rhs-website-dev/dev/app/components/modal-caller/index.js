'use strict';

angular
.module('RelayServicesApp.Components')
.directive('modalCaller', [
	'specialServiceModalService',
	function(specialServiceModalService) {
    return {
        restrict:'A',
        link: function(scope) {
            scope.openModal = specialServiceModalService.openModal;
        }
    };
	}
]);
