'use strict';

function RescheduleRejectConfirmationCtrl($scope, $uibModalInstance, SettingsService) {
    var vm = this;
    vm.rejectDropdownOptions = SettingsService.RescheduleRejectDropdownOptions;

    $scope.messageLabel = {
        CURRENT: SettingsService.Messages.REJECT_RESCHEDULE_CONFIRMATION
    };

    vm.submit = function(action) {
        $uibModalInstance.close(action);
    };

    vm.close = function() {
        $uibModalInstance.dismiss(null);
    };
}

RescheduleRejectConfirmationCtrl.$inject = [
    '$scope',
    '$uibModalInstance',
    'SettingsService'
];

(angular
    .module('RelayServicesApp.Components')
).controller('RescheduleRejectConfirmationCtrl', RescheduleRejectConfirmationCtrl);
