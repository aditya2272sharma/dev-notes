'use strict';

function InlineSignup($window, accountModalService, LoginManagerService, SettingsService,
    vcRecaptchaService, Environment, $scope, $rootScope) {

    var ctrl = this;
    ctrl.messageLabel = {
        CURRENT: '',
        CURRENT_SIGNUP: '',
        CURRENT_GUEST: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR
    };

    ctrl.featurePasswordRecovery = Environment.features.featurePasswordRecovery;
    ctrl.pwdStandardsFailed = false;
    ctrl.custInfoTouched = false;
    ctrl.signinCaptcha = '';
    ctrl.signupCaptcha = '';
    ctrl.guestCaptcha = '';
    ctrl.isGuest = false;
    ctrl.promptSALUser = false;
    ctrl.recaptchaApiKey = SettingsService.Keys.RECAPTCHA_API_KEY;
    ctrl.recaptchaSignupApiKey = SettingsService.Keys.RECAPTCHA_PROD_API_KEY;
    if (Environment.name === 'prod') {
        ctrl.recaptchaApiKey = SettingsService.Keys.RECAPTCHA_PROD_API_KEY;
    }

    // Method used by user for authentication while checkout
    // Valid values are 'signin', 'signup', 'guest'
    ctrl.AUTH_TYPES = {
        SIGNIN: 'signin',
        SIGNUP: 'signup',
        GUEST: 'guest'
    };

    ctrl.popover = {
        password: 'assets/templates/pages/account/signup/popover-password-standards.html'
    };

    ctrl.init = function () {
        ctrl.authenticationType = null;
        ctrl.customerDetails = {};

        if(ctrl.isRegistered) {
            ctrl.showCustDetails = true;
            ctrl.customerDetails = {
                name: $rootScope.firstName + ' ' + $rootScope.lastName,
                email: $rootScope.email,
                contact: $rootScope.contact,
                profileImage: $rootScope.profileImage
            };
        }

        $rootScope.$on('user:authentication:change', function(event, user) {
            //Assign authenticated data if exists
            ctrl.customerDetails = {
                name: user.firstName + ' ' + user.lastName,
                email: user.email,
                contact: user.contact,
                profileImage: user.profileImage
            };
            ctrl.isRegistered = true;
        });

        $scope.$watch('$ctrl.authenticationType', function() {
            ctrl.isCustInfoSelected = true;
            ctrl.custInfoTouched = true;
        });

        $scope.$watch('$ctrl.isRegistered', function() {
            ctrl.showCustDetails = true;
            ctrl.customerDetails = {
                name: $rootScope.firstName + ' ' + $rootScope.lastName,
                email: $rootScope.email,
                contact: $rootScope.contact,
                profileImage: $rootScope.profileImage
            };
        });
    };

    ctrl.selectAuthenticationType = function (method) {
        ctrl.authenticationType = method;
        ctrl.isCustInfoSelected = true;
        ctrl.isGuest = (method === ctrl.AUTH_TYPES.GUEST);
    }

    /**
     * Signs user in
     */
    ctrl.signIn = function (form) {
        if (form.$valid) {
            ctrl.loginData = {
                'username': ctrl.username,
                'password': ctrl.password,
                'recaptchaToken': ctrl.signinCaptcha
            };
            LoginManagerService.login(ctrl.loginData).then(ctrl.loginSuccess, ctrl.loginError);
        }
    };

    /**
     * Success response of signin service
     */
    ctrl.loginSuccess = function() {
        $rootScope.$broadcast('user:loggedin');
        ctrl.onRegisterSuccess();
    };

     /**
     * Success response of signup/guest service
     */
    ctrl.onRegisterSuccess = function() {
        ctrl.showCustDetails = true;
        if(ctrl.isGuest) {
            $rootScope.$emit('guest-checkout', true);
        }
        ctrl.onSuccess();
    };

    /**
     * Error response of signin service
     * @param  {Object} error -  Error response
     */
    ctrl.loginError = function (error) {
        ctrl.messageLabel.CURRENT = error.message ? error.message : ctrl.messageLabel.DEFAULT;
        vcRecaptchaService.reload(0);
    };

    ctrl.setSigninCaptcha = function(response) {
        ctrl.signinCaptcha = response;
    }

    ctrl.setSignupCaptcha = function(response) {
        ctrl.signupCaptcha = response;
    }

    ctrl.setGuestCaptcha = function(response) {
        ctrl.guestCaptcha = response;
    }

    /**
     * Calls Register service
     * @param  {Object} form - Contains the form object
     */
    ctrl.signUp = function (form) {
        ctrl.pwdStandardsFailed = false;
        ctrl.isGuest = false;
        ctrl.messageLabel.CURRENT_SIGNUP = '';
        if (form.$valid) {
            ctrl.registerData = {
                'username': ctrl.email,
                'password': ctrl.password,
                'cpassword': ctrl.passwordConfirm,
                'acceptconditions': true,
                'firstname': ctrl.firstname,
                'lastname': ctrl.lastname,
                'contact': ctrl.phone,
                'recaptchaToken': ctrl.signupCaptcha
            };
            LoginManagerService.register(ctrl.registerData).then(ctrl.onRegisterSuccess, ctrl.registerError);
        }
    };

     /**
     * Validates if a guest user exists already in the system
     * Meant to be triggered on blur of email & phone number fields
     * Both values should be present
     * @param  {Object} form - Contains the form object
     */
     ctrl.validateGuestUserAccount = function (form) {
        var username;

        if (!form.email.$valid || !form.email.$viewValue) {
            return;
        }

        ctrl.messageLabel.CURRENT_GUEST = '';
        username = form.email.$viewValue;

        LoginManagerService.isSALUser(username, false)
        .then(function(response) {
            if (response) {
                ctrl.promptSALUser = true;
            } else {
                ctrl.promptSALUser = false;
            }
        }, ctrl.guestSignupError);
    };
     /**
     * Calls Guest Signup service
     * @param  {Object} form - Contains the form object
     */
    ctrl.guestSignUp = function (form) {
        ctrl.pwdStandardsFailed = false;
        ctrl.isGuest = true;
        ctrl.messageLabel.CURRENT_SIGNUP = '';
        if (form.$valid) {
            ctrl.registerData = {
                'username': form.email.$viewValue,
                'firstname': form.firstname.$viewValue,
                'lastname': form.lastname.$viewValue,
                'contact': form.phone.$viewValue
            };

            LoginManagerService.registerGuest(ctrl.registerData).then(ctrl.onRegisterSuccess, ctrl.guestSignupError);
        }
    };

    /**
     * Error response of register service
     * @param  {Object} error -  Error response
     */
    ctrl.registerError = function (error) {
        console.log('recaptcha reload');
        vcRecaptchaService.reload(1);
        ctrl.messageLabel.CURRENT_SIGNUP = error && error.message ? error.message : ctrl.messageLabel.DEFAULT;
        if (SettingsService.Error.SIGNUP_PASSWORD_STD_ERROR === ctrl.messageLabel.CURRENT_SIGNUP) {
            ctrl.pwdStandardsFailed = true;
        }

        if (error.code === "errors.signup.duplicate.user") {
            ctrl.username = ctrl.email;
            ctrl.messageLabel.CURRENT_SIGNUP = "errors.signup.duplicate.user";
        }
    };

    ctrl.gotoSignin = function () {
        ctrl.authenticationType = ctrl.AUTH_TYPES.SIGNIN;
    }

     /**
     * Error response of guest signup service
     * @param  {Object} error -  Error response
     */
    ctrl.guestSignupError = function (error) {
        console.log('recaptcha reload');
        vcRecaptchaService.reload(2);

        ctrl.messageLabel.CURRENT_GUEST = error && error.message ? error.message : ctrl.messageLabel.DEFAULT;
        if (SettingsService.Error.SIGNUP_PASSWORD_STD_ERROR === ctrl.messageLabel.CURRENT_GUEST) {
            ctrl.pwdStandardsFailed = true;
        }
    };

    ctrl.passwordValidationError = null;

    function validate(event) {
        if (!ctrl.email) {
            ctrl.passwordValidationError = 'Provide your email first';
            return;
        }
        var fieldValue = event.target.value;
        var mailId = ctrl.email.split('@')[0];

        if (!fieldValue) {
            ctrl.passwordValidationError = 'Password is required';
            return;
        }

        if (fieldValue.length < 8) {
            ctrl.passwordValidationError = 'Password too small';
            return;
        }

        if (!/[A-z]/.test(fieldValue)) {
            ctrl.passwordValidationError = 'Must contain letters';
            return;
        }

        if (!/[0-9]/.test(fieldValue)) {
            ctrl.passwordValidationError = 'Password must contain numbers';
            return;
        }

        if (fieldValue.indexOf(ctrl.firstname) > -1 || fieldValue.indexOf(ctrl.lastname) > -1) {
            ctrl.passwordValidationError = 'Password must not be\/contain your name';
            return;
        }

        if (fieldValue.indexOf(mailId) > -1) {
            ctrl.passwordValidationError = 'Password must not be\/contain your Email Id';
            return;
        }

        if (/([0-9a-zA-Z])\1{3,}/gi.test(fieldValue)) {
            ctrl.passwordValidationError = 'Can\'t repeat same character more than 3 times in a row';
            return;
        }

        if (/([?!\s])/gi.test(fieldValue)) {
            ctrl.passwordValidationError = 'No spaces, ! or ?';
            return;
        }
        /*
        // More rules can be added as per requirement
        if (/[~!@#$%^&*()_+=-`<>/]/.test(fieldValue)) {
            ngModel.$setValidity('passwordValidation', false);
            scope.passwordValidationError = 'Password must contain special characters';
            return undefined;
        }
        */
        ctrl.passwordValidationError = null;
    }
    ctrl.validate = validate;

    ctrl.recoverInit = function () {
        accountModalService.recoverInit();
    };

    ctrl.goToTermsOfUse = function () {
        $window.open(SettingsService.URLS.SEARS_TERMS_OF_USE_URL, '_blank');
    };

    ctrl.goToShopYourWayProgramTerms = function () {
        $window.open(SettingsService.URLS.SYW_PROGRAM_TERMS_URL, '_blank');
    };

    ctrl.goToPrivacyPolicy = function () {
        $window.open(SettingsService.URLS.SEARS_PRIVACY_POLICY_URL, '_blank');
    };

    ctrl.init();
}

InlineSignup.$inject = [
    '$window', 'accountModalService', 'LoginManagerService', 'SettingsService',
    'vcRecaptchaService', 'ENVIRONMENT', '$scope', '$rootScope'
];

(angular
    .module('RelayServicesApp.Components')
).component('inlineSignup', {
    templateUrl: (
        'assets/templates/components/inline-signup/index.html'
    ),
    controller: InlineSignup,
    bindings: {
        onSuccess: '&',
        onContinue: '&',
        isRegistered: '=',
        isCustInfoOpen: '='
    }
});
