'use strict';

function LearnMoreModal($uibModalInstance) {

    var vm = this;
    
    vm.init = function() {
        
    };

    vm.ok = function () {
        $uibModalInstance.close();
    };

    vm.close = function() {
        $uibModalInstance.close();
    };

    vm.requestTechTalk = function() {
        $uibModalInstance.close({requestTechTalk:true});
    };

    vm.scheduleInhomeRepair = function() {
        $uibModalInstance.close({scheduleInHomeRepair:true});
    };

    vm.init();
}

LearnMoreModal.$inject = ['$uibModalInstance'];

(angular
    .module('RelayServicesApp.Components')
).controller('TechTalkLearnMoreModal', LearnMoreModal);
