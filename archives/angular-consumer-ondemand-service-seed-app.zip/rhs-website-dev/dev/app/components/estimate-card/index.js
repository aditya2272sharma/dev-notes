'use strict';

function EstimateCard($log, ProjectsService, SettingsService, modal, ProjectDateTimeModalService) {
    var ctrl = this,
        projectId = ctrl.projectId,
        updatedDate = '',
        updatedTimeSlot = '';
    //project;

    ctrl.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR,
        CANCEL: SettingsService.Error.CANCEL_ERROR
    };

    ctrl.acceptRejectEstimate = function(decision, estimateId) {
        //Call modal
        if (decision === 'Reject') {
            ctrl.rejectEstimate(decision, estimateId);
        } else {
            ProjectDateTimeModalService.openModal(projectId, ctrl.startDate, function(serviceDate, serviceTime) {
                updatedDate = serviceDate;
                updatedTimeSlot = serviceTime;
                ctrl.handleEstimate(decision, estimateId, ctrl.acceptEstimateCallback);
            });
        }
    };

    ctrl.handleEstimate = function(decision, estimateId, successCallback, errorCallback) {
        (ProjectsService
            .acceptOrRejectProjectEstimation(projectId, estimateId, decision)
        ).then(function(result) {
            //Cancel service
            if (ctrl.decision === 'Reject') {

                var cancelService = {
                    projectId: projectId,
                    reason: 'Product Damaged',
                    comment: 'Product Damaged'
                };

                (ProjectsService.getCancelMessageByProjectId(projectId))
                .then(function(cancelMessage) {
                    cancelService.amount = cancelMessage.charge;
                    (ProjectsService.cancel(cancelService)).then(function() {
                        if (successCallback) {
                            successCallback();
                        }
                    }, function(error) {
                        ctrl.estimateCardError(error);
                    });
                }, function(error) {
                    if (errorCallback) {
                        errorCallback(error);
                    } else {
                        ctrl.estimateCardError(error);
                    }
                });
            } else {
                if (successCallback) {
                    successCallback(result);
                }
            }
        }, function(error) {
            if (errorCallback) {
                errorCallback(error);
            } else {
                ctrl.estimateCardError(error);
            }
        });
    };

    ctrl.acceptEstimateCallback = function(acceptRejectObject) {
        ctrl.onAccept({
            response: acceptRejectObject,
            estimate: ctrl.estimate,
            date: updatedDate,
            time: updatedTimeSlot
        });
    };

    ctrl.rejectEstimate = function(decision, estimateId) {
        ctrl.estimateId = estimateId;
        ctrl.decision = decision;
        var actionsModal = modal.open({
            animation: true,
            controller: 'RejectActionsCtrl as RejectActionsController',
            templateUrl: 'assets/templates/pages/projects/reject-actions/index.html'
        });

        actionsModal.result.then(function(action) {
            //submit actions
            if (action === 'RESELECT') {
                //actions for reselect
                ctrl.handleEstimate(ctrl.decision, ctrl.estimateId, ctrl.reselectCallback);
            }
            if (action === 'CANCEL') {
                //actions for cancel
                ctrl.handleEstimate(ctrl.decision, ctrl.estimateId, ctrl.cancelCallback);
            }
        }, function() {
            //closed modal
        });
    };

    ctrl.estimateCardError = function(error) {
        ctrl.messageLabel.CURRENT = error && error.message ? error.message : ctrl.messageLabel.DEFAULT;
    };

    ctrl.reselectCallback = function() {
        ctrl.onRejectReselect({projectId: projectId});
    };

    ctrl.cancelCallback = function() {
        ctrl.onRejectCancel({projectId: projectId});
    };

}

EstimateCard.$inject = ['$log', 'ProjectsService', 'SettingsService', '$uibModal', 'ProjectDateTimeModalService'];

(angular
    .module('RelayServicesApp.Components')
).component('estimateCard', {
    templateUrl: (
        'assets/templates/components/estimate-card/index.html'
    ),
    controller: EstimateCard,
    bindings: {
        projectId: '<',
        projectStatus: '<',
        estimate: '<',
        onAccept: '&',
        onReject: '&',
        onError: '&',
        onRejectReselect: '&',
        onRejectCancel: '&'
    }
});
