'use strict';

function AppointmentDateTimePicker($filter, moment, SettingsService, _) {
    var ctrl = this,
    monthNames = SettingsService.DateTime.MonthNamesArray;

    ctrl.mode = {
        step: {
            days: 7
        }
    };
    ctrl.disableLeftMoveButton = false;
    ctrl.disableRightMoveButton = false;
    ctrl.formatWeekViewDayHeader = 'EEEE';
    ctrl.formatWeekViewDateHeader = 'd';

    ctrl.timeRanges = SettingsService.DateTime.TimeRanges;
    ctrl.preferredStartDates = ctrl.project.preferredStartDates;
    ctrl.preferredTimeSlots = ctrl.project.preferredSlots;
    ctrl.preferredNewDates = [];
    ctrl.preferredNewSlots = [];

    /** Error Messages **/
    ctrl.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR
    };

    /**
	* Getting initial info
    */
    ctrl.init = function() {
        ctrl.dates = ctrl.getDates(ctrl.availableDates[0].date, 7);
        ctrl.disableReschedule = false;
    };

    /**
    * Calculates 5 consecutive days from a startTime
    * @param {Object} startTime - Contains the date object
    * @param {variable} n - Consecutive days limit
    * @returns {Object} - Array of date objects
    */
    ctrl.getDates = function(startTime, n) {
        var dates = new Array(n),
            current = new Date(startTime),
            i = 0,
            month = -1,
            year = 0,
            monthYear = '';
        current.setHours(12); // Prevent repeated dates because of timezone bug
        while (i < n) {
            dates[i++] = {
                date: new Date(current)
            };
            if (month !== current.getMonth()) {
                if (month === -1) {
                    monthYear = monthNames[current.getMonth()];
                } else if (year !== 0 && year !== current.getFullYear()) {
                    monthYear = monthYear + ', ' + year + ' - ' + monthNames[current.getMonth()];
                } else {
                    monthYear = monthYear + ' - ' + monthNames[current.getMonth()];
                }
                month = current.getMonth();
                year = current.getFullYear();
            }
            current.setDate(current.getDate() + 1);
        }
        monthYear = monthYear + ', ' + year;
        ctrl.activeMonthYear = monthYear;
        return dates;
    };

    /**
    * For navigating through calendar view
    * @param {variable} direction - Indicates backward or forward move
    */
    ctrl.move = function(direction) {
        var step = ctrl.mode.step,
        curDay = new Date(ctrl.dates[0].date),
        currentCalendarDate = curDay,
        year = currentCalendarDate.getFullYear() + direction * (step.years || 0),
        month = currentCalendarDate.getMonth() + direction * (step.months || 0),
        date = currentCalendarDate.getDate() + direction * (step.days || 0);
        currentCalendarDate.setFullYear(year, month, date);

        ctrl.dates = ctrl.getDates(currentCalendarDate, 7);
        ctrl.enableMoveButton(ctrl.dates[ctrl.dates.length - 1].date);
    };

    /**
    * For enabling right navigation button
    */
    ctrl.enableMoveButton = function(dayOfWeek) {
        var maxDay = moment(ctrl.availableDates[ctrl.availableDates.length - 1].date).toDate();
        var minDay = moment(ctrl.availableDates[0].date).toDate();
        if (dayOfWeek > maxDay) {
            ctrl.disableRightMoveButton = true;
        } else {
            ctrl.disableRightMoveButton = false;
        }
        if (dayOfWeek < minDay) {
            ctrl.disableLeftMoveButton = true;
        } else {
            ctrl.disableLeftMoveButton = false;
        }
    };

    /**
    * Highlight current timeslot(s) in calendar view
    * @param {Object} date - date from calendarview
    * @param {Object} timeslot - timeslot from calendarview
    * @returns {boolean} - returns true if date and timeslot is same as current date and time
    */
    ctrl.getDefaultData = function(date, timeslot) {
        var newTimeSlot, formattedDate, timeslotParam, decision;
        formattedDate = moment(date).format('YYYY-MM-DD');
        if (formattedDate === ctrl.currentDate) {
            newTimeSlot = ctrl.getNewTimeSlot(ctrl.currentTimeSlot);
            timeslotParam = ctrl.getNewTimeSlot(timeslot);
            if (timeslotParam === newTimeSlot) {
                return true;
            }
        }
        if (ctrl.preferredStartDates.length > 0 && ctrl.currentDate === null) {
            // we don't need to preserve the result of the filter anymore
            // because we're using a variable `decision` to decide
            // whether to highlight a date-time in orange or not, and
            // this also means that we can replace `filter` with `forEach`
            ctrl.preferredStartDates.filter(function (date, index) {
                if (formattedDate === date) {
                    newTimeSlot = ctrl.getNewTimeSlot(ctrl.preferredTimeSlots[index]);
                    timeslotParam = ctrl.getNewTimeSlot(timeslot);
                    if (timeslotParam === newTimeSlot) {
                        decision = true;
                    }
                    
                }
                return (formattedDate === date);
            });
            return decision;
        }
        return false;
    };

    ctrl.getNewTimeSlot = function(timeslot) {
        if (timeslot.indexOf('8:00 AM') > -1) {
            return '8:00 AM - 12:00 PM';
        }
        if (timeslot.indexOf('12:00 PM') > -1 && timeslot.indexOf('4:00 PM') > -1) {
            return '12:00 PM - 4:00 PM';
        }
        if (timeslot.indexOf('8:00 PM') > -1) {
            return '4:00 PM - 8:00 PM';
        }
        return timeslot;
    };

    /**
    * Sets valid new date and time slot
    * @param {Object} timeSlot - timeslot from calendarview
    * @param {Object} date - date from calendarview
    */
    ctrl.setTimeSlot = function(timeSlot, date) {
        var newDate = {};
        var formattedDate = moment(date).format('YYYY-MM-DD');
        var formattedTimeSlot = ctrl.getNewTimeSlot(timeSlot);
        var currentTimeSlot = ctrl.getNewTimeSlot(ctrl.currentTimeSlot);
        if (ctrl.checkDateValidity(date) ||
            (formattedDate === ctrl.currentDate && formattedTimeSlot === currentTimeSlot)) {
            ctrl.disableReschedule = true;
        } else {
            // Multiple date-time slots appear only in unaccepted `SSv3` orders
            // `startDate` for such projects is null & is a valid Project type check
            // we've to check for Project type before we insert date into `preferredNewDates`
            if (ctrl.project.startDate === null) {
                ctrl.messageLabel.CURRENT = '';
                if (ctrl.checkForDuplicateTimeslots(timeSlot, date)) {
                    ctrl.messageLabel.CURRENT = [
                        'You\'ve already selected the date/timeslot.',
                        'Please select different date/timeslot'
                    ].join(' ');
                    return;
                }

                if (ctrl.preferredNewDates.length < 3 && ctrl.preferredNewSlots.length < 4) {
                    ctrl.preferredNewDates.push(formattedDate);
                    ctrl.preferredNewSlots.push(formattedTimeSlot);
                } else {
                    ctrl.preferredNewDates.splice(0, 1);
                    ctrl.preferredNewSlots.splice(0, 1);
                    ctrl.preferredNewDates.push(formattedDate);
                    ctrl.preferredNewSlots.push(formattedTimeSlot);
                }

                ctrl.disableReschedule = false;
                newDate = {
                    dates: ctrl.preferredNewDates,
                    timeSlots: ctrl.preferredNewSlots,
                    rescheduleBtnStatus: ctrl.disableReschedule
                };
                ctrl.onRescheduleDateChange({ RescheduledDate: newDate });
                return;
            }
            ctrl.disableReschedule = false;
            ctrl.newTimeSlot = timeSlot;
            ctrl.newDate = date;
            newDate = {
                date: ctrl.newDate,
                timeSlot: ctrl.newTimeSlot,
                rescheduleBtnStatus: ctrl.disableReschedule
            };
            ctrl.onRescheduleDateChange({ RescheduledDate: newDate });
            ctrl.formattedNewDate = formattedDate;
        }
    };

    /**
    * Highlight new timeslot in calendar view in Green
    * @param {Object} date - date from calendarview
    * @param {Object} timeSlot - timeslot from calendarview
    * @returns {boolean} - returns true if selected timeslot is a valid time
    */
    ctrl.getActiveNewDate = function(date, timeSlot) {
        var formattedDate = $filter('date')(date, 'yyyy-MM-dd');
        // this condition will hold good for other service types where we have only
        // one date & time-slot
        if (ctrl.newTimeSlot  === timeSlot && ctrl.formattedNewDate === formattedDate &&
            ctrl.newTimeSlot !== ctrl.currentDate) {
            return true;
        }

        // for multiple slots i.e. for SSv3, check the length
        // filter through the `preferredNewDates` array to find
        // if there are any matching dates
        // if the dates match, then check for the corresponding timeslot
        // if both cases pass, then `filteredDateTime` will hold
        // the array of matches
        // PS: This logic can be improved
        if (ctrl.preferredNewDates && ctrl.preferredNewDates.length > 0) {
            var filteredDateTime = ctrl.preferredNewDates.filter(function(date, index) {
                if (date === formattedDate) {
                    return (timeSlot === ctrl.preferredNewSlots[index]);
                }
            });
            return filteredDateTime.length > 0;
        }
    };

    /**
    * Checks new date validity
    * @param {Object} date - date from calendarview
    * @returns {Object} isValidDate- returns true if date is a weekday
    */
    ctrl.checkDateValidity = function(date) {
        date = moment(date).format('YYYY-MM-DD');
        var filteredResults = _.filter(ctrl.availableDates, function(availableDate) {
            return (date === availableDate.date);
        });
        return filteredResults.length > 0 ? false : true;
    };

    /**
    * For disabling left navigation arrow
    * @returns {boolean} - returns true if start date in the calendar is current date
    */
    ctrl.checkCurrentStart = function() {
        var startDay = $filter('date')(new Date(ctrl.dates[0].date), 'yyyy-MM-dd');
        var finaldate = moment().add(2, 'days');
        finaldate = finaldate.weekday() && finaldate.weekday() <= 5 ?
                    finaldate : finaldate.add(8 - (finaldate.weekday() || 7), 'days');
        var formattedDate = $filter('date')(finaldate._d, 'yyyy-MM-dd');
        if (startDay === formattedDate) {
            return true;
        }
    };

    ctrl.formatPreferredDate = function(date) {
        if (angular.isDate(moment(date)._d)) {
            return ($filter('date')(date, 'EEEE, dd MMMM yyyy'));
        }
    };

    ctrl.changeSelectedPreferenceTimeSequence = function(itemIndex, newIndex) {
        var tempNewDate = ctrl.preferredNewDates[newIndex];
        var tempNewTimeSlot = ctrl.preferredTimeSlots[newIndex];
        ctrl.preferredNewDates[newIndex] = ctrl.preferredNewDates[itemIndex];
        ctrl.preferredNewSlots[newIndex] = ctrl.preferredNewSlots[itemIndex];
    
        ctrl.preferredNewDates[itemIndex] = tempNewDate;
        ctrl.preferredNewSlots[itemIndex] = tempNewTimeSlot;
    };

    ctrl.deletePreferenceItem = function (itemIndex) {
        if (ctrl.preferredNewDates.length > itemIndex && ctrl.preferredNewSlots.length > itemIndex) {
            ctrl.preferredNewDates.splice(itemIndex, 1);
            ctrl.preferredNewSlots.splice(itemIndex, 1);
        }
    };

    ctrl.checkForDuplicateTimeslots = function(selectedTimeSlot, selectedDate) {
        var decision = false,
            formattedDate = moment(selectedDate).format('YYYY-MM-DD');

        // check if the date & time slot are already present
        // in the old set of date-time slots
        // if yes, set decision to `true`
        _.filter(ctrl.preferredStartDates, function(date, index){
            if (formattedDate === date) {
                if (selectedTimeSlot === ctrl.preferredTimeSlots[index]) {
                    decision = true;
                }
            }
        });

        if (decision) {
            return decision;
        }

        // a user can't reschedule if date is duplicate
        // check if the currently selected date is present
        // in the freshly selected dates. Check for the
        // time slot on that date. If they match, then
        // set decision to `true`
        // if they don't match, then return `decision`
        // default value for `decision` is `false`.
        _.filter(ctrl.preferredNewDates, function(date, index){
            if (formattedDate === date) {
                if (selectedTimeSlot === ctrl.preferredNewSlots[index]) {
                    decision = true;
                }
            }
        });

        return decision;
    };

    ctrl.init();
}

AppointmentDateTimePicker.$inject = ['$filter', 'moment', 'SettingsService', '_'];

(angular
	.module('RelayServicesApp.Components')
).component('appointmentDateTimePicker', {
    templateUrl: 'assets/templates/components/appointment-date-time-picker/index.html',
    controller: AppointmentDateTimePicker,
    bindings: {
        currentDate: '<',
        currentTimeSlot: '<',
        onRescheduleDateChange: '&',
        availableDates: '<',
        project: '<'
    }
});
