'use strict';

function OrderDetails(_, SettingsService, ProjectsService, modal, ProjectDateTimeModalService, $sce,
    $state, EstimateSummaryInfoService, EstimateActionsService, CheckoutInfoService, $window,
    estimateRejectConfirmationService, moment, ENV) {

    var ctrl = this,
        projectMinStatus = SettingsService.ProjectMinStatus,
        projectMinActions = SettingsService.ProjectMinActions;

    ctrl.featurePaymentsV2 = (ENV.features.featurePaymentsV2 === 'true');

    ctrl.messageLabel = {
        EDIT_ADDRESS: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR,
        SERVICE_UNAVAILABLE_ERROR: SettingsService.Error.SERVICE_UNAVAILABLE_ERROR
    };

    ctrl.cancelOrder = function() {
        ctrl.onCancelOrder();
    };

    ctrl.init = function() {
        ctrl.isReschedule = false;
        ctrl.orderSteps = new Array(3);
        ctrl.estimate = ctrl.completeEstimate.estimate;
        ctrl.project = ctrl.completeEstimate.project;
        ctrl.completeEstimate.availableDates = ctrl.availableDates;

        ctrl.historyEventData = {
            itemNum: 0,
            title: '',
            desc: '',
            eventComment: '',
            time: '',
            status: '',
            isCurrentStep: false,
            showEstimateButtons: false,
            showBookProButton: false,
            showEstimateLink: false,
            showInvoiceLink: false,
            showProRescheduleLink: false,
            showProRescheduleButtons: false,
            showComments: false,
            showAvailableProsLink: false,
            availableProsURL: ''
        };

        (ProjectsService.getProjectMinHistory(ctrl.projectId)).
        then(function(minHistoryResp) {
            if (minHistoryResp.count === 0) {
                ctrl.messageLabel.CURRENT = SettingsService.Error.NO_RESPONSE;
            }

            var count = 0;
            var eventTitle = '';
            var eventDesc = '';
            var eventComment = '';

            //For greying-out the last step
            var isLastStep = false;
            var lastEvent = '';
            var lastEventIndex = '';
            var showEstimateButtons = false;
            var showBookProButton = false;
            var showEvent = false;
            var showEstimateLink = false;
            var showInvoiceLink = false;
            var showProRescheduleLink = false;
            var showProRescheduleButtons = false;
            var showComments = false;
            var serviceType = ctrl.project.serviceType;
            var serviceTypeText = '';
            var conjunction = '';
            var title = '';
            var orderTileDetailsMessage = '';
            var showAvailableProsLink = false;
            var availableProsURL = '';

            for (var i = 0; i < minHistoryResp.data.length; i++) {

                orderTileDetailsMessage = '';
                showEvent = false;
                showComments = false;
                showEstimateLink = false;
                showInvoiceLink = false;
                eventComment = '';
                lastEvent = minHistoryResp.data[minHistoryResp.data.length - 1].eventId;
                lastEventIndex = minHistoryResp.data.length - 1;
                // serviceType = minHistoryResp.data[i].metadata.serviceType;
                if (serviceType === SettingsService.ServiceTypes.STANDARD) {
                    serviceTypeText = '';
                } else {
                    serviceTypeText = 'estimate';
                }

                if (ctrl.estimate === undefined) {
                    title = '';
                } else {
                    title = ctrl.estimate.title;
                }

                if (serviceType === SettingsService.ServiceTypes.STANDARD_FIXED_PRICE) {
                    if (ctrl.completeEstimate.estimatesCount > 1) {
                        title = 'provider';
                    }
                }

                if (i === minHistoryResp.data.length - 1) {
                    isLastStep = true;
                }

                switch (minHistoryResp.data[i].eventId) {

                    case projectMinStatus.PROJECT_CREATED.eventId:
                        showEvent = true;
                        count ++;
                        if (ctrl.estimate === undefined) {
                            conjunction = 'for';
                            title = ctrl.project.title;
                        } else {
                            conjunction = 'to';
                            if (minHistoryResp.data[i].metadata.firmsdetails !== undefined) {
                                title = minHistoryResp.data[i].metadata.firmsdetails[0];
                            }
                        }
                        eventTitle = minHistoryResp.data[i].eventName;
                        eventDesc = $sce.trustAsHtml(projectMinStatus.PROJECT_CREATED.desc
                            .replace('{0}', serviceTypeText)
                            .replace('{1}', conjunction)
                            .replace('{2}', '<strong>' + title + '</strong>')
                        );
                        break;

                    case projectMinStatus.ESTIMATE_RECEIVED.eventId:
                        showEvent = true;
                        count ++;
                        eventTitle = minHistoryResp.data[i].eventName;
                        if (minHistoryResp.data[i].metadata.firmsdetails !== undefined) {
                            title = _.toArray(minHistoryResp.data[i].metadata.firmsdetails)[0];
                        }
                        eventDesc = $sce.trustAsHtml(projectMinStatus.ESTIMATE_RECEIVED.desc
                                .replace('{0}', '<strong>' + title + '</strong>')
                                .replace('{1}', '<strong>$' + minHistoryResp.data[i].metadata.estimateprice + '</strong>')
                            );

                        if (lastEvent === minHistoryResp.data[i].eventId &&
                            minHistoryResp.data[i].actions.indexOf(projectMinActions.ACCEPT_ESTIMATE) >= 0 &&
                            lastEventIndex === i) {
                            showEstimateButtons = true;
                        }
                        if (minHistoryResp.data[i].actions.indexOf(projectMinActions.VIEW_ESTIMATE) >= 0 &&
                        lastEventIndex === i) {
                            showEstimateLink = true;
                        }
                        break;

                    case projectMinStatus.ESTIMATE_ACCEPTED.eventId:
                        showEvent = true;
                        count ++;
                        eventTitle = minHistoryResp.data[i].eventName;
                        eventDesc = $sce.trustAsHtml(projectMinStatus.ESTIMATE_ACCEPTED.desc.replace('{0}',
                            '<strong>$' + minHistoryResp.data[i].metadata.estimateprice + '</strong>'));

                        if (lastEvent === minHistoryResp.data[i].eventId &&
                            minHistoryResp.data[i].actions.indexOf(projectMinActions.BOOK_PRO) >= 0 &&
                            lastEventIndex === i) {
                            showBookProButton = true;
                        }
                        break;

                    case projectMinStatus.AUTHORIZE_PAYMENT.eventId:
                        showEvent = true;
                        count ++;
                        eventTitle = minHistoryResp.data[i].eventName;
                        eventDesc = $sce.trustAsHtml(projectMinStatus.AUTHORIZE_PAYMENT.desc);
                        break;

                    case projectMinStatus.ORDER_UPDATED.eventId:
                        showEvent = true;
                        count ++;
                        eventTitle = minHistoryResp.data[i].eventName;
                        eventDesc = $sce.trustAsHtml(projectMinStatus.ORDER_UPDATED.desc);
                        break;

                    case projectMinStatus.ESTIMATE_CONFIRMED.eventId:
                        showEvent = true;
                        count ++;
                        eventTitle = minHistoryResp.data[i].eventName;
                        eventDesc = $sce.trustAsHtml(projectMinStatus.ESTIMATE_CONFIRMED.desc);
                        break;

                    case projectMinStatus.ESTIMATE_REJECTED.eventId:
                        showEvent = true;
                        count ++;
                        eventTitle = minHistoryResp.data[i].eventName;
                        eventDesc = $sce.trustAsHtml(projectMinStatus.ESTIMATE_REJECTED.desc);
                        break;

                    case projectMinStatus.ORDER_CREATED.eventId:
                        showEvent = true;
                        count ++;
                        // wasn't able to comprehend why [i - 1], moving ahead with [i] instead
                        // if (minHistoryResp.data[i - 1].actions.indexOf(projectMinActions.BOOK_PRO) >= 0) { ... }
                        if (lastEvent === minHistoryResp.data[i].eventId &&
                            minHistoryResp.data[i].actions.indexOf(projectMinActions.BOOK_PRO) >= 0 &&
                            lastEventIndex === i) {
                            showBookProButton = true;
                        }
                        eventTitle = minHistoryResp.data[i].eventName;
                        eventDesc = $sce.trustAsHtml(projectMinStatus.ORDER_CREATED.desc);
                        
                        break;

                    case projectMinStatus.PROJECT_CONFIRMED.eventId:
                        showEvent = true;
                        count ++;
                        eventTitle = minHistoryResp.data[i].eventName;
                        if (minHistoryResp.data[i].metadata.firmsdetails === undefined) {
                            orderTileDetailsMessage = 'your ServiceLive Provider.';
                        } else {
                            orderTileDetailsMessage = '<strong>' + minHistoryResp.data[i].metadata.firmsdetails + '</strong>';
                        }
                        eventDesc = $sce.trustAsHtml(projectMinStatus.PROJECT_CONFIRMED.desc
                            .replace('{0}', orderTileDetailsMessage));
                        if (lastEvent === minHistoryResp.data[i].eventId &&
                            minHistoryResp.data[i].actions.indexOf(projectMinActions.BOOK_PRO) >= 0 &&
                            lastEventIndex === i) {
                            showBookProButton = true;
                        }
                        break;

                    case projectMinStatus.PROCESS_PAYMENT.eventId:
                        showEvent = true;
                        count ++;
                        eventTitle = minHistoryResp.data[i].eventName;
                        eventDesc = $sce.trustAsHtml(projectMinStatus.PROCESS_PAYMENT.desc);
                        break;

                    case projectMinStatus.PROJECT_CLOSED.eventId:
                        showEvent = true;
                        count ++;
                        eventTitle = minHistoryResp.data[i].eventName;
                        eventDesc = $sce.trustAsHtml(projectMinStatus.PROJECT_CLOSED.desc);
                        break;

                    case projectMinStatus.RESCHEDULE_INITIATED.eventId:
                        showEvent = true;
                        showComments = true;
                        count ++;

                        eventTitle = minHistoryResp.data[i].eventName;
                        eventDesc = $sce.trustAsHtml(projectMinStatus.RESCHEDULE_INITIATED.desc.replace('{0}',
                            ctrl.createRescheduleText(minHistoryResp.data[i].metadata.dateTime,
                                minHistoryResp.data[i].metadata.slotBegin, minHistoryResp.data[i].metadata.slotEnd)));
                        eventComment = $sce.trustAsHtml(minHistoryResp.data[i].metadata.comment);
                        break;

                    case projectMinStatus.RESCHEDULE_INITIATED_PRO.eventId:
                        showEvent = true;
                        showComments = true;
                        count ++;

                        if (lastEvent === minHistoryResp.data[i].eventId &&
                            minHistoryResp.data[i].actions.indexOf(projectMinActions.ACCEPT_RESCHEDULE) >= 0 &&
                            lastEventIndex === i) {
                            showProRescheduleButtons = true;
                        }
                        if (lastEvent === minHistoryResp.data[i].eventId &&
                            minHistoryResp.data[i].actions.indexOf(projectMinActions.NEW_APPOINTMENT) >= 0 &&
                            lastEventIndex === i) {
                            showProRescheduleLink = true;
                        }
                        eventTitle = minHistoryResp.data[i].eventName;
                        eventDesc = $sce.trustAsHtml(projectMinStatus.RESCHEDULE_INITIATED_PRO.desc);
                        eventComment = $sce.trustAsHtml(minHistoryResp.data[i].metadata.rescheduleComments);
                        break;

                    case projectMinStatus.RESCHEDULE_CANCELLED.eventId:
                        showEvent = true;
                        count ++;
                        eventTitle = minHistoryResp.data[i].eventName;
                        eventDesc = $sce.trustAsHtml(projectMinStatus.RESCHEDULE_CANCELLED.desc);
                        break;

                    case projectMinStatus.PROJECT_CANCELLED.eventId:
                        showEvent = true;
                        count ++;
                        showInvoiceLink = true;
                        eventTitle = minHistoryResp.data[i].eventName;
                        eventDesc = $sce.trustAsHtml(projectMinStatus.PROJECT_CANCELLED.desc);
                        break;

                    case projectMinStatus.ORDER_COMPLETED.eventId:
                        showEvent = true;
                        count ++;
                        showInvoiceLink = true;
                        eventTitle = minHistoryResp.data[i].eventName;
                        if (ctrl.estimate === undefined) {
                            title = 'provider';
                        } else {
                            title = ctrl.estimate.title;
                        }
                        eventDesc = $sce.trustAsHtml(projectMinStatus.ORDER_COMPLETED.desc
                            .replace('{0}', '<strong>' + title + '</strong>'));
                        break;

                    case projectMinStatus.ESTIMATE_UPDATED.eventId:
                        showEvent = true;
                        count ++;
                        if (lastEvent === minHistoryResp.data[i].eventId &&
                            minHistoryResp.data[i].actions.indexOf(projectMinActions.ACCEPT_ESTIMATE) >= 0 &&
                            lastEventIndex === i) {
                            showEstimateButtons = true;
                        }
                        if (minHistoryResp.data[i].actions.indexOf(projectMinActions.VIEW_ESTIMATE) >= 0 &&
                        lastEventIndex === i) {
                            showEstimateLink = true;
                        }
                        if (lastEvent === minHistoryResp.data[i].eventId &&
                            minHistoryResp.data[i].actions.indexOf(projectMinActions.BOOK_PRO) >= 0 &&
                            lastEventIndex === i) {
                            showBookProButton = true;
                        }
                        eventTitle = minHistoryResp.data[i].eventName;
                        eventDesc = $sce.trustAsHtml(projectMinStatus.ESTIMATE_UPDATED.desc
                            .replace('{0}', '<strong>' + title + '</strong>')
                            .replace('{1}', '<strong>$' + minHistoryResp.data[i].metadata.oldPrice + '</strong>')
                            .replace('{2}', '<strong>$' + minHistoryResp.data[i].metadata.newPrice + '</strong>')
                        );
                        break;
                    case projectMinStatus.ESTIMATE_UPDATED_PRICE.eventId:
                        showEvent = true;
                        count ++;
                        if (lastEvent === minHistoryResp.data[i].eventId &&
                            minHistoryResp.data[i].actions.indexOf(projectMinActions.ACCEPT_ESTIMATE) >= 0 &&
                            lastEventIndex === i) {
                            showEstimateButtons = true;
                        }
                        if (minHistoryResp.data[i].actions.indexOf(projectMinActions.VIEW_ESTIMATE) >= 0 &&
                        lastEventIndex === i) {
                            showEstimateLink = true;
                        }
                        if (lastEvent === minHistoryResp.data[i].eventId &&
                            minHistoryResp.data[i].actions.indexOf(projectMinActions.BOOK_PRO) >= 0 &&
                            lastEventIndex === i) {
                            showBookProButton = true;
                        }
                        eventTitle = minHistoryResp.data[i].eventName;
                        eventDesc = $sce.trustAsHtml(projectMinStatus.ESTIMATE_UPDATED_PRICE.desc
                            .replace('{0}', '<strong>' + title + '</strong>')
                            .replace('{1}', '<strong>$' + minHistoryResp.data[i].metadata.oldPrice + '</strong>')
                            .replace('{2}', '<strong>$' + minHistoryResp.data[i].metadata.newPrice + '</strong>')
                        );
                        break;
                    case projectMinStatus.ESTIMATE_UPDATED_DETAILS.eventId:
                        showEvent = true;
                        count ++;
                        if (lastEvent === minHistoryResp.data[i].eventId &&
                            minHistoryResp.data[i].actions.indexOf(projectMinActions.ACCEPT_ESTIMATE) >= 0 &&
                            lastEventIndex === i) {
                            showEstimateButtons = true;
                        }
                        if (minHistoryResp.data[i].actions.indexOf(projectMinActions.VIEW_ESTIMATE) >= 0 &&
                        lastEventIndex === i) {
                            showEstimateLink = true;
                        }
                        if (lastEvent === minHistoryResp.data[i].eventId &&
                            minHistoryResp.data[i].actions.indexOf(projectMinActions.BOOK_PRO) >= 0 &&
                            lastEventIndex === i) {
                            showBookProButton = true;
                        }
                        eventTitle = minHistoryResp.data[i].eventName;
                        eventDesc = $sce.trustAsHtml(projectMinStatus.ESTIMATE_UPDATED_DETAILS.desc
                            .replace('{0}', '<strong>' + title + '</strong>')
                        );
                        break;
                    case projectMinStatus.RESCHEDULE_ACCEPTED_PRO.eventId:
                        showEvent = true;
                        count ++;
                        eventTitle = minHistoryResp.data[i].eventName;
                        eventDesc = $sce.trustAsHtml(projectMinStatus.RESCHEDULE_ACCEPTED_PRO.desc);
                        break;
                    case projectMinStatus.RESCHEDULE_REJECTED_PRO.eventId:
                        showEvent = true;
                        count ++;
                        eventTitle = minHistoryResp.data[i].eventName;
                        eventDesc = $sce.trustAsHtml(projectMinStatus.RESCHEDULE_REJECTED_PRO.desc);
                        break;
                    case projectMinStatus.RESCHEDULE_CANCELLED_PRO.eventId:
                        showEvent = true;
                        count ++;
                        eventTitle = minHistoryResp.data[i].eventName;
                        eventDesc = $sce.trustAsHtml(projectMinStatus.RESCHEDULE_CANCELLED_PRO.desc);
                        break;
                    case projectMinStatus.RESCHEDULE_REJECTED.eventId:
                        showEvent = true;
                        count ++;
                        eventTitle = minHistoryResp.data[i].eventName;
                        eventDesc = $sce.trustAsHtml(projectMinStatus.RESCHEDULE_REJECTED.desc);
                        break;
                    case projectMinStatus.RESCHEDULE_ACCEPTED.eventId:
                        showEvent = true;
                        count ++;
                        eventTitle = minHistoryResp.data[i].eventName;
                        eventDesc = $sce.trustAsHtml(projectMinStatus.RESCHEDULE_ACCEPTED.desc);
                        break;
                    case projectMinStatus.ORDER_EXPIRED.eventId:
                        showEvent = true;
                        count ++;
                        eventTitle = minHistoryResp.data[i].eventName;
                        eventDesc = $sce.trustAsHtml(projectMinStatus.ORDER_EXPIRED.desc);
                        break;
                    case projectMinStatus.ORDER_REJECTED_BY_FIRM.eventId:
                        showEvent = true;
                        count ++;
                        eventTitle = minHistoryResp.data[i].eventName;
                        eventDesc = $sce.trustAsHtml(projectMinStatus.ORDER_REJECTED_BY_FIRM.desc);
                        break;
                    case projectMinStatus.ORDER_RELEASED_BY_FIRM.eventId:
                        showEvent = true;
                        count ++;
                        eventTitle = minHistoryResp.data[i].eventName;
                        if (minHistoryResp.data[i].metadata.firmsdetails === undefined) {
                            orderTileDetailsMessage = 'firm';
                        } else {
                            orderTileDetailsMessage = '<strong>' + _.toArray(minHistoryResp.data[i].metadata.firmsdetails)
                                            .join(', ') + '</strong>';
                        }
                        if (lastEvent === minHistoryResp.data[i].eventId &&
                            minHistoryResp.data[i].actions.indexOf(projectMinActions.SHOW_AVAILABLE_PROS) >= 0 &&
                            lastEventIndex === i) {
                            ctrl.changeFirmVisibility();
                            if (minHistoryResp.data[i].metadata.availableFirmUrl) {
                                showAvailableProsLink = true;
                                availableProsURL = minHistoryResp.data[i].metadata.availableFirmUrl;
                            }
                        }
                        eventDesc = $sce.trustAsHtml(projectMinStatus.ORDER_RELEASED_BY_FIRM.desc
                            .replace('{0}', orderTileDetailsMessage));
                        break;
                    case projectMinStatus.ORDER_ACCEPTED_BY_PROVIDER.eventId:
                        showEvent = true;
                        count ++;
                        eventTitle = minHistoryResp.data[i].eventName;
                        title = minHistoryResp.data[i].metadata.firmName || 'firm';
                        eventDesc = $sce.trustAsHtml(projectMinStatus.ORDER_ACCEPTED_BY_PROVIDER.desc
                            .replace('{0}', '<strong>' + title + '</strong>'));
                        break;
                    case projectMinStatus.ORDER_REVISIT_NEEDED_BY_PROVIDER.eventId:
                        showEvent = true;
                        count ++;
                        eventTitle = minHistoryResp.data[i].eventName;
                        eventDesc = $sce.trustAsHtml(projectMinStatus.ORDER_REVISIT_NEEDED_BY_PROVIDER.desc
                            .replace('{0}', ctrl.createRevisitText(minHistoryResp.data[i].metadata.revisitDate)));
                        break;
                    case projectMinStatus.ORDER_REPOSTED_TO_NEW_FIRM.eventId:
                        showEvent = true;
                        count ++;
                        eventTitle = minHistoryResp.data[i].eventName;
                        if (minHistoryResp.data[i].metadata.firmsdetails === undefined) {
                            orderTileDetailsMessage = 'new firm.';
                        } else {
                            orderTileDetailsMessage = '<strong>' + _.toArray(minHistoryResp.data[i].metadata.firmsdetails)
                                            .join(', ') + '</strong>';
                        }
                        eventDesc = $sce.trustAsHtml(projectMinStatus.ORDER_REPOSTED_TO_NEW_FIRM.desc
                            .replace('{0}', orderTileDetailsMessage));
                        break;
                    case projectMinStatus.PROVIDER_CHECKED_IN.eventId:
                        showEvent = true;
                        count ++;
                        eventTitle = minHistoryResp.data[i].eventName;
                        eventDesc = $sce.trustAsHtml(projectMinStatus.PROVIDER_CHECKED_IN.desc);
                        break;
                    case projectMinStatus.PROVIDER_CANCELLED_PROJECT.eventId:
                        showEvent = true;
                        count ++;
                        eventTitle = minHistoryResp.data[i].eventName;
                        eventDesc = $sce.trustAsHtml(projectMinStatus.PROVIDER_CANCELLED_PROJECT.desc);
                        break;
                }
                
                if (_.get(ctrl, 'completeEstimate.estimate.bid') === null) {
                    showEstimateLink = false;
                }

                if (showEvent) {
                    // displaying events in reverse order
                    ctrl.historyEventData[minHistoryResp.data.length - 1 - i] = {
                        itemNum: count,
                        time: minHistoryResp.data[i].date,
                        title: eventTitle,
                        desc: eventDesc,
                        eventComment: eventComment,
                        isCurrentStep: isLastStep,
                        showEstimateButtons: showEstimateButtons,
                        showBookProButton: showBookProButton,
                        showEstimateLink: showEstimateLink,
                        showInvoiceLink: showInvoiceLink,
                        showProRescheduleLink : showProRescheduleLink,
                        showProRescheduleButtons : showProRescheduleButtons,
                        showComments : showComments,
                        showAvailableProsLink: showAvailableProsLink,
                        availableProsURL: availableProsURL
                    };
                }
            }
        }, function(error) {
            ctrl.messageLabel.CURRENT = error && error.message ? error.message : SettingsService.Error.NO_RESPONSE;
        });
    };

    ctrl.createRescheduleText = function(startDate, beginTimeSlot, endTimeSlot) {
        var formatstartDate = moment(startDate).format('MMM. D, YYYY');
        var rescheduleText = '<strong>' + formatstartDate + ' (' + beginTimeSlot + '-' + endTimeSlot + ')' + '</strong>';
        return rescheduleText;
    };

    ctrl.createRevisitText = function(revisitDateTime) {
        var dateTime = revisitDateTime.split(' ');
        var formatStartDate = moment(dateTime[0], 'YYYY-MM-DD')
            .format('MMM. D, YYYY');
        var revisitText = '<strong>' + formatStartDate +
            ' (' +
            dateTime[1].replace(/^0+/, '') +
            ' ' +
            dateTime[2] +
            ' - ' +
            dateTime[4].replace(/^0+/, '') +
            ' ' +
            dateTime[5] + ')' +
            '</strong>';
        return revisitText;
    };

    ctrl.rejectEstimateConfirmation = function(decision) {
        estimateRejectConfirmationService.openModal(function() {
            ctrl.acceptRejectEstimate(decision);
        }, ctrl.project, ctrl.estimate);
    };

    ctrl.acceptRejectEstimate = function(decision) {
        if (ctrl.status === 'ESTIMATE_UPDATED' || (ctrl.status === 'PROVIDER_CHECK_IN' &&
            (ctrl.estimate && ctrl.estimate.status === 'UPDATED'))) {
            // the second condition handles the specific case when a povider has alerady checked in
            // and updates the estimate at the service location
            var firmIds = ctrl.estimate.bid.estimateId,
            projectId = ctrl.project.id;
            ProjectsService.
            acceptOrRejectProjectEstimation(projectId, firmIds, decision)
            .finally(function() {
                $state.go($state.current, {}, {reload: true});
            });
        } else {
            var project = ctrl.completeEstimate.project;
            var estimate = ctrl.completeEstimate.estimate;
            // switch to acceptRejectEstimateWithoutDate(...) after payments v2 is ready
            if (ctrl.featurePaymentsV2) {
                EstimateActionsService.acceptRejectEstimateWithoutDate(decision, estimate, project, ctrl.availableDates).
                then(function() {}, function() {
                    ctrl.onEstimateActionFailed();
                });
            } else {
                EstimateActionsService.acceptRejectEstimate(decision, estimate, project, ctrl.availableDates).
                then(function() {}, function() {
                    ctrl.onEstimateActionFailed();
                });
            }
        }
    };

    ctrl.gotToCheckout = function() {
        var order = {
            id: ctrl.project.orderId,
            price: ctrl.estimate.bid.price,
            tax: ctrl.estimate.bid.tax
        };
        CheckoutInfoService.setCheckout({
            order: order,
            project: ctrl.project.id,
            firm: ctrl.estimate,
            zipcode: ctrl.project.location.zipCode,
            selectedTime: ctrl.project.timeSlot,
            selectedDate: ctrl.project.startDate,
            isNSFlow: true,
            email: ctrl.project.contact.emailId,
            availableDates: ctrl.availableDates
        });

        $state.go('payment.checkout');
    };

    ctrl.loadEstimateSummary = function() {
        EstimateSummaryInfoService.setEstimateSummary(ctrl.completeEstimate);
        $state.go('account.estimate-summary', {id: ctrl.projectId});
    };

    ctrl.viewProjectInvoice = function() {
        EstimateSummaryInfoService.setEstimateSummary(ctrl.completeEstimate);
        $state.go('projects.invoice', {id: ctrl.projectId});
    };

    ctrl.submit = function(action) {
        switch (action) {
            case 'Accept':
            case 'Reject':
                var updatedInfo = {
                    'id': ctrl.project.id,
                    'decision' : action
                };
                ProjectsService.acceptRejectProReschedule(updatedInfo).then(function() {
                    $state.go($state.current, {}, {reload: true});
                });
                break;
            case 'Propose':
                ctrl.proposeProjectData('Reject');
                break;
            case 'OpenRejectionDialog':
                var modalInstance = modal.open({
                    animation: true,
                    size: 'sm',
                    controller: 'RescheduleRejectConfirmationCtrl',
                    controllerAs: 'RescheduleRejectConfirmationCtrl',
                    templateUrl: 'assets/templates/components/reschedule-reject-confirmation/index.html'
                });
                modalInstance.result.then(ctrl.submit);
                break;
            default:
                break;
        }
    };

    ctrl.proposeProjectData = function(type) {
        var updatedInfo = {
            'id': ctrl.project.id,
            'decision' : type
        };
        ProjectsService.acceptRejectProReschedule(updatedInfo).then(function() {
            var projectDetails = {
                estimateObject: ctrl.completeEstimate.estimate,
                projectObject: ctrl.completeEstimate.project
            };
            var modalInstance = modal.open({
                animation: true,
                size: 'md',
                controller: 'RescheduleYourAppointment',
                controllerAs: 'RescheduleYourAppointment',
                resolve: {
                    project: function() {
                        return projectDetails;
                    },
                    availableDates: function() {
                        return ProjectsService.checkRescheduleAvailability(ctrl.project.id);
                    }
                },
                templateUrl: [
                    'assets/templates/components/reschedule/reschedule-your-appointment/index.html'
                ].join('')
            });
            modalInstance.result.then(function() {
                $window.location.reload();
            });
        });
    };

    ctrl.loadProReschedule = function() {
        var estimate = ctrl.completeEstimate;
        var modalInstance = modal.open({
            animation: true,
            size: 'md',
            controller: 'ProReschedule',
            controllerAs: 'ProReschedule',
            resolve: {
                project: function() {
                    return estimate;
                },
                availableDates: function() {
                    return ProjectsService.checkRescheduleAvailability(ctrl.project.id);
                },
            },
            templateUrl: [
                'assets/templates/components/reschedule/pro-reschedule/',
                'index.html'
            ].join('')
        });

        modalInstance.result.then(function() {
            $window.location.reload();
        });
    };

    ctrl.init();
}

OrderDetails.$inject = ['_', 'SettingsService', 'ProjectsService', '$uibModal', 'ProjectDateTimeModalService', '$sce',
'$state', 'EstimateSummaryInfoService', 'EstimateActionsService', 'CheckoutInfoService', '$window',
'estimateRejectConfirmationService', 'moment', 'ENVIRONMENT'];

(angular.
    module('RelayServicesApp.Components')
).component('orderDetails', {
    templateUrl: (
        'assets/templates/components/order-detail/index.html'
    ),
    controller: OrderDetails,
    bindings: {
        status: '<',
        onCancelOrder: '&',
        standard: '<',
        onAccept: '&',
        onReject: '&',
        onRejectReselect: '&',
        onRejectCancel: '&',
        projectId: '<',
        completeEstimate: '<',
        onEstimateActionFailed: '&',
        availableDates: '<',
        changeFirmVisibility: '&'
    }
});
