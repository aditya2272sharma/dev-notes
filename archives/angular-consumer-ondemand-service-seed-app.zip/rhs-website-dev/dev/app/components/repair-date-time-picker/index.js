'use strict';

function RepairDateTimePicker($filter, moment, SettingsService, RepairService) {
    var ctrl = this,
    monthNames = SettingsService.DateTime.MonthNamesArray;

    ctrl.mode = {
        step: {days: 5}
    };

    ctrl.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR,
        UNAVAILABLE: SettingsService.Error.NO_TIME_SLOTS_AVAILABLE
    };

    ctrl.formatWeekViewDayHeader = 'EEEE';
    ctrl.formatWeekViewDateHeader = 'd';

    /**
	* Getting initial info
    */
    ctrl.init = function() {
        RepairService.getAvailableDates(ctrl.projectData).then(function(availDates) {
            if (availDates && availDates.count > 0) {
                ctrl.availableTimeslots = availDates.data;
                ctrl.count = availDates.data.length;
                ctrl.availableTimeslots = ctrl.parseDate();
                ctrl.populateDates(ctrl.availableTimeslots[0].date);
                ctrl.isTimeslotsFound = true;
            } else {
                ctrl.isTimeslotsFound = false;
            }
        }, function(error) {
            ctrl.showError();
            ctrl.messageLabel.CURRENT = error.message;
        });
        ctrl.disableReschedule = false;
    };

    /**
    * To parse json response
    * @returns {Object} - Array of available time slots with date
    */
    ctrl.parseDate = function() {
        var i = 0;
        var availTimeSlotes = new Array(ctrl.count);
        while (i < ctrl.count) {
            var timeSlotAvailability = ctrl.checkAvailTimeSlotes(ctrl.availableTimeslots[i].timeSlots);
            availTimeSlotes[i] = {
                date: ctrl.availableTimeslots[i].date,
                timeSlots: timeSlotAvailability
            };
            i++;
        }
        return availTimeSlotes;
    };

    /**
    * Populates timeslots in  fromTime - toTime format
    * @param {Object} timeSlots - Contains the timeslote object
    * @returns {Object} - Array of timeSlotes objects
    */
    ctrl.checkAvailTimeSlotes = function(timeSlots) {
        var timeslotes = new Array(3);
        if (timeSlots[0]) {
            timeslotes[0] = timeSlots[0].fromTime + ' - ' + timeSlots[0].toTime;
        }
        if (timeSlots[1]) {
            timeslotes[1] = timeSlots[1].fromTime + ' - ' + timeSlots[1].toTime;
        }
        if (timeSlots[2]) {
            timeslotes[2] = timeSlots[2].fromTime + ' - ' + timeSlots[2].toTime;
        }
        return timeslotes;
    };

    /**
    * Converts time into 12 hours format
    * @param {Object} time - Contains the time object
    */
    ctrl.convertTime = function(time) {
        // Check correct time format and split into components
        time = time.toString ().match (/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [time];

        if (time.length > 1) {
            time = time.slice (1);  // Remove full string match value
            time[5] = +time[0] < 12 ? 'am' : 'pm';
            time[0] = +time[0] % 12 || 12;
        }
        return time[0] + time[5];
    };

    /**
    * Populates dates with status  isAvail
    * @param {Object} weekStart - Contains the date object
    */
    ctrl.populateDates = function(weekStart) {
        ctrl.dates = ctrl.getDates(weekStart, 5);
        var i = 0, j = 0, formattedDate;
        ctrl.repairAvailability = new Array(5);
        while (i < 5) {
            j = 0;
            formattedDate = $filter('date')(ctrl.dates[i].date, 'yyyy-MM-dd');
            while (j < ctrl.count) {
                if (ctrl.availableTimeslots[j].date === formattedDate) {
                    ctrl.repairAvailability[i] = {
                        date: ctrl.availableTimeslots[j].date,
                        timeslots: ctrl.availableTimeslots[j].timeSlots,
                        isAvail: true
                    };
                    break;
                }
                if (j === ctrl.count - 1) {
                    var defaultSlots = new Array(3);
                    defaultSlots[0] = '8am - 12pm';
                    defaultSlots[1] = '10am - 2pm';
                    defaultSlots[2] = '1pm - 5pm';
                    ctrl.repairAvailability[i] = {
                        date: formattedDate,
                        timeslots: defaultSlots,
                        isAvail: false
                    };
                }
                j++;
            }
            i++;
        }
    };

    /**
    * Calculates 5 consecutive days from a startTime
    * @param {Object} startTime - Contains the date object
    * @param {variable} n - Consecutive days limit
    * @returns {Object} - Array of date objects
    */
    ctrl.getDates = function(startTime, n) {
        var dates = new Array(n),
            current = new Date(startTime),
            i = 0,
            month = -1,
            year = 0,
            monthYear = '';
        current.setHours(12); // Prevent repeated dates because of timezone bug
        while (i < n) {
            dates[i++] = {
                date: new Date(current)
            };
            if (month !== current.getMonth()) {
                if (month === -1) {
                    monthYear = monthNames[current.getMonth()];
                } else if (year !== 0 && year !== current.getFullYear()) {
                    monthYear = monthYear + ', ' + year + ' - ' + monthNames[current.getMonth()];
                } else {
                    monthYear = monthYear + ' - ' + monthNames[current.getMonth()];
                }
                month = current.getMonth();
                year = current.getFullYear();
            }
            current.setDate(current.getDate() + 1);
        }
        monthYear = monthYear + ', ' + year;
        ctrl.activeMonthYear = monthYear;
        return dates;
    };

    /**
    * For navigating through calendar view
    * @param {variable} direction - Indicates backward or forward move
    */
    ctrl.move = function(direction) {
        var step = ctrl.mode.step,
        curDay = new Date(ctrl.dates[0].date),
        currentCalendarDate = curDay,
        year = currentCalendarDate.getFullYear() + direction * (step.years || 0),
        month = currentCalendarDate.getMonth() + direction * (step.months || 0),
        date = currentCalendarDate.getDate() + direction * (step.days || 0);
        currentCalendarDate.setFullYear(year, month, date);
        ctrl.populateDates(currentCalendarDate);
    };

    /**
    * Sets valid new date and time slot
    * @param {Object} timeSlot - timeslot from calendarview
    * @param {Object} date - date from calendarview
    */
    ctrl.setTimeSlot = function(timeSlot, date, isDateValid) {
        if (!isDateValid) {
            ctrl.disableReschedule = true;
        } else {
            ctrl.disableReschedule = false;
            ctrl.selectedTimeSlot = timeSlot;
            ctrl.selectedDate = date;
            var scheduleData = {
                date: ctrl.selectedDate,
                timeSlot: ctrl.selectedTimeSlot,
                scheduleBtnStatus: ctrl.disableReschedule
            };
            ctrl.onRepairScheduleChange({RepairSchedule: scheduleData});
        }
    };

    /**
    * Highlight new timeslot in calendar view
    * @param {Object} date - date from calendarview
    * @param {Object} timeSlot - timeslot from calendarview
    * @returns {boolean} - returns true if selected timeslot is a valid time
    */
    ctrl.getActiveNewDate = function(date, timeSlot, isDateValid) {
        if (isDateValid && date === ctrl.selectedDate && timeSlot === ctrl.selectedTimeSlot) {
            return true;
        }
    };

    /**
    * To check timeslot
    * @param {Object} range - timeslot from calendarview
    * @returns {boolean} - returns true if timeslot is a valid time
    */
    ctrl.checkTimeSlot = function(range) {
        if (!range) {
            return true;
        }
    };

    ctrl.init();
}

RepairDateTimePicker.$inject = ['$filter', 'moment', 'SettingsService', 'RepairService'];

(angular
	.module('RelayServicesApp.Components')
).component('repairDateTimePicker', {
    templateUrl: 'assets/templates/components/repair-date-time-picker/index.html',
    controller: RepairDateTimePicker,
    bindings: {
        projectData: '<',
        onRepairScheduleChange: '&',
        showError: '&'
    }
});
