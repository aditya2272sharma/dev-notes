'use strict';

function taskLocationCtrl($scope, $window, modalInstance,
    projectTitle, addressesService,
    _, $rootScope, locationService) {

    var vm = {
        showOtherLocation: false,
        geolocation: {
            loader: false
        }
    };

    function setGeolocation() {
        var geolocation = $window.navigator && $window.navigator.geolocation;

        if (geolocation) {
            vm.geolocation.loader = true;
            $window.navigator.geolocation
            .getCurrentPosition(function(position) {
                locationService
                .getAddressByLatLong(position.coords.latitude, position.coords.longitude)
                .then(function(response) {
                      response.address = angular.copy(response);
                    _.assign(vm.geolocation, response, {loader: false});
                });
            });
        }
    }

    vm.toogleOtherLocation = function() {
        vm.showOtherLocation = !vm.showOtherLocation;
        if (vm.showOtherLocation) {
            vm.showAddNewAddress = false;
        }
        if (vm.showOtherLocation) {
            setGeolocation();
        }
    };

    vm.toogleAddNewAddress = function() {
        vm.showAddNewAddress = !vm.showAddNewAddress;
        if (vm.showAddNewAddress) {
            vm.showOtherLocation = false;
        }
    };

    /**
    * Getting initial info
    */
    $scope.init = function() {
        //console.log(projectTitle);
        $scope.projectName = projectTitle;

        addressesService.list().then(function(response) {
            vm.list = response;
            if (vm.list.length) {
                vm.addressSelected = (
                    vm.addressSelected && _.find(response, vm.addressSelected)
                ) || _.first(response);
            } else {
                vm.showOtherLocation = true;
                setGeolocation();
            }
            // vm.onAddressChange({address: vm.addressSelected});
        });
    };

    $scope.close = function() {
        modalInstance.dismiss();
    };

    $scope.serviceResults = function() {
        if (vm.showOtherLocation && $scope.completeAddress.street) {
            modalInstance.close($scope.completeAddress);
        } else {
            modalInstance.close(vm.addressSelected);
        }
    };

    $scope.showGeolocationLoader = function() {
        return vm.showOtherLocation && vm.geolocation.loader;
    };

    $scope.setLocation = function(location) {
        $scope.completeAddress = location.finalAddress;
        $scope.gstreet = location.address;
    };

    $scope.hasLocatization = function() {
        return vm.showOtherLocation && !!vm.geolocation.address;
    };

    /**
    ******************Init****************
    */
    $scope.init();

    $rootScope.$on('address:change', function() {
        vm.showOtherLocation = false;
        vm.showAddNewAddress = false;
        $scope.init();
    });

    return vm;
}

taskLocationCtrl.$inject = ['$scope', '$window', '$uibModalInstance',
    'projectTitle', 'addressesService',
    '_', '$rootScope', 'locationService'
];

(angular
    .module('RelayServicesApp.Components')
).controller('taskLocationCtrl', taskLocationCtrl);
