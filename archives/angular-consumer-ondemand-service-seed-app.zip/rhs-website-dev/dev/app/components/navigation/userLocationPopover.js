'use strict';

function UserLocationPopoverController(
    $rootScope,
    ZipcodeInfoService,
    locationService
  ) {
    var vm = this;

    vm.zipCode = ZipcodeInfoService.getZipcode();
    vm.isShowZipCodeError = false;

    vm.changedUserLocation = function() {
        if(vm.zipCode.length === 5) {
            vm.isShowZipCodeError = false; // hide zipcode error
            locationService
            .getlocation(vm.zipCode)
            .then(function(response){
              if(angular.isObject(response)) {
                  ZipcodeInfoService.setZipcode(vm.zipCode);
                  $rootScope.$emit('close-user-location-popover', response);
              } else {
                  vm.isShowZipCodeError = true; // show zipcode error
              }
            }, function(error) {
                console.log('Error: locationService.getlocation', error);
                vm.isShowZipCodeError = true;
            });
        }
    };

    vm.cancelUserLocationPopover = function() {
        $rootScope.$emit('close-user-location-popover', '');
    };
}

UserLocationPopoverController.$inject = [
    '$rootScope',
    'ZipcodeInfoService',
    'locationService'
];

(angular
    .module('RelayServicesApp.Components')
).controller('UserLocationPopoverController', UserLocationPopoverController);
