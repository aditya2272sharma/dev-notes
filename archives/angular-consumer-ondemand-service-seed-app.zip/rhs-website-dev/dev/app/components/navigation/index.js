 'use strict';

function NavigationBarCtrl(
    $window,
    $rootScope,
    location,
    $state,
    accountModalService,
    loginService,
    Notifications,
    SettingsService,
    specialServiceModalService,
    ZipcodeInfoService,
    repairProductModalService,
    $filter,
    ENV,
    _,
    $uibModal,
    $log,
    smartPhone,
    CookieManager,
    locationService
) {
    var ctrl = this,
        city,
        state;

    ctrl.logoRedirectionState = 'home.new';
    ctrl.customProject = ENV.features.customProject;
    ctrl.contactNumber = '1-888-236-1894';//CookieManager.getNavigationBarContactNumber();
    ctrl.displayCustomBanner = false;
    ctrl.userLocationPopoverTemplateUrl = [
      'assets/templates/components/',
      'navigation/userLocationPopoverView.html'
    ].join(''); // Array.join() for line breaks
    ctrl.userLocation = '';
    ctrl.isUserLocationPopoverOpen = false;
    ctrl.hidePbx = false; // to show/hide header pbx number
    ctrl.isSSV3 = ZipcodeInfoService.getServiceAvailabilityForZipcode();
    ctrl.pathName = window.location.pathname;
    ctrl.isModalOpen = false;
    ctrl.hidenavigationbar = true;
    ctrl.disableUserLocationEdit = false;
    ctrl.disableUserAuthentication = false;
    if (ctrl.pathName === '/mobile-login' ||
        ctrl.pathName === '/mobile-signup' ||
        ctrl.pathName === '/mobile-recover') {
        ctrl.hidenavigationbar = false;
    }

    ctrl.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR
    };

    ctrl.notifPopoverisOpen = false;
    ctrl.notificationsLoaded = false;

    //Default content
    ctrl.userData = {
        isRegistered: false,
        firstName: '',
        lastName: '',
        profileImage: ''
    };

    ctrl.bookAServiceBanner = ENV.features.bookAServiceBanner;
    ctrl.guaranteeBanner = ENV.features.guaranteeBanner;
    ctrl.earnPointsBanner = ENV.features.earnPointsBanner;

    $rootScope.$watch(function() {
        return location.path();
    }, function(a){
        if (a === '/' && ENV.features.displayCustomTopBanner) {
            ctrl.displayCustomBanner = true;
        } else {
            ctrl.displayCustomBanner = false;
        }
    });

    /*******************************************************************/
    /******** Moving all private method declarations to the top ********/
    function setCityAndState() {
        if ((city.length > 0) && (state.length > 0)) {
            ctrl.userLocation = city + ', ' + state;
        } else {
            // There are cases when we get only state or only city,
            // leading to an undesirable leading comma before the
            // empty string. This fix will prevent such cases.
            ctrl.userLocation = city + state;
        }
    }

    /**
     * Common Success callback for all `location` API calls
     * It sets the value for private variables - city and state
     * @param {result} Object - containing locaiton information
     * @return undefined
     */
    function locationFetchSuccessCallBack(result) {
        if(angular.isObject(result)){
            // address when fetched from googleApiUtilsService, it comes
            // with a `finalAddress` property, which the location api doesn't
            if (result.finalAddress) {
                result.city = result.finalAddress.city;
                result.state = result.finalAddress.state;
            }
            city = angular.isString(result.city) ? result.city : '';
            state = angular.isString(result.state) ? result.state : '';
            setCityAndState();
            ctrl.isSSV3 = ZipcodeInfoService.getServiceAvailabilityForZipcode();
        }
    }

    /**
     * This function abstract show zipcode modal functionality.
     * @param {String} zipCode it is optional field. To show predefined zipcode in the modal.
     */
    function showAskZipcodeModal(zipCode) {
        if(!ctrl.isModalOpen) {
            var size = 'xs';
            var modalInstance = $uibModal.open({
                animation: true,
                ariaLabelledBy: 'modal-title',
                ariaDescribedBy: 'modal-body',
                templateUrl: [
                    'assets/templates/components/ask-user-zipcode/',
                    'ask-zipcode-modal/',
                    'ask-zipcode-modal-view.html',
                ].join(''),
                controller: 'AskZipcodeModalController',
                controllerAs: 'askZipcodeModalCtrl',
                keyboard: false,
                backdrop  : 'static',
                size: size,
                resolve: {
                    zipcode: function () {
                        return (zipCode && zipCode.length === 5) ? zipCode : '';
                    }
                }
            });

            modalInstance.result
            .then(locationFetchSuccessCallBack, function () {
                $log.info('Modal dismissed at: ' + new Date());
            });

            modalInstance.opened.then(function () {
                ctrl.isModalOpen = true;
            });

            modalInstance.closed.then(function () {
                ctrl.isModalOpen = false;
            });
        }
    }

    /**
     * Common Error callback for all `googleApiUtilsService` calls
     * It takes an additional step & prompts the user to enter zipcode
     * @param {error} Object
     * @return undefined
     */
    function getUserLocationErrorCallback (error) {
        console.log('Error: googleApiUtilsService', error);
         // In case of zipcode already asked
         var zipCode = ZipcodeInfoService.getZipcode();
         if(!zipCode) {
            showAskZipcodeModal();
         }
        
    }

    function getUserLocationDetails() {
        var zipCode;
        zipCode = ZipcodeInfoService.getZipcode();

        if (zipCode) {
            // All valid USA Zipcodes have 5 digits
            // The ones with 4 digits are always used with a leading '0'
            if (zipCode.length === 5) {
                locationService.getlocation(zipCode)
                .then(locationFetchSuccessCallBack, function(error) {
                    console.log('Error: locationService.getlocation', error);
                }, getUserLocationErrorCallback);
            } 
        }
    }

    /**
     * getUserLocation
     * call google user location api and then convert location to get address
     * @param none
     * @return undefined
     */
    function getUserLocation() {
        var zipCode;
        zipCode = ZipcodeInfoService.getZipcode();

        if (zipCode) {
            // All valid USA Zipcodes have 5 digits
            // The ones with 4 digits are always used with a leading '0'
            if (zipCode.length === 5) {
                locationService.getlocation(zipCode)
                .then(locationFetchSuccessCallBack, function(error) {
                    console.log('Error: locationService.getlocation', error);
                }, getUserLocationErrorCallback);
            } else {
                // Anything other than 5 digts will mean that it's not a valid
                // location in USA. The user could be out of home location or
                // may be they don't have a GPS in their device.
                // In this case, we should as them to provide their zipcode.
                showAskZipcodeModal();
            }
        } else {
            var geolocation = $window.navigator && $window.navigator.geolocation;
            // Skip firefox browser due to this bug
            // https://bugzilla.mozilla.org/show_bug.cgi?id=675533
            if (geolocation && navigator.userAgent.toLowerCase().indexOf('firefox') === -1) {
                $window.navigator.geolocation
                .getCurrentPosition(function(position) {
                    locationService
                    .getAddressByLatLong(position.coords.latitude, position.coords.longitude)
                    .then(function(response) {
                        
                        // Anything other than 5 digts will mean that it's not a valid
                        // location in USA. The user could be out of home location or
                        // may be they don't have a GPS in their device.
                        if (response.zipCode.length !== 5) {
                            // In case of zipcode already asked
                            zipCode = ZipcodeInfoService.getZipcode();
                            if(!zipCode) {
                                showAskZipcodeModal();
                            }
                        } else {
                             _.assign(geolocation, response);
                            locationFetchSuccessCallBack(response);
                            zipCode = angular.isString(response.zipCode) ? response.zipCode : '';
                            ZipcodeInfoService.setZipcode(zipCode);
                        }
                    }, getUserLocationErrorCallback);
                }, getUserLocationErrorCallback);
            } else {
                // If geolocation API isn't available, ask the user to manually
                // enter their zipcode.
                showAskZipcodeModal();
            }
        }
    }
    /*******************************************************************/
    /***************** Private method declarations end *****************/
    /*******************************************************************/

    // handle user location popover close event, for update location state/city in navigation bar.
    $rootScope.$on('close-user-location-popover', function (event, data) {
        angular.noop(event);
        locationFetchSuccessCallBack(data);
        ctrl.isUserLocationPopoverOpen = false;
    });

    // handle notification when zipcode serviceability updated notification
    $rootScope.$on('zipcode-service-updated-notification', function (event) {
        angular.noop(event);
        var zipCode = ZipcodeInfoService.getZipcode();
        if (zipCode && zipCode.length === 5) {
          locationService.getlocation(zipCode)
          .then(locationFetchSuccessCallBack, getUserLocationErrorCallback);
        }
    });

    // handle notification when contact number in cookie updated notification
    $rootScope.$on('contact-number-in-cookie-updated-notification', function (event) {
        angular.noop(event);
        ctrl.contactNumber = CookieManager.getNavigationBarContactNumber();
    });

    // show/hide header pbx
    $rootScope.$on('show-hide-header-pbx', function(event, flag){
        ctrl.hidePbx = (flag === true) ? true : false;
    });

    $rootScope.$on('disable-zipcode-updation', function(event, flag){
        ctrl.disableUserLocationEdit = (flag === true) ? true : false;
    });

    $rootScope.$on('guest-checkout', function(event, flag){
        ctrl.disableUserAuthentication = (flag === true) ? true : false;
    });

    ctrl.allNotificationsClick = function() {
        ctrl.notifPopoverisOpen = false;
        $state.go('account.notifications');
    };

    ctrl.signInInit = function() {
        if (ctrl.signInModalInstance) {
            return;
        }
        ctrl.signInModalInstance = accountModalService.signInInit();
        ctrl.signInModalInstance.result.finally(function() {
            ctrl.signInModalInstance = null;
        });
    };

    ctrl.signUpInit = function() {
        if (ctrl.signUpModalInstance) {
            return;
        }
        ctrl.signUpModalInstance = accountModalService.signUpInit();
        ctrl.signUpModalInstance.result.finally(function() {
            ctrl.signUpModalInstance = null;
        });
    };

    ctrl.recoverInit = function() {
        accountModalService.recoverInit();
    };

    ctrl.changePasswordInit = function() {
        accountModalService.changePasswordInit();
    };

    ctrl.goToNotificationDetail = function(notification) {
        Notifications.readNotification(notification.id).then(function() {
            if (notification.read === false) {
                notification.read = true;
                if ($rootScope.unreadNotificationsNumber > 0) {
                    --$rootScope.unreadNotificationsNumber;
                }
            }
            var projectId = notification.metaData.id ? notification.metaData.id : notification.metaData.projectId;
            if (projectId) {
                $state.go('account.booking-detail', {id: projectId});
            } else {
                ctrl.checkForNotifications();
            }
        });
    };

    ctrl.checkForNotifications = function() {
        if (ctrl.userData.isRegistered) {
            Notifications.getNotificationsSummary()
            .then(function(response) {
                ctrl.notificationsCount = response.count;
                ctrl.unreadNotificationsCount = response.unreadCount;
                $rootScope.unreadNotificationsNumber = ctrl.unreadNotificationsCount;
            }, function(response) {
                ctrl.messageLabel.CURRENT = (response && response.message) ? response.message : ctrl.messageLabel.DEFAULT;
            });
            Notifications.unread()
            .then(function(response) {
                ctrl.notifications = response.data;
                ctrl.notificationsLoaded = true;
            }, function(response) {
                ctrl.messageLabel.CURRENT = (response && response.message) ? response.message : ctrl.messageLabel.DEFAULT;
            });
        }
    };

    ctrl.logout = function() {
        loginService.logout()
        .then(function() {
            //ZipcodeInfoService.setZipcode('');
            window.location = '/';
        });
    };

    ctrl.init = function() {
        ctrl.toggleBanner = false;
        //Listen for authenticated user
        $rootScope.$on('user:authentication:change', function(event, user) {
            //Assign authenticated data if exists
            ctrl.userData.isRegistered = user.isRegistered;
            ctrl.userData.firstName = user.firstName;
            ctrl.userData.lastName = user.lastName;
            ctrl.userData.email = user.email;
            ctrl.userData.profileImage = user.profileImage;
            ctrl.checkForNotifications();
            $rootScope.firstName = user.firstName;
            $rootScope.lastName = user.lastName;
            $rootScope.email = user.email;
            $rootScope.contact = user.contact;
            $rootScope.profileImage = user.profileImage;
        });

        $rootScope.$on('user:authentication:needs', function() {
            ctrl.signInInit();
        });

        if (location.search().recover) {
            ctrl.changePasswordInit();
        }
        ctrl.navCollapsed = true;

        ctrl.notificationsPopover = {
            url: 'assets/templates/pages/account/notifications/popover/index.html'
        };

        ctrl.checkForNotifications();

        $rootScope.$on('get:user:location', function() {
            getUserLocation(); // get user location on navigation component load
        });

        $rootScope.$on('ask:zipcode', function() {
            showAskZipcodeModal(); // show the zipcode location dialog box
        });

        getUserLocationDetails();
       
    };

    ctrl.createSpecialProject = function() {
        specialServiceModalService.openModal();
    };

    ctrl.toggle = function() {
        ctrl.toggleBanner = !ctrl.toggleBanner;
    };

    ctrl.init();
}

NavigationBarCtrl.$inject = [
    '$window',
    '$rootScope',
    '$location',
    '$state',
    'accountModalService',
    'LoginManagerService',
    'Notifications',
    'SettingsService',
    'specialServiceModalService',
    'ZipcodeInfoService',
    'repairProductModalService',
    '$filter',
    'ENVIRONMENT',
    '_',
    '$uibModal',
    '$log',
    'smartPhone',
    'CookieManager',
    'locationService'
];

(angular
    .module('RelayServicesApp.Components')
    ).component('navigationBar', {
        templateUrl: 'assets/templates/components/navigation/index.html',
        controller: NavigationBarCtrl
    });
