'use strict';

function RepairZipCode($rootScope, addressesService, ZipcodeInfoService, $window,
    _, locationService, SettingsService, ErrorHandler) {
    var ctrl = this;

    ctrl.invalidZipcode = false;
    ctrl.showAddress = false;
    ctrl.address = {};
    ctrl.nonServiceableZipCodeErrorMessage = '';
    ctrl.zipcode = ZipcodeInfoService.getZipcode();

    ctrl.init = function() {
        if (ctrl.zipcode) {
            ctrl.getZipcodeDetails(ctrl.zipcode);
        } else {
            ctrl.setGeolocation();
        }
    };

    ctrl.setGeolocation = function() {
        var geolocation = $window.navigator && $window.navigator.geolocation;
        if (geolocation) {
            $window.navigator.geolocation
            .getCurrentPosition(function(position) {
                locationService
                .getAddressByLatLong(position.coords.latitude, position.coords.longitude)
                .then(function(response) {
                    _.assign(geolocation, response);
                    ctrl.completeAddress = response;
                    if (!ctrl.zipcode) {
                        ctrl.zipcode = angular.isString(ctrl.completeAddress.zipCode) ?  ctrl.completeAddress.zipCode : '';
                    }
                    if (ctrl.zipcode.length === 5) {
                        ctrl.getZipcodeDetails(ctrl.zipcode);
                    }
                });
            });
        }
    };

    ctrl.getZipcodeDetails = function(zipcode) {
        ctrl.showAddress = false;
        ctrl.noAddZipcodeMsg = '';
        ctrl.nonServiceableZipCodeErrorMessage = '';
        ctrl.invalidZipcode = false;
        if (zipcode && zipcode.length === 5) {
            locationService
            .getServiceability(zipcode, 'NON_STANDARD')
            .then(function(response) {
                ctrl.nonServiceableZipCodeErrorMessage = '';
                ctrl.completeAddress = response;
                ctrl.address.zipCode = response.zipCode;
                ctrl.address.city = response.city;
                ctrl.address.state = response.state;
                ctrl.showAddress = true;
                ctrl.isAddressValid({isAddressValid: true, address: ctrl.address});
            }, function(error) {
                ctrl.address.city = '';
                ctrl.address.state = '';
                ctrl.isAddressValid({isAddressValid: false, address: ctrl.address});
                ErrorHandler.displayZipCodeErrorMessage(error, ctrl);
            });
        } else {
            ctrl.isAddressValid({isAddressValid: false, address: ctrl.address});
        }
    };

    ctrl.close = function() {
        ctrl.showAddress = false;
    };

    ctrl.init();
}
RepairZipCode.$inject = ['$rootScope', 'addressesService', 'ZipcodeInfoService', '$window',
'_', 'locationService', 'SettingsService', 'ErrorHandler'];
(angular
    .module('RelayServicesApp.Components')
).component('repairZipCode', {
    templateUrl: (
        'assets/templates/components/repair-zip-code/index.html'
    ),
    controller: RepairZipCode,
    bindings: {
        isAddressValid: '&',
        zipcode: '<'
    }
});
