'use strict';

function AddressesList($filter, _, addressesService, paymentAddressesService,
    SettingsService, $rootScope, modal, ErrorHandler, locationService) {
    var ctrl = this,
        addressEvent = 'address:change';

    ctrl.FormValidation = SettingsService.FormValidation || {};
    ctrl.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR,
        INVALID_ADDRESS: SettingsService.Error.INVALID_ADDRESS_ERROR
    };

    ctrl.init = function() {
        ctrl.isEditing = false;
        ctrl.address = undefined;
        ctrl.editAddress = undefined;
        ctrl.messageLabel.CURRENT = '';
        ctrl.today = new Date();
        ctrl.city = '';
        ctrl.disableRadioButton = false;
        addressesService.list().then(function(response) {
            ctrl.list = response;
            ctrl.model = (
                ctrl.model && _.find(response, ctrl.model)
            ) || _.first(response);
            ctrl.onAddressChange({address: ctrl.model});
        });
    };

    ctrl.initNew = function() {
        ctrl.isEditing = false;
        ctrl.messageLabel.CURRENT = '';
        ctrl.disableRadioButton = true;
        ctrl.address = {
            firstname: '',
            lastname: '',
            addressline1: '',
            addressline2: '',
            contactNo: '',
            city: '',
            state: '',
            zipcode: '',
            country: 'US'
        };
        ctrl.cancelEdit();
    };

    ctrl.initEdit = function(address) {
        ctrl.isEditing = true;
        ctrl.messageLabel.CURRENT = '';
        ctrl.city = address.city;
        ctrl.editAddress = {
            id: address.id,
            firstname: address.firstname,
            lastname: address.lastname,
            addressline1: address.addressline1,
            addressline2: address.addressline2,
            contactNo: $filter('bcTelephone')(address.contactNo || address.phone, 'format'),
            phone: address.contactNo || address.phone,
            city: address.city,
            state: address.state,
            zipcode: address.zipcode,
            country: 'US'
        };

        if (!address.addressline2) {
            ctrl.editAddress.addressline2 = '';
        }
        ctrl.cancelNew();
    };

    ctrl.remove = function(addressId) {
        //@TODO: Apply token when API allows it.
        var modalInstance = modal.open({
            animation: true,
            size: 'sm',
            controller: 'deleteAddressServiceCtrl',
            controllerAs: 'deleteAddressServiceCtrl',
            templateUrl: [
                'assets/templates/components/delete-address/',
                'index.html'
            ].join('')
        });
        modalInstance.result.then(function(shouldDelete) {
            if (shouldDelete === true) {
                return addressesService.remove(addressId).then(function() {
                    ctrl.init();
                    $rootScope.$broadcast(addressEvent);
                }, ctrl.requestError);
            }
        });
    };

    ctrl.editAddressFn = function() {
        // @TODO: Apply token when API allows it.
        return addressesService.edit(
            ctrl.editAddress.id,
            new addressesService.Address(ctrl.editAddress)
        ).then(function() {
            ctrl.init();
            $rootScope.$broadcast(addressEvent);
        }, ctrl.addressError);
    };

    ctrl.addNew = function() {
        return addressesService.insert(
            new addressesService.Address(ctrl.address)
        ).then(function() {
            ctrl.init();
            $rootScope.$broadcast(addressEvent);
        }, ctrl.addressError);
    };

    ctrl.getZipcodeDetails = function(zipcode) {
        var ctl = this;
        if (zipcode && zipcode.length === 5) {
            ctrl.invalidZipcode = false;
            locationService.getlocation(zipcode).then(function(response) {
                ctrl.city = response.city;
                if (ctrl.isEditing) {
                    ctl.editAddress.city = ctrl.city;
                    ctl.editAddress.state = response.state;
                } else {
                    ctl.address.city = ctrl.city;
                    ctl.address.state = response.state;
                }
            }, function() {
                ctrl.city = '';
                if (ctrl.isEditing) {
                    ctl.editAddress.city = '';
                    ctl.editAddress.state = '';
                } else {
                    ctl.address.city = '';
                    ctl.address.state = '';
                }
                ctrl.invalidZipcode = true;
            });
        }
    };

    ctrl.cancelNew = function() {
        ctrl.address = undefined;
        ctrl.messageLabel.CURRENT = '';
        ctrl.disableRadioButton = false;
        $rootScope.$broadcast(addressEvent);
    };

    ctrl.cancelEdit = function() {
        ctrl.isEditing = false;
        ctrl.editAddress = undefined;
        ctrl.messageLabel.CURRENT = '';
        ctrl.disableRadioButton = false;
        $rootScope.$broadcast(addressEvent);
    };
    /**
     * Error response of address service
     * @param  {Object} error -  Error response
     */
    ctrl.requestError = function(error) {
        ctrl.messageLabel.CURRENT = error && error.message ? error.message : ctrl.messageLabel.DEFAULT;
        ErrorHandler.displayAddressDeleteError(error, ctrl);
    };
    /**
     * Error response of address service
     * @param  {Object} error -  Error response
     */
    ctrl.addressError = function(error) {
        ctrl.messageLabel.CURRENT = error && error.message ? error.message : ctrl.messageLabel.INVALID_ADDRESS;
    };

    ctrl.init();

    if (ctrl.componentOpen) {
        ctrl.initNew();
    }
}

AddressesList.$inject = ['$filter', '_', 'addressesService', 'PaymentAddressesService',
    'SettingsService', '$rootScope', '$uibModal', 'ErrorHandler', 'locationService'];
(angular
    .module('RelayServicesApp.Components')
).component('addressesList', {
    templateUrl: (
        'assets/templates/components/addresses-list/index.html'
    ),
    controller: AddressesList,
    bindings: {
        onAddressChange: '&',
        hideTitle: '<',
        componentOpen: '<',
        editView: '<',
        showEdit: '<',
        enableDeleteButton: '<'
    }
});
