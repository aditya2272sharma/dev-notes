'use strict';

function ComingAppsModal($uibModalInstance, LoginManagerService, appdownloadService) {

    var vm = this;
    vm.messageLabel = {
        CURRENT: ''
    };
    vm.init = function() {
        vm.userInfo = LoginManagerService.getUser();
        vm.email = vm.userInfo.email || '';
        vm.submitted = false;
        vm.emailObject = undefined;
        vm.isEmailSaved = false;
    };

    vm.close = function() {
        $uibModalInstance.close();
    };

    vm.suscribeComingAppsSubmit = function() {
        vm.submitted = true;
        vm.emailObject = {
            email: vm.email,
            ios: false,
            android: false
        };
        appdownloadService.sendEmail(vm.emailObject).then(function(response) {
            vm.messageLabel.CURRENT = response.message;
            vm.isEmailSaved = true;
            console.log(response);
        });
        //vm.close();
    };

    vm.init();
}

ComingAppsModal.$inject = ['$uibModalInstance', 'LoginManagerService', 'appdownloadService'];

(angular
    .module('RelayServicesApp.Components')
).controller('ComingAppsModal', ComingAppsModal);
