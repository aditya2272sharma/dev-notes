'use strict';

function repairDetailsCtrl($scope, $uibModalInstance) {

    $scope.messageLabel = {
        CURRENT: ''
    };

    /**
    * Reset form validations
    */
    $scope.resetValidation = function() {
        $scope.error = {
            invalidZipCode: false
        };
    };

    $scope.init = function() {
    };

    $scope.close = function() {
        $uibModalInstance.dismiss();
    };

    /*$scope.submitReairForm = function(repairForm) {
    };*/

    $scope.init();
}

repairDetailsCtrl.$inject = ['$scope', '$uibModalInstance'];
(angular
    .module('RelayServicesApp.Components')
).controller('repairDetailsCtrl', repairDetailsCtrl);
