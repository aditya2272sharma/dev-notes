'use strict';

function proconImages($uibModalInstance, Uploads, utils, project, $window, ProjectsService,
    SettingsService, modal, $state, $log, $timeout, $filter) {

    var vm = this,
        projectId = $state.params.id,
        estimate,
        firmDetails,
        projectStatus = SettingsService.ProjetStatus;
    vm.maxImages = 5;
    vm.images = [];
    vm.maxProjectImages = 0;
    vm.loadingFile = false;
    vm.hideUploadButton = true;
    vm.disableUploadBtn = false;
    vm.addPhotoPosAbs = 'addPhotoPosAbs'; // Aligning the Upload Button
    vm.alignuploadsubmit = ''; // Adjusting the text while upload
    vm.uploadText = 'Add Photo'; // Loader Text discplay
    vm.enableuploadBtn = true; // Disable the Upload Button while it is uploading file.
    vm.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR
    };
    vm.init = function() {
        (ProjectsService
        .getProjectByProjectId(projectId)
      ).then(function(project) {
            vm.project = project;
            vm.maxProjectImages = vm.project.images.length;
        }, function(error) {
            if (error) {
                vm.messageLabel.CURRENT = error.message ? error.message : vm.messageLabel.DEFAULT;
                if (error.status === 401) {
                    vm.unauthorized = true;
                }
            }
        });

        // Get Project status
        (ProjectsService
        .getProjectEstimatesByProjectId(projectId)
        ).then(function(estimateObject) {
            estimate = [];
            firmDetails = [];
            vm.providerName = '';
            if (estimateObject.estimates && estimateObject.estimates.data || estimateObject.estimates.count !== 0) {
                estimate = estimateObject.estimates.data;
            }
            if (estimateObject.firms && estimateObject.firms.data && estimateObject.firms.count !== 0) {
                firmDetails = estimateObject.firms.data;
                vm.firm = $filter('filter')(firmDetails, {id:estimate[0].id})[0];
                if (vm.firm === undefined) {
                    vm.firm = $filter('filter')(firmDetails, {firmId:estimate[0].id})[0];
                    vm.firm.title = vm.firm.businessName;
                }
                vm.providerName = $filter('safeUrls')(vm.firm.title);
            }
            vm.proEstimate = {
                estimate: estimate[0],
                firm: firmDetails[0],
                project: estimateObject.project
            };
            vm.initEstimate();
        }, function(error) {
            if (error) {
                vm.messageLabel.CURRENT = error.message ? error.message : vm.messageLabel.DEFAULT;
                if (error.status === 401) {
                    vm.unauthorized = true;
                }
            }
        });
    };

    vm.initEstimate = function() {
        vm.estimateData = estimate;

        if (vm.project.status === projectStatus.PROJECT_COMPLETE ||
                vm.project.status === projectStatus.PROJECT_COMPLETE_FAIL ||
                vm.project.status === projectStatus.COMPLETE_PENDING_CLAIM ||
                vm.project.status === projectStatus.PROVIDER_CHECK_IN ||
                vm.project.status === projectStatus.PROJECT_CANCELLED) {
            vm.hideUploadButton = false;
        }
    };

    vm.close = function() {
        $uibModalInstance.dismiss();
    };

    vm.getProjectImage = function(url) {
        return utils.getProjectImage(url);
    };

    vm.deleteImg = function(id) {
        vm.messageLabel.DEFAULT = '';
        Uploads.DeleteImgs(id, projectId).then(function() {
            vm.maxProjectImages--;
            vm.init();
        }, function(error) {
            vm.messageLabel.CURRENT = error.message ? error.message : vm.messageLabel.DEFAULT;
        }, vm.requestError);
    };

    vm.upload = function(file) {
        vm.uploadText = 'Uploading';
        vm.enableuploadBtn = false;
        vm.disableUploadBtn = true;
        if (vm.addPhotoPosAbs === 'addPhotoPosAbs') {
            vm.addPhotoPosAbs = '';
        }
        if (vm.alignuploadsubmit === '') {
            vm.alignuploadsubmit = 'alignuploadsubmiti';
        }
        Uploads.uploadFile(file).then(function(response) {
            vm.uploadText = 'Add Photo';
            vm.enableuploadBtn = true;
            vm.images.push(response.data.url);
            vm.maxProjectImages++;
        }, function(error) {
            vm.messageLabel.CURRENT = error.message ? error.message : vm.messageLabel.DEFAULT;
        }, function(evt) {
            //vm.loadingFile = evt.loaded !== evt.total;
            $log.log(evt.loaded, '/', evt.total);
        });
    };

    vm.submitImgs = function() {
        var images = vm.images.toString();
        Uploads.UploadImages(images, projectId)
        .then(function() {
            vm.disableUploadBtn = false;
            vm.images = [];
            vm.init();
            if (vm.addPhotoPosAbs === '') {
                vm.addPhotoPosAbs = 'addPhotoPosAbs';
            }
            if (vm.alignuploadsubmit === 'alignuploadsubmiti') {
                vm.alignuploadsubmit = '';
            }
        }, function(error) {
            vm.messageLabel.CURRENT = error.message ? error.message : vm.messageLabel.DEFAULT;
        });
    };

    /**
    * Validates more than 5 images are uploaded at the same time
    */
    vm.validateImage = function() {
        vm.disableUploadBtn = true;
        vm.disabledSelect = false;
        if (vm.images.length >= vm.maxImages - 1) {
            vm.disabledSelect = true;
            vm.disableUploadBtn = false;
        }
    };

    /**
     * Removes image from images array and remove DOM element
     * @param  {number} index Image index
     * @param  {Object} event click event
     */
    vm.deleteImage = function(index, event) {
        //@TODO: Check next line. Make a directive?
        event.target.parentElement.remove();
        vm.maxProjectImages--;
        vm.images.splice(index, 1);
        vm.disabledSelect = false;
        if (vm.images.length === 0) {
            vm.disableUploadBtn = false;
            if (vm.addPhotoPosAbs === '') {
                vm.addPhotoPosAbs = 'addPhotoPosAbs';
            }
            if (vm.alignuploadsubmit === 'alignuploadsubmiti') {
                vm.alignuploadsubmit = '';
            }
        }
    };

    vm.init();
}

proconImages.$inject = ['$uibModalInstance', 'UploadsService', 'UtilsService', 'project', '$window', 'ProjectsService',
'SettingsService', '$uibModal', '$state', '$log', '$timeout', '$filter'];
(angular
    .module('RelayServicesApp.Components')
).controller('proconImages', proconImages);
