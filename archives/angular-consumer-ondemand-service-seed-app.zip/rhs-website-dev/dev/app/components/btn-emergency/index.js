'use strict';

function BtnEmergencyCtrl() {
    var ctrl = this;

    ctrl.isFloating = ctrl.isFloating || false;
    ctrl.emergencyText = ctrl.emergencyText || false;
}

BtnEmergencyCtrl.$inject = [];

(angular
    .module('RelayServicesApp.Components')
).component('btnEmergency', {
    templateUrl: 'assets/templates/components/btn-emergency/index.html',
    controller: BtnEmergencyCtrl,
    bindings: {
        isFloating: '<',
        emergencyText: '<'
    }
});
