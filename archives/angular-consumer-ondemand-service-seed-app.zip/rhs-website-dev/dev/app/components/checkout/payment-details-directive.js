'use strict';
angular
    .module('RelayServicesApp.Components')
    .directive('formOnChange', ['$parse',
        function($parse) {
            return {
                require: 'form',
                link: function(scope, element, attrs) {
                    var cb = $parse(attrs.formOnChange);
                    element.on('change', function() {
                        cb(scope);
                    });
                }
            };
        }
        ]);
