'use strict';

angular
.module('RelayServicesApp.Components')
.directive('starRating', [
    function() {
        return {
            restrict: 'A',
            scope: {
                max: '@',
                rating: '@',
                starsVar: '=',
                questionIndex: '@'
            },
            templateUrl: 'assets/templates/components/star-rating/star-rating.html',
            link: function(scope) {

                scope.initStars = function() {
                    var max = +scope.max || 5,
                        ratingNumber = (Math.round(+scope.rating * 2) / 2).toFixed(1),
                        starsData = [];

                    for (var i = 0; i < max; i++) {
                        if ((i + 0.5) === ratingNumber) {
                            starsData.push({status: 'star-half-empty'});
                        } else if (i < ratingNumber) {
                            starsData.push({status: 'star'});
                        } else {
                            starsData.push({status: 'star-o'});
                        }
                    }
                    scope.stars = starsData;
                    scope.rating = ratingNumber;
                };

                scope.starClick = function(starIndex) {
                    scope.rating = starIndex + 1;
                    if (scope.rating) {
                        scope.starsVar[parseInt(scope.questionIndex)] = scope.rating;
                    }
                    scope.initStars();
                };

                scope.initStars();
            }
        };
    }
]);
