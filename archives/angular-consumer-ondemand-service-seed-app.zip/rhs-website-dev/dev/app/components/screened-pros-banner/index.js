'use strict';

function screenedProsBanner() {
}

screenedProsBanner.$inject = [];

(angular
    .module('RelayServicesApp.Components')
).component('screenedProsBanner', {
    templateUrl: (
        'screened-pros-banner.template'
    )
});
