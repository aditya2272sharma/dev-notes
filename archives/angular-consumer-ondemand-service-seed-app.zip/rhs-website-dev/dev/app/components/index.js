'use strict';

function Configure() {
}

function Run() {
}

(angular
    .module('RelayServicesApp.Components', [])
    .config(Configure)
).run(Run);
