'use strict';

function StatusNotification(SettingsService) {
    var ctrl = this;
    ctrl.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR
    };
    ctrl.enabled = false;
    ctrl.message = '';

    ctrl.statusMessages = SettingsService.ProjectStatusMessages;
    ctrl.statusIcon = {
        WAITING: 'ico_inprocess.svg',
        ESTIMATE_RECEIVED: 'ico_received.svg'
    };

    ctrl.init = function() {
        switch (ctrl.status) {
            case SettingsService.ProjetStatus.PROJECT_WAITING:
                ctrl.enabled = true;
                ctrl.message = ctrl.statusMessages.WAITING;
                ctrl.icon = ctrl.statusIcon.WAITING;
                break;
            case SettingsService.ProjetStatus.PROJECT_CONFIRMED:
                ctrl.enabled = true;
                ctrl.message = ctrl.statusMessages.CONFIRMED;
                ctrl.icon = ctrl.statusIcon.WAITING;
                break;
            case SettingsService.ProjetStatus.PROJECT_CANCELLED:
                ctrl.enabled = true;
                ctrl.message = ctrl.statusMessages.CANCELLED;
                ctrl.icon = ctrl.statusIcon.ESTIMATE_RECEIVED;
                break;
            case SettingsService.ProjetStatus.PROJECT_UPCOMING:
                ctrl.enabled = false;
                ctrl.message = ctrl.statusMessages.UPCOMING;
                ctrl.icon = ctrl.statusIcon.WAITING;
                break;
            case SettingsService.ProjetStatus.ESTIMATE_RECEIVED:
                ctrl.enabled = true;
                ctrl.message = ctrl.statusMessages.ESTIMATE_RECEIVED;
                ctrl.icon = ctrl.statusIcon.ESTIMATE_RECEIVED;
                break;
            case SettingsService.ProjetStatus.ESTIMATE_ACCEPTED:
                ctrl.enabled = true;
                ctrl.message = ctrl.statusMessages.ESTIMATE_ACCEPTED;
                ctrl.icon = ctrl.statusIcon.ESTIMATE_RECEIVED;
                break;
            case SettingsService.ProjetStatus.ESTIMATE_REJECTED:
                ctrl.enabled = true;
                ctrl.message = ctrl.statusMessages.ESTIMATE_REJECTED;
                ctrl.icon = ctrl.statusIcon.ESTIMATE_RECEIVED;
                break;
            case SettingsService.ProjetStatus.ESTIMATE_UPDATED:
                ctrl.enabled = true;
                ctrl.message = ctrl.statusMessages.ESTIMATE_UPDATED;
                ctrl.icon = ctrl.statusIcon.ESTIMATE_RECEIVED;
                break;
            case SettingsService.ProjetStatus.COMPLETE_PENDING_CLAIM:
                ctrl.enabled = true;
                ctrl.message = ctrl.statusMessages.COMPLETE_PENDING_CLAIM;
                ctrl.icon = ctrl.statusIcon.ESTIMATE_RECEIVED;
                break;
            case SettingsService.ProjetStatus.PROJECT_COMPLETE:
            case SettingsService.ProjetStatus.PROJECT_COMPLETE_FAIL:
                ctrl.enabled = true;
                ctrl.message = ctrl.statusMessages.COMPLETE;
                ctrl.icon = ctrl.statusIcon.ESTIMATE_RECEIVED;
                break;
            case SettingsService.ProjetStatus.RESCHEDULE_INITIATED:
                ctrl.enabled = true;
                ctrl.message = ctrl.statusMessages.RESCHEDULE_INITIATED;
                ctrl.icon = ctrl.statusIcon.WAITING;
                break;
            case SettingsService.ProjetStatus.RESCHEDULE_CANCELLED:
                ctrl.enabled = true;
                ctrl.message = ctrl.statusMessages.RESCHEDULE_CANCELLED;
                ctrl.icon = ctrl.statusIcon.WAITING;
                break;
            case SettingsService.ProjetStatus.RESCHEDULE_INITIATED_BY_PROVIDER:
                ctrl.enabled = true;
                ctrl.message = ctrl.statusMessages.RESCHEDULE_INITIATED_BY_PROVIDER;
                ctrl.icon = ctrl.statusIcon.WAITING;
                break;
            case SettingsService.ProjetStatus.PROJECT_EXPIRED:
                ctrl.enabled = true;
                ctrl.message = ctrl.statusMessages.EXPIRED;
                ctrl.icon = ctrl.statusIcon.ESTIMATE_RECEIVED;
                break;
            case SettingsService.ProjetStatus.PROVIDER_CHECK_IN:
                ctrl.enabled = true;
                ctrl.message = ctrl.statusMessages.PROVIDER_CHECK_IN;
                ctrl.icon = ctrl.statusIcon.ESTIMATE_RECEIVED;
                break;
            case SettingsService.ProjetStatus.PROVIDER_REVISIT_NEEDED:
                ctrl.enabled = true;
                ctrl.message = ctrl.statusMessages.PROVIDER_REVISIT_NEEDED;
                ctrl.icon = ctrl.statusIcon.WAITING;
                break;
            default:
                ctrl.enabled = false;
                break;
        }
    };
    //if (ctrl.serviceType !== 'STANDARD') {
    ctrl.init();
    //}
}

StatusNotification.$inject = [
    'SettingsService'];

(angular
    .module('RelayServicesApp.Components')
        ).component('statusNotification', {
            templateUrl: 'assets/templates/components/status-notification/index.html',
            controller: StatusNotification,
            bindings: {
                status: '<',
                serviceType: '<',
                estimateStatus: '<'
            }
        });
