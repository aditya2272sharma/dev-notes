'use strict';

function cancelServiceCtrl($scope, $uibModalInstance, project,
    UploadsService, ProjectsService, SettingsService, $window, $state) {

    var cancelService = {};
    var cancelStatus = false;

    $scope.cancelServiceNew = {status : 'FALSE', cancelMessage : '', singleSelect : ''};
    $scope.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.CANCELLATION_ERROR
    };

    $scope.CancelServiceMessages = SettingsService.CancelServiceMessages || {};
    /**
    * Getting initial info
    */
    $scope.init = function() {
        cancelService.projectId = project;
        cancelService.reason = 'Product Damaged';
        cancelService.comment = 'Product Damaged';

        (ProjectsService.getCancelMessageByProjectId(project)).then(function(cancelMessage) {

            $scope.cancelServiceNew.cancelMessage = cancelMessage;

            (ProjectsService.getCancelReasons(cancelService.projectId)).then(function(list) {
                //$scope.singleSelect(list);
                $scope.data = {
                    model: null,
                    availableOptions: list.data
                };
            });
        }, function(error) {
            $scope.messageLabel.CURRENT = error && error.message ? error.message : $scope.messageLabel.DEFAULT;
        });
    };

    $scope.checkForOtherReason = function(cancelServiceReason) {
        if (cancelServiceReason === 'Other (please specify)') {
            $scope.isOtherReason = true;
        } else {
            $scope.isOtherReason = false;
        }
    };

    $scope.close = function() {
        if (cancelStatus) {
            $state.go($state.current, {}, {reload: true});
        }
        $uibModalInstance.dismiss(cancelStatus);
    };

    $scope.submit = function() {
        if ($scope.cancelServiceNew.status) {
            $scope.messageLabel.CURRENT = '';
        }
        cancelService.reason = $scope.cancelServiceNew.reason;
        if ($scope.cancelServiceNew.comment) {
            cancelService.comment = $scope.cancelServiceNew.comment;
        } else {
            cancelService.comment = '';
        }
        ProjectsService.cancel(cancelService).then(function() {
            $scope.cancelServiceNew.status = 'TRUE';
            cancelStatus = true;
        }, function() {
            $scope.messageLabel.CURRENT = $scope.messageLabel.DEFAULT;
        });
    };

    $scope.init();
}

cancelServiceCtrl.$inject = ['$scope', '$uibModalInstance', 'project',
    'UploadsService', 'ProjectsService', 'SettingsService', '$window', '$state'];
(angular
    .module('RelayServicesApp.Components')
).controller('cancelServiceCtrl', cancelServiceCtrl);
