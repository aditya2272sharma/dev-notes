'use strict';
/***Routes configuring and services resolves needed to start the page*/
function RelayServicesAppConfiguration($stateProvider, $urlRouterProvider, $location, $provide,
    localStorageServiceProvider, $httpProvider) {
    $httpProvider.interceptors.push(function() {
        return {
            request: function(config) {
                if (config.url.indexOf('html') > -1 && (/uib|v=|\?|\&|\{|\}|timestamp/gi.exec(config.url) === null)) {
                    config.url += ((config.url.indexOf('?') > -1) ? '&' : '?') + config.paramSerializer({
                        v: (+new Date())
                    });
                }
                return config;
            }
        };
    });
    $stateProvider.state('styleguide', {
        url: '/styleguide',
        templateUrl: 'assets/templates/pages/styleguide.html'
    });

    // Setting prefix for localStorage
    localStorageServiceProvider.setPrefix('');
    $location.html5Mode(true).hashPrefix('!');
    $urlRouterProvider.otherwise('page-not-found');
}

RelayServicesAppConfiguration.$inject = [
    '$stateProvider', '$urlRouterProvider', '$locationProvider', '$provide',
    'localStorageServiceProvider', '$httpProvider'
];

module.exports = RelayServicesAppConfiguration;
