'use strict';

// Preloader
require('./services/preloader/preloader');
require('./services/preloader/preload-provider');

require('./filters/');
require('./filters/cardTypeImage');
require('./filters/columnize');
require('./filters/percent');
require('./filters/first');
require('./filters/unread');
require('./filters/safe-urls');
require('./filters/uib-typeahead-concat');
require('angular-telephone-filter');
require('angular-ui-mask');

require('./services');
require('./services/lodash');
require('./services/providers');

//All API data services must extend abstract service
require('./services/abstract-service');
require('./services/authorization-service');
require('./services/utils-service');
require('./services/settings-service');
require('./services/error-handler-service');

// All Test mock responses
require('./services/mock-services/mock-project-service');
require('./services/mock-services/mock-config-service');
require('./services/mock-services/mock-environment-service');

require('./services/projects');
require('./services/projects/categories');
require('./services/projects/new-categories');
require('./services/projects/project-datetime-modal-service');
require('./services/projects/project-view');
require('./services/projects/custom-project');

require('./services/addresses');
require('./services/payments/addresses');
require('./services/payments/checkout-info');
require('./services/payments/methods');
require('./services/payments/process');
require('./services/payments/braintree-token-service');
require('./services/payments/order-summary-fixed');
require('./services/payments/fetch-billing-address-details');
require('./services/payments/fetch-service-location-details');
require('./services/payments/fetch-payment-method-details');

require('./services/reviews');

require('./services/uploads');

require('./services/google-api-utils-service');

require('./services/category-service');

require('./services/zipcode');

require('./services/breadcrumb');

require('./services/contact/contact-service');
require('./services/become-a-pro/become-a-pro');

//API
require('./services/managers/login-manager-service');
require('./services/account-modal/account-modal-service');
require('./services/special-service-modal/special-service-modal-service');

require('./services/repair-product-modal/repair-product-modal-service');
require('./services/repair/repair-details-modal-service');
require('./services/repair-image-gallery-modal/repair-image-modal-service');

require('./services/notifications');
require('./services/estimate/estimate-actions-service');
require('./services/estimate/estimate-summary-info');
require('./services/project-update-modal/project-update-modal-service');
require('./services/availability');
require('./services/location-service');
require('./services/application-download/appdownload');
require('./services/repair-schedule-modal/repair-schedule-modal-service');
require('./services/repair/repair');
require('./services/repair/repair-help-line');
require('./services/repair-last-step-modal/repair-last-step-modal-service');
require('./services/estimate-reject-confirmation-modal/estimate-reject-confirmation-service');

require('./services/search');
require('./services/search/search-info');
require('./services/select-category-modal/select-category-modal-service');
require('./services/date-time-validation');

require('./services/cookie-manager.js');

require('./components');
require('./components/addresses-list');
require('./components/navigation');
require('./components/navigation/userLocationPopover.js');
require('./components/main-footer');
require('./components/btn-emergency');
require('./components/breadcrumb');
require('./components/estimates-filter');
require('./components/estimate-card');
require('./components/pro-card');
require('./components/payment-addresses-list');
require('./components/service-addresses-list');
require('./components/service-contacts-list');
require('./components/payment-methods-list');
require('./components/checkout/payment-details-directive');
require('./components/star-rating/star-rating-directive');
require('./components/address-autocomplete/address-autocomplete-directive');
require('./components/on-error-image/on-error-image-directive');
require('./components/time-selector');
require('./components/task-location');
require('./components/popular-services');
require('./components/edit-project');
require('./components/cancel-service');
require('./components/delete-address');
require('./components/delete-payment-mode');
require('./components/reschedule/confirmation');
require('./components/reschedule/reschedule-your-appointment');
require('./components/reschedule/request-modal');
require('./components/reschedule/pro-reschedule');
require('./components/reschedule/cancel-reschedule');
require('./components/appointment-date-time-picker');
require('./components/screened-pros-banner');
require('./components/search-services');
require('./components/search-services/search-service-directive');
require('./components/modal-caller');
require('./components/coming-apps-modal');
require('./components/hiw-carousel');
require('./components/home-carousel');
require('./components/pro-register');
require('./components/provider-consumer-image-modal');
require('./components/status-notification');
require('./components/order-detail');
require('./components/input-directive/only-digits-directive');
require('./components/input-directive/only-alphabet-directive');
require('./components/input-directive/nospace-characters-directive.js');
require('./components/review-counter');
require('./components/repair-details-modal');
require('./components/guarantee-banner');
require('./components/repair-zip-code');
require('./components/repair-modal-caller');
require('./components/custom-modal-caller');
require('./components/book-services');
require('./components/repair-date-time-picker');
require('./components/reschedule-reject-confirmation');
require('./components/tech-talk/learn-more-modal/learn-more-modal.js');
require('./components/radio-panel/radio-panel-directive');
require('./components/ask-user-zipcode/ask-zipcode-modal/ask-zipcode-modal.js');
require('./components/tt-validity-check-modal/tt-validity-check-modal.js');
require('./components/service-detail-sidebar');
require('./components/inline-signup');
require('./components/payment-summary');

require('./pages/account');
require('./pages/account/signin');
require('./pages/account/signup');
require('./pages/account/mobile-signin');
require('./pages/account/mobile-signup');
require('./pages/account/recover');
require('./pages/account/mobile-recover');
require('./pages/account/changePassword');
require('./pages/account/myAccount');
require('./pages/account/myProjects');
require('./pages/account/myBookings');
require('./pages/account/myBookings/bookingDetail');
require('./pages/account/myBookings/detail-gallery');
require('./pages/account/myBookings/estimate-summary');
require('./pages/account/myBookings/estimate-reject-confirmation');
require('./pages/account/notifications');
require('./pages/account/notifications/popover');

require('./pages/new-service-offerings/');

require('./pages/payment');
require('./pages/payment/checkout');
require('./pages/payment/guest-checkout');
require('./pages/payment/confirmation');
require('./pages/payment/confirmation-with-id');

//require('./pages/booking');
//require('./pages/booking/lightbox');

require('./pages/home');
require('./pages/home/main');
require('./pages/home-new/');
require('./pages/homepage-new/');
require('./pages/appliance');
require('./pages/appliance/main');

require('./pages/generic-error-page');

require('./pages/terms');
require('./pages/terms/terms');

require('./pages/maintain');
require('./pages/maintain/maintain');

require('./pages/repair');
require('./pages/repair/repair');
require('./pages/repair/schedule-appointment');
require('./pages/repair/repair-product');
require('./pages/repair/repair-service-details');
require('./pages/repair/repair-provider');
require('./pages/repair/repair-preview');
require('./pages/repair/repair-sku');
require('./pages/repair/repair-help-line');
require('./pages/repair/repair-last-step-modal');
require('./pages/repair/repair-received');
require('./pages/repair/repair-view-all');
require('./pages/repair/repair-schedule/');

require('./pages/providers');
require('./pages/providers/estimate');
require('./pages/providers/estimate/detail');
require('./pages/providers/find');
require('./pages/providers/profile/about');
require('./pages/providers/profile/reviews');
require('./pages/providers/profile');
require('./pages/providers/profile/reviews-detail');

require('./pages/ratings');
require('./pages/ratings/providers');
require('./pages/ratings/providers/rate-pros');

require('./pages/FAQ');
require('./pages/FAQ/faq-controller');
require('./pages/how-it-works');
require('./pages/how-it-works/how-it-works-controller');
require('./pages/blog');
require('./pages/blog/blog-controller');
require('./pages/contact');
require('./pages/contact/contact-controller');
require('./pages/about');
require('./pages/about/about-controller');
require('./pages/we-are-growing');
require('./pages/we-are-growing/we-are-growing-controller');

require('./pages/standard-services');
require('./pages/standard-services/results');
require('./pages/standard-services/category');
require('./pages/standard-services/popular-services');
require('./pages/standard-services/service-packages');
require('./pages/standard-services/results-filter');

require('./pages/projects');
require('./pages/projects/create');
require('./pages/projects/create/category');
require('./pages/projects/create/category-subcategory');
require('./pages/projects/create/details');
require('./pages/projects/create/estimates');
require('./pages/projects/create/estimates-filter');
require('./pages/projects/create/special-service-modal');
require('./pages/projects/received');
require('./pages/projects/detail');
require('./pages/projects/reject-actions');
require('./pages/projects/date-time-modal');
require('./pages/projects/project-update-modal');
require('./pages/projects/invoice');
require('./pages/projects/custom-project/category');
require('./pages/projects/custom-project/sub-category');
require('./pages/projects/custom-project/sub-sub-category');
require('./pages/projects/custom-project/create-project');

require('./pages/become-a-pro');
require('./pages/become-a-pro/become-a-pro-controller');

require('./pages/rapid-response');

require('./pages/search');
require('./pages/search/search-result');
require('./pages/search/select-category-modal');

require('./pages/tech-talk/tech-talk-module.js');
require('./pages/tech-talk/landing/controller.js');
require('./pages/tech-talk/static-landing/controller.js');
require('./pages/tech-talk/confirmation/controller.js');
require('./pages/tech-talk/appointment/index.js');

var RelayServicesAppConfiguration = require('./app-configuration.js');
var RelayServicesAppRun = require('./app-run.js');
var moment = require('moment');
var momentTZ = require('moment-timezone');
var smartPhone = require('detect-mobile-browser')(false);

(angular
    .module('RelayServicesApp', [
        // Third-party services
        'ui.router',
        'ui.bootstrap',
        require('angular-animate'),
        'ngPassword',
        'ngFileUpload',
        'ngCookies',
        'braintree-angular',
        'credit-cards',
        'LocalStorageModule',
        'Preloader',
        'vcRecaptcha',
        // Services
        'RelayServicesApp.Services',
        // Filters
        'RelayServicesApp.Filters',
        'bc.TelephoneFilter',
        'ui.mask',
        //Components
        'RelayServicesApp.Components',
        // Pages
        'RelayServicesApp.Account',
        'RelayServicesApp.Payment',
        //'RelayServicesApp.Booking',
        'RelayServicesAppRun.Home',
        'RelayServicesAppRun.Appliance',
        'RelayServicesApp.GenericError',
        'RelayServicesApp.HowItWorks',
        'RelayServicesApp.ContactUs',
        'RelayServicesApp.RapidResponse',
        'RelayServicesApp.Providers',
        'RelayServicesApp.Projects',
        'RelayServicesApp.Ratings',
        'RelayServicesApp.FAQ',
        'RelayServicesApp.blog',
        'RelayServicesApp.becomeAPro',
        'RelayServicesApp.StandardServices',
        'RelayServicesApp.Terms',
        'RelayServicesApp.About',
        'RelayServicesApp.wearegrowing',
        'RelayServicesApp.Maintain',
        'RelayServicesApp.Repair',
        'RelayServicesApp.Search',
        'RelayServicesApp.NewServices',
        'RelayServicesApp.TechTalk'
    ])
    .constant('ENVIRONMENT', angular.fromJson('@@environment'))
    .constant('CONFIGURATION', angular.fromJson('@@configuration'))
    .constant('PRODUCTION', angular.fromJson('@@production'))
    .config(RelayServicesAppConfiguration)

    .service('moment', function() {
        return moment;
    })

    .service('momentTZ', function() {
        return momentTZ;
    })

    .service('smartPhone', function() {
        return smartPhone;
    })

).run(RelayServicesAppRun);
