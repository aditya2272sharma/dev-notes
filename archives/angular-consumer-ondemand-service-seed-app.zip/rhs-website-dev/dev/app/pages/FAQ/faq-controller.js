'use strict';

function FaqController($anchorScroll) {
    var vm = this;

    $anchorScroll();

    /**
     * Send message
     * @param  {Object} form - Contains the form object
     */
    vm.sendMessage = function(form) {
        if (form.$valid) {
            vm.loginData = {
                'fullName': vm.name,
                'email': vm.email,
                'message': vm.message
            };
            //TODO: Add service to send message
        }
    };

    vm.questions = {
        frequent: [{
            q: 'What is ServiceLive?',
            a: 'ServiceLive connects members with one or more independent contractors (Pros) for various services ' +
            'such as electrical, plumbing, HVAC, installations, Home improvement, repairs, emergency ' +
            'services, and custom project. The main features of ServiceLive are:',
            list: [
                'Peace-of-mind: Every Pro in our ServiceLive network goes through a thorough background ' +
                'check and is vetted for expertise.',
                'Estimates: Once you input your job criteria/specifications, we typically return a ' +
                'verified estimate within 24-hrs.',
                'As a user, you can choose from standard services or create your own custom projects.',
                'Creating your own project includes telling us about the project, being matched with ' +
                'an appropriate ServiceLive Pro, and then getting the job done.',
                'To contact ServiceLive, call 800-497-6154 or click on the "contact us" link at the bottom of the website.'
            ],
            isOpen: false
        },
        {
            q: 'How does ServiceLive works?',
            a: 'ServiceLive has been designed to eliminate the hassle of home repairs/installations/and more. ' +
            'We have a three-step process to get your work done:',
            list: [
                'Services: Select from the pre-packaged services or create a project by entering all the ' +
                'specifications/details you have. Take pictures of the work you want to be done or upload ' +
                'images that inspire your project.',
                'Get matched: Dozens of local Pros are ready and waiting. Choose from multiple matches for ' +
                'the specific work you need done.',
                'Get it done: The selected Pro will visit you on the date and time you selected and then get ' +
                'the specific work done.'
            ],
            isOpen: false
        },
        {
            q: 'How are providers (Pros), in the same area, sorted?',
            a: 'Based on the description of the job you need done, and details shared by you, our system returns the best ' +
            'match for your needs/requirements. You can choose to change the way the list of ' +
            'Pros is sorted by selecting ratings, price quoted, etc.',
            isOpen: false
        },
        {
            q: 'Where is ServiceLive available?',
            a: 'Nationally (coast to coast accross the United States).',
            isOpen: false
        },
        {
            q: 'Is ServiceLive part of Sears? I am a ShopYourWay member. Will I get additional ' +
            'benefits (points)?',
            a: 'Yes. ServiceLive is the latest in a set of programs by Sears – to make our members’ ' +
            'lives easier. Being a ShopYourWay member will entitle you to get SYW points on each ' +
            'transaction. The program details are currently being finalized and will be communicated ' +
            'once completed.',
            isOpen: false
        },
        {
            q: 'What services are offered by ServiceLive?',
            a: 'ServiceLive offers both pre-packaged services as well as an option to create a custom project based on your ' +
            'specific requirements. A sampling of our pre-packaged services are:',
            list: [
                'Electrical',
                'Plumbing',
                'Connected Living',
                'Heating & Cooling'
            ],
            isOpen: false
        }],
        benefits: [
        {
            q: 'How can I trust the service provider (Pro) coming to my location? ' +
            'Can I choose the ServiceLive Pro who visits my house?',
            a: 'Every Pro in our network goes through a thorough background check and is ' +
            'vetted for expertise and safety. Additionally, we have a very stringent ratings and review ' +
            'system which is done by other members who have used the services. We are committed ' +
            'to your safety. You can choose the service provider who gets the contract to provide ' +
            'the service. The service provider will sends an enrolled Pro, based on scheduling. ',
            isOpen: false
        },
        {
            q: 'How is ServiceLive different from other home services?',
            a: 'ServiceLive offers best-in-class features. With 7,000 trucks, 35,000+ approved ' +
            'Pros and average ratings of 4.6, ServiceLive is a place to get help with home projects, ' +
            'repairs, and services. A few key differences, of ServiceLive, are:',
            list: [
                'Peace-of-mind: Every Pro in our ServiceLive network goes through a thorough background ' +
                'check and is vetted for expertise.',
                'Estimates: Once you input your job criteria/specifications, we return a verified ' +
                'estimate typically within 24-hrs.',
                'Where is my Pro: We take the guess-work out of when your ServiceLive Pro will arrive.' +
                'Track your Pro in real-time on a map of your local area.'
            ],
            isOpen: false
        }],
        disabledRequest:[{
            q: 'What is the difference between standard (pre-packaged) services and custom project?',
            a: 'Standard (Pre-packaged) services are regular services a home owner typically requires. ' +
            'These services are standard and don’t require much customization (think, fixing a leaking faucet). ' +
            'They are pre-priced. Custom services, as the name suggests, are services which are unique based on ' +
            'your specific requirements (think, installing the entire drainage system in your house). ' +
            'These services require custom pricing. A pro will provide an estimate based on the details you share. ',
            isOpen: false
        }],
        request: [{
            q: 'Do I have to be home when the ServiceLive Pro comes to do the work?',
            a: 'The pro requires access to the house to do the work. While this can be done in ways which ' +
            'do not require your physical presence at the address, we strongly recommend you be present when ' +
            'the work is carried out.',
            isOpen: false
        },
        {
            q: 'What happens if the ServiceLive Pro does not arrive on time?',
            a: 'Our pros have been specifically trained and instructed to respect your time. We even have a ' +
            'real-time tracking mechanism which helps you track your pro in real time and estimate the arrival ' +
            'time. While we take all necessary precautions to ensure the pros don’t get delayed, in the unforeseen ' +
            'circumstance that it does happen, our systems will inform you of the delay beforehand and ask your ' +
            'permission to reschedule.',
            isOpen: false
        },
        {
            q: 'How can I reschedule an appointment?',
            a: 'In the ServiceLive website, go to My Bookings and open the booking details of the service ' +
            'scheduled. On the booking details screen, you can reschedule based on the provider’s availability. ' +
            'The provider can either accept or reject the reschedule request. The ' +
            'provider can submit alternative reschedule requests.',
            isOpen: false
        },
        {
            q: 'Do I have to supply any tools/materials or will the ServiceLive Pro bring all the needed tools/materials?',
            a: 'Our pros bring all necessary tools, equipment and material to ensure you get a complete service.',
            isOpen: false
        },
        {
            q: 'Once I accept a ServiceLive Pro estimate, will the estimate/ what I am charged change?',
            a: 'As the name suggests, the initial price quotation given to you is just an estimate and is subject ' +
            'to change. However, we will require your approval before proceeding at each instance where' +
            ' the estimate is revised.',
            isOpen: false
        },
        {
            q: 'What happens if I cancel the service request?',
            a: 'You may be subject to a cancellation fees, as follows:',
            list: [
                'A cancellation fee of $89 (plus applicable tax) will be charged on any service cancelled ' +
                'with less than 24 hour notice or for declined estimates.'
            ],
            disabledList: [
                'Service request is posted but order is not accepted by provider: No Cancellation fee.',
                'Order is accepted but appointment start is more than 24 hours away: No Cancellation fee.',
                'Order is accepted and the ServiceLive appointment starts within the next 24 hours: ' +
                'Member will pay the cancellation fee of $25 (as long as the pro has not arrived on-site).',
                {
                    main: 'Order is active and Provider is on-site:',
                    list: [
                        '1. Member initiates cancellation: Member will pay the cancellation fee of $49. ' +
                        'The Pro has the authority to reduce the fee, should he/she see fit.',
                        {
                            main: '2. Provider initiates cancellation: Provider will select ' +
                            'one of the following amounts based on any completed work.',
                            list: [
                                'i. Applicable Member on-site cancellation fee of $49',
                                'ii. Applicable Member on-site cancellation fee of an amount set by provider,' +
                                ' not to exceed $49.',
                                'iii. No cancellation fee applicable.'
                            ]
                        }
                    ]
                }
            ],
            isOpen: false
        }]
    };

}
FaqController.$inject = ['$anchorScroll'];

(angular
    .module('RelayServicesApp.FAQ')
).controller('FaqController', FaqController);
