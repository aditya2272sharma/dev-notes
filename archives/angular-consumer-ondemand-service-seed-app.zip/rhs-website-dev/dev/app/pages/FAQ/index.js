'use strict';

function Configure($stateProvider) {

    $stateProvider.state('faq', {
        url: '/faq',
        templateUrl: 'assets/templates/pages/FAQ/index.html',
        controller: 'FaqController as FaqController',
        params: {
            hasHero: true
        },
        resolve : {
            'sessionStatus': require('../../services/session-status-resolve')
        }
    });

}

Configure.$inject = ['$stateProvider'];

function Run() {
}

(angular
    .module('RelayServicesApp.FAQ', [])
    .config(Configure)
).run(Run);
