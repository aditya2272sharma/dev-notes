'use strict';

function RepairLastStepCtrl($state, $uibModalInstance, project, selectedFirm, RepairScheduleModalService,
    ProjectsService, SettingsService, NewServiceLocation, addressesService, CheckoutInfoService) {

    var vm = this, isNewServiceLocation = false,
    isServiceLocationAvail = false;

    /**
    * Reset form validations
    */
    vm.resetValidation = function() {
        vm.error = {
            invalidZipCode: false
        };
    };
    vm.closeServiceLocation = false;
    vm.showCancel = false;

    vm.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR
    };

    vm.close = function() {
        $uibModalInstance.dismiss();
    };

    /**
     * Used to confirm the project update. 4 steps included
     * 1. Add address to profile as service location(if not selected an existing)
     * 2. Update addressId to the project
     */
    vm.confirm = function() {
        var address = vm.getServicelocationAddress();
        if (!address.addressid) {
            // insert new address for service location
            addressesService.insert(new addressesService.Address(address)
            ).then(function(response) {
                vm.addressId = response.id;
                // update project
                vm.updateProjectData();
            }, function(error) {
                vm.addressInsertError = error && error.message ? error.message : vm.messageLabel.DEFAULT;
            });
        } else {
            vm.addressId = address.addressid;
            // update project
            vm.updateProjectData();
        }
    };

    vm.getServicelocationAddress = function() {
        var address = '',
            newServiceLocation = NewServiceLocation.getServiceLocation(),
            existingServiceLocation = NewServiceLocation.getServiceLocationList();
        if (!newServiceLocation.addressLine1 || newServiceLocation.addressLine1 === '') {
            address = existingServiceLocation;
        } else {
            address = {
                firstname: newServiceLocation.firstname,
                lastname: newServiceLocation.lastname,
                addressline1: newServiceLocation.addressLine1,
                addressline2: newServiceLocation.addressLine2,
                city: newServiceLocation.city,
                state: newServiceLocation.state,
                zipcode: newServiceLocation.zipcode,
                country: 'US',
                name: newServiceLocation.name,
                contactNo: newServiceLocation.phone
            };
        }
        return address;
    };

    vm.updateProjectData = function() {
        var  updatedInfo = {
            'addressid': vm.addressId,
            'id': project.id
        };
        ProjectsService.updateCustomProject(updatedInfo)
        .then(function() {
            if (selectedFirm.packageDetails.serviceType === SettingsService.ServiceTypes.NON_STANDARD) {
                vm.askForProjectEstimations();
            } else {
                vm.acceptEstimate();
            }
            vm.close();
        }, function(error) {
            vm.messageLabel.CURRENT = error && error.message ? error.message : vm.messageLabel.DEFAULT;
        });
    };

    //Send the firms selected and ask them for estimations
    vm.askForProjectEstimations = function() {
        var firmIds = selectedFirm.id,
            startDate = project.startDate;
        ProjectsService.
        askForProjectEstimations(project.id, firmIds, startDate)
        .finally(function() {
            $state.go('projects.request-received', {id: project.id});
        });
    };

    vm.acceptEstimate = function() {
        var projectId = project.id,
            estimateId = selectedFirm.packageDetails.bid.estimateId,
            decision = 'Accept';
        selectedFirm.projectId = projectId;
        selectedFirm.location = {};
        ProjectsService.acceptOrRejectProjectEstimation(projectId, estimateId, decision)
        .then(function(acceptRejectObject) {
            CheckoutInfoService.setCheckout({
                order: acceptRejectObject,
                project: projectId,
                firm: selectedFirm,
                selectedDate: project.startDate,
                selectedTime: project.timeSlot,
                zipcode: project.location.zipCode
            });
            $state.go('payment.checkout');
        }, function(error) {
            vm.messageLabel.CURRENT = error && error.message ? error.message : vm.messageLabel.DEFAULT;
        });
    };

    vm.init = function() {
        vm.servicelocation = {
            zipcode : project.location.zipCode,
            city: project.location.city,
            state: project.location.state
        };
        NewServiceLocation.resetServiceLocation();
    };

    vm.trackServiceAddrChanges = function(newAddrReqInitiated, isFormValid, setServiceLocation) {
        if (setServiceLocation) {
            vm.newServiceLocationValid = true;
            isServiceLocationAvail = true;
        }  else if (newAddrReqInitiated) {
            isNewServiceLocation = true;
            vm.newServiceLocationValid = false;
        } else if (isNewServiceLocation) {
            if (isFormValid) {
                vm.newServiceLocationValid = true;
            } else {
                vm.newServiceLocationValid = false;
            }
        }
    };

    vm.closeServiceLocationForm = function() {
        NewServiceLocation.resetServiceLocation();
        vm.messageLabel.CURRENT = '';
        vm.addressInsertError = '';
        vm.closeServiceLocation = !vm.closeServiceLocation;
        vm.newServiceLocationValid = false;
        isNewServiceLocation = false;
        if (isServiceLocationAvail) {
            vm.newServiceLocationValid = true;
        }
    };

    vm.init();
}

RepairLastStepCtrl.$inject = ['$state', '$uibModalInstance', 'project', 'selectedFirm', 'RepairScheduleModalService',
'ProjectsService', 'SettingsService', 'NewServiceLocation', 'addressesService', 'CheckoutInfoService'];
(angular
    .module('RelayServicesApp.Components')
).controller('RepairLastStepCtrl', RepairLastStepCtrl);
