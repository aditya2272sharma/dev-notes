'use strict';

function AppointmentScheduler($uibModalInstance, project, selectedFirm, ProjectsService, SettingsService, _,
    moment, $filter, modal, $window, $state, CheckoutInfoService) {

    var vm = this/*,
    projectId = project*/;

    vm.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR
    };

    vm.timeRanges = [
        {label:'8am - 12pm', value:'8:00 AM - 12:00 PM'},
        {label: '10am - 2pm', value:'10:00 AM - 2:00 PM'},
        {label: '1pm - 5pm', value:'1:00 PM - 5:00 PM'}];

    vm.init = function() {
        vm.enableScheduleBtn = true;
        /*ProjectsService.getProjectEstimatesByProjectId(projectId)
        .then(function(estimateObject) {
            vm.estimate = estimateObject.estimates.data[0];
            vm.project = estimateObject.project;
        });*/
        vm.project = project;
        vm.estimate = selectedFirm;
        //vm.project = project.id;
        vm.invalidDateTime = false;
    };

    vm.validateSelectedDateTime = function() {
        var isValidTime = false;
        _.forEach(vm.timeRanges, function(timeRange) {
            if (vm.selectedTimeSlot === timeRange.label) {
                vm.timeslot = timeRange.value;
                isValidTime = true;
            }
        });
    };
    vm.closeModal = function(path) {
        $uibModalInstance.dismiss();
        if (path) {
            $state.go(path, {id: vm.estimate.id, serviceType: selectedFirm.packageDetails.serviceType});
        }
    };

    vm.updateProjectData = function() {
        vm.validateSelectedDateTime();
        var updatedInfo = {
                'id': project.id,
                'timeslot': vm.selectedTimeSlot,
                'startdate': vm.repairScheduleDate
            };
        ProjectsService.updateCustomProject(updatedInfo)
        .then(function() {
            project.timeSlot = vm.selectedTimeSlot;
            project.startDate = vm.repairScheduleDate;
            vm.proceed();
        }, function(error) {
            vm.messageLabel.CURRENT = error && error.message ? error.message : vm.messageLabel.DEFAULT;
        });
    };

    vm.proceed = function() {
        $uibModalInstance.dismiss();
        vm.acceptEstimate();
    };

    vm.acceptEstimate = function() {
        var projectId = project.id,
            estimateId = selectedFirm.packageDetails.bid.estimateId,
            decision = SettingsService.APIConstants.ACCEPT;
        selectedFirm.projectId = projectId;
        selectedFirm.location = {};
        ProjectsService.acceptOrRejectProjectEstimation(projectId, estimateId, decision)
        .then(function(acceptRejectObject) {
            CheckoutInfoService.setCheckout({
                order: acceptRejectObject,
                project: projectId,
                firm: selectedFirm,
                selectedDate: project.startDate,
                selectedTime: project.timeSlot,
                zipcode: project.location.zipCode
            });
            $state.go('payment.checkout');
        }, function(error) {
            vm.messageLabel.CURRENT = error && error.message ? error.message : vm.messageLabel.DEFAULT;
        });
    };

    vm.setRescheduledDate = function(RepairSchedule) {
        vm.repairScheduleDate = RepairSchedule.date;
        vm.selectedTimeSlot = RepairSchedule.timeSlot;
        vm.enableScheduleBtn = RepairSchedule.scheduleBtnStatus;
    };

    vm.showError = function() {
        vm.enableScheduleBtn = true;
        vm.messageLabel.CURRENT = SettingsService.Error.DEFAULT_ERROR;
    };

    vm.diagnosticPopover = {
        url: 'assets/templates/pages/repair/repair-provider/diagnosticFeeTemplate.html'
    };

    vm.init();
}

AppointmentScheduler.$inject = ['$uibModalInstance', 'project', 'selectedFirm',
    'ProjectsService', 'SettingsService', '_', 'moment', '$filter', '$uibModal', '$window', '$state', 'CheckoutInfoService'];
(angular
    .module('RelayServicesApp.Repair')
).controller('AppointmentScheduler', AppointmentScheduler);
