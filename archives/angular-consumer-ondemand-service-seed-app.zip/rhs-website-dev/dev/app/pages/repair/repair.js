'use strict';

function RepairController(SettingsService) {
    var vm = this;
    vm.searsHomeRepairPageUrl = SettingsService.URLS.SEARS_HOME_REPAIR_PAGE_URL;

    vm.repair = {
        'TopProducts': [
			'Dishwasher',
			'Washer',
			'Refrigerator',
			'Dryer',
			'Range',
			'Oven'
		],
        'Products': {
            'Air Conditioner: Window, Room Installed': {
                'MerchCode': 'AIRCONRML',
                'TopBrands': [
					'Kenmore',
					'Kenmore Elite',
					'Frigidaire',
					'LG',
					'GE',
					'Amana'
				],
                'Brand': [
					'Admiral',
					'AirTemp',
					'Amana',
					'Arctic King',
					'Carrier',
					'Climatrol',
					'Coolerator',
					'Comfort Aire',
					'Crosley',
					'Emerson',
					'Fedders',
					'Frigidaire',
					'GE',
					'Gibson',
					'Goldstar',
					'Hotpoint',
					'Kelvinator',
					'Kenmore',
					'LG',
					'Norge',
					'Panasonic',
					'Quasar',
					'Roper',
					'Tappan',
					'Westinghouse',
					'Whirlpool'
				],
                'NatureOfProblem': [
					'Air conditioner doesnot cool properly',
					'Air conditioner doesnot run',
					'Air conditioner drips water inside the house',
					'Air conditioner drips water outside the house',
					'Air conditioner is noisy',
					'Other'
				]
            },
            'Air Conditioner: Window, Over 11,500 BTU': {
                'MerchCode': 'AIRCON1Y5P',
                'TopBrands': [
					'Kenmore',
					'Kenmore Elite',
					'Frigidaire',
					'LG',
					'GE',
					'Amana'
				],
                'Brand': [
					'Admiral',
					'AirTemp',
					'Amana',
					'Arctic King',
					'Carrier',
					'Climatrol',
					'Coolerator',
					'Comfort Aire',
					'Crosley',
					'Emerson',
					'Fedders',
					'Frigidaire',
					'GE',
					'Gibson',
					'Goldstar',
					'Hotpoint',
					'Kelvinator',
					'Norge',
					'Panasonic',
					'Quasar',
					'Roper',
					'Tappan',
					'Westinghouse',
					'Whirlpool'
				],
                'NatureOfProblem': [
					'Air conditioner doesnot cool properly',
					'Air conditioner doesnot run',
					'Air conditioner drips water inside the house',
					'Air conditioner drips water outside the house',
					'Air conditioner is noisy',
					'Other'
				]
            },
            'Boiler': {
                'MerchCode': 'BOILERGAS',
                'TopBrands': [
					'Kenmore',
					'Dunkirk',
					'Weil Mclain',
					'Burnham',
					'Rheem',
					'Lennox'
				],
                'Brand': [
					{
    'Name': 'AmericanStandard'
					},
					'Burnham',
					'Bryant',
					'Carrier',
					'Coleman',
					'Dunkirk',
					'Kenmore',
					'Lennox',
					{
    'Name': 'Rheem'
					},
					{
    'Name': 'Ruud'
					},
					'Trane',
					'Utica Boilers',
					{
    'Name': 'York'
					}
				],
                'NatureOfProblem': [
					'No heat or hot water',
					'Leaking and dripping',
					'Pilot light not working',
					'Strange sounds',
					'Frozen condensation pipe',
					'Losing pressure',
					'Thermostat issues',
					'Boiler keeps switching off',
					'Other'
				]
            },
            'Central Air Conditioner': {
                'MerchCode': 'AIRCENT1Y1P',
                'TopBrands': [
					'Amana',
					'Goodman',
					'Carrier',
					'Arcoaire',
					'American Standard',
					'Kenmore'
				],
                'Brand': [
					'Amana',
					{
    'Name': 'AmericanStandard'
					},
					{
    'Name': 'Arcoaire'
					},
					'Bryant',
					'Carrier',
					{
    'Name': 'Coleman'
					},
					{
    'Name': 'Comfortmaker'
					},
					'Goodman',
					{
    'Name': 'Heil'
					},
					'Kenmore',
					{
    'Name': 'Lennox'
					},
					{
    'Name': 'Rheem'
					},
					{
    'Name': 'Ruud'
					},
					'Tempstar',
					'Trane',
					{
    'Name': 'York'
					}
				],
                'NatureOfProblem': [
					'Power: Doesnot run',
					'Temperature: Not cooling enough',
					'Other'
				]
            },
            'Cooktop': {
                'MerchCode': 'COOKTOP',
                'TopBrands': [
					'Kenmore',
					'Kenmore Elite',
					'Kenmore Pro',
					'GE',
					'KitchenAid',
					'Whirlpool'
				],
                'Brand': [
					{
    'Name': 'Admiral'
					},
					'Amana',
					'Bosch',
					'Caloric',
					'Frigidaire',
					'GE',
					'Hotpoint',
					'KitchenAid',
					'Kenmore',
					'Kenmore Elite',
					'Kenmore Pro',
					'Magic Chef',
					'Maytag',
					'Profile',
					'Tappan',
					'Westinghouse',
					'Whirlpool'
				],
                'NatureOfProblem': [
					'Burners: Not heating adequately',
					'Entire Unit: Not working',
					'No power',
					'Other'
				]
            },
            'Dishwasher': {
                'MerchCode': 'DISHWASHBI',
                'TopBrands': [
					'Bosch',
					'Frigidaire',
					'GE',
					'Kenmore',
					'KitchenAid',
					'Whirlpool'
				],
                'Brand': [
					{
    'Name': 'Admiral'
					},
					'Amana',
					'Bosch',
					'Crosley',
					'Frigidaire',
					'GE',
					'GE Profile',
					'Gibson',
					'Hotpoint',
					'Kelvinator',
					'Kenmore',
					'Kenmore Elite',
					'Kenmore Pro',
					'Kitchen Aid',
					{
    'Name': 'LG',
    'Phone': 'LGDefault',
    'Url': 'LGDefault'
					},
					'Maytag',
					{
    'Name': 'Samsung',
    'Phone': 'SamsungDefault',
    'Url': 'SamsungDefault'
					},
					'Whirlpool'
				],
                'NatureOfProblem': [
					'Displaying error code',
					'Leaking',
					'Noise or vibration issue',
					'Not cleaning dishes properly',
					'Not draining',
					'Not drying dishes properly',
					'Not starting',
					'Stopping during cycle',
					'Visible damage',
					'Other'
				]
            },
            'Dryer': {
                'MerchCode': 'DRYALL',
                'Type': {
                    'Electric': {
                        'MerchCode': 'DRYERE',
                        'TopBrands': [
							'Kenmore',
							'Kenmore Elite',
							'Whirlpool',
							'GE',
							'Maytag',
							'Samsung'
						],
                        'Brand': [
							{
    'Name': 'Admiral'
							},
							'Amana',
							'Bosch',
							'Electrolux',
							'Frigidaire',
							'GE',
							'GE Profile',
							'Gibson',
							'Hotpoint',
							'Kelvinator',
							'Kenmore',
							'Kenmore Elite',
							{
    'Name': 'LG',
    'Phone': 'LGDefault',
    'Url': 'LGDefault'
							},
							'Maytag',
							'Roper',
							{
    'Name': 'Samsung',
    'Phone': 'SamsungDefault',
    'Url': 'SamsungDefault'
							},
							'Speed Queen',
							'WCI',
							'Westinghouse',
							'Whirlpool'
						],
                        'NatureOfProblem': [
							'Clothes not drying/taking too long to dry',
							'Display/buttons not working',
							'Displaying error code',
							'Noise/vibration issue',
							'Not heating',
							'Not running/no power',
							'Stopping during cycle',
							'Visible damage',
							'Other'
						]
                    },
                    'Gas': {
                        'MerchCode': 'DRYERG',
                        'TopBrands': [
							'Frigidaire',
							'Kenmore',
							'Kenmore Elite',
							'LG',
							'Maytag',
							'Samsung'
						],
                        'Brand': [
							{
    'Name': 'Admiral'
							},
							'Amana',
							'Bosch',
							'Electrolux',
							'Frigidaire',
							'GE',
							'GE Profile',
							'Gibson',
							'Hotpoint',
							'Kelvinator',
							'Kenmore',
							'Kenmore Elite',
							{
    'Name': 'LG',
    'Phone': 'LGDefault',
    'Url': 'LGDefault'
							},
							'Maytag',
							'Roper',
							{
    'Name': 'Samsung',
    'Phone': 'SamsungDefault',
    'Url': 'SamsungDefault'
							},
							'Speed Queen',
							'WCI',
							'Westinghouse',
							'Whirlpool'
						],
                        'NatureOfProblem': [
							'Clothes not drying/taking too long to dry',
							'Display/buttons not working',
							'Displaying error code',
							'Noise/vibration issue',
							'Not heating',
							'Not running/no power',
							'Stopping during cycle',
							'Visible damage',
							'Other'
						]
                    },
                    'Stacked Laundry Unit': {
                        'MerchCode': 'WASHERDRYERL',
                        'TopBrands': [
						'Kenmore',
						'Kenmore Elite',
						'Whirlpool',
						'GE',
						'Maytag',
						'Frigidaire'
					],
                        'Brand': [
						'Amana',
						'Electrolux',
						'Frigidaire',
						'GE',
						'Gibson',
						{
    'Name': 'Kelvinator'
						},
						'Kenmore',
						'KitchenAid',
						{
    'Name': 'LG',
    'Phone': 'LGDefault',
    'Url': 'LGDefault'
						},
						'Maytag',
						{
    'Name': 'Roper'
						},
						{
    'Name': 'Samsung',
    'Phone': 'SamsungDefault',
    'Url': 'SamsungDefault'
						},
						'Speed Queen',
						{
    'Name': 'WCI'
						},
						'Westinghouse',
						'Whirlpool'
					],
                        'NatureOfProblem': [
						'Cleaning: Excessive lint on clothes',
						'Draining: Continues to fill and drain',
						'Draining: Water isnot pumped out during spin cycle',
						'Draining: Water wonot drain from washer',
						'Draining: Continue to fill',
						'Function: Clothes donot dry or take a long time to dry',
						'Function: Dryer doesnot run',
						'Function: Dryer runs but doesnot heat up',
						'Function: Runs with door open',
						'Function: Washer wonot run or stops during cycle',
						'Function: Wonot run clean cycle',
						'Function: Wonot shut off',
						'Noise: Strange noises or vibrations in dryer',
						'Noise: Strange noises or vibrations in washer',
						'Timing: Basket is slow or will not spin',
						'Timing: Runs and shuts off quickly',
						'Water: Water doesnot fill washer',
						'Other'
					]
                    }
                }
            },
            'Elliptical Machine': {
                'MerchCode': 'EXERCISENE',
                'TopBrands': [
					'Proform',
					'AFG',
					'Weslo',
					'Epic',
					'Star Trac',
					'Health Rider'
				],
                'Brand': [
					'AFG',
					'Champion',
					'DP',
					'Diamondback',
					'Epic',
					'FitnessQuest',
					'Health Rider',
					'Horizon',
					'Icon',
					'Image',
					'Lifestyler',
					'Nautilus',
					'Nobrand',
					'Proform',
					'Reebok',
					'Schwinn',
					'Star Trac',
					'Weider',
					'Weslo'
				],
                'NatureOfProblem': [
					'Belt/Chain: Doesnot Move',
					'Belt/Chain: Slips',
					'Console Display Problem',
					'Noise: Strange or Excessive',
					'Power: Doesnot Run',
					'Vibration: Strange or Excessive',
					'Other'
				]
            },
            'Fitness Weight Machine': {
                'MerchCode': 'FITNESS',
                'TopBrands': [
					'Weider',
					'Bow Flex',
					'Proform',
					'Health Rider',
					'Horizon',
					'Weider'
				],
                'Brand': [
					'Body Gear',
					'Body Solid',
					'Bow Flex',
					'FitnessQuest',
					'Health Rider',
					'Horizon',
					'Icon',
					'Proform',
					'Weider'
				],
                'NatureOfProblem': [
					'Resistance: Doesnot Move',
					'Strange Movements'
				]
            },
            'Freezer': {
                'MerchCode': 'FREEZERO9',
                'TopBrands': [
					'Kenmore',
					'Kenmore Elite',
					'Frigidaire',
					'Whirlpool',
					'Electrolux'
				],
                'Brand': [
					'Admiral',
					'Amana',
					'Coldspot',
					'Frigidaire',
					'GE',
					'Gibson',
					'Hotpoint',
					'Kenmore',
					'Kenmore Elite',
					'KitchenAid',
					'Maytag',
					'Westinghouse',
					'Whirlpool'
				],
                'NatureOfProblem': [
					'Frost build up',
					'Making strange noises',
					'Running too long',
					'Small amount of water is leaking on the floor',
					'Temperature too warm',
					'Will not run',
					'Other'
				]
            },
            'Furnace': {
                'MerchCode': 'FURNFAGAS',
                'TopBrands': [
					'Amana',
					'Kenmore',
					'Arcoaire',
					'Carrier',
					'Goodman',
					'American Standard'
				],
                'Brand': [
					'Amana',
					'AmericanStandard',
					'Arcoaire',
					'Bryant',
					'Carrier',
					{
    'Name': 'Coleman'
					},
					{
    'Name': 'Comfortmaker'
					},
					'Goodman',
					{
    'Name': 'Heil'
					},
					'Kenmore',
					'Lennox',
					{
    'Name': 'Rheem'
					},
					{
    'Name': 'Ruud'
					},
					'Tempstar',
					'Trane',
					{
    'Name': 'York'
					}
				],
                'NatureOfProblem': [
					'Power: Doesnot run',
					'Not heating/not heating enough',
					'Other'
				]
            },
            'Garage Door Opener': {
                'MerchCode': 'GARAGEDOOROP',
                'TopBrands': [
					'Craftsman',
					'CraftsmanPro',
					'Chamberlain'
				],
                'Brand': [
					'Chamberlain',
					'Craftsman',
					'CraftsmanPro'
				],
                'NatureOfProblem': [
					'Door doesnot function at all',
					'Door is excessively noisy',
					'Door reverses without pressing control',
					'Door will not open',
					'Not fully opening or closing',
					'Opens or closes without pressing control',
					'Routine maintenance',
					'Other'
				]
            },
            'Garbage Disposal': {
                'MerchCode': 'DISPOSER',
                'Brand': [
					'Kenmore'
				],
                'NatureOfProblem': [
					'Does not turn on',
					'Makes a humming noise',
					'Leaking',
					'Slow draining',
					'Flywheel is stuck',
					'Other'
				]
            },
            'Grill': {
                'MerchCode': 'GRILLOUTGAS',
                'TopBrands': [
					'Kenmore',
					'Kenmore Elite',
					'KitchenAid',
					'CharBroil',
					'Coleman',
					'Weber'
				],
                'Brand': [
					'CharBroil',
					'Coleman',
					'Fiesta',
					'Kenmore',
					'Kenmore Elite',
					'KitchenAid',
					'Sunbeam',
					'Thermos',
					'Weber'
				],
                'NatureOfProblem': [
					'Function: Burners do not light completely',
					'Temperature: Does not heat sufficiently',
					'Temperature: Does not ignite',
					'Other'
				]
            },
            'Heat Pump': {
                'MerchCode': 'AIRHEATPUMP',
                'TopBrands': [
					'Amana',
					'Kenmore',
					'Arcoaire',
					'Carrier',
					'Goodman',
					'American Standard'
				],
                'Brand': [
					'Amana',
					'AmericanStandard',
					'Arcoaire',
					'Bryant',
					'Carrier',
					'Coleman',
					'Comfortmaker',
					'Goodman',
					'Heil',
					'Kenmore',
					'Lennox',
					'Rheem',
					'Ruud',
					'Tempstar',
					'Trane',
					'York'
				],
                'NatureOfProblem': [
					'Power: Doesnot run',
					'Temperature: Not cooling enough',
					'Temperature: Not warm enough',
					'Other'
				]
            },
            'Ice Maker Freestanding': {
                'MerchCode': 'ICEMAKER',
                'TopBrands': [
					'Kenmore',
					'KenmoreElite',
					'Kitchen Aid'
				],
                'Brand': [
					'Kenmore',
					'Kenmore Elite',
					'KitchenAid'
				],
                'NatureOfProblem': [
					'Other'
				]
            },
            'Microwave': {},
            'Double Oven': {
                'MerchCode': 'OVENBIDB',
                'TopBrands': [
					'KitchenAid',
					'GE',
					'Kenmore',
					'Whirlpool',
					'Maytag',
					'Frigidaire'
				],
                'Brand': [
					'Admiral',
					'Amana',
					'Bosch',
					'Caloric',
					'Frigidaire',
					'GE',
					'GE Profile',
					'Hotpoint',
					'Kenmore',
					'Kenmore Elite',
					'Kenmore Pro',
					'KitchenAid',
					{
    'Name': 'LG',
    'Phone': 'LGDefault',
    'Url': 'LGDefault'
					},
					'Magic Chef',
					'Maytag',
					'Modern Maid',
					'Roper',
					{
    'Name': 'Samsung',
    'Phone': 'SamsungDefault',
    'Url': 'SamsungDefault'
					},
					'Tappan',
					'Whirlpool'
				],
                'NatureOfProblem': [
					'Displaying error code',
					'Display not working properly',
					'Door not opening/closing',
					'Not working/no power',
					'Temperature problem',
					'Visible damage',
					'Other'
				]
            },
            'Oven': {
                'MerchCode': 'OVENBI',
                'TopBrands': [
					'KitchenAid',
					'GE',
					'Kenmore',
					'Whirlpool',
					'Maytag',
					'Frigidaire'
				],
                'Brand': [
					{
    'Name': 'Admiral'
					},
					'Amana',
					'Bosch',
					'Electrolux',
					'Frigidaire',
					'GE',
					'GE Profile',
					'Hotpoint',
					'Kenmore',
					'Kenmore Elite',
					'Kenmore Pro',
					'KitchenAid',
					{
    'Name': 'LG',
    'Phone': 'LGDefault',
    'Url': 'LGDefault'
					},
					'Magic Chef',
					'Maytag',
					{
    'Name': 'Samsung',
    'Phone': 'SamsungDefault',
    'Url': 'SamsungDefault'
					},
					'Whirlpool'
				],
                'NatureOfProblem': [
					'Displaying error code',
					'Display not working properly',
					'Door not opening/closing',
					'Not working/no power',
					'Temperature problem',
					'Visible damage',
					'Other'
				]
            },
            'Range': {
                'MerchCode': 'RANGEEG',
                'TopBrands': [
					'GE',
					'Kitchen Aid',
					'Kenmore',
					'Whirlpool',
					'Samsung',
					'Frigidaire'
				],
                'Brand': [
					{
    'Name': 'Admiral'
					},
					'Amana',
					'Caloric',
					'Frigidaire',
					'GE',
					'GE Profile',
					'Hotpoint',
					'Kenmore',
					'Kenmore Elite',
					'Kenmore Pro',
					'KitchenAid',
					{
    'Name': 'LG',
    'Phone': 'LGDefault',
    'Url': 'LGDefault'
					},
					'Magic Chef',
					'Maytag',
					{
    'Name': 'Samsung',
    'Phone': 'SamsungDefault',
    'Url': 'SamsungDefault'
					},
					'Roper',
					'Tappan',
					'Westinghouse',
					'Whirlpool'
				],
                'NatureOfProblem': [
					'Cooktop/burners not working (oven is ok)',
					'Display problem',
					'Displaying error code',
					'Door not opening/closing',
					'Not running/no power',
					'Noise issue',
					'Oven not working (cooktop/burners are ok)',
					'Oven temperature problem',
					'Visible damage',
					'Other'
				]
            },
            'Range Hood': {
                'MerchCode': 'RANGEHOOD',
                'TopBrands': [
					'Kenmore',
					'GE',
					'KitchenAid',
					'Broan',
					'Whirlpool',
					'Frigidaire'
				],
                'Brand': [
					'Amana',
					'Best',
					{
    'Name': 'Broan'
					},
					'Caloric',
					'Frigidaire',
					'GE',
					'Hotpoint',
					'Kenmore',
					'KitchenAid',
					'Whirlpool'
				],
                'NatureOfProblem': [
					'Fan does not work',
					'Fan is noisy',
					'Light does not work',
					'Other'
				]
            },
            'Refrigerator': {
                'MerchCode': 'REFRIGALL',
                'Type': {
                    'Bottom Freezer': {
                        'MerchCode': 'REFRIGBF',
                        'TopBrands': [
							'Kenmore',
							'GE',
							'Maytag',
							'KitchenAid',
							'Samsung',
							'Whirlpool'
						],
                        'Brand': [
							'Admiral',
							'Amana',
							'Coldspot',
							'Estate',
							'Frigidaire',
							'GE',
							'GE Profile',
							'Gibson',
							'Hotpoint',
							'Kenmore',
							'Kenmore Elite',
							'KitchenAid',
							{
    'Name': 'LG',
    'Phone': 'LGDefault',
    'Url': 'LGDefault'
							},
							'Maytag',
							'Roper',
								{
    'Name': 'Samsung',
    'Phone': 'SamsungDefault',
    'Url': 'SamsungDefault'
							},
							'Westinghouse',
							'Whirlpool'
						],
                        'NatureOfProblem': [
							'Dispenser not working properly',
							'Displaying error code',
							'Ice maker not working properly',
							'Leaking',
							'Not running/no power',
							'Noise problem',
							'Odor problem',
							'Temperature (too cold)',
							'Temperature (too warm)',
							'Visible damage',
							'Other'
						]
                    },
                    'Side-by-Side': {
                        'MerchCode': 'REFRIGSS',
                        'TopBrands': [
							'Kenmore',
							'GE',
							'Maytag',
							'KitchenAid',
							'Samsung',
							'Whirlpool'
						],
                        'Brand': [
							'Admiral',
							'Amana',
							'Coldspot',
							'Estate',
							'Frigidaire',
							'GE',
							'GE Profile',
							'Gibson',
							'Hotpoint',
							'Kenmore',
							'Kenmore Elite',
							'KitchenAid',
							{
    'Name': 'LG',
    'Phone': 'LGDefault',
    'Url': 'LGDefault'
							},
							'Maytag',
							'Roper',
							{
    'Name': 'Samsung',
    'Phone': 'SamsungDefault',
    'Url': 'SamsungDefault'
							},
							'Westinghouse',
							'Whirlpool'
						],
                        'NatureOfProblem': [
							'Dispenser not working properly',
							'Displaying error code',
							'Ice maker not working properly',
							'Leaking',
							'Not running/no power',
							'Noise problem',
							'Odor problem',
							'Temperature (too cold)',
							'Temperature (too warm)',
							'Visible damage',
							'Other'
						]
                    },
                    'Top Freezer': {
                        'MerchCode': 'REFRIG',
                        'TopBrands': [
							'Kenmore',
							'GE',
							'Maytag',
							'KitchenAid',
							'Samsung',
							'Whirlpool'
						],
                        'Brand': [
							'Admiral',
							'Amana',
							'Coldspot',
							'Estate',
							'Frigidaire',
							'GE',
							'GE Profile',
							'Gibson',
							'Hotpoint',
							'Kenmore',
							'Kenmore Elite',
							'KitchenAid',
							{
    'Name': 'LG',
    'Phone': 'LGDefault',
    'Url': 'LGDefault'
							},
							'Maytag',
							'Roper',
							{
    'Name': 'Samsung',
    'Phone': 'SamsungDefault',
    'Url': 'SamsungDefault'
							},
							'Westinghouse',
							'Whirlpool'
						],
                        'NatureOfProblem': [
							'Dispenser not working properly',
							'Displaying error code',
							'Ice maker not working properly',
							'Leaking',
							'Not running/no power',
							'Noise problem',
							'Odor problem',
							'Temperature (too cold)',
							'Temperature (too warm)',
							'Visible damage',
							'Other'
						]
                    }
                }
            },
            'Riding Mower': {
                'MerchCode': 'TRACTRD1YR',
                'TopBrands': [
					'Craftsman'
				],
                'Brand': [
					'Agri/Fab',
					'Briggs & Stratton',
					'Companion',
					'Craftsman',
					'Homelite',
					'Honda',
					'Husqvarna',
					'Kawasaki',
					'Lifetime',
					'Mackissic',
					'Mcculloch',
					'Murray',
					'Ohio Steel',
					'Poulan',
					'Poulan Pro',
					'Snapper',
					'Swisher',
					'Troybilt',
					'Weedeater',
					'Yard Machine',
					'Yardman',
					'YardPro'
				],
                'NatureOfProblem': [
					'Cutting: Grass isnot cut',
					'Cutting: Lawn is cut unevenly',
					'Cutting: Plugs up and doesnot discharge grass clippings',
					'Deck Levers: Require Adjustment',
					'Engine: Does not run smoothly',
					'Engine: Will not start',
					'Leaking: Leaks oil or gas',
					'Steering: Doesnot steer well',
					'Other'
				]
            },
            'Snowblower': {
                'MerchCode': 'SNOWTH2S1YR',
                'TopBrands': [
					'Craftsman',
					'Snapper',
					'Swisher',
					'Yard Machine',
					'Yardman',
					'YardPro'
				],
                'Brand': [
					'Agri/Fab',
					'Briggs & Stratton',
					'Companion',
					'Craftsman',
					'Homelite',
					'Honda',
					'Husqvarna',
					'Kawasaki',
					'Lifetime',
					'Mackissic',
					'Mcculloch',
					'Murray',
					'Ohio Steel',
					'Poulan',
					'Poulan Pro',
					'Snapper',
					'Swisher',
					'Troybilt',
					'Weedeater',
					'Yard Machine',
					'Yardman',
					'YardPro'
				],
                'NatureOfProblem': [
					'Augur: Hit obstruction',
					'Augur: Not turning properly',
					'Chute rotation problem',
					'Not blowing snow far enough',
					'Not cleaning snow properly',
					'Self-propulsion mechanism problem',
					'Starting system problem',
					'Tire problem',
					'Other'
				]
            },
            'Stacked Laundry Unit': {
                'MerchCode': 'WASHERDRYERL',
                'TopBrands': [
					'Kenmore',
					'Kenmore Elite',
					'Whirlpool',
					'GE',
					'Maytag',
					'Frigidaire'
				],
                'Brand': [
					'Amana',
					'Electrolux',
					'Frigidaire',
					'GE',
					'Gibson',
					{
    'Name': 'Kelvinator'
					},
					'Kenmore',
					'KitchenAid',
					{
    'Name': 'LG',
    'Phone': 'LGDefault',
    'Url': 'LGDefault'
					},
					'Maytag',
					{
    'Name': 'Roper'
					},
					{
    'Name': 'Samsung',
    'Phone': 'SamsungDefault',
    'Url': 'SamsungDefault'
					},
					'Speed Queen',
					{
    'Name': 'WCI'
					},
					'Westinghouse',
					'Whirlpool'
				],
                'NatureOfProblem': [
					'Cleaning: Excessive lint on clothes',
					'Draining: Continues to fill and drain',
					'Draining: Water isnot pumped out during spin cycle',
					'Draining: Water wonot drain from washer',
					'Draining: Continue to fill',
					'Function: Clothes donot dry or take a long time to dry',
					'Function: Dryer doesnot run',
					'Function: Dryer runs but doesnot heat up',
					'Function: Runs with door open',
					'Function: Washer wonot run or stops during cycle',
					'Function: Wonot run clean cycle',
					'Function: Wonot shut off',
					'Noise: Strange noises or vibrations in dryer',
					'Noise: Strange noises or vibrations in washer',
					'Timing: Basket is slow or will not spin',
					'Timing: Runs and shuts off quickly',
					'Water: Water doesnot fill washer',
					'Other'
				]
            },
            'Stationary Bike': {
                'MerchCode': 'EXERCISE1',
                'TopBrands': [
					'Bladez',
					'Proform',
					'Schwinn',
					'Life Fitness',
					'AFG'
				],
                'Brand': [
					'AFG',
					'Bladez',
					'Champion',
					'Diamondback',
					'Free Spirit',
					'Health Rider',
					'Huffy',
					'Icon',
					'Ironman',
					'Life Fitness',
					'Lifestyler',
					'Nautilus',
					'Proform',
					'Reebok',
					'Schwinn',
					'Tetra',
					'Weslo'
				],
                'NatureOfProblem': [
					'Belt/Chain: Doesnot Move',
					'Belt/Chain: Slips',
					'Console Display Problem',
					'Noise: Strange or Excessive',
					'Power: Doesnot Run',
					'Vibration: Strange or Excessive',
					'Other'
				]
            },
            'Stepper': {
                'MerchCode': 'EXERCISER',
                'TopBrands': [
					'Bowflex',
					'Stairmaster',
					'Proform',
					'Star Trac',
					'Horizon'
				],
                'Brand': [
					'Champion',
					'DP',
					'Diamondback',
					'FitnessQuest',
					'Health Rider',
					'Horizon',
					'Icon',
					'Image',
					'Lifestyler',
					'Nautilus',
					'Proform',
					'Reebok',
					'Schwinn',
					'Star Trac',
					'Weider',
					'Weslo'
				],
                'NatureOfProblem': [
					'Belt/Chain: Doesnot Move',
					'Belt/Chain: Slips',
					'Console Display Problem',
					'Noise: Strange or Excessive',
					'Power: Doesnot Run',
					'Vibration: Strange or Excessive',
					'Other'
				]
            },
            'Treadmill': {'MerchCode': 'TREADMILL',
				'TopBrands': [
					'Proform',
					'AFG',
					'Weslo',
					'Icon',
					'Life Fitness'
				],
				'Brand': [
					'AFG',
					'Bladez',
					'CFS',
					'DP',
					'Evolution',
					'Health Rider',
					'Horizon',
					'Icon',
					'Image',
					'Life Fitness',
					'Lifestyler',
					'Nautilus',
					'Proform',
					'Sole',
					'Weslo'
				],
				'NatureOfProblem': [
					'Belt: Slow During Use',
					'Console Display Problem',
					'Incline: Doesnot work',
					'Noise: Strange or Excessive',
					'Power: Doesnot Run',
					'Vibration: Strange or Excessive',
					'Other'
				]
			},
            'TV': {
                'MerchCode': 'TVALL',
                'Type': {
                    'Plasma': {
                        'MerchCode': 'TVPLASM2',
                        'TopBrands': [
							'Panasonic',
							'LG',
							'Sharp',
							'Sony',
							'Toshiba',
							'RCA'
						],
                        'Brand': [
							'Fisher',
							'Funai',
							'GE',
							'Goldstar',
							'Haier',
							'Hitachi',
							'JVC',
							{
    'Name': 'LG',
    'Phone': 'LGDefault',
    'Url': 'LGDefault'
							},
							'LXI',
							'Loewe',
							'Magnavox',
							'Memorex',
							'Mitsubishi',
							'Panasonic',
							'Philips',
							'Pioneer',
							'Prima',
							'Proscan',
							'Protron',
							'Quasar',
							'RCA',
							{
    'Name': 'Samsung',
    'Phone': 'SamsungDefault',
    'Url': 'SamsungDefault'
							},
							'Sanyo',
							'Sharp',
							'Sony',
							'Superscan',
							'Sylvania',
							'Symphonic',
							'Toshiba',
							'Vizio',
							'Yorx',
							'Zenith'
						],
                        'NatureOfProblem': [
							'Function: No picture and sound',
							'Function: TV doesnot work correctly',
							'Picture: a new TV shows interference when it is new and first set up',
							'Picture: Blurry image',
							'Picture: Color is bad',
							'Picture: Shows lines or is distorted',
							'Picture: Weak or double image',
							'Remote Control: Wonot work',
							'Other'
						]
                    },
                    'Projection': {
                        'MerchCode': 'TVPROJECT1Y1',
                        'Brand': [
							'Emerson',
							'Fisher',
							'Funai',
							'GE',
							'Goldstar',
							'Hitachi',
							'JVC',
							{
    'Name': 'LG',
    'Phone': 'LGDefault',
    'Url': 'LGDefault'
							},
							'Magnavox',
							'Mitsubishi',
							'Montgomery Ward',
							'Panasonic',
							'Philco',
							'Philips',
							'Quasar',
							'RCA',
							{
    'Name': 'Samsung',
    'Phone': 'SamsungDefault',
    'Url': 'SamsungDefault'
							},
							'Sanyo',
							'Sears LXI',
							'Sharp',
							'Sony',
							'Silvertone',
							'Sony',
							'Sylvania',
							'Symphonic',
							'Toshiba',
							'Zenith'
						],
                        'NatureOfProblem': [
							'Function: No picture and sound',
							'Function: TV doesnot work correctly',
							'Picture: a new TV shows interference when it is new and first set up',
							'Picture: Blurry image',
							'Picture: Color is bad',
							'Picture: Shows lines or is distorted',
							'Picture: Weak or double image',
							'Remote Control: Wonot work',
							'Other'
						]
                    },
                    'Projection DLP': {
                        'MerchCode': 'TVPDLPHD1YR',
                        'TopBrands': [
							'Panasonic',
							'LG',
							'Sharp',
							'Sony',
							'Toshiba',
							'RCA'
						],
                        'Brand': [
							{
    'Name': 'Fisher'
							},
							{
    'Name': 'Funai'
							},
							{
    'Name': 'GE'
							},
							{
    'Name': 'Goldstar'
							},
							'Haier American Trading',
							{
    'Name': 'Hitachi'
							},
							'JVC',
							{
    'Name': 'LG',
    'Phone': 'LGDefault',
    'Url': 'LGDefault'
							},
							'LXI',
							'Loewe',
							'Magnavox',
							{
    'Name': 'Memorex'
							},
							{
    'Name': 'Mitsubishi'
							},
							'Panasonic',
							'Philips',
							'Pioneer',
							'Prima',
							'Proscan',
							'Protron',
							'Quasar',
							'RCA',
							{
    'Name': 'Samsung',
    'Phone': 'SamsungDefault',
    'Url': 'SamsungDefault'
							},
							'Sanyo',
							{
    'Name': 'Sharp'
							},
							{
    'Name': 'Sony'
							},
							'Superscan',
							'Sylvania',
							'Symphonic',
							{
    'Name': 'Toshiba'
							},
							{
    'Name': 'Vizio'
							},
							{
    'Name': 'Yorx'
							},
							{
    'Name': 'Zenith'
							}
						],
                        'NatureOfProblem': [
							'Function: No picture and sound',
							'Function: TV doesnot work correctly',
							'Picture: a new TV shows interference when it is new and first set up',
							'Picture: Blurry image',
							'Picture: Color is bad',
							'Picture: Shows lines or is distorted',
							'Picture: Weak or double image',
							'Remote Control: Wonot work',
							'Other'
						]
                    },
                    'Projection LCD': {
                        'MerchCode': 'TVPROJLCD1YR',
                        'TopBrands': [
							'Panasonic',
							'LG',
							'Sharp',
							'Sony',
							'Toshiba',
							'RCA'
						],
                        'Brand': [
							{
    'Name': 'Fisher'
							},
							{
    'Name': 'Funai'
							},
							{
    'Name': 'GE'
							},
							{
    'Name': 'Goldstar'
							},
							'Haier American Trading',
							{
    'Name': 'Hitachi'
							},
							'JVC',
							{
    'Name': 'LG',
    'Phone': 'LGDefault',
    'Url': 'LGDefault'
							},
							'LXI',
							'Loewe',
							'Magnavox',
							{
    'Name': 'Memorex'
							},
							{
    'Name': 'Mitsubishi'
							},
							'Panasonic',
							'Philips',
							'Pioneer',
							'Prima',
							'Proscan',
							'Protron',
							'Quasar',
							'RCA',
							{
    'Name': 'Samsung',
    'Phone': 'SamsungDefault',
    'Url': 'SamsungDefault'
							},
							'Sanyo',
							{
    'Name': 'Sharp'
							},
							{
    'Name': 'Sony'
							},
							'Superscan',
							'Sylvania',
							'Symphonic',
							{
    'Name': 'Toshiba'
							},
							{
    'Name': 'Vizio'
							},
							{
    'Name': 'Yorx'
							},
							{
    'Name': 'Zenith'
							}
						],
                        'NatureOfProblem': [
							'Function: No picture and sound',
							'Function: TV doesnot work correctly',
							'Picture: a new TV shows interference when it is new and first set up',
							'Picture: Blurry image',
							'Picture: Color is bad',
							'Picture: Shows lines or is distorted',
							'Picture: Weak or double image',
							'Remote Control: Wonot work',
							'Other'
						]
                    },
                    'Tube 35 inch and larger': {
                        'MerchCode': 'TV35IN90D',
                        'TopBrands': [
							'Panasonic',
							'LG',
							'Sharp',
							'Sony',
							'Toshiba',
							'RCA'
						],
                        'Brand': [
							{
    'Name': 'Fisher'
							},
							{
    'Name': 'Funai'
							},
							{
    'Name': 'GE'
							},
							{
    'Name': 'Goldstar'
							},
							'Haier American Trading',
							{
    'Name': 'Hitachi'
							},
							'JVC',
							{
    'Name': 'LG',
    'Phone': 'LGDefault',
    'Url': 'LGDefault'
							},
							'LXI',
							'Loewe',
							'Magnavox',
							{
    'Name': 'Memorex'
							},
							{
    'Name': 'Mitsubishi'
							},
							'Montgomery Ward',
							'Panasonic',
							'Philips',
							'Pioneer',
							'Prima',
							'Proscan',
							'Protron',
							'Quasar',
							'RCA',
							{
    'Name': 'Samsung',
    'Phone': 'SamsungDefault',
    'Url': 'SamsungDefault'
							},
							'Sanyo',
							{
    'Name': 'Sharp'
							},
							{
    'Name': 'Sony'
							},
							'Superscan',
							'Sylvania',
							'Symphonic',
							{
    'Name': 'Toshiba'
							},
							{
    'Name': 'Vizio'
							},
							{
    'Name': 'Yorx'
							},
							{
    'Name': 'Zenith'
							}
						],
                        'NatureOfProblem': [
							'Function: No picture and sound',
							'Function: TV doesnot work correctly',
							'Picture: a new TV shows interference when it is new and first set up',
							'Picture: Blurry image',
							'Picture: Color is bad',
							'Picture: Shows lines or is distorted',
							'Picture: Weak or double image',
							'Remote Control: Wonot work',
							'Other'
						]
                    }
                }
            },
            'Trash Compactor': {
                'MerchCode': 'COMPACTOR',
                'TopBrands': [
					'Kenmore',
					'Kenmore Elite',
					'GE',
					'Whirlpool',
					'KitchenAid'
				],
                'Brand': [
					'Frigidaire',
					'GE',
					'Kenmore',
					'Kenmore Elite',
					'KitchenAid',
					'Profile',
					'Whirlpool'
				],
                'NatureOfProblem': [
					'Function: Not compacting',
					'Drawer does not open or close',
					'Power: Does not activate',
					'Smell: Strange odor',
					'Other'
				]
            },
            'Washer': {
                'MerchCode': 'WASHALL',
                'Type': {
                    'Front Load': {
                        'MerchCode': 'WASHERFL',
                        'TopBrands': [
							'Kenmore',
							'Kenmore Elite',
							'Maytag',
							'Whirlpool',
							'Samsung',
							'LG'
						],
                        'Brand': [
							'Amana',
							'Electrolux',
							'Frigidaire',
							'GE',
							'Kelvinator',
							'Kenmore',
							'Kenmore Elite',
							'KitchenAid',
							{
    'Name': 'LG',
    'Phone': 'LGDefault',
    'Url': 'LGDefault'
							},
							'Maytag',
							{
    'Name': 'Roper'
							},
							{
    'Name': 'Samsung',
    'Phone': 'SamsungDefault',
    'Url': 'SamsungDefault'
							},
							'Speed Queen',
							'WCI',
							'Westinghouse',
							'Whirlpool'
						],
                        'NatureOfProblem': [
						'Display/buttons not working',
						'Displaying error code',
						'Noise/vibration issue',
						'Not filling with water',
						'Not draining water',
						'Not running/no power',
						'Stopping during cycle',
						'Visible damage',
						'Other'
						]
                    },
                    'Top Load': {
                        'MerchCode': 'WASHERDD',
                        'TopBrands': [
							'Kenmore',
							'Kenmore Elite',
							'Samsung',
							'GE',
							'Maytag',
							'Whirlpool'
						],
                        'Brand': [
							'Amana',
							'Electrolux',
							'Frigidaire',
							'GE',
							'GE Profile',
							'Kelvinator',
							'Kenmore',
							'Kenmore Elite',
							{
    'Name': 'LG',
    'Phone': 'LGDefault',
    'Url': 'LGDefault'
							},
							'Maytag',
							{
    'Name': 'Roper'
							},
							{
    'Name': 'Samsung',
    'Phone': 'SamsungDefault',
    'Url': 'SamsungDefault'
							},
							'Speed Queen',
							'WCI',
							'Westinghouse',
							'Whirlpool'
						],
                        'NatureOfProblem': [
							'Display/buttons not working',
							'Displaying error code',
							'Noise/vibration issue',
							'Not filling with water',
							'Not draining water',
							'Not running/no power',
							'Stopping during cycle',
							'Visible damage',
							'Other'
						]
                    },
                    'Stacked Laundry Unit': {
                        'MerchCode': 'WASHERDRYERL',
                        'TopBrands': [
							'Kenmore',
							'Kenmore Elite',
							'Whirlpool',
							'GE',
							'Maytag',
							'Frigidaire'
						],
                        'Brand': [
							'Amana',
							'Electrolux',
							'Frigidaire',
							'GE',
							'Gibson',
							{
    'Name': 'Kelvinator'
							},
							'Kenmore',
							'KitchenAid',
							{
    'Name': 'LG',
    'Phone': 'LGDefault',
    'Url': 'LGDefault'
							},
							'Maytag',
							{
    'Name': 'Roper'
							},
							{
    'Name': 'Samsung',
    'Phone': 'SamsungDefault',
    'Url': 'SamsungDefault'
							},
							'Speed Queen',
							{
    'Name': 'WCI'
							},
							'Westinghouse',
							'Whirlpool'
						],
                        'NatureOfProblem': [
							'Cleaning: Excessive lint on clothes',
							'Draining: Continues to fill and drain',
							'Draining: Water isnot pumped out during spin cycle',
							'Draining: Water wonot drain from washer',
							'Draining: Continue to fill',
							'Function: Clothes donot dry or take a long time to dry',
							'Function: Dryer doesnot run',
							'Function: Dryer runs but doesnot heat up',
							'Function: Runs with door open',
							'Function: Washer wonot run or stops during cycle',
							'Function: Wonot run clean cycle',
							'Function: Wonot shut off',
							'Noise: Strange noises or vibrations in dryer',
							'Noise: Strange noises or vibrations in washer',
							'Timing: Basket is slow or will not spin',
							'Timing: Runs and shuts off quickly',
							'Water: Water doesnot fill washer',
							'Other'
						]
                    }
                }
            },
            'Water Heater': {
                'MerchCode': 'WATERHEAT',
                'TopBrands': [
					'AO Smith',
					'State',
					'Kenmore',
					'American',
					'Rheem',
					'GE'
				],
                'Brand': [
					'Ace',
					'Ambassador',
					'American',
					'AO Smith',
					'Apollo',
					'Central Hardware',
					'Crosly',
					'GE',
					'Kenmore',
					'Marathon',
					'Penfield',
					'President',
					'Reliance',
					'Rexel',
					'Rexel United',
					'Rheem',
					'Ruud',
					'Sentry',
					'State',
					'Superior',
					'The Boss',
					'Thermo King',
					'Wheelers'
				],
                'NatureOfProblem': [
					'Gas: Gas is leaking',
					'Leaks: Water is leaking',
					'Leaks: Water is leaking when flame is on',
					'Leaks: Water leaks continuously from bottom of tank',
					'Leaks: Water leaks from temperature/pressure relief valve',
					'Noise: Makes sizzling noises',
					'Noise: Makes strange noises',
					'Temperature: No hot water from gas water heater',
					'Temperature: No hot water from electric water heater',
					'Temperature: Thermostat needs setting',
					'Temperature: Water not hot enough',
					'Temperature: Water too hot',
					'Water: Runs out of hot water',
					'Other'
				]
            },
            'Wide Deck Mower': {
                'MerchCode': 'MOWERLWA2YR',
                'TopBrands': [
					'Craftsman',
					'Honda',
					'Poulan',
					'Troybilt'
				],
                'Brand': [
					'Agri/Fab',
					'Briggs & Stratton',
					'Companion',
					'Craftsman',
					'Homelite',
					'Honda',
					'Husqvarna',
					'Kawasaki',
					'Lifetime',
					'Mackissic',
					'Mcculloch',
					'Murray',
					'Ohio Steel',
					'Poulan',
					'Poulan Pro',
					'Snapper',
					'Swisher',
					'Troybilt',
					'Weedeater',
					'Yard Machine',
					'Yardman',
					'YardPro'
				],
                'NatureOfProblem': [
					'Bagging difficult or impossible',
					'Blade damage from obstruction',
					'Cable: pinched or cut',
					'Mower cuts poorly',
					'Self-propulsion mechanism problem',
					'Starting system problem',
					'Strange vibrations',
					'Other'
				]
            },
            'Whole House Dehumidifiers and Humidifiers': {
                'MerchCode': 'HUMID1Y1P',
                'TopBrands': [
					'Aprilaire',
					'Kenmore'
				],
                'Brand': [
					'Aprilaire',
					'Kenmore'
				],
                'NatureOfProblem': [
					'Routine Maintenance',
					'Other'
				]
            }
        },
        'WarrantyStatuses': {
            'No Coverage': 0,
            'Sears Protection Agreement': 1,
            'Manufacturer Warranty': 2,
            'Sears Home Warranty': 3,
            'Not Sure': 4
        },
        'BrandPhoneNumbers': {
            'LGDefault': '800-243-0000',
            'SamsungDefault': '800-726-7864'
        },
        'BrandUrls': {
            'LGDefault' : 'http://www.lg.com/us/support',
            'SamsungDefault' : 'http://www.samsung.com/us/support/'
        }
    };
}

RepairController.$inject = ['SettingsService'];

(angular
    .module('RelayServicesApp.Repair')
).controller('RepairController', RepairController);
