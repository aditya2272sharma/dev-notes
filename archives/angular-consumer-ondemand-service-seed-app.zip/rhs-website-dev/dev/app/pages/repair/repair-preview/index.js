'use strict';

function RepairPreviewController($uibModal, SettingsService, BreadcrumbService,
    ProjectsService, state, ZipcodeInfoService, $log, $anchorScroll) {

    // in the event of a back button press, we need to
    // re-direct the user to the home/new page
    if (JSON.stringify(state.params.project) === '{}') {
        state.go('home.new');
    }

    var vm = this,
        projectId = state.params.id,
        catalogId = state.params.catalogId,
        zipcode = ZipcodeInfoService.getZipcode(),
        catalogId = state.params.catalogId,
        location = state.params.location,
        project = state.params.project,
        techtalkSKUDetails = state.params.techtalkSKUDetails;

    vm.name = state.params.name; // this is for hold appliance name

    /** Error Messages **/
    vm.messageLabel = {
            CURRENT: '',
            DEFAULT: SettingsService.Error.DEFAULT_ERROR,
            NO_PROS_MSG: SettingsService.NO_PROS_FOR_ZIPCODE_ERROR
        };

    /** Initially load data from API**/
    vm.init = function() {
        $anchorScroll();
        vm.projectData = project;
        vm.location = location;
        /** Get breadcrumb details **/
        vm.breadcrumbDetails = BreadcrumbService.getTaskDescription();
        vm.pathElements = [{
            item: 'Home',
            state: {
                name: 'home'
            }
        }, {
            item: 'Home Appliances',
            disabled: true
        }, {
            item: vm.name,
            disabled: true
        }];
    };

    // link methods with the view as per requirement
    // Takes to the Schedule / Date & Time Slot selection page (inactive now)
    vm.goToSchedulePage = function() {
        state.go('repair-schedule', {
          id: projectId,
          catalogId: catalogId
        });
    };

    // Takes to the SKU Selection page (active now)
    vm.goToSKUSelectionPage = function() {
        state.go('repair-sku', {
            project: vm.projectData,
            name: vm.name
        });
    };

    vm.goToTechTalkLandingPage = function() {
        // boolean flag to help swap changes quickly in future
        if (true) {

          // To create a TT (tech-talk) project, you need to pass in
          // catalogId as `99999`
          // serviceType as `TECH_TALK`
          project.catalogid = catalogId;
          project.servicetype = SettingsService.ServiceTypes.TECHTALK;
          project.skuDetails  = techtalkSKUDetails;

          // Creates a tech talk project
          ProjectsService.create(project)
          .then(function(projectObject) {
              // After project creation call `firms/package` to obtain the `acceptReject`
              // object, which also contains the `estimateId` required to book the project

              // catalogId is actually serviceCode here
              state.go('tech-talk-landing', {
                projectId: projectObject.id,
                catalogId: projectObject.category.serviceCode,
                project: vm.projectData,
                location: vm.location,
                name: vm.name
              });
          }, function(error) {
              if (error && error.message) {
                  if (error.message.includes(SettingsService.ADDRESS_NOT_FOUND_FOR_ZIP)) {
                      vm.error.invalidZipCode = true;
                      vm.noAddZipcodeMsg = error.message;
                  } else {
                      vm.messageLabel.CURRENT = vm.messageLabel.DEFAULT;
                  }
              } else {
                  vm.messageLabel.CURRENT = vm.messageLabel.DEFAULT;
              }
          });
        } else {
            // In the previous implementation, we called the `create project` API
            // before landing on this page. Therefore, we could simply update any
            // type of project into a Tech Talk project.
            ProjectsService
            .changeProjectToTechTalk(projectId)
            .then(function(response) {
                state.go('tech-talk-landing', {
                    projectId: projectId,
                    catalogId: catalogId,
                    acceptRejectObject: response
                });
            });
        }
    };

    vm.learnMoreAboutTechTalk = function() {
        var size = 'md';
        var modalInstance = $uibModal.open({
            animation: true,
            ariaLabelledBy: 'modal-title',
            ariaDescribedBy: 'modal-body',
            templateUrl: 'assets/templates/components/tech-talk/learn-more-modal/learn-more-modal.html',
            controller: 'TechTalkLearnMoreModal',
            controllerAs: '$ctrl',
            size: size,
            resolve: {
            }
        });

        modalInstance.result.then(function (result) {
            if (result.requestTechTalk) {
                vm.goToTechTalkLandingPage();
            } else if (result.scheduleInHomeRepair) {
                // keeping this in `comments` for swapping in future if required
                // vm.goToSchedulePage();
                vm.goToSKUSelectionPage();
            }
        }, function () {
            $log.info('Modal dismissed at: ' + new Date());
        });
    };

    /** Calling project API and get project details **/
    if (!project && projectId !== 'decision') {
      ProjectsService
      .getProjectByProjectId(projectId)
      .then(function(projectObject) {
          project = projectObject;
          vm.init();
      }, function(error) {
          if (error) {
              vm.messageLabel.CURRENT = error.message ? error.message : vm.messageLabel.DEFAULT;
          }
      });
    } else {
        vm.init();
    }
}

RepairPreviewController.$inject = ['$uibModal', 'SettingsService', 'BreadcrumbService',
    'ProjectsService', '$state', 'ZipcodeInfoService', '$log', '$anchorScroll'];

(angular.module('RelayServicesApp.Repair')).controller(
        'RepairPreviewController', RepairPreviewController);
