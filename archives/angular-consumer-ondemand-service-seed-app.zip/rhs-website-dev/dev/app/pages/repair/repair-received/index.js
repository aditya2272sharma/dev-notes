'use strict';

function RepairReceivedCtrl(scope, $log, state, modal, ProjectsService, $anchorScroll, $state) {
    var vm = this,
        projectId = state.params.id,
        firmIds = state.params.firmIds,
        startDate = state.params.startDate,
        mockProject = state.params.mockProject,
        mockFirm = state.params.mockFirm,
        //project,
        //firms,
        estimates;

    vm.descriptionExpanded = false;
    vm.isQuickassigned = state.params.isQuickassigned;
    var mockFirmData = {data:[]};
    mockFirmData.data.push(mockFirm);
    if (!projectId || !firmIds || !startDate) {
        // to handle refresh and back navigation
        $state.go('home.main');
    }

    $anchorScroll();

    /*ProjectsService.
    askForProjectEstimations(projectId, firmIds, startDate)
    .then(function(data) {
        project = data.project;
        firms = data.firms;
        estimates = data.estimates;
        vm.init();
    }, function(errorResponse) {
        //@TODO: Handle errors
        vm.isQuickassigned = true;
        $log.debug(errorResponse);
    });*/

    vm.init = function() {
        //Glue for data project
        vm.project = mockProject;
        vm.firmCollection = mockFirmData;
        vm.estimateCollection = estimates;
        vm.description = mockProject.taskDescription;
        if (vm.description) {
            var formattedDesc = String(vm.description).replace(/<[^>]+>/gm, '');
            if (formattedDesc.length > 20) {
                vm.descriptionShort = formattedDesc.substring(0, 20) + '...';
                vm.descExpandable = true;
            } else {
                vm.descriptionShort = formattedDesc;
            }
        }
    };

    vm.init();
}

RepairReceivedCtrl.$inject = ['$scope', '$log', '$state', '$uibModal', 'ProjectsService', '$anchorScroll', '$state'];

(angular
    .module('RelayServicesApp.Repair')
).controller('RepairReceivedCtrl', RepairReceivedCtrl);
