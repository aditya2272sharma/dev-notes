'use strict';

function RepairServiceDetails($uibModalInstance, Uploads, $log, productDetails, RepairService, state, repairProductModalService,
 SettingsService, Projects, LoginManagerService, accountModalService) {
    var vm = this;
    vm.maxImages = 5;
    vm.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR,
        NO_PROS_MSG: SettingsService.NO_PROS_FOR_ZIPCODE_ERROR
    };

    vm.productDetails = productDetails;

    /**
    * Reset form validations
    */
    vm.resetValidation = function() {
        vm.error = {
            invalidZipCode: false
        };
    };

    vm.init = function() {
        vm.images = [];
        vm.symptomDesc = '';
        vm.modalNumber = '';
        vm.hideApplianceSelection = false;
        vm.mCode = vm.productDetails.product;
        if (!LoginManagerService.getUser().isRegistered) {
            LoginManagerService.anonymousLogin();
        }
        (RepairService.getProductType(vm.productDetails.product)
        ).then(function(repairObject) {
            vm.repairProduct = repairObject;
            if (vm.repairProduct.problems) {
                vm.hideApplianceSelection = true;
                vm.problemList = vm.repairProduct.problems;
                vm.catalogid = productDetails.selectedCategoryId;
            } else if (vm.repairProduct.productTypes[0].problems) {
                // new implementation that appeared after SSV3 was introduced
                vm.hideApplianceSelection = true;
                vm.problemList = vm.repairProduct.productTypes[0].problems;
                vm.catalogid = productDetails.selectedCategoryId;
            } else {
                vm.repairProductList = vm.repairProduct.productTypes;
            }
        }, function(error) {
            vm.messageLabel.CURRENT = error.message ? error.message : vm.messageLabel.DEFAULT;
        });
        vm.loadingFile = false;
    };

    vm.changeApplianceSelection = function(applianceTypeData) {
        vm.problemList = applianceTypeData.problems;
        vm.catalogid = applianceTypeData.id;
        vm.selected = applianceTypeData.merchCode;
        vm.selectedProblemType = null;
        vm.mCode = applianceTypeData.merchCode;
    };

    vm.close = function() {
        $uibModalInstance.dismiss();
    };

    /**
    * Validates more than 5 images are uploaded at the same time
    */
    vm.validateImage = function() {
        vm.disabledSelect = false;
        if (vm.images.length >= vm.maxImages - 1) {
            vm.disabledSelect = true;
        }
    };

    /**
     * Removes image from images array and remove DOM element
     * @param  {number} index Image index
     * @param  {Object} event click event
     */
    vm.deleteImage = function(index, event) {
        event.target.parentElement.remove();
        vm.images.splice(index, 1);
        vm.disabledSelect = false;
    };

    /**
    * Upload images component
    * @param {string} file
    */
    vm.upload = function(file) {
        if (file) {
            vm.loadingFile = true;
            Uploads.uploadFile(file).then(function(response) {
                vm.loadingFile = false;
                vm.images.push(response.data.url);
            }, function(error) {
                vm.loadingFile = false;
                /*vm.images.push('http://s3.amazonaws.com/rhs-static-resources/app/res/images/icon-electrical.png');
                vm.images.push('https://s3.amazonaws.com/rhs-static-resources/app/res/images/icon-plumbing.png');
                vm.images.push('https://s3.amazonaws.com/rhs-static-resources/app/res/images/icon-hvac.png');
                vm.images.push('https://s3.amazonaws.com/rhs-static-resources/app/res/images/icon-handyman.png');
                vm.images.push('https://s3.amazonaws.com/rhs-static-resources/app/res/images/icon-computer.png');*/
                vm.messageLabel.CURRENT = error.message ? error.message : vm.messageLabel.DEFAULT;
            }, function(evt) {
                //vm.loadingFile = evt.loaded !== evt.total;
                $log.log(evt.loaded, '/', evt.total);
            });
        }
    };

    vm.submitServiceDetails = function() {
        if (LoginManagerService.getUser().isRegistered) {
            vm.createRepairProject();
        } else {
            accountModalService.signInInit(function() {
                vm.createRepairProject();
            }, false, false, true);
        }
    };

    /**
     * TODO
     * Currently the id is hardcoded, to navigate to the repair page 3.
     * For testing please create a SS Project Id and give that Id as the hardcoded value.
     */
    vm.createRepairProject = function() {
        var project = {
            catalogid: vm.catalogid,
            zipcode: vm.productDetails.address.zipCode,
            description: vm.symptomDesc,
            images: vm.images,
            brand: vm.productDetails.brand,
            problem: vm.selectedProblemType,
            warrantytype: vm.productDetails.warrantyType,
            modelnumber: vm.modalNumber,
            servicetype: SettingsService.ServiceTypes.REPAIR
        };
        Projects.create(project).then(function(response) {
            state.go('repair-provider', {id: response.id});
            vm.close();
        }, function(error) {
            if (error && error.message) {
                if (error.message.includes(SettingsService.ADDRESS_NOT_FOUND_FOR_ZIP)) {
                    vm.error.invalidZipCode = true;
                    vm.noAddZipcodeMsg = error.message;
                } else {
                    vm.messageLabel.CURRENT = vm.messageLabel.DEFAULT;
                }
            } else {
                vm.messageLabel.CURRENT = vm.messageLabel.DEFAULT;
            }
        });
    };

    vm.isAddressValid = function(isAddressValid, address) {
        if (isAddressValid) {
            vm.isValidAddress = true;
            vm.address = address;
        } else {
            vm.isValidAddress = false;
            vm.address = '';
        }
    };

    vm.checkRepairStatus = function() {
        vm.repirBtnStatus = true;
        if (vm.catalogid &&  vm.isValidAddress && vm.selectedProblemType && vm.symptomDesc) {
            vm.repirBtnStatus = false;
        }
        return (vm.repirBtnStatus);
    };

    vm.backToProductModal = function() {
        vm.close();
        repairProductModalService.openModal(vm.productDetails);
    };

    vm.init();
}

RepairServiceDetails.$inject = ['$uibModalInstance', 'UploadsService', '$log', 'productDetails', 'RepairService', '$state',
 'repairProductModalService', 'SettingsService', 'ProjectsService', 'LoginManagerService', 'accountModalService'];
(angular
    .module('RelayServicesApp.Repair')
).controller('RepairServiceDetails', RepairServiceDetails);
