'use strict';

function RepairProductController(SettingsService, $uibModalInstance, $scope, RepairService,
 repairDetailsModalService, repairHelpLineModalService, productDetails, selectedProduct, _) {

    var vm = this;
    vm.productDetails = productDetails;

    vm.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR
    };

    vm.defaultApplianceName = 'appliance';
    vm.applianceName = vm.defaultApplianceName;

    vm.init = function() {
        if (vm.productDetails) {
            vm.selectedAddress = vm.productDetails.address.zipCode;
        }
        vm.repirBtnStatus = false;
        vm.error = {
            repairNotSelected: false
        };
        vm.Brands = '';
        (RepairService.getAllProduct()
        ).then(function(repairObject) {
            vm.repair = repairObject;
            vm.warranties = vm.repair.warranties;
            if (vm.productDetails) {
                vm.populateSelectedValues();
            }
            if (selectedProduct) {
                vm.setRepairProduct(selectedProduct);
                var isTopProdcut = false;
                _.each(vm.repair.topProducts, function(eachProduct) {
                    if (selectedProduct.name === eachProduct.name) {
                        isTopProdcut = true;
                    }
                });
                if (isTopProdcut === false) {
                    vm.selectFromAllProducts = JSON.stringify(selectedProduct);
                    vm.changeRepairSelection();
                }
            }
        }, function(error) {
            vm.messageLabel.CURRENT = error.message ? error.message : vm.messageLabel.DEFAULT;
        });
    };

    vm.popover = {
        url: 'assets/templates/pages/repair/repair-product/service-type.html'
    };

    $scope.closePopOver = function() {
        $scope.isOpen = false;
    };

    vm.setRepairProduct = function(data) {
        vm.selected = data.merchCode;
        vm.selectedRepairProduct = data.merchCode;
        vm.selFromTopBrand = data.merchCode;
        vm.selectedData = data;
        vm.Brands = data.allBrands;
        vm.productName = data.name;
        vm.selectedCategoryId = data.id;
        vm.selectFromAllProducts = '';
        vm.repairProductBrand = null;
        vm.applianceName = vm.productName;
    };

    vm.changeRepairSelection = function() {
        //vm.Brands = vm.repair.productDetails[vm.selectFromAllProducts].allBrands;
        //vm.productName = vm.repair.productDetails[vm.selectFromAllProducts].name;
        //vm.selectedCategoryId = vm.repair.productDetails[vm.selectFromAllProducts].id;
        if (vm.selectFromAllProducts) {
            var parsedProduct = JSON.parse(vm.selectFromAllProducts);
            vm.Brands = parsedProduct.allBrands;
            vm.productName = parsedProduct.name;
            vm.selectedCategoryId = parsedProduct.id;
            vm.selectedRepairProduct = parsedProduct.merchCode;
            vm.applianceName = vm.productName;
        } else {
            vm.Brands = null;
            vm.applianceName = vm.defaultApplianceName;
        }
        vm.selected = null;
        vm.selectedData =  null;
        vm.repairProductBrand = null;
        vm.selFromTopBrand = null;
    };

    vm.setWarrantyType = function(selectWarranty) {
        vm.selectedWarranty = selectWarranty.status;
        vm.selectedWarrantyKey = selectWarranty.id;
    };

    vm.submitProductDetails = function() {
        var repairProductDetails = {
            product: vm.selectedRepairProduct,
            productName: vm.productName,
            selectedData: vm.selectedData,
            selectedCategoryId: vm.selectedCategoryId,
            topProduct: vm.selFromTopBrand,
            productFromAll: vm.selectFromAllProducts,
            brand: vm.repairProductBrand,
            address: vm.address,
            warrantyType: vm.selectedWarranty
        };
        if (vm.selectedWarrantyKey === 1 || vm.selectedWarrantyKey === 2 ||
                vm.selectedWarrantyKey === 3 || vm.selectedWarrantyKey === 4) {
            repairHelpLineModalService.openModal(repairProductDetails);
        } else {
            $uibModalInstance.dismiss();
            repairDetailsModalService.openModal(repairProductDetails);
        }
    };

    vm.isAddressValid = function(isAddressValid, address) {
        if (isAddressValid) {
            vm.isValidAddress = true;
            vm.address = address;
        } else {
            vm.isValidAddress = false;
            vm.address = '';
        }
    };

    vm.checkRepairStatus = function() {
        vm.repirBtnStatus = true;
        if (vm.isValidAddress && vm.selectedRepairProduct && vm.repairProductBrand && vm.selectedWarranty) {
            vm.repirBtnStatus = false;
        }
        return (vm.repirBtnStatus);
    };

    vm.close = function() {
        $uibModalInstance.dismiss();
    };

    vm.populateSelectedValues = function() {
        vm.repairProductBrand = vm.productDetails.brand;
        vm.selectedRepairProduct = vm.productDetails.product;
        if (vm.productDetails.selectedData) {
            vm.setRepairProduct(vm.productDetails.selectedData);
        } else {
            vm.selectFromAllProducts = vm.productDetails.productFromAll;
            vm.changeRepairSelection();
        }
        vm.selectedWarranty = vm.productDetails.warrantyType;
        vm.repairProductBrand = vm.productDetails.brand;
    };

    vm.init();
}

RepairProductController.$inject = ['SettingsService', '$uibModalInstance', '$scope', 'RepairService',
'repairDetailsModalService', 'repairHelpLineModalService', 'productDetails', 'selectedProduct', '_'];
(angular
    .module('RelayServicesApp.Repair')
).controller('RepairProductController', RepairProductController);
