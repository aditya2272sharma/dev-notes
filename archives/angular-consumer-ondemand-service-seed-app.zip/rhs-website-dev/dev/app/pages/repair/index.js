'use strict';

function Configure($stateProvider) {

    $stateProvider.state('repair', {
        url: '/repair',
        templateUrl: 'assets/templates/pages/repair/index.html',
        controller: 'RepairController as $repair',
        resolve : {
            'sessionStatus': require('../../services/session-status-resolve')
        }
    }).state('repair-form', {
        url: '/ssv3',
        templateUrl: 'assets/templates/pages/new-service-offerings/index.html',
        controller: 'NewServiceOfferingsController as $ctrl',
        params : {
            'repairObject': {},
            'selectedProduct': {}
        },
        resolve : {
            'sessionStatus': require('../../services/session-status-resolve')
        }
    }).state('repair-sku', {
        url: '/repair/sku/:id',
        templateUrl: 'assets/templates/pages/repair/repair-sku/index.html',
        controller: 'RepairSKUController as $ctrl',
        params: {
            'project': {},
            'name': ''
        },
        resolve : {
            'sessionStatus': require('../../services/session-status-resolve')
        }
    }).state('repair-preview', {
        url: '/repair/:catalogId/preview/:id',
        templateUrl: 'assets/templates/pages/repair/repair-preview/index.html',
        controller: 'RepairPreviewController as $ctrl',
        params: {
            'project': {},
            'name': '',
            'location': {},
            'catalogId': '9999',
            'techtalkSKUDetails': [],
            'id': 'decision'
        },
        resolve : {
            'sessionStatus': require('../../services/session-status-resolve')
        }
    }).state('repair-schedule', {
        url: '/repair/:catalogId/schedule/:id',
        params: {
            category: '',
            subcategory:'',
        },
      templateUrl: 'assets/templates/pages/repair/repair-schedule/index.html',
        controller: 'RepairScheduleController as $ctrl',
        resolve : {
            'sessionStatus': require('../../services/session-status-resolve')
        }
    }).state('repair-provider', {
        url: '/repair/projects/:id',
        templateUrl: 'assets/templates/pages/repair/repair-provider/index.html',
        controller: 'RepairProviderController as RepairProviderController',
        resolve : {
            'sessionStatus': require('../../services/session-status-resolve')
        },
    }).state('repair-received', {
        url: '/repair/projects/received/:id',
        templateUrl: 'assets/templates/pages/repair/repair-received/index.html',
        controller: 'RepairReceivedCtrl as RepairReceivedCtrl',
        params : {
            isQuickassigned : false,
            firmIds: '',
            startDate: '',
            mockProject: {},
            mockFirm: {}
        }
    }).state('repair-view-all', {
        url: '/repair/services',
        templateUrl: 'assets/templates/pages/repair/repair-view-all/index.html',
        controller: 'RepairViewAllCtrl as RepairViewAllCtrl',
        params : {
            isQuickassigned : false,
            allProducts: {}
        }
    });
}

Configure.$inject = ['$stateProvider'];

function Run() {
}

(angular
    .module('RelayServicesApp.Repair', [])
    .config(Configure)
).run(Run);
