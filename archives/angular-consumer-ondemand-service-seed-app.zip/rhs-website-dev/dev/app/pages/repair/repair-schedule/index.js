'use strict';

function RepairScheduleController($scope, $rootScope, SettingsService, BreadcrumbService, ProjectsService,
    state, moment, DateTimeValidationService, $filter, _, LoginManagerService, ZipcodeInfoService, NewProjectCategoriesService,
    $anchorScroll, $location, $timeout, $uibModal) {
    var vm = this,
        projectId = state.params.id,
        zipcode = ZipcodeInfoService.getZipcode(),
        catalogId = state.params.catalogId,
        category = state.params.category,
        subcategory = state.params.subcategory,
        project;

    /** Error Messages **/
    vm.messageLabel = {
            CURRENT: '',
            DEFAULT: SettingsService.Error.DEFAULT_ERROR,
            NO_PROS_MSG: SettingsService.NO_PROS_FOR_ZIPCODE_ERROR
        };

    $scope.$watch("$ctrl.selectedDate", function(newValue) {
        vm.selectedDate = newValue;
        vm.formattedSelectedDate = $filter('date')(newValue, 'EEEE, dd MMMM yyyy');
    });

    // Calendar Data
    vm.preferences = [];
    vm.startDates = [];
    vm.timeSlots = [];
    vm.availableDates = [];
    vm.selectedDate = new Date();
    vm.shouldOpenDatePicker = true;
    vm.serviceType = SettingsService.ServiceTypes.STANDARDV3;
    vm.timeRanges = DateTimeValidationService.timeRanges;

    /**
     * This function return date format string based on mode.
     * @param {String} mode - Day, Month, year
     */
    function dateFormatString(mode)
    {
        if (mode === 'year')
            return 'yyyy';
        else if (mode === 'month')
            return 'yyyy-MM';
        else
            return 'yyyy-MM-dd';
    }

    /**
     * This function disbaled dates in calendar view. If it not coming in the response of backend API.
     * @param {Object} data - During calendar drawing, Angular UI Bootstrap library call this method for each calendar date and mode. To execute logic for enabled/disabled date/month/year in calendar view.
     */
    function disabled(data) {
        var date = data.date,
            formattedDate = $filter('date')(date, dateFormatString(data.mode)),
            filteredResults;
        filteredResults = _.find(vm.availableDates, function(availableDate) {
            return (formattedDate === $filter('date')(availableDate.date, dateFormatString(data.mode) ) );
        });
        return angular.isDefined(filteredResults) ? false : true;
    }

    vm.datePickerOptions = {
        minDate: new Date(),
        maxDate: new Date(),
        startingDay: 0,
        showWeeks: false,
        dateDisabled: disabled
    };

    /** Calling project API and get project details **/
    ProjectsService
    .getProjectByProjectId(projectId)
    .then(function(projectObject) {
            project = projectObject;
            vm.serviceType = project.serviceType;
            ProjectsService
            .checkAvailability(catalogId, zipcode, vm.serviceType)
            .then(function(response) {
                vm.availableDates = response && response.data || [];
                vm.datePickerOptions.minDate = vm.availableDates[0].date;
                vm.selectedDate = vm.availableDates[0].date;
                vm.formattedSelectedDate = $filter('date')(vm.selectedDate, 'EEEE, dd MMMM yyyy');
                vm.datePickerOptions.maxDate = vm.availableDates[vm.availableDates.length - 1].date;
            })
            .finally(function() {
                vm.init();
            });

    }, function(error) {
        if (error) {
            vm.messageLabel.CURRENT = error.message ? error.message : vm.messageLabel.DEFAULT;
        }
        state.go('home.new');
    });

    $anchorScroll(); // SLT-171
    /** Initially load data from API**/
    vm.init = function() {
        vm.projectData = project;
        /** Get breadcrumb details **/
        vm.breadcrumbDetails = BreadcrumbService.getTaskDescription();
        vm.loggedInUser = LoginManagerService.getUser();

        if(vm.serviceType ===  SettingsService.ServiceTypes.STANDARDV3) {
            vm.pathElements = [
                {
                    item: 'Home',
                    state: {
                        name: 'home'
                    }
                }, {
                    item: 'Home Appliances',
                    disabled: true
                }, {
                    item: vm.projectData.title,
                    disabled: true
                }, {
                    item: 'Schedule'
                }
            ];
        } else {
            NewProjectCategoriesService.getcategoriesbyid(catalogId)
            .then(function(response) {
                vm.pathElements = [
                    {
                        item: 'Home',
                        state: {
                            name: 'home'
                        }
                    },
                    {
                        item: response.mainCategoryTitle,
                        state: {
                            name: 'services.category',
                            params: {
                                category: category,
                                id: response.mainCategoryId
                            }
                        }
                    },
                    {
                        item: response.title,
                        state: {
                            name: 'services.category',
                            params: {
                                category: category,
                                id: response.mainCategoryId
                            }
                        }
                    }, {
                        item: 'Schedule'
                    }
                ];
            });
        }
    };

    vm.timeSlotClicked = function(currentTimeSlot) {
        var timeSlot = {
            date: vm.selectedDate,
            timeSlot: currentTimeSlot
        };
        if (!checkForDuplicateTimeslots(currentTimeSlot)) {
            if (vm.preferences.length < 3) {
                vm.preferences.push(timeSlot);
            } else {
                vm.preferences.splice(0, 1);
                vm.preferences.push(timeSlot);
            }
            vm.messageLabel.CURRENT = '';
        } else {
            vm.messageLabel.CURRENT = 'Please select different timeslot';
        }
    };

    function checkForDuplicateTimeslots(selectedTimeSlot) {
        var dupArray = [];
        dupArray = _.filter(vm.preferences, function (el) {
            return moment(el.date).format('YYYY-MM-DD') === moment(vm.selectedDate).format('YYYY-MM-DD')
                && el.timeSlot === selectedTimeSlot;
        });
        return (dupArray.length === 0) ? false : true;
    }

    vm.isSlotSelected = function(currentTimeSlot) {
        if (currentTimeSlot === vm.timeSlotSelected) {
            return true;
        } else {
            return false;
        }
    };

    vm.updateProject = function() {
        // get selected date array from preferences items
        var selectedDate = vm.preferences.map(function(item) {
            return (item.date) ? $filter('date')(item.date, 'yyyy-MM-dd') : '';
        });

        // get selected time slot value array from preferences items
        var selectedTimeSlot = vm.preferences.map(function(item) {
            return (item.timeSlot.value) ? item.timeSlot.value : '';
        });

        var updatedInfo = {
            'startdates': selectedDate.join(", "),
            'timeSlots': selectedTimeSlot.join(", "),
            'id': projectId,
            'show_availability': true
        };

        ProjectsService.update(updatedInfo).then(function() {
            // `response` is arguments[0]
            // omitted to prevent no-unused-vars lint error
            $timeout( function() {
                if(vm.serviceType ===  SettingsService.ServiceTypes.STANDARDV3) {
                    state.go('repair-provider', {
                        id: projectId
                    });
                } else {
                    state.go('services.results', {
                        category: category,
                        subcategory: subcategory,
                        categoryId: catalogId,
                        pId: projectId
                    });
                }
            }, 300);
        }, function(error) {
            vm.messageLabel.CURRENT = error && error.message ? error.message : vm.messageLabel.DEFAULT;
        });
    };

    vm.openPopUp = function() {
        vm.shouldOpenDatePicker = true;
    };

    vm.formattedPreferenceItem = function(item) {
        if ((angular.isObject(item) && angular.isDate(moment(item.date)._d))) {
            return ($filter('date')(item.date, 'EEEE, dd MMMM yyyy') + ', ' + item.timeSlot.label);
        } else {
            return item.timeSlot.label;
        }
    };

    vm.changeSelectedPreferenceTimeSequence = function(itemIndex, newIndex) {
        var temp = vm.preferences[newIndex];
        vm.preferences[newIndex] = vm.preferences[itemIndex];
        vm.preferences[itemIndex] = temp;
    };

    vm.deletePreferenceItem = function(itemIndex) {
        if (vm.preferences.length > itemIndex) {
            vm.preferences.splice(itemIndex, 1);
        }
    };

    vm.getUpdatedHAProjectData = function(zipcode) {
        var images = "";
        if(vm.projectData.images.length > 0) {
            images = _.reduce(vm.projectData.images, function(urls, obj){
                return (urls === "") ? obj.url : urls + "," + obj.url;
            }, "");
        }

        return {
            catalogid: vm.projectData.category.rowid,
            zipcode: zipcode,
            description: vm.projectData.taskDescription,
            images: images,
            brand: vm.projectData.brand, // brand is optional
            problem: vm.projectData.problem, // the model contains an object, so we can't use it
            warrantytype: 'No Coverage',
            modelnumber: vm.projectData.modelnumber, // model number is optional
            servicetype: SettingsService.ServiceTypes.STANDARDV3,
            appliance: vm.projectData.appliance,// e.g. Refrigerator
            appliancetype: vm.projectData.applianceType,
            appliancesubtype: '', // not required for ssv4 flow
        };
    };

    vm.getUpdatedPEProjectData = function(zipcode) {
        return {
            'subcategoryid': vm.projectData.category.rowid,
            'title': vm.projectData.title,
            'zipcode': zipcode,
            'taskTitle': vm.projectData.taskDescription,
            'description': vm.taskTitle,
            'size': 'small',
            'servicetype': vm.projectData.serviceType,
            'show_availability' : true,
            'catalogid': vm.projectData.category.rowid
        };
    };

    vm.createProjectWithNewZipcode = function() {
        var browserZipCode = ZipcodeInfoService.getZipcode();

        if (browserZipCode && browserZipCode.length === 5) {
            var isServiceAvailableForZipcode = ZipcodeInfoService.getServiceAvailabilityForZipcode();

            if (!isServiceAvailableForZipcode && vm.projectData.serviceType === SettingsService.ServiceTypes.STANDARDV3) {
                state.go("repair-form", {
                    referer: "RepairScheduleController"
                });
            } else {
               var updatedProjectData = {};
                if(vm.projectData.serviceType === SettingsService.ServiceTypes.STANDARDV3) {
                    updatedProjectData = vm.getUpdatedHAProjectData(browserZipCode);
                } else {
                    updatedProjectData = vm.getUpdatedPEProjectData(browserZipCode);
                }

                ProjectsService.create(updatedProjectData).then(function(response) {
                    projectId = response.id;
                    vm.projectData = response;
                    project = response;

                    var path = $location.path();
                    if(path.indexOf("repair") > -1 && vm.projectData.serviceType === SettingsService.ServiceTypes.STANDARDV3) {
                        path = path.substring(0, path.lastIndexOf("/") + 1) +  projectId;
                        $location.path(path);
                    }

                    if(vm.preferences.length > 0 && path.indexOf("schedule") === -1) {
                        // get selected date array from preferences items
                        var selectedDate = vm.preferences.map(function(item) {
                            return (item.date) ? $filter('date')(item.date, 'yyyy-MM-dd') : '';
                        });

                        // get selected time slot value array from preferences items
                        var selectedTimeSlot = vm.preferences.map(function(item) {
                            return (item.timeSlot.value) ? item.timeSlot.value : '';
                        });

                        var updatedInfo = {
                            'startdates': selectedDate.join(", "),
                            'timeSlots': selectedTimeSlot.join(", "),
                            'id': projectId,
                            'show_availability': true
                        };

                        ProjectsService.update(updatedInfo);
                    }

                });
            }
        } else {
            state.go("home.new");
        }


    };

    // SLT-398 Code Revert
    // vm.gotoTechTalk = function() {
    //     state.go("tech-talk-static-landing");
    // }

    // vm.learnMoreAboutTechTalk = function() {
    //     var size = "md";
    //     var modalInstance = $uibModal.open({
    //       animation: true,
    //       ariaLabelledBy: "modal-title",
    //       ariaDescribedBy: "modal-body",
    //       templateUrl:
    //         "assets/templates/components/tech-talk/learn-more-modal/learn-more-modal.html",
    //       controller: "TechTalkLearnMoreModal",
    //       controllerAs: "$ctrl",
    //       size: size,
    //       resolve: {}
    //     });

    //     modalInstance.result.then(
    //       function(result) {
    //         if(result)
    //           vm.gotoTechTalk();
    //       },
    //       function() {
    //         $log.info("Modal dismissed at: " + new Date());
    //       }
    //     );
    //   };

    // handle notification when zipcode serviceability updated notification
    $rootScope.$on("zipcode-service-updated-notification", function(event, data) {
        vm.createProjectWithNewZipcode(); // update screen UI constant based on user zipcode
    });

    // In case of signin/up, recreate the project with the new session
    $rootScope.$on('user:authentication:change', function(event, user) {
        // check whether the user session has changed
        if(user.isRegistered && !angular.equals(user, vm.loggedInUser)) {
            vm.loggedInUser = user;
            vm.createProjectWithNewZipcode();
        }
    });
}

RepairScheduleController.$inject = ['$scope', '$rootScope', 'SettingsService', 'BreadcrumbService', 'ProjectsService',
    '$state', 'moment', 'DateTimeValidationService', '$filter', '_', 'LoginManagerService', 'ZipcodeInfoService', 'NewProjectCategoriesService',
    '$anchorScroll', '$location', '$timeout', '$uibModal'];
(angular.module('RelayServicesApp.Repair')).controller(
        'RepairScheduleController', RepairScheduleController);
