'use strict';

function RepairHelpLineController(SettingsService, $uibModalInstance, $scope, RepairService,
    repairHelpLineModalService, repairDetailsModalService, productDetails) {

    var vm = this;
    vm.productDetails = productDetails;

    vm.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR
    };

    vm.submitHelpLineDetails = function() {
        $uibModalInstance.dismiss();
    };

    /*vm.init = function() {
        vm.repirBtnStatus = false;
        vm.error = {
            repairNotSelected: false
        };
        vm.Brands = '';
        (RepairService.getAllProduct()
        ).then(function(repairObject) {
            vm.repair = repairObject;
        }, function(error) {
            vm.messageLabel.CURRENT = error.message ? error.message : vm.messageLabel.DEFAULT;
        });
    };

    vm.init();*/

    vm.closePopup = function() {
        $uibModalInstance.dismiss();
    };
}

RepairHelpLineController.$inject = ['SettingsService', '$uibModalInstance', '$scope', 'RepairService',
'repairHelpLineModalService', 'repairDetailsModalService', 'productDetails'];
(angular
    .module('RelayServicesApp.Components')
).controller('RepairHelpLineController', RepairHelpLineController);
