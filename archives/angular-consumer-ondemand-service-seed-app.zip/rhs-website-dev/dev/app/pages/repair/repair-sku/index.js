'use strict';

function RepairSKUController(SettingsService, BreadcrumbService, Projects,
    state, LoginManagerService, accountModalService, $sce, ZipcodeInfoService, _,
    $q, $rootScope) {
    var vm = this,
        project = state.params.project,
        name = state.params.name,
        disableContinue = false,
        zipcode = ZipcodeInfoService.getZipcode();

    vm.updatePriceRequests = function(browserZipcode) {
        _.each(vm.skuDetails, function(item, index) {
            vm.getPriceRequests[index] = Projects
                .getPrice(vm.skuDetails[index].sku, browserZipcode, 'STANDARD_V3');
        });
    };

    if (project.skuDetails) {
        vm.skuDetails = project.skuDetails;
        vm.getPriceRequests = [];
        vm.prices = [];
        delete project.skuDetails;
        vm.updatePriceRequests(zipcode);
    } else {
        state.go('home.new');
    }
    vm.expanded = [];
    vm.textToRead = [];
    
    /** Error Messages **/
    vm.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR,
        NO_PROS_MSG: SettingsService.NO_PROS_FOR_ZIPCODE_ERROR
    };

    vm.init = function() {
        vm.projectData = project;
        vm.catalogid = vm.skuDetails[0].catalogId;
        /** Get breadcrumb details **/
        vm.breadcrumbDetails = BreadcrumbService.getTaskDescription();
        vm.pathElements = [
            {
                item: 'Home',
                state: {
                    name: 'home'
                }
            }, {
                item: 'Home Appliances',
                disabled: true
            }, {
                item: name,
                disabled: true
            }, {
                item: 'SKU Selection'
            }
        ];
        vm.getPriceforSKUs();
    };

    vm.getPriceforSKUs = function() {
        $q.all(vm.getPriceRequests)
        .then(function(response){
            vm.prices = response;
            vm.messageLabel.CURRENT = '';
            vm.disableContinue = false;
        }, function(error) {
            vm.messageLabel.CURRENT = error && error.message
            ? 'Sorry, we don\'t have any providers available. But we are constantly growing our network so do check back with us soon' 
            : vm.messageLabel.DEFAULT;
            vm.disableContinue = true;
        });
    };

    // handle notification when zipcode serviceability updated notification
    $rootScope.$on('zipcode-service-updated-notification', function (event, data) {
       zipcode = ZipcodeInfoService.getZipcode();
       if(zipcode && (zipcode.length === 5))
        {
            vm.getPriceRequests = [];
            vm.prices = [];
            vm.updatePriceRequests(zipcode);
            vm.getPriceforSKUs();
        }
    });

    vm.submitServiceDetails = function() {
        if (LoginManagerService.getUser().isRegistered) {
            vm.createRepairProject();
        } else {
            accountModalService.signInInit(function() {
                vm.createRepairProject();
            }, false, false, true);
        }
    };

    vm.createRepairProject = function() {
        Projects.create(project).then(function(response) {
            // old implementation was to take the user to the decision page i.e. `/preview`
            // state.go('repair-preview', {...});
            state.go('repair-schedule', {
              id: response.id,
              catalogId: vm.catalogid
            });
        }, function(error) {
            if (error && error.message) {
                if (error.message.includes(SettingsService.ADDRESS_NOT_FOUND_FOR_ZIP)) {
                    vm.error.invalidZipCode = true;
                    vm.noAddZipcodeMsg = error.message;
                } else {
                    vm.messageLabel.CURRENT = vm.messageLabel.DEFAULT;
                }
            } else {
                vm.messageLabel.CURRENT = vm.messageLabel.DEFAULT;
            }
        });
    };

    vm.goToSchedulePage = function() {
        project.catalogid = vm.catalogid;
        vm.createRepairProject();
    };

    vm.goToHome = function() {
        state.go('home.new');
    };

    vm.getSafeDesc = function(descHtml) {
        return $sce.trustAsHtml(descHtml);
    };

    vm.toggleExpanded = function(index) {
        vm.expanded[index] = !vm.expanded[index];
        vm.textToRead[index] = vm.expanded[index] ? 'Read Less' : 'Read More';
    };

    vm.init();
}

RepairSKUController.$inject = ['SettingsService', 'BreadcrumbService', 'ProjectsService',
    '$state', 'LoginManagerService', 'accountModalService', '$sce', 'ZipcodeInfoService', '_',
    '$q', '$rootScope'];

(angular.module('RelayServicesApp.Repair')).controller(
        'RepairSKUController', RepairSKUController);
