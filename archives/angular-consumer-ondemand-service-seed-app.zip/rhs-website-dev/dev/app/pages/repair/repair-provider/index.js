'use strict';

function RepairProviderController(SettingsService, BreadcrumbService, modal, ProjectsService, state,
        RepairScheduleModalService, RepairImageGalleryModalService, $filter, RepairLastStepModalService,
        CheckoutInfoService, LoginManagerService, accountModalService, _, $anchorScroll, $rootScope,
        ZipcodeInfoService, $location) {
    var vm = this,
        projectId = state.params.id,
        selectedFirms = [],
        estimateId = null,
        project;

    /** TODO: Remove this once real API is ready**/
    //projectId = '20350';

    /** Initialization **/
    vm.availabilityLoaded = false;
    vm.firmCollection = null;
    vm.selectedProCard = undefined;
    vm.isCardSelected = false;
    vm.breadcrumbDetails = '';
    vm.isProAvailable = false;

    /** Error Messages **/
    vm.messageLabel = {
            CURRENT: '',
            DEFAULT: SettingsService.Error.DEFAULT_ERROR,
            NO_PROS_MSG: SettingsService.NO_PROS_FOR_ZIPCODE_ERROR
        };

    /** Calling project API and get project details **/
    (ProjectsService
            .getProjectByProjectId(projectId)
        ).then(function(projectObject) {
            project = projectObject;
            vm.init();
        }, function(error) {
            if (error) {
                vm.messageLabel.CURRENT = error.message ? error.message : vm.messageLabel.DEFAULT;
            }
        });

    /** Initially load data from API**/
    vm.init = function() {
        /** Get breadcrumb details **/
        $anchorScroll();
        vm.breadcrumbDetails = BreadcrumbService.getTaskDescription();
        vm.loggedInUser = LoginManagerService.getUser();
        vm.pathElements = [
            {
                item: 'Home',
                state: {
                    name: 'home'
                }
            }, {
                item: 'Home Appliances',
                disabled: true
            }, {
                item: project.title,
                disabled: true
            }, {
                item: 'Choose Providers'
            }
        ];
        vm.projectData = project;
        /** Get Service providers for Repair **/
        ProjectsService
        .getProjectEstimatesFirms(vm.projectData.id)
        .then(function(projectCollection) {
            vm.firmCollection = projectCollection;
            selectedFirms = angular.copy(projectCollection.items);
            vm.costEstimate = projectCollection.items && projectCollection.items[0] ?
                projectCollection.items[0].packageDetails.bid.price : 0;
            vm.availabilityLoaded = true;
            vm.isProAvailable = true;
            $anchorScroll();
        }, function(error) {
            vm.messageLabel.CURRENT = error && error.message ? error.message : vm.messageLabel.NO_PROS_MSG;
            vm.availabilityLoaded = false;
        });
    };

    /** Modal to show images in separate popup **/
    vm.showGallery = function(openImageIndex) {
        RepairImageGalleryModalService.openModal(openImageIndex, vm.projectData.images);
    };

    /** Select procard frim list **/
    /*vm.selectProCard = function(selectedProCardObj) {
        if (selectedProCardObj) {
            vm.selectedProCard = selectedProCardObj;
            if (vm.selectedProCard) {
                vm.isCardSelected = true;
            }
        }
    };*/

    /** Modal to show images in separate popup **/
    /*vm.scheduleAppointment = function() {
        if (vm.projectData) {
            RepairScheduleModalService.openModal(vm.projectData, vm.selectedProCard);
        }
    };*/

    /**
     * Select SSv3 firm / Non Standard firm / Repair firm
     * @param {Object} provider provider
     * @param {Number} index position of the provider element in the array
     * @param {Boolean} isAdded action indicating wheter to remove or add (true or false)
     */
    vm.changeFirm = function(provider, index, isAdded) {
        if (project.serviceType === SettingsService.ServiceTypes.REPAIR) {
            RepairLastStepModalService.openModal(vm.projectData, provider);
        }
        if (selectedFirms) {
            if(isAdded) {
                selectedFirms[index] = provider;
            } else {
                selectedFirms[index] = undefined;
            }
        }
        // meant for disabling the continue-button
        vm.updateSelectedProviders();
    };

    /** Send the firms selected and ask them for estimations **/
    vm.askForProjectEstimations = function() {
        var firmIds = vm.firmsSelected.id,
            startDate = project.startDate;
        ProjectsService.
        askForProjectEstimations(projectId, firmIds, startDate)
        .finally(function() {
            state.go('projects.request-received', {id: projectId});
        });
    };

    vm.goToPaymentsPage = function() {
        if (!LoginManagerService.getUser().isRegistered) {
            var updatedInfo = {
                'startdates': project.preferredStartDates,
                'timeSlots': project.preferredSlots,
                'id': project.id,
                'show_availability': true
            };
            ProjectsService.create(ProjectsService.prepareProjectData(project))
            .then(function(response){
                updatedInfo.id = response.id;
                ProjectsService.update(updatedInfo)
                .then(function(projectObject) {
                    project = projectObject;
                    vm.projectData = projectObject;
                    vm.performCheckout();
                });
            });
        } else {
            vm.performCheckout();
        }
    };

    vm.performCheckout = function() {
        vm.updateSelectedProviders();
        ProjectsService.update({
            id: project.id,
            selectedfirms: vm.selectedFirmIDs.join(',')
        }).then(function() {
            CheckoutInfoService.setCheckout({
                estimateId: estimateId,
                project: project.id,
                firm: vm.firmCollection.items[0],
                selectedDate: project.startDate,
                selectedTime: project.timeSlot
            });
            state.go('payment.checkout');
        }, function(error) {
            vm.messageLabel.CURRENT = error && error.message ? error.message : vm.messageLabel.DEFAULT;
        });
    };

    vm.acceptEstimateForCheckout = function() {
        ProjectsService
        .acceptOrRejectProjectEstimation(vm.projectData.id, estimateId, 'Accept')
        .then(function(acceptRejectObject) {
            CheckoutInfoService.setCheckout({
                order: acceptRejectObject,
                project: project.id,
                firm: vm.selectedFirm,
                selectedDate: project.startDate,
                selectedTime: project.timeSlot
            });
            state.go('payment.checkout');
        }, function(error) {
            vm.messageLabel.CURRENT = error && error.message ? error.message : vm.messageLabel.DEFAULT;
        });

        if (vm.guestCheckout) {
            state.go('payment.guestCheckout');
        } else {
            state.go('payment.checkout');
        }
    };

    vm.updateSelectedProviders = function() {
        var selectedFirmIDs = [];
        _.each(selectedFirms, function(item) {
            if(item) {
                selectedFirmIDs.push(item.id);
                estimateId = item.packageDetails.bid.estimateId;
            }
        });

        vm.selectedFirmIDs = selectedFirmIDs;
    };

    vm.getUpdatedHAProjectData = function(zipcode) {
        var images = "";
        if(vm.projectData.images.length > 0) {
            images = _.reduce(vm.projectData.images, function(urls, obj){
                return (urls === "") ? obj.url : urls + "," + obj.url;
            }, "");
        }
        return {
            catalogid: vm.projectData.category.rowid,
            zipcode: zipcode,
            description: vm.projectData.taskDescription,
            images: images,
            brand: vm.projectData.brand, // brand is optional
            problem: vm.projectData.problem, // the model contains an object, so we can't use it
            warrantytype: 'No Coverage',
            modelnumber: vm.projectData.modelnumber, // model number is optional
            servicetype: SettingsService.ServiceTypes.STANDARDV3,
            appliance: vm.projectData.appliance,// e.g. Refrigerator
            appliancetype: vm.projectData.applianceType,
            appliancesubtype: '', // not required for ssv4 flow
        };
    };

    vm.createProjectWithNewZipcode = function() {
        var browserZipCode = ZipcodeInfoService.getZipcode();

        if (browserZipCode && browserZipCode.length === 5) {
            var isServiceAvailableForZipcode = ZipcodeInfoService.getServiceAvailabilityForZipcode();

            if (!isServiceAvailableForZipcode && vm.projectData.serviceType === SettingsService.ServiceTypes.STANDARDV3) {
                state.go("repair-form", {
                    referer: "RepairScheduleController"
                });
            } else {
               var updatedProjectData = {};
                updatedProjectData = vm.getUpdatedHAProjectData(browserZipCode);

                ProjectsService.create(updatedProjectData).then(function(response) {
                    projectId = response.id;
                    var updatedInfo = {
                        'startdates': vm.projectData.preferredStartDates.join(", "),
                        'timeSlots': vm.projectData.preferredSlots.join(", "),
                        'id': projectId,
                        'show_availability': true
                    };
                    vm.projectData = response;
                    project = response;

                    ProjectsService.update(updatedInfo).then(function() {
                        var path = $location.path();
                        if(path.indexOf("repair") > -1) {
                            path = path.substring(0, path.lastIndexOf("/") + 1) +  projectId;
                            $location.path(path);
                        }
                    });

                });
            }
        } else {
            state.go("home.new");
        }

        
    };

    // handle notification when zipcode serviceability updated notification
    $rootScope.$on("zipcode-service-updated-notification", function(event, data) {
        vm.createProjectWithNewZipcode(); // update screen UI constant based on user zipcode
    });

    // In case of signin/up, recreate the project with the new session
    $rootScope.$on('user:authentication:change', function(event, user) {
        // check whether the user session has changed
        if(user.isRegistered && !angular.equals(user, vm.loggedInUser)) {
            vm.loggedInUser = user;
            vm.createProjectWithNewZipcode();
        }
    });
}

RepairProviderController.$inject = ['SettingsService', 'BreadcrumbService', '$uibModal', 'ProjectsService', '$state',
        'RepairScheduleModalService', 'RepairImageGalleryModalService', '$filter', 'RepairLastStepModalService',
        'CheckoutInfoService', 'LoginManagerService', 'accountModalService', '_', '$anchorScroll', '$rootScope',
        'ZipcodeInfoService', '$location'];

(angular.module('RelayServicesApp.Repair')).controller(
        'RepairProviderController', RepairProviderController);
