'use strict';

function RepairViewAllCtrl($state, $scope, RepairService, $anchorScroll, $filter,
    _, $sce, repairProductModalService) {

    var vm = this;

    vm.init = function() {
        $anchorScroll();
        RepairService.getAllProduct()
        .then(function(repairObject) {
            vm.viewAllProducts = [];
            vm.viewAllProducts = repairObject.productDetails.concat(repairObject.topProducts);
        }, function(error) {
            vm.messageLabel.CURRENT = error.message ? error.message : vm.messageLabel.DEFAULT;
        });
    };

    $scope.trustSrc = function(src) {
        return $sce.trustAsResourceUrl(src);
    };

    vm.showRepairDialog = function(selectedProduct) {
        repairProductModalService.openModal(undefined, selectedProduct);
    };

    vm.init();
}

RepairViewAllCtrl.$inject = [
    '$state', '$scope', 'RepairService', '$anchorScroll', '$filter',
    '_', '$sce', 'repairProductModalService'
];

(angular
    .module('RelayServicesApp.Repair')
).controller('RepairViewAllCtrl', RepairViewAllCtrl);
