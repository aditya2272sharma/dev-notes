'use strict';

function ContactUsCtrl($anchorScroll, $log, Uploads, LoginManagerService,
    ContactUsService, SettingsService, $state, _, $filter, ZipcodeInfoService,
    locationService) {

    var vm = this,
    uploadedURL = '';
    vm.contactReasons = [];

    vm.messageLabel = {
        CURRENT: '',
        SUBMITTED: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR,
        SUCCESS: SettingsService.Success.CONTACT_US_SUCCESS
    };

    vm.submitContactForm = function() {
        vm.messageLabel.SUBMITTED = '';
        vm.contactDetails.phone = $filter('bcTelephone')(vm.contactDetails.phone, 'clean');
        vm.contactDetails.email = vm.contactDetails.email.toLowerCase();
        ContactUsService.submitContact(vm.contactDetails, uploadedURL);
        vm.messageLabel.SUBMITTED = vm.messageLabel.SUCCESS;
    };

    vm.upload = function(file) {
        vm.loadingFile = true;
        vm.uploadError = false;
        if (file === undefined) {
            vm.loadingFile = false;
            return;
        }
        Uploads.uploadFile(file).then(function(response) {
            vm.loadingFile = false;
            vm.images.push(response.data.url);
            uploadedURL = response.data.url;
        }, function(error) {
            vm.loadingFile = false;
            vm.uploadError = true;
            vm.messageLabel.CURRENT = error.message ? error.message : vm.messageLabel.DEFAULT;
        }, function(evt) {
            $log.log(evt.loaded, '/', evt.total);
        });
    };

    vm.validateImage = function() {
        vm.disabledSelect = false;
        if (vm.images.length >= vm.maxImages - 1) {
            vm.disabledSelect = true;
        }
    };

    vm.deleteImage = function() {
        vm.images = [];
    };

    vm.init = function() {
        $anchorScroll();
        vm.images = [];
        vm.contactDetails = {
            firstname : '',
            lastname : '',
            phone : '',
            email: '',
            zipcode: '',
            contactUsReason: '',
            message: ''
        };

        ContactUsService.getContactReasons()
        .then(function(reasons){
            vm.contactReasons = _.sortBy(reasons, 'id');
        });

        vm.loadingFile = false;
        vm.uploadError = false;
        if (!LoginManagerService.getUser().isRegistered) {
            LoginManagerService.anonymousLogin();
        } else {
            var userInfo = LoginManagerService.getUser();
            if (userInfo) {
                vm.contactDetails = {
                    firstname : userInfo.firstName,
                    lastname : userInfo.lastName,
                    phone : $filter('bcTelephone')(userInfo.contact, 'format'),
                    email: userInfo.email,
                    message: ''
                };
            }
        }
        var browserZipCode = ZipcodeInfoService.getZipcode();
        vm.contactDetails.zipcode = (browserZipCode && (browserZipCode.length === 5)) ? browserZipCode : '';
    };

    vm.loadContactUs = function() {
        $state.go($state.current, {}, {reload: true});
    };

    vm.validateZipcode = function(zipcode, form) {
        if (zipcode && zipcode.length === 5) {
            locationService
            .getlocation(zipcode)
            .then(function(){
                form.zipcode.$setValidity('pattern', true);
            }, function(){
                form.zipcode.$setValidity('pattern', false);
            })
        }
    };

    vm.init();
}
ContactUsCtrl.$inject = [
    '$anchorScroll', '$log', 'UploadsService', 'LoginManagerService',
    'ContactUsService', 'SettingsService', '$state', '_', '$filter', 'ZipcodeInfoService',
    'locationService'
];

(angular
    .module('RelayServicesApp.blog')
).controller('ContactUsCtrl', ContactUsCtrl);
