'use strict';

function Configure($stateProvider) {

    $stateProvider.state('contact', {
        url: '/contact',
        controller: 'ContactUsCtrl',
        controllerAs: 'ContactUsCtrl',
        templateUrl: 'assets/templates/pages/contact/index.html',
        params: {
            hasHero: true
        },
        resolve : {
            'sessionStatus': require('../../services/session-status-resolve')
        }
    });

}

Configure.$inject = ['$stateProvider'];

function Run() {
}

(angular
    .module('RelayServicesApp.ContactUs', [])
    .config(Configure)
).run(Run);
