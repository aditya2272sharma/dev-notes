'use strict';

function WeareGrowingCtrl($anchorScroll) {

    $anchorScroll();
}

WeareGrowingCtrl.$inject = ['$anchorScroll'];

(angular
	.module('RelayServicesApp.wearegrowing')
).controller('WeareGrowingCtrl', WeareGrowingCtrl);
