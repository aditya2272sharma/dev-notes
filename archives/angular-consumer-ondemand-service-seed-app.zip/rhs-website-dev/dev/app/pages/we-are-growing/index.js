'use strict';

function Configure($stateProvider) {

    $stateProvider.state('wearegrowing', {
        url: '/we-are-growing',
        controller: 'WeareGrowingCtrl as WeareGrowingCtrl',
        templateUrl: 'assets/templates/pages/we-are-growing/we-are-growing.html',
        resolve : {
            'sessionStatus': require('../../services/session-status-resolve')
        }
    });

}

Configure.$inject = ['$stateProvider'];

function Run() {
}

(angular
    .module('RelayServicesApp.wearegrowing', [])
    .config(Configure)
).run(Run);
