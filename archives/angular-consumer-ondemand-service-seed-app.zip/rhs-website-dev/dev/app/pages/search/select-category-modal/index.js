'use strict';

function SelectCategoryModalCtrl($uibModalInstance, catalogs, createProject, SettingsService, _) {

    var vm = this;

    vm.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR
    };

    vm.close = function() {
        $uibModalInstance.dismiss();
    };

    vm.confirm = function() {
        createProject(vm.selectedCatalog);
        vm.close();
    };

    vm.init = function() {
        vm.catalogList = catalogs;
        vm.selectedCatalog = _.first(catalogs);
    };

    vm.init();
}

SelectCategoryModalCtrl.$inject = ['$uibModalInstance', 'catalogs', 'createProject', 'SettingsService', '_'];
(angular
    .module('RelayServicesApp.Search')
).controller('SelectCategoryModalCtrl', SelectCategoryModalCtrl);
