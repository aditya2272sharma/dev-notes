'use strict';

function Configure($stateProvider) {

    $stateProvider.state('search', {
        url: '/search',
        controller: 'SearchCtrl',
        controllerAs: 'SearchCtrl',
        templateUrl: 'assets/templates/pages/search/search-result/index.html',
        resolve : {
            'sessionStatus': require('../../services/session-status-resolve')
        }
    });

}

Configure.$inject = ['$stateProvider'];

function Run() {
}

(angular
    .module('RelayServicesApp.Search', [])
    .config(Configure)
).run(Run);
