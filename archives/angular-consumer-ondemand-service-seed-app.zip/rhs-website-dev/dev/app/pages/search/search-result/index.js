'use strict';

function SearchCtrl(SettingsService, SearchService, ZipcodeInfoService, ProjectsService,
        $window, SearchInfoService, _, $filter, $state,
        ProjectUpdateModalService, accountModalService, LoginManagerService, $sce,
        SelectCategoryModalService, ProjectCategoriesService, locationService,
        NewProjectCategoriesService) {

    var vm = this,
        CONSTANTS = SettingsService.Constants;

    vm.proSearchResults = [];
    vm.searchCity = '';
    vm.searchState = '';
    vm.limitProResults = 4;

    vm.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR,
        ZIP_ERROR: SettingsService.Error.NO_PROS_FOR_ZIPCODE_ERROR
    };

    var trusted = {};

    vm.getPopoverContent = function(content) {
        return trusted[content] || (trusted[content] = $sce.trustAsHtml(content));
    };

    vm.init = function() {
        var searchInfo = SearchInfoService.getSearchInfo();
        if (searchInfo) {
            vm.searchKey = searchInfo.keyword;
            vm.selectedKey = searchInfo.keyword;
        }
        vm.currentPage = 1;
        vm.searchZip = ZipcodeInfoService.getZipcode();
        if (!vm.searchZip) {
            vm.getZipFromGeolocation();
        } else {
            vm.getSearchResults(vm.searchKey, vm.searchZip);
        }
        vm.searchModal = {
            keyword: vm.searchKey,
            zipcode: vm.searchZip
        };

        NewProjectCategoriesService.autocompleteCategories()
        .then(function(response) {
            vm.subCategories = response;
            vm.addMoreServices();
        }, function() {
            vm.subCategories = [];
            vm.addMoreServices();
        });
    };

    vm.addMoreServices = function() {
        vm.searchKeysList = SettingsService.SearchKeysList;

        //Adding more keys to subcat array
        vm.searchServicesList = vm.subCategories.concat(vm.searchKeysList);

    };

    vm.modelOptions = {
        debounce: {
            default: 200,
            blur: 100
        },
        getterSetter: true
    };
    vm.firmsAbout = function(path, firmid) {
        $state.go(path, {id: firmid, serviceType: SettingsService.ServiceTypes.NON_STANDARD});
    };

    vm.pageChanged = function() {
        vm.processProResultsForPage(vm.currentPage);
    };
    vm.loadMoreClicked = function() {
        vm.hourlyRateArray = [];
        var increamented = vm.limitProResults + 4;
        vm.proSearchResults = vm.proSearchResultsAll;
        vm.limitProResults = increamented > vm.proSearchResultsAll.length ? vm.proSearchResultsAll.length : increamented;
        _.forEach(vm.proSearchResultsAll, function(pro) {
            var catalogDetails = pro.catalogDetails;
            if (catalogDetails && catalogDetails.length > 0) {
                vm.hourlyRateArray.push(CONSTANTS.HOURLY_RATE_LABEL + vm.getProcessedHourlyRate(catalogDetails));
            } else {
                vm.hourlyRateArray.push(CONSTANTS.NO_HOURLY_RATE_FOUND);
            }
        });
    };

    vm.processProResultsForPage = function(page) {
        vm.proSearchResults = [];
        vm.hourlyRateArray = [];
        var startIndex = page * 4 - 4;
        var endIndex = page * 4;
        endIndex = endIndex < vm.proSearchResultsAll.length ? endIndex :  vm.proSearchResultsAll.length;
        vm.proSearchResults = _.slice(vm.proSearchResultsAll, startIndex, endIndex);
        _.forEach(vm.proSearchResults, function(pro) {
            var catalogDetails = pro.catalogDetails;
            if (catalogDetails && catalogDetails.length > 0) {
                vm.hourlyRateArray.push(CONSTANTS.HOURLY_RATE_LABEL + vm.getProcessedHourlyRate(catalogDetails));
            } else {
                vm.hourlyRateArray.push(CONSTANTS.NO_HOURLY_RATE_FOUND);
            }
        });
    };

    vm.getProcessedHourlyRate = function(catalogs) {
        var processedRate = CONSTANTS.NO_HOURLY_RATE_FOUND,
            minRateArray = [],
            maxRateArray = [];
        _.forEach(catalogs, function(catalog) {
            if (catalog.hourlyRate) {
                var rates = catalog.hourlyRate.replace(SettingsService.RegEx.CURRENCY_DOLLAR, '').split(' - ');
                if (rates.length > 0) {
                    minRateArray.push(Number(rates[0]).toFixed(1));
                    maxRateArray.push(Number(rates[1]).toFixed(1));
                }
            }
        });
        if (minRateArray.length > 0 && maxRateArray.length > 0) {
            minRateArray = _.sortBy(minRateArray);
            maxRateArray = _.sortBy(maxRateArray);
            if (minRateArray[0] === maxRateArray[(maxRateArray.length - 1)]) {
                processedRate = '$' + minRateArray[0];
            } else {
                processedRate = '$' + minRateArray[0] + ' - $' + maxRateArray[(maxRateArray.length - 1)];
            }
        }
        return processedRate;
    };

    vm.getSearchResults = function(keyword, zipcode) {
        vm.limitProResults = 4;
        if (keyword && zipcode) {
            vm.searchModal = {
                keyword: keyword,
                zipcode: zipcode
            };
            SearchInfoService.setSearchInfo(vm.searchModal);
            SearchService.searchProByKeyAndZip(keyword, zipcode)
            .then(function(response) {
                vm.proSearchResultsAll = response.firmProviderInfo;
                vm.processPackageDescription(response.packageDetails);
                vm.processProResultsForPage(vm.currentPage);
            }, function(error) {
                vm.messageLabel.CURRENT = error && error.message ? error.message : vm.messageLabel.DEFAULT;
                vm.proSearchResultsAll = null;
                vm.packageSearchResultAll = null;
                vm.proSearchResults = null;
            });
        }
    };

    vm.processPackageDescription = function(packageDetails) {
        vm.packageSearchResultAll = packageDetails;
        if (packageDetails && packageDetails.length > 0) {
            _.forEach(packageDetails, function(item) {
                var description = $filter('limitTo')(item.categoryDescription, 60);
                description = description ? String(description).
                        replace(/<ul>/gm, ' ').
                        replace(/<\/ul>/gm, ' ').
                        replace(/<\/li>/gm, '. ').
                        replace(SettingsService.RegEx.HTML_TAGS, '') : '';
                item.shortDescription = $sce.trustAsHtml(description);
                item.categoryDescription = $sce.trustAsHtml(item.categoryDescription);
            });
        }
    };

    vm.getZipFromGeolocation = function() {
        var geolocation = $window.navigator && $window.navigator.geolocation;
        if (geolocation) {
            $window.navigator.geolocation
            .getCurrentPosition(function(position) {
                locationService
                .getAddressByLatLong(position.coords.latitude, position.coords.longitude)
                .then(function(response) {
                    var completeAddress = response;
                    vm.searchZip = completeAddress.zipCode;
                    if (vm.searchZip) {
                        vm.getSearchResults(vm.searchKey, vm.searchZip);
                    } else {
                        vm.messageLabel.CURRENT = vm.messageLabel.ZIP_ERROR;
                    }
                }, function(error) {
                    vm.messageLabel.CURRENT = error && error.message ? error.message : vm.messageLabel.DEFAULT;
                });
            });
        }
    };

    vm.initiateSearch = function() {
        vm.messageLabel.CURRENT = '';
        vm.currentPage = 1;
        if (vm.selectedKey.name) {
            vm.getSearchResults(vm.selectedKey.name, vm.searchModal.zipcode);
        } else {
            vm.getSearchResults(vm.selectedKey, vm.searchModal.zipcode);
        }

        vm.searchKey = vm.searchModal.keyword;
        vm.searchZip = vm.searchModal.zipcode;
    };

    vm.getEstimates = function(firm) {
        vm.messageLabel.CURRENT = '';
        var catalogList = firm.catalogDetails;
        if (catalogList && catalogList.length > 0) {
            if (catalogList.length > 1) {
                SelectCategoryModalService.openModal(catalogList, function(catalog) {
                    vm.proceedWithNSProject(firm, catalog);
                });
            } else {
                vm.proceedWithNSProject(firm, catalogList[0]);
            }
        } else {
            vm.messageLabel.CURRENT = vm.messageLabel.DEFAULT;
        }
    };

    vm.proceedWithNSProject = function(firm, catalog) {
        if (LoginManagerService.getUser().isRegistered) {
            vm.createNSProjectAndAskEstimates(firm, catalog);
        } else {
            accountModalService.signInInit(function() {
                vm.createNSProjectAndAskEstimates(firm, catalog);
            }, false, false, true);
        }
    };

    vm.createNSProjectAndAskEstimates = function(firm, catalog) {
        var project = {
            zipcode: vm.searchZip,
            description: catalog.subCategoryTitle,
            timeslot: SettingsService.DateTime.TimeRanges[0].value,
            servicetype: SettingsService.ServiceTypes.NON_STANDARD,
            catalogid: catalog.catalogId,
            title: catalog.mainCategoryTitle,
            taskTitle: catalog.mainCategoryTitle,
            timechoice: 'ONE_WEEK'
        };

        ProjectsService.createCustomProject(project)
        .then(function(response) {
            var projectId = response.id;
            var projectStartDate = response.startDate;
            ProjectUpdateModalService.openModal(response, null, function() {
                var firmIds = firm.firmId;
                ProjectsService.
                askForProjectEstimations(projectId, firmIds, projectStartDate)
                .finally(function() {
                    $state.go('projects.request-received', {id: response.id});
                });
            });
        }, function(error) {
            vm.messageLabel.CURRENT = error && error.message ? error.message : vm.messageLabel.DEFAULT;
        });
    };

    vm.getProvidersForPackage = function(packageDetails) {
        var categoryName = $filter('safeUrls')(packageDetails.categoryTitle);
        var subcategoryName = '';

        if (packageDetails.skuName) {
            subcategoryName = $filter('safeUrls')(packageDetails.skuName);
        }
        $state.go('services.results', {
            category: categoryName,
            subcategory: subcategoryName,
            categoryId: packageDetails.catalogId,
            zipcode: vm.searchModal.zipcode
        });
    };

    vm.init();
}
SearchCtrl.$inject = [
    'SettingsService', 'SearchService', 'ZipcodeInfoService', 'ProjectsService',
    '$window', 'SearchInfoService', '_', '$filter', '$state',
    'ProjectUpdateModalService', 'accountModalService', 'LoginManagerService', '$sce',
    'SelectCategoryModalService', 'ProjectCategoriesService', 'locationService',
    'NewProjectCategoriesService'
];

(angular
    .module('RelayServicesApp.Search')
).controller('SearchCtrl', SearchCtrl);
