'use strict';

function AboutCtrl($anchorScroll) {

    $anchorScroll();
}

AboutCtrl.$inject = ['$anchorScroll'];

(angular
	.module('RelayServicesApp.About')
).controller('AboutCtrl', AboutCtrl);
