'use strict';

function Configure($stateProvider) {

    $stateProvider.state('about', {
        url: '/about',
        controller: 'AboutCtrl as AboutCtrl',
        templateUrl: 'assets/templates/pages/about/about.html',
        resolve : {
            'sessionStatus': require('../../services/session-status-resolve')
        },
        params: {
            hasHero: true
        }
    });

}

Configure.$inject = ['$stateProvider'];

function Run() {
}

(angular
    .module('RelayServicesApp.About', [])
    .config(Configure)
).run(Run);
