'use strict';

function Configure($stateProvider, Env) {
    $stateProvider.state('home', {
        url: '/',
        abstract: true,
        templateUrl: 'assets/templates/pages/partials/abstract.html',
        resolve : {
            'sessionStatus': require('../../services/session-status-resolve')
        }
    }).state('home.main', {
        url: ((Env.features.defaultSSV3HomePage) ? 'old' : ''),
        controller: 'HomeMainCtrl',
        controllerAs: 'HomeMainCtrl',
        templateUrl: 'assets/templates/pages/home/main.html',
        params: {
            hasHero: true
        }
    }).state('home.newpage', {
        url: 'homenew',
        controller: 'HomeNewCtrl',
        controllerAs: 'HomeNewCtrl',
        templateUrl: 'assets/templates/pages/home-new/index.html',
        params: {
            hasHero: true
        }
    }).state('home.new', {
        url: ((Env.features.defaultSSV3HomePage) ? '' : 'new'),
        controller: 'HomeNewCtrl',
        controllerAs: 'HomeNewCtrl',
        templateUrl: 'assets/templates/pages/home-new/index.html',
        resolve : {
            'sessionStatus': require('../../services/session-status-resolve')
        }
    });

}

Configure.$inject = ['$stateProvider', 'ENVIRONMENT'];

function Run() {
}

(angular
    .module('RelayServicesAppRun.Home', [])
    .constant('ENVIRONMENT', angular.fromJson('@@environment'))
    .config(Configure)
).run(Run);
