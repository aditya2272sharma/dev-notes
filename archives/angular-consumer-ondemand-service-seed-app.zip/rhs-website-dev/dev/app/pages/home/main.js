'use strict';

function HomeMainCtrl($anchorScroll, SettingsService, ProjectCategoriesService,
    CategoryService, _, $state, $filter, Env, repairProductModalService,
    CookieManager, NewProjectCategoriesService) {

    CookieManager.setNavigationBarContactNumber('1-800-497-6154'); // save home page phone number in cookie

    var vm = this;

    vm.packages = [];

    vm.portableScheduler = Env.features.portableScheduler;
    vm.bookAServiceBanner = Env.features.bookAServiceBanner;
    vm.guaranteeBanner = Env.features.guaranteeBanner;
    vm.earnPointsBanner = Env.features.earnPointsBanner;
    vm.customProject = Env.features.customProject;
    vm.maintainVertical = Env.features.featureMaintainVertical;

    vm.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR
    };

    vm.init = function() {
        $anchorScroll();
        NewProjectCategoriesService.popularCategoriesWithSubcategories()
        .then(function(response) {
            vm.packages = response.maincategories;
        }, function(error) {
            vm.messageLabel.CURRENT = error && error.message ? error.message : vm.messageLabel.DEFAULT;
        });

        // RepairService.getAllProduct()
        // .then(function(repairObject) {
        //     vm.topProducts = repairObject.topProducts;
        // }, function(error) {
        //     vm.messageLabel.CURRENT = error.message ? error.message : vm.messageLabel.DEFAULT;
        // });
    };

    vm.taskParameters = function(category, subcategory, categoryId) {
        var categoryName = $filter('safeUrls')(category);//$filter('safeUrls')(_.get(subcategory, 'parentCategory.title'));
        var subcategoryName = $filter('safeUrls')(subcategory);
        //var subcategoryId = _.get(subcategory, 'id');
        //var categoryId = _.get(subcategory, 'parentCategory.id');
        //$anchorScroll();
        return $state.href('services.results', {
            category: categoryName,
            subcategory: subcategoryName,
            categoryId: categoryId
        });
    };

    vm.taskLocation = function(subcategory) {
        var categoryId = _.get(subcategory, 'parentCategory.id');
        var subcategoryId = _.get(subcategory, 'id');
        var categoryName = $filter('safeUrls')(_.get(subcategory, 'parentCategory.title'));
        var subcategoryName = $filter('safeUrls')(_.get(subcategory, 'title'));
        //$anchorScroll();
        $state.go('services.results', {
            categoryId: categoryId,
            id: subcategoryId,
            category: categoryName,
            subcategory: subcategoryName
        });
    };

    vm.categoryPage = function(category) {
        var categoryName = $filter('safeUrls')(category.title);
        $state.go('services.category', {
            category: categoryName
        });
        //$anchorScroll();
    };

    vm.categoryPageUrl = function(category) {
        var categoryName = $filter('safeUrls')(category.title);
        //$anchorScroll();
        return $state.href('services.category', {
            category: categoryName
        });
    };

    vm.categoryPagebyId = function(category) {
        var categoryName = $filter('safeUrls')(_.get(category, 'title'));
        $state.go('services.category', {
            mainCategoryId: category.id,
            category: categoryName
        });
    };

    vm.repairViewAllPageUrl = function() {
        $state.go('repair-view-all');
    };

    vm.showRepairDialog = function(selectedProduct) {
        repairProductModalService.openModal(undefined, selectedProduct);
    };

    vm.init();
}

HomeMainCtrl.$inject = ['$anchorScroll', 'SettingsService', 'ProjectCategoriesService',
    'CategoryService', '_', '$state', '$filter', 'ENVIRONMENT', 'repairProductModalService',
    'CookieManager', 'NewProjectCategoriesService'];

(angular
    .module('RelayServicesAppRun.Home')
).controller('HomeMainCtrl', HomeMainCtrl);
