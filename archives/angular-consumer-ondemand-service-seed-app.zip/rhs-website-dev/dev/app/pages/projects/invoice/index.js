'use strict';

function ProjectInvoiceCtrl(SettingsService, $state, $anchorScroll, $sce,
    EstimateSummaryInfoService, ProjectsService, moment, Environment) {
    var vm = this,
        projectId = $state.params.id;

    vm.featureNewInvoice = Environment.features.featureNewInvoice;
    vm.laborPriceChanged = false;
    vm.cancelStatus = false;

    vm.init = function() {
        if (!EstimateSummaryInfoService.hasEstimateSummary()) {
            $state.go('account.booking-detail', {id: projectId});
        } else {
            var estimateInfo = EstimateSummaryInfoService.getEstimateSummary();
            vm.estimate = estimateInfo.estimate;
            vm.project = estimateInfo.project;
            vm.firm = estimateInfo.firm;

            if (vm.project.status === SettingsService.ProjetStatus.PROJECT_CANCELLED) {
                vm.cancelStatus = true;
            }

            $anchorScroll();

            if (vm.featureNewInvoice === 'false') {
                (ProjectsService
                        .getEstimateSummary(projectId, vm.estimate.bid.estimateId)
                ).then(function(estimateSummary) {
                    vm.summary = estimateSummary;
                    if (vm.summary && vm.summary.estimateDate) {
                        vm.invoiceDate = moment(vm.summary.estimateDate).format('ddd[,] MMM D[,] YYYY');
                    }
                });
            } else {
                (ProjectsService
                        .getInvoiceSummary(projectId)
                ).then(function(invoiceSummary) {
                    vm.summary = invoiceSummary;
                    if (vm.summary.estimationRefNo === null) {
                        vm.summary.estimationRefNo = vm.summary.orderNo;
                    }
                    if (vm.summary.laborTasks === null) {
                        vm.summary.laborTasks = [{
                            taskName: vm.project.category.title,
                            additionalDetails: vm.project.subcategory,
                            description: vm.project.category.subcategory,
                            quantity: 1,
                            totalPrice: (vm.estimate != null && vm.estimate.bid != null) ? vm.estimate.bid.price : 0,
                            unitPrice: (vm.estimate != null && vm.estimate.bid != null) ? vm.estimate.bid.price : 0
                        }];
                    }
                   
                    /*
                    vm.summary.laborPrice = 0;
                    vm.summary.partsPrice = 0;
                    // There are anomalies in SSv2 where we get `$` in prices.
                    // So, we've to replace `$` from JSON for the `currency` filter to work.
                    for (var i = 0; i < vm.summary.laborTasks.length; i++) {
                        var laborTasksTotalPrice = vm.summary.laborTasks[i].totalPrice.replace('$', '');
                        vm.summary.laborPrice += parseInt(laborTasksTotalPrice);
                        vm.summary.laborTasks[i].unitPrice = parseInt(vm.summary.laborTasks[i].unitPrice.replace('$', ''));
                        vm.summary.laborTasks[i].totalPrice = parseInt(vm.summary.laborTasks[i].totalPrice.replace('$', ''));
                    }
                    if (vm.summary.parts !== null) {
                        for (var j = 0; j < vm.summary.parts.length; j++) {
                            var partsTotalPrice = vm.summary.parts[j].totalPrice.replace('$', '');
                            vm.summary.partsPrice += parseInt(partsTotalPrice);
                            vm.summary.parts[j].unitPrice = parseInt(vm.summary.parts[j].unitPrice.replace('$', ''));
                            vm.summary.parts[j].totalPrice = parseInt(vm.summary.parts[j].totalPrice.replace('$', ''));
                        }
                    }
                    */

                    if (vm.summary && vm.summary.estimateDate) {
                        vm.invoiceDate = moment(vm.summary.estimateDate).format('ddd[,] MMM D[,] YYYY');
                    }
                    if (vm.summary.laborPriceChangeComments && vm.summary.laborPriceChangeComments.length > 0) {
                        vm.laborPriceChanged = true;
                    }
                    vm.summary.finalPriceForLabor = parseInt(vm.summary.finalPriceForLabor);
                });
            }
        }
    };

    vm.loadServiceRequestDetails = function() {
        $state.go('account.booking-detail', {id: $state.params.id});
    };

    vm.getSafeDesc = function(descHtml) {
        return $sce.trustAsHtml(descHtml);
    };

    vm.init();
}

ProjectInvoiceCtrl.$inject = [
    'SettingsService', '$state', '$anchorScroll', '$sce',
    'EstimateSummaryInfoService', 'ProjectsService', 'moment', 'ENVIRONMENT'
];

(angular
    .module('RelayServicesApp.Projects')
).controller('ProjectInvoiceCtrl', ProjectInvoiceCtrl);
