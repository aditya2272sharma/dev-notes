'use strict';

function ProjectsDeatilCtrl(
    $state, $log, $scope, ProjectsService, CheckoutInfoService,
    $anchorScroll, utils, $window, SettingsService, modal
) {
    var vm = this,
        projectId = $state.params.id,
        project,
        estimate;

    //vm.defaultImage = utils.getProjectImage(SettingsService.AssetsPaths.DEFAULT_PROJECT_IMAGE);
    vm.defaultImage = SettingsService.AssetsPaths.DEFAULT_PROJECT_IMAGE;

    $anchorScroll();

    (ProjectsService
        .getProjectByProjectId(projectId)
    ).then(function(projectObject) {
        project = projectObject;
        $scope.projectId = projectId;
        vm.init();
    }, function(error) {
        vm.messageLabel.CURRENT = error.message ? error.message : vm.messageLabel.DEFAULT;
    });

    vm.init = function() {
        //Glue for data project
        vm.hasEstimate = false;
        vm.projectData = project;
        vm.projectImage = vm.defaultImage;
        if (project.images.length > 0) {
            vm.projectImage = project.images[0];
        }
        //console.log(vm.projectData);
        (ProjectsService
            .getProjectEstimatesByProjectId(projectId)
        ).then(function(estimateObject) {
            vm.hasEstimate = true;
            estimate = estimateObject.estimates.items;
            vm.initEstimate();
        }, function(error) {
            vm.messageLabel.CURRENT = error.message ? error.message : vm.messageLabel.DEFAULT;
            vm.hasEstimate = false;
        });
    };

    vm.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR
    };

    vm.initEstimate = function() {
        vm.estimateData = estimate;
    };

    $scope.estimateAccept = function(acceptRejectObject, firm) {
        CheckoutInfoService.setCheckout({
            order: acceptRejectObject,
            project: project,
            firm: firm
        });
        $state.go('payment.checkout');
    };

    $scope.estimateReject = function() {
        $window.location.reload();
    };

    $scope.estimateError = function(errorResponse) {
        $log.debug(errorResponse);
    };

    /**
     * Go to project edit form
     */
    vm.updatePhoto = function() {
        var modalInstance = modal.open({
            animation: true,
            size: 'lg',
            controller: 'editProjectCtrl',
            controllerAs: 'editProjectCtrl',
            resolve: {
                project: function() {
                    return project;
                }
            },
            templateUrl: [
                'assets/templates/components/edit-project/',
                'index.html'
            ].join('')
        });

        modalInstance.result.then(function() {
            $window.location.reload();
        });
    };

}

ProjectsDeatilCtrl.$inject = [
    '$state', '$log', '$scope', 'ProjectsService', 'CheckoutInfoService',
    '$anchorScroll', 'UtilsService', '$window', 'SettingsService', '$uibModal'
];

(angular
    .module('RelayServicesApp.Projects')
).controller('ProjectsDeatilCtrl', ProjectsDeatilCtrl);
