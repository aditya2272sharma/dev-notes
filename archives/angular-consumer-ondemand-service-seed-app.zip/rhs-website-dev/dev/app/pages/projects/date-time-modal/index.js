'use strict';

function ProjectDateTimeCtrl($uibModalInstance, project, proceed,
    ProjectsService, SettingsService, _, moment, $filter) {

    var vm = this;
    vm.project = project;

    vm.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR
    };

    vm.timeRanges = [
        {label:'8am - 12pm', value:'8:00 AM - 12:00 PM'},
        {label: '12pm - 4pm', value:'12:00 PM - 4:00 PM'},
        {label: '4pm - 8pm', value:'4:00 PM - 8:00 PM'}];

    vm.close = function() {
        $uibModalInstance.dismiss();
    };

    vm.proceed = function() {
        vm.validateSelectedDateTime();
        if (!vm.invalidDateTime) {
            vm.updateProjectData();
        }
    };

    vm.updateProjectData = function() {
        var formattedDate = $filter('date')(vm.selectedServiceDate, 'yyyy-MM-dd');
        var projectId = isNaN(parseInt(project)) ? project.id : project;
        var updatedInfo = {
            'startdate': formattedDate,
            'id': projectId,
            'timeslot' : vm.selectedTimeSlot
        };
        ProjectsService.updateCustomProject(updatedInfo).then(function(response) {
            if (response && proceed) {
                proceed(response.startDate, response.timeSlot);
                vm.close();
            }
        }, function(error) {
            vm.messageLabel.CURRENT = error && error.message ? error.message : vm.messageLabel.DEFAULT;
        });
    };

    vm.validateSelectedDateTime = function() {
        var isValidDate = moment(vm.selectedServiceDate).weekday() <= 6;
        var isValidTime = false;
        _.forEach(vm.timeRanges, function(timeRange) {
            if (vm.selectedTimeSlot === timeRange.value) {
                isValidTime = true;
            }
        });
        if (!isValidDate || !isValidTime) {
            vm.invalidDateTime = true;
        }
    };

    vm.init = function() {
        var finaldate = moment().add(1, 'days');
        finaldate = finaldate.weekday() && finaldate.weekday() <= 5 ?
            finaldate : finaldate.add(8 - (finaldate.weekday() || 7), 'days');
        vm.selectedServiceDate = finaldate._d;
        /*vm.selectedServiceDate = moment(vm.project.startDate)._d;*/
        vm.selectedTimeSlot = vm.timeRanges[0].value;
        vm.invalidDateTime = false;
    };

    /**
     ******************Date Picker****************
     */
    vm.popup2 = {
        opened: false
    };

    // Disable weekend selection
    function disabled(data) {
        var date = data.date,
            mode = data.mode;
        return mode === 'day' && (date.getDay() === 0);
    }

    vm.dateOptions = {
        dateDisabled: disabled,
        // formatYear: 'yy',
        maxDate: moment().add(3, 'months'),
        minDate: moment().add(1, 'days'),
        startingDay: 0,
        showWeeks: false
    };

    vm.open2 = function() {
        vm.popup2.opened = true;
    };

    vm.init();
}

ProjectDateTimeCtrl.$inject = ['$uibModalInstance', 'project', 'proceed',
    'ProjectsService', 'SettingsService', '_', 'moment', '$filter'];
(angular
    .module('RelayServicesApp.Projects')
).controller('ProjectDateTimeCtrl', ProjectDateTimeCtrl);
