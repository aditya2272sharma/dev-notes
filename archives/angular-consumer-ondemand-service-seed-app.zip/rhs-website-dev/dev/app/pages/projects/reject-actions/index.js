'use strict';

function RejectActionsCtrl(modalInstance) {
    var vm = this;

    vm.setActions = function(action) {
        modalInstance.close(action);
    };
    vm.close = function() {
        modalInstance.dismiss();
    };
}

RejectActionsCtrl.$inject = ['$uibModalInstance'];

(angular
    .module('RelayServicesApp.Projects')
).controller('RejectActionsCtrl', RejectActionsCtrl);
