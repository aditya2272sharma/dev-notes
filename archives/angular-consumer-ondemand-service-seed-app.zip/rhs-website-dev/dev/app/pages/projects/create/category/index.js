'use strict';

function ProjectCreateCategoryCtrl(scope, $rootScope, state, modal, ProjectCategories, SettingsService, $anchorScroll) {
    var vm = this;

    vm.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR
    };

    vm.init = function() {
        vm.messageLabel.CURRENT = '';
        vm.tasktReady = false;
        scope.setStep(1);
        (ProjectCategories
            .categories(false)
        ).then(function(response) {
            vm.categories = response;
        }, function(error) {
            vm.categoryError(error);
        });
        $anchorScroll();
    };

    /**
     * Brings task from a specific category
     * @param  {number} category id
     */
    vm.pickSubcategory = function(category) {
        vm.tasktReady = false;
        (ProjectCategories
            .subcategories(category.id)
        ).then(function(response) {
            vm.tasks = response.subCategories;
            vm.tasktReady = true;
        }, function(error) {
            vm.categoryError(error);
        });
    };

    /**
     * Selects a task from the task ddl and send the category and subcategory project obj
     * @param  {Object} category category obj
     * @param  {Object} subcategory subcategory obj event
     */
    vm.pick = function(category, subcategory) {
        scope.setProjectCategory(category);
        scope.setProjectSubcategory(subcategory);
        state.go('projects.create.details');
    };

    vm.categoryError = function(error) {
        vm.messageLabel.CURRENT = error.message ? error.message : vm.messageLabel.DEFAULT;
    };

    vm.init();

    $rootScope.$on('user:authentication:change', function() {
        vm.init();
    });
}

ProjectCreateCategoryCtrl.$inject = [
    '$scope', '$rootScope', '$state', '$uibModal', 'ProjectCategoriesService', 'SettingsService', '$anchorScroll'
];

(angular
    .module('RelayServicesApp.Projects')
).controller('ProjectsCreateCategoryCtrl', ProjectCreateCategoryCtrl);
