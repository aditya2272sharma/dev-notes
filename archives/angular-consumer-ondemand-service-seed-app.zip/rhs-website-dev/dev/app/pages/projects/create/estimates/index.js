'use strict';

function ProjectCreateEstimatesCtrl(scope, $log, state, modal, ProjectsService, SettingsService,
     $anchorScroll, ProjectUpdateModalService, $filter, ENV, LoginManagerService, accountModalService) {
    var vm = this,
        projectId = state.params.id,
        project;

    vm.feautreDraftProject = (ENV.features.feautreDraftProject === 'true');
    vm.showDraftProjectsCard = false;
    vm.descriptionExpanded = false;
    vm.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR,
        NO_PROS_MSG: SettingsService.NO_PROS_FOR_ZIPCODE_ERROR
    };

    vm.availabilityLoaded = false;

    if (!projectId) {
        return state.go('projects.create.category');
    }

    (ProjectsService
        .getProjectByProjectId(projectId)
    ).then(function(projectObject) {
        project = projectObject;
        vm.init();
    }, function(error) {
        vm.messageLabel.CURRENT = error.message ? error.message : vm.messageLabel.DEFAULT;
    });

    //Will store a collection of selected firms
    vm.firmsSelected = [];

    //Will store the collection of firms
    vm.firmCollection = null;

    vm.init = function() {
        //Glue for data project
        $anchorScroll();
        vm.projectData = project;
        vm.description = project.taskDescription;
        if (vm.description) {
            var formattedDesc = String(vm.description).replace(/<[^>]+>/gm, '');
            if (formattedDesc.length > 20) {
                vm.descriptionShort = formattedDesc.substring(0, 20) + '...';
                vm.descExpandable = true;
            } else {
                vm.descriptionShort = formattedDesc;
            }
        }
        vm.filterData = {
            projectLocation: project.completeAddress
        };

        vm.showDraftProjectsCard = false;
        //Get firms for estimations
        ProjectsService
        .getProjectEstimatesFirms(projectId)
        .then(function(projectCollection) {
            vm.firmCollection = projectCollection;
            vm.availabilityLoaded = true;
            $anchorScroll();
            if (vm.feautreDraftProject) {
                if (projectCollection.items.length === 0) {
                    vm.showDraftProjectsCard = true;
                }
            }
        }, function(error) {
            if (error) {
                vm.messageLabel.CURRENT = error.message ? error.message : vm.messageLabel.DEFAULT;
            }
            vm.availabilityLoaded = true;
        });
    };

    //Toggles firm selection
    vm.changeFirm = function(provider) {
        var dateInfo = {
                date: $filter('date')(project.startDate, 'yyyy-MM-dd'),
                timeSlot: project.timeSlot
            };
        ProjectUpdateModalService.openModal(vm.projectData, dateInfo, function() {
            vm.firmsSelected = provider;
            //Not allow to select multiple providers, only one
            vm.askForProjectEstimations();
        });
    };

    //Send the firms selected and ask them for estimations
    vm.askForProjectEstimations = function() {
        var firmIds = vm.firmsSelected.id,
            startDate = project.startDate;
        ProjectsService.
        askForProjectEstimations(projectId, firmIds, startDate)
        .finally(function() {
            state.go('projects.request-received', {id: projectId});
        });
    };

    vm.openFilters = function() {
        var modalInstance = modal.open({
            animation: true,
            controller: 'ProjectsCreateEstimatesFiltersCtrl',
            controllerAs: 'ProjectEstimatesFilters',
            templateUrl: [
                'assets/templates/pages/projects/create/estimates-filter/',
                'index.html'
            ].join('')
        });
        modalInstance.result.then(function() {
            state.go('projects.create.details');
        });
    };

    vm.showGallery = function(openImageIndex) {
        modal.open({
            animation: true,
            windowClass: 'photo-detail',
            controller: 'DetailsGalleryCtrl as DetailsGalleryController',
            templateUrl: 'assets/templates/pages/account/myBookings/detail-gallery/index.html',
            resolve: {
                projectImages: function() {
                    return {
                        'images' : vm.projectData.images,
                        'openIndex': openImageIndex
                    };
                }
            }
        });
    };

    vm.proceedWithDraftProj = function() {
        var dateInfo = {
            date: $filter('date')(project.startDate, 'yyyy-MM-dd'),
            timeSlot: project.timeSlot
        };
        ProjectUpdateModalService.openModal(vm.projectData, dateInfo, function() {
            ProjectsService.waitForEstimates(projectId)
            .finally(function() {
                state.go('account.booking-detail', {id: projectId});
            });
        });
    };

    vm.waitForEstimates = function() {
        if (!LoginManagerService.getUser().isRegistered) {
            accountModalService.signInInit(function() {
                vm.proceedWithDraftProj();
            }, false, true);
        } else {
            vm.proceedWithDraftProj();
        }
    };

}

ProjectCreateEstimatesCtrl.$inject = ['$scope', '$log', '$state', '$uibModal', 'ProjectsService', 'SettingsService',
 '$anchorScroll', 'ProjectUpdateModalService', '$filter', 'ENVIRONMENT', 'LoginManagerService', 'accountModalService'];

(angular
    .module('RelayServicesApp.Projects')
).controller('ProjectsCreateEstimatesCtrl', ProjectCreateEstimatesCtrl);
