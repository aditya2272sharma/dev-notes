'use strict';

function ProjectCreateDetailsCtrl(
    $log, _, scope, state, Projects, Uploads, utils, SettingsService, $anchorScroll, $filter, moment
) {
    var vm = this;
    vm.maxImages = 5;

    vm.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR
    };

    vm.init = function() {
        //console.log(vm.details);
        $anchorScroll();
        if (_.isEmpty(scope.getProject())) {
            state.go('projects.create.category');
        }
        scope.setStep(2);
        vm.sizes = [
            {
                id: 1,
                title: 'Small',
                description: 'Est: 1 hr',
                value: 'small'
            },
            {
                id: 2,
                title: 'Medium',
                description: 'Est: 3 hrs',
                value: 'medium'
            },
            {
                id: 3,
                title: 'Large',
                description: 'Est: 4-6 hrs',
                value: 'large'
            }
        ];
        vm.images = [];
        //vm.statesList = Utils.getStatesList();
        vm.loadingFile = false;
        vm.unitno = '';
    };

    vm.setSize = function(size) {
        vm.size = size;
        vm.emptySize = false;
    };

    vm.submit = function() {
        var project = {};
        if (!vm.size) {
            return (vm.emptySize = true);
        }

        /*street = '844 N Roselle Rd';
        city = 'Hoffman Estates';
        stateUS = 'IL';
        zipcode = '60169';*/

        _.extend(project, {
            title: vm.title,
            street: scope.completeAddress.streetNumber + ' ' + scope.completeAddress.street,
            city: scope.completeAddress.city,
            state: scope.completeAddress.state,
            zipcode: scope.completeAddress.zipcode,
            unitno: vm.unitno,
            description: vm.description,
            size: vm.size.value,
            startdate: $filter('date')(vm.creationDate, 'yyyy-MM-dd')
        }, scope.getProject());
        if (vm.images.length) {
            project.images = vm.images;
        }

        Projects.create(project).then(function(project) {
            scope.cleanProject();
            state.go('projects.create.estimates', {id: project.id});
        }, function(error) {
            vm.messageLabel.CURRENT = error.message ? error.message : vm.messageLabel.DEFAULT;
            $anchorScroll();
        });
    };

    vm.getProjectImage = function(url) {
        return utils.getProjectImage(url);
    };

    vm.upload = function(file) {
        vm.loadingFile = true;
        Uploads.uploadFile(file).then(function(response) {
            vm.loadingFile = false;
            vm.images.push(response.data.url);
        }, function(error) {
            vm.messageLabel.CURRENT = error.message ? error.message : vm.messageLabel.DEFAULT;
        }, function(evt) {
            //vm.loadingFile = evt.loaded !== evt.total;
            $log.log(evt.loaded, '/', evt.total);
        });
    };

    /**
    * Validates more than 5 images are uploaded at the same time
    */
    vm.validateImage = function() {
        vm.disabledSelect = false;
        if (vm.images.length >= vm.maxImages - 1) {
            vm.disabledSelect = true;
        }
    };

    /**
     * Removes image from images array and remove DOM element
     * @param  {number} index Image index
     * @param  {Object} event click event
     */
    vm.deleteImage = function(index, event) {
        //@TODO: Check next line. Make a directive?
        event.target.parentElement.remove();
        vm.images.splice(index, 1);
        vm.disabledSelect = false;
    };

    vm.popup2 = {
        opened: false
    };

    vm.dateOptions = {
        //dateDisabled: disabled,
        // formatYear: 'yy',
        maxDate: new Date(2020, 5, 22),
        minDate: moment().add(1, 'days'),
        startingDay: 0,
        showWeeks: false
    };

    vm.open2 = function() {
        vm.popup2.opened = true;
    };

    vm.init();
}

ProjectCreateDetailsCtrl.$inject = [
    '$log', '_', '$scope', '$state', 'ProjectsService', 'UploadsService', 'UtilsService',
    'SettingsService', '$anchorScroll', '$filter', 'moment'
];

(angular
    .module('RelayServicesApp.Projects')
).controller('ProjectsCreateDetailsCtrl', ProjectCreateDetailsCtrl);
