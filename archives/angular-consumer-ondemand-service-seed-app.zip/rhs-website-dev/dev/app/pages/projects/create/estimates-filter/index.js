'use strict';

function ProjectsCreateEstimatesFiltersCtrl(modalInstance) {
    var vm = this;

    vm.close = function() {
        modalInstance.close();
    };
}

ProjectsCreateEstimatesFiltersCtrl.$inject = ['$uibModalInstance'];

(angular
    .module('RelayServicesApp.Projects')
).controller(
    'ProjectsCreateEstimatesFiltersCtrl', ProjectsCreateEstimatesFiltersCtrl
);
