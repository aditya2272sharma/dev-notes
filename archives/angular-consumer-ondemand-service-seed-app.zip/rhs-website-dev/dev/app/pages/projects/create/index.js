'use strict';
function ProjectsCreateCtrl(sessionStatus, $scope, $anchorScroll) {
    var vm = this;

    // if (!sessionStatus.isRegistered) {
    //     LoginManagerService.getLoginWindow();
    //     //Listen for authenticated user
    //     $rootScope.$on('user:authentication:change', function() {
    //         $scope.reloadRoute = function() {
    //             $state.reload();
    //         };
    //     });
    // }
    $scope.setStep = function(value) {
        vm.currentStep = value;
    };

    $scope.setProjectCategory = function(category) {
        $scope.project.category = category.title;
    };

    $scope.setProjectSubcategory = function(subcategory) {
        $scope.project.subcategory = subcategory.title;
        $scope.project.mcode = subcategory.id;
    };

    $scope.init = function() {
        $scope.project = {};
        $anchorScroll();
    };

    $scope.cleanProject = function() {
        $scope.project = {};
    };

    $scope.getProject = function() {
        return $scope.project || {};
    };

    $scope.init();
}

ProjectsCreateCtrl.$inject = ['sessionStatus', '$scope', '$anchorScroll'];

(angular
    .module('RelayServicesApp.Projects')
).controller('ProjectsCreateCtrl', ProjectsCreateCtrl);
