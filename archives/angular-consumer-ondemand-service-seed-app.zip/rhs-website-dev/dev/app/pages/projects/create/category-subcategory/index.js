'use strict';

function ProjectsCreateSubcategoryCtrl(modalInstance, category, subcategories) {
    var vm = this;

    vm.pick = function(subcategory) {
        modalInstance.close(subcategory);
    };

    vm.init = function() {
        vm.category = category;
        vm.subcategories = subcategories;
    };

    vm.init();
}

ProjectsCreateSubcategoryCtrl.$inject = [
    '$uibModalInstance', 'category', 'subcategories'
];

(angular
    .module('RelayServicesApp.Projects')
).controller(
    'ProjectsCreateSubcategoryCtrl', ProjectsCreateSubcategoryCtrl
);
