'use strict';

function SpecialProjectCtrl(
    $window, $log, _, scope, state, Projects, Uploads, utils,
    SettingsService, $uibModalInstance, ZipcodeInfoService, googleApiUtilsService, $scope,
    LoginManagerService, accountModalService, category, ProjectCategoriesService,  moment,
    $filter, availabilityService, locationService
) {
    var vm = this,
        parentCategory;
    vm.maxImages = 5;
    vm.category = '';

    vm.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR,
        NO_PROS_MSG: SettingsService.NO_PROS_FOR_ZIPCODE_ERROR
    };

    vm.timeframes = [
        {value: 'Tomorrow', days: 2, activeClass: 'active-0'},
        {value: 'Within A Week', days: 7, activeClass: 'active-1'},
        {value: 'In Two Weeks', days: 14, activeClass: 'active-2'},
        {value: 'In One month', days: 28, activeClass: 'active-3'},
        {value:'No Time Frame', days: 30, activeClass: 'active-4'}
    ];

    vm.selectedSubcategory = 0;

    /**
     * Reset form validations
     */
    vm.resetValidation = function() {
        vm.error = {
            general: false,
            emptyDescription: false,
            categoryNotSelected: false,
            invalidZipCode: false,
            emptyZipcode: false,
            emptyTimePeriod: false,
        };
    };

    /**
     * Setting up info/vars on load
     */
    vm.init = function() {
        vm.images = [];
        vm.loadingFile = false;
        vm.unitno = '';
        vm.timePeriod = '';
        vm.specialService = {
            zipcode : ZipcodeInfoService.getZipcode() || '',
            description: ''
        };
        vm.setGeolocation();
        vm.getCategories();
        if (!LoginManagerService.getUser().isRegistered) {
            LoginManagerService.anonymousLogin();
        }
        vm.resetValidation();
    };

    /**
     * Set selected category by id
     * @param {number} categoryId Category Id
     * @param {boolean} popular If it's a popularCategory, popular = true
     */
    vm.setCategory = function(categoryId, popular) {
        var currentCategories = popular ? vm.popularCategories : vm.categories ;
        vm.error.categoryNotSelected = false;
        if (currentCategories && categoryId !== '') {
            for (var count = 0; count < currentCategories.length; count++) {
                parentCategory = currentCategories[count];
                if (parentCategory && parentCategory.id === categoryId) {
                    vm.changeCategorySelection(parentCategory);
                    break;
                }
            }
        } else {
            $scope.selectedCategoryId = null;
        }
        if (popular) {
            vm.category = '';
        }
    };

    vm.changeCategorySelection = function(parentCategory) {
        $scope.selected = parentCategory.title;
        $scope.selectedCategoryId = parentCategory.id;
    };

    /**
     * Set selected category by id
     * @param {number} categoryId Get first subcategory Id from the selected category
     */
    vm.setTempSubcat = function(categoryId) {
        ProjectCategoriesService.subcategories(categoryId)
        .then(function(response) {
            // We will select the first subcat id for now
            vm.selectedSubcategory = response.subCategories[0].id;
        });
    };

    /**
     * Get categories
     */
    vm.getCategories = function() {
        // All categories = false; categories and popularcategories splited = true
        ProjectCategoriesService.categories(false, true)
        .then(function(response) {
            vm.popularCategories = response.popularcategories;
            vm.categories = response.categories;
        }, function(error) {
            vm.messageLabel.CURRENT = error && error.message ? error.message : vm.messageLabel.DEFAULT;
        });
    };

    /**
     * Get current Zip code
     */
    vm.setGeolocation = function() {
        var geolocation = $window.navigator && $window.navigator.geolocation;

        if (geolocation) {
            $window.navigator.geolocation
            .getCurrentPosition(function(position) {
              locationService
              .getAddressByLatLong(position.coords.latitude, position.coords.longitude)
              .then(function(response) {
                  _.assign(geolocation, response);
                  vm.completeAddress = response;
                  if (!vm.specialService.zipcode) {
                      vm.specialService.zipcode = vm.completeAddress.zipCode;
                  }
              }, function(error) {
                  vm.messageLabel.CURRENT = error && error.message ? error.message : vm.messageLabel.DEFAULT;
              });
            });
        }
    };

    vm.getProjectImage = function(url) {
        return utils.getProjectImage(url);
    };

    /**
     * Upload images component
     * @param {string} file
     */
    vm.upload = function(file) {
        if (file) {
            vm.loadingFile = true;
            Uploads.uploadFile(file).then(function(response) {
                vm.loadingFile = false;
                vm.images.push(response.data.url);
            }, function(error) {
                vm.loadingFile = false;
                vm.messageLabel.CURRENT = error.message ? error.message : vm.messageLabel.DEFAULT;
            }, function(evt) {
                //vm.loadingFile = evt.loaded !== evt.total;
                $log.log(evt.loaded, '/', evt.total);
            });
        }
    };

    /**
    * Validates more than 5 images are uploaded at the same time
    */
    vm.validateImage = function() {
        vm.disabledSelect = false;
        if (vm.images.length >= vm.maxImages - 1) {
            vm.disabledSelect = true;
        }
    };

    /**
     * Removes image from images array and remove DOM element
     * @param  {number} index Image index
     * @param  {Object} event click event
     */
    vm.deleteImage = function(index, event) {
        event.target.parentElement.remove();
        vm.images.splice(index, 1);
        vm.disabledSelect = false;
    };

    vm.close = function() {
        $uibModalInstance.dismiss();
    };

    vm.sentProjectInfo = function() {
        vm.resetValidation();
        if ($scope.selectedCategoryId) {
            ProjectCategoriesService.subcategories($scope.selectedCategoryId)
            .then(function(response) {
                // We will select the first subcat id for now
                vm.selectedSubcategory = response.subCategories[0].id;

                if (vm.selectedSubcategory === 0) {
                    vm.error.general = true;
                    vm.error.categoryNotSelected = true;
                }
                if (vm.specialService.description === '') {
                    vm.error.general = true;
                    vm.error.emptyDescription = true;
                }
                if (vm.specialService.zipcode === '' || vm.specialService.zipcode.length < 5) {
                    vm.error.general = true;
                    vm.error.emptyZipcode = true;
                }
                if (vm.timePeriod === '') {
                    vm.error.general = true;
                    vm.error.emptyTimePeriod = true;
                }
                if (vm.error.general === false) {
                    if (LoginManagerService.getUser().isRegistered) {
                        vm.createSpecialProject();
                    } else {
                        accountModalService.signInInit(function() {
                            vm.createSpecialProject();
                        }, false, false, true);
                    }
                }
            });
        } else {
            vm.error.general = true;
            vm.error.categoryNotSelected = true;
        }
    };

    /**
     * Create custom project
     */
    vm.createSpecialProject = function() {
        if (vm.ProjectDetailsForm.$valid) {
            if (vm.specialService.quickAssign) {
                state.go('projects.request-received', {id: 0, isQuickassigned: true});
                vm.close();
            } else {
                var project = {
                    /*subcategoryid: vm.selectedSubcategory,*/
                    title: $scope.selected,
                    taskTitle: $scope.selected,
                    //addressline1: '844 N Roselle Rd',
                    zipcode: vm.specialService.zipcode,
                    images: vm.images,
                    description: vm.specialService.description,
                    startdate: vm.timePeriod,
                    timeslot: '8:00 AM - 12:00 PM',
                    catalogid: vm.selectedSubcategory
                };

                Projects.create(project).then(function(response) {
                    availabilityService.getAvailability($scope.selectedCategoryId, vm.specialService.zipcode,
                    response.serviceType)
                    .then(function(responsedata) {
                        if (responsedata.data.length > 0) {
                            ZipcodeInfoService
                            .setZipcode(response.location.zipCode, {
                                checkServiceability: false
                            });
                            state.go('projects.estimates', {id: response.id});
                            vm.close();
                        } else {
                            vm.error.invalidZipCode = true;
                            vm.noAddZipcodeMsg = vm.messageLabel.NO_PROS_MSG;
                        }
                    }, function(error) {
                        vm.locationError = true;
                        vm.messageLabel.CURRENT = error && error.message ? error.message : vm.messageLabel.DEFAULT;
                    });

                }, function(error) {
                    if (error && error.message) {
                        if (error.message.includes('Address not found for zipcode')) {
                            vm.error.invalidZipCode = true;
                            vm.noAddZipcodeMsg = error.message;
                        } else {
                            vm.messageLabel.CURRENT = error.message;
                        }
                    } else {
                        vm.messageLabel.CURRENT = vm.messageLabel.DEFAULT;
                    }
                });
            }
        }
    };

    vm.setTimePeriod = function(timeframeSelected) {
        var dateCalculated = moment().add(timeframeSelected.days, 'days');
        dateCalculated = dateCalculated.weekday() && dateCalculated.weekday() <= 5 ?
                    dateCalculated : dateCalculated.add(8 - (dateCalculated.weekday() || 7), 'days');
        vm.timePeriod = $filter('date')(new Date(dateCalculated), 'yyyy-MM-dd');
        vm.timeValueSelected = timeframeSelected.value;
        vm.error.emptyTimePeriod = false;
    };

    vm.init();
}

SpecialProjectCtrl.$inject = [
    '$window', '$log', '_', '$scope', '$state', 'ProjectsService', 'UploadsService', 'UtilsService',
    'SettingsService', '$uibModalInstance', 'ZipcodeInfoService', 'googleApiUtilsService', '$scope',
    'LoginManagerService', 'accountModalService', 'category', 'ProjectCategoriesService', 'moment',
    '$filter', 'availabilityService', 'locationService'
];

(angular
    .module('RelayServicesApp.Projects')
).controller('SpecialProjectCtrl', SpecialProjectCtrl);
