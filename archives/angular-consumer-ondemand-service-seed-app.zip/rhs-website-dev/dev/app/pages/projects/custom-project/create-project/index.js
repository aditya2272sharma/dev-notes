'use strict';

function CustomProjectCreateProjectCtrl(Details, SettingsService, $uibModalInstance, CustomProjectService,
    moment, $filter, Uploads, LoginManagerService, $log, $scope,
    accountModalService, ZipcodeInfoService, availabilityService, Projects, state) {
    var vm = this;
    vm.maxImages = 5;
    vm.categoryDetail = Details.categoryDetail;
    vm.selectedSubCategoryId = Details.subCategoryId;
    vm.selectedSubCategoryTitle = Details.subCategoryTitle;
    vm.selectedSubSubCategoryId = Details.subSubCategoryId;
    vm.selectedSubSubCategoryTitle = Details.subSubCategoryTitle;
    vm.selectedcatalogid = Details.catalogid;
    vm.skills = Details.skills;
    vm.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR
    };

    vm.timeframes = [
        {value: 'Tomorrow', days: 2, activeClass: 'active-0', key: 'TOMORROW'},
        {value: 'Within A Week', days: 7, activeClass: 'active-1', key: 'ONE_WEEK'},
        {value: 'In Two Weeks', days: 14, activeClass: 'active-2', key: 'TWO_WEEKS'},
        {value: 'In A Month', days: 28, activeClass: 'active-3', key: 'ONE_MONTH'},
        {value:'No Time Frame', days: 30, activeClass: 'active-4', key: 'NO_TIME_FRAME'}
    ];

    vm.init = function() {
        vm.categoryName = vm.categoryDetail.categoryName;
        vm.loadingFile = false;
        vm.images = [];
        vm.timePeriod = '';
        vm.setDefaultSkill();
        if (!LoginManagerService.getUser().isRegistered) {
            LoginManagerService.anonymousLogin();
        }
        vm.specialService = {
            description: ''
        };
        vm.resetValidation();
    };

    vm.setDefaultSkill = function() {
        var i = 0;
        while (i < vm.skills.length) {
            if (vm.skills[i].skill === 'Repair') {
                vm.subCategorySkill = vm.skills[i];
                break;
            }
            i++;
        }
        if (i >= vm.skills.length) {
            vm.subCategorySkill = vm.skills[0];
        }
    };

    vm.resetValidation = function() {
        vm.error = {
            general: false,
            emptyDescription: false,
            emptyTimePeriod: false
        };
    };

    vm.deleteImage = function(index, event) {
        event.target.parentElement.remove();
        vm.images.splice(index, 1);
        vm.disabledSelect = false;
    };

    vm.upload = function(file) {
        if (file) {
            vm.loadingFile = true;
            Uploads.uploadFile(file).then(function(response) {
                vm.loadingFile = false;
                vm.images.push(response.data.url);
            }, function(error) {
                vm.loadingFile = false;
                vm.messageLabel.CURRENT = error.message ? error.message : vm.messageLabel.DEFAULT;
            }, function(evt) {
                $log.log(evt.loaded, '/', evt.total);
            });
        }
    };

    vm.validateImage = function() {
        vm.disabledSelect = false;
        if (vm.images.length >= vm.maxImages - 1) {
            vm.disabledSelect = true;
        }
    };

    vm.sentProjectInfo = function() {
        vm.resetValidation();
        vm.selectedSubcategory = vm.selectedSubCategoryId;
        if (vm.specialService.description === '') {
            vm.error.general = true;
            vm.error.emptyDescription = true;
        }
        if (vm.timePeriod === '') {
            vm.error.general = true;
            vm.error.emptyTimePeriod = true;
        }
        if (vm.error.general === false) {
            if (LoginManagerService.getUser().isRegistered) {
                vm.createCustomProject();
            } else {
                accountModalService.signInInit(function() {
                    vm.createCustomProject();
                }, false, false, true);
            }
        }
    };

    vm.createCustomProject = function() {
        if (vm.CustomProjectForm.$valid) {
            if (vm.specialService.quickAssign) {
                state.go('projects.request-received', {id: 0, isQuickassigned: true});
                vm.close();
            } else {
                var project = {
                    title: vm.categoryDetail.categoryName,
                    taskTitle: vm.categoryDetail.categoryName,
                    zipcode: vm.categoryDetail.address.zipCode,
                    images: vm.images,
                    description: vm.specialService.description,
                    timechoice: vm.timePeriod,
                    timeslot: '8:00 AM - 12:00 PM',
                    servicetype: SettingsService.ServiceTypes.NON_STANDARD,
                    /*subcategoryid: vm.selectedSubSubCategoryId,*/
                    catalogid: vm.subCategorySkill.catalogId
                };

                Projects.createCustomProject(project).then(function(response) {
                    /*availabilityService.getAvailability(vm.selectedSubCategoryId, vm.categoryDetail.address.zipCode,
                    response.serviceType)
                    .then(function(responsedata) {
                        if (responsedata.data.length > 0) {
                            ZipcodeInfoService.setZipcode(vm.categoryDetail.address.zipCode);
                            state.go('projects.estimates', {id: response.id});
                            vm.close();
                        } else {
                            vm.error.invalidZipCode = true;
                            vm.noAddZipcodeMsg = vm.messageLabel.NO_PROS_MSG;
                        }
                    }, function(error) {
                        vm.locationError = true;
                        vm.messageLabel.CURRENT = error && error.message ? error.message : vm.messageLabel.DEFAULT;
                    });*/
                    ZipcodeInfoService.setZipcode(vm.categoryDetail.address.zipCode);
                    state.go('projects.estimates', {id: response.id});
                    vm.close();
                }, function(error) {
                    if (error && error.message) {
                        if (error.message.includes('Address not found for zipcode')) {
                            vm.error.invalidZipCode = true;
                            vm.noAddZipcodeMsg = error.message;
                        } else {
                            vm.messageLabel.CURRENT = error.message;
                        }
                    } else {
                        vm.messageLabel.CURRENT = vm.messageLabel.DEFAULT;
                    }
                });
            }
        }
    };

    vm.close = function() {
        $uibModalInstance.dismiss();
    };

    vm.backToCategoryModal = function() {
        $uibModalInstance.dismiss();
        var Details = {
            categoryDetail:vm.categoryDetail,
            subCategoryId:vm.selectedSubCategoryId,
            subCategoryTitle:vm.selectedSubCategoryTitle,
            subSubCategoryId:vm.selectedSubSubCategoryId,
            subSubCategoryTitle:vm.selectedSubSubCategoryTitle,
            catalogid:vm.selectedcatalogid,
            skills: vm.skills
        };
        CustomProjectService.openSubCategoryModal(Details);
    };

    vm.MoveToSubSubCategory = function() {
    };

    vm.setTimePeriod = function(timeframeSelected) {
        vm.timePeriod = timeframeSelected.key;
        vm.timeValueSelected = timeframeSelected.value;
        vm.error.emptyTimePeriod = false;
    };

    vm.checkButtonStatus = function() {
        vm.enableProceedBtn = true;
        if (vm.specialService.description &&  vm.subCategorySkill.catalogId && vm.timePeriod) {
            vm.enableProceedBtn = false;
        }
        return (vm.enableProceedBtn);
    };

    vm.init();
}

CustomProjectCreateProjectCtrl.$inject = ['Details', 'SettingsService', '$uibModalInstance', 'CustomProjectService',
'moment', '$filter', 'UploadsService', 'LoginManagerService', '$log', '$scope',
'accountModalService', 'ZipcodeInfoService', 'availabilityService', 'ProjectsService', '$state'];

(angular
    .module('RelayServicesApp.Projects')
).controller('CustomProjectCreateProjectCtrl', CustomProjectCreateProjectCtrl);
