'use strict';

function CustomProjectCategoryCtrl($rootScope, SettingsService, $uibModalInstance, $scope, ProjectCategoriesService,
    LoginManagerService, CustomProjectService, Details, state, NewProjectCategoriesService) {
    var vm = this,
    parentCategory;
    vm.maxImages = 5;
    vm.category = '';
    vm.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR
    };
    vm.init = function() {

        if (Details) {
            vm.categoryDetail = Details.categoryDetail;
        }
        vm.images = [];
        vm.loadingFile = false;
        vm.unitno = '';
        vm.timePeriod = '';
        vm.getCategories();
        vm.resetValidation();
        if (vm.categoryDetail) {
            vm.selectedAddress = vm.categoryDetail.address.zipCode;
            $scope.selectedCategoryId = vm.categoryDetail.categoryId;
            $scope.selected = vm.categoryDetail.categoryName;
            vm.address = vm.categoryDetail.address;
            vm.popularCategoryType = vm.categoryDetail.category;
            vm.otherCategoryType = vm.categoryDetail.others;
        }
    };

    vm.resetValidation = function() {
        vm.error = {
            categoryNotSelected: false
        };
    };
    vm.isAddressValid = function(isAddressValid, address) {
        if (isAddressValid) {
            vm.isValidAddress = true;
            vm.address = address;
        } else {
            vm.isValidAddress = false;
            vm.address = '';
        }
    };

    vm.continueCategaory = function() {
        $uibModalInstance.dismiss();
        var categoryDetail = {
            categoryId:$scope.selectedCategoryId,
            categoryName: $scope.selected,
            address: vm.address,
            category: vm.popularCategoryType,
            others: vm.otherCategoryType
        };
        var Details = {
            categoryDetail:categoryDetail,
            subCategoryId:'',
            subCategoryTitle:''
        };
        CustomProjectService.openCategoryModal(Details);
    };

    vm.setCategory = function(categoryId, popular) {
        var currentCategories = popular ? vm.popularCategories : vm.categories ;
        vm.error.categoryNotSelected = false;
        if (currentCategories && categoryId !== '') {
            for (var count = 0; count < currentCategories.length; count++) {
                parentCategory = currentCategories[count];
                if (parentCategory && parentCategory.id === categoryId) {
                    vm.changeCategorySelection(parentCategory);
                    break;
                }
            }
        } else {
            $scope.selectedCategoryId = null;
        }
        if (popular) {
            vm.category = '';
            vm.popularCategoryType = true;
            vm.otherCategoryType = false;
        } else {
            vm.popularCategoryType = false;
            vm.otherCategoryType = true;
        }
    };

    vm.changeCategorySelection = function(parentCategory) {
        $scope.selected = parentCategory.title;
        $scope.selectedCategoryId = parentCategory.id;
    };

    /**
     * Get categories
     */
    vm.getCategories = function() {
        // All categories = false; categories and popularcategories splited = true
        NewProjectCategoriesService.mainCategories()
        .then(function(response) {
            vm.popularCategories = response.popularMaincategories;
            vm.categories = response.mainCategories;
            if (vm.categoryDetail) {
                if (vm.otherCategoryType) {
                    vm.category = vm.categoryDetail.categoryId;
                }
            }
        }, function(error) {
            vm.messageLabel.CURRENT = error && error.message ? error.message : vm.messageLabel.DEFAULT;
        });
    };

    vm.checkCategoryStatus = function() {
        vm.continueBtnStatus = true;
        if (vm.isValidAddress && $scope.selectedCategoryId) {
            vm.continueBtnStatus = false;
        }
        return (vm.continueBtnStatus);
    };

    vm.close = function() {
        $uibModalInstance.dismiss();
    };

    vm.checkCategoryType = function(categoryType) {
        if (categoryType === 'Other') {
            vm.otherCategoryType = true;
            $scope.selectedCategoryId = null;
            $scope.selected = '';
        }
    };
    vm.init();
}

CustomProjectCategoryCtrl.$inject = [
    '$rootScope', 'SettingsService', '$uibModalInstance', '$scope', 'ProjectCategoriesService',
    'LoginManagerService', 'CustomProjectService', 'Details', '$state',
    'NewProjectCategoriesService'];

(angular
    .module('RelayServicesApp.Projects')
).controller('CustomProjectCategoryCtrl', CustomProjectCategoryCtrl);
