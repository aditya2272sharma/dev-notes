'use strict';

function CustomProjectSubSubCategoryCtrl($uibModalInstance, SettingsService, NewProjectCategoriesService,
    Details, CustomProjectService) {
    var vm = this;
    vm.categoryDetail = Details.categoryDetail;
    vm.selectedSubCategoryId = Details.subCategoryId;
    vm.selectedSubCategoryTitle = Details.subCategoryTitle;
    vm.skills = Details.skills;
    vm.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR
    };

    vm.init = function() {
        vm.categoryName = vm.categoryDetail.categoryName;
        //need to implement new API for sub category
        (NewProjectCategoriesService.subCategorieslist(vm.categoryDetail.categoryId,
            vm.selectedSubCategoryId)).then(function(response) {
            vm.SubCategoryForm.subCategories = response.subcategories;
            vm.tasktReady = true;
        }, function(error) {
            vm.messageLabel.CURRENT = error && error.message ? error.message : vm.messageLabel.DEFAULT;
        });
        //need to implement new API for sub category
        if (Details) {
            vm.selectedSubSubCategoryId = Details.subSubCategoryId;
            vm.selectedSubSubCategoryTitle = Details.subSubCategoryTitle;
        }
    };

    vm.close = function() {
        $uibModalInstance.dismiss();
    };

    vm.backToCategoryModal = function() {
        $uibModalInstance.dismiss();
        var Details = {
            categoryDetail:vm.categoryDetail,
            subCategoryId:vm.selectedSubCategoryId,
            subCategoryTitle:vm.selectedSubCategoryTitle,
            subSubCategoryId:vm.selectedSubSubCategoryId,
            subSubCategoryTitle:vm.selectedSubSubCategoryTitle
        };
        CustomProjectService.openCategoryModal(Details);
    };

    vm.MoveToSubSubCategory = function() {
        $uibModalInstance.dismiss();
        var Details = {
            categoryDetail:vm.categoryDetail,
            subCategoryId:vm.selectedSubCategoryId,
            subCategoryTitle:vm.selectedSubCategoryTitle,
            subSubCategoryId:vm.selectedSubSubCategoryId,
            subSubCategoryTitle:vm.selectedSubSubCategoryTitle,
            skills:vm.skills
        };
        CustomProjectService.openCreateProjectModal(Details);
    };

    vm.setSubSubCategory = function(subSubCategory) {
        vm.showSelected = false;
        if (subSubCategory.id) {
            vm.showSelected = true;
            vm.selectedSubSubCategoryId = subSubCategory.id;
            vm.selectedSubSubCategoryTitle = subSubCategory.title;
            vm.selectedcatalogid = subSubCategory.catalogId;
            vm.skills = subSubCategory.skills;
        }
    };

    vm.init();
}

CustomProjectSubSubCategoryCtrl.$inject = ['$uibModalInstance', 'SettingsService', 'NewProjectCategoriesService',
'Details', 'CustomProjectService'];

(angular
    .module('RelayServicesApp.Projects')
).controller('CustomProjectSubSubCategoryCtrl', CustomProjectSubSubCategoryCtrl);
