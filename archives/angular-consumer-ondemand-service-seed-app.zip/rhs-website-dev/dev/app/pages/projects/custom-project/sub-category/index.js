'use strict';

function CustomProjectSubCategoryCtrl($uibModalInstance, SettingsService, NewProjectCategoriesService,
    Details, CustomProjectService) {
    var vm = this;
    vm.categoryDetail = Details.categoryDetail;
    vm.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR
    };

    vm.init = function() {
        vm.categoryName = vm.categoryDetail.categoryName;
        (NewProjectCategoriesService.categorieslist(vm.categoryDetail.categoryId)).then(function(response) {
            vm.SubCategoryForm.subCategories = response.categories;
            vm.tasktReady = true;
        }, function(error) {
            vm.messageLabel.CURRENT = error && error.message ? error.message : vm.messageLabel.DEFAULT;
        });
        if (Details) {
            vm.selectedSubCategoryId = Details.subCategoryId;
            vm.selectedSubCategoryTitle = Details.subCategoryTitle;
        }
    };

    vm.close = function() {
        $uibModalInstance.dismiss();
    };

    vm.backToCategoryModal = function() {
        $uibModalInstance.dismiss();
        var Details = {
            categoryDetail:vm.categoryDetail,
            subCategoryId:vm.selectedSubCategoryId,
            subCategoryTitle:vm.selectedSubCategoryTitle
        };
        CustomProjectService.openModal(Details);
    };

    vm.MoveToSubSubCategory = function() {
        $uibModalInstance.dismiss();
        var Details = {
            categoryDetail:vm.categoryDetail,
            subCategoryId:vm.selectedSubCategoryId,
            subCategoryTitle:vm.selectedSubCategoryTitle
        };
        CustomProjectService.openSubCategoryModal(Details);
    };

    vm.setSubcategory = function(subcategoryId, subCategoryTitle) {
        vm.showSelected = false;
        if (subcategoryId) {
            vm.showSelected = true;
            vm.selectedSubCategoryId = subcategoryId;
            vm.selectedSubCategoryTitle = subCategoryTitle;
        }
    };
    vm.init();
}

CustomProjectSubCategoryCtrl.$inject = ['$uibModalInstance', 'SettingsService', 'NewProjectCategoriesService',
'Details', 'CustomProjectService'];

(angular
    .module('RelayServicesApp.Projects')
).controller('CustomProjectSubCategoryCtrl', CustomProjectSubCategoryCtrl);
