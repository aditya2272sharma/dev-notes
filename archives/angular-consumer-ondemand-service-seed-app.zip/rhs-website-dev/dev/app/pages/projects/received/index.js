'use strict';

function ProjectReceivedEstimatesCtrl(scope, $log, state, modal, ProjectsService, $anchorScroll, $state, $sce,
$rootScope, Notifications) {
    var vm = this,
        projectId = state.params.id,
        project,
        firms,
        estimates;

    vm.descriptionExpanded = false;
    vm.isQuickassigned = state.params.isQuickassigned;

    if (!projectId) {
        // to handle refresh and back navigation
        $state.go('home.new');
    }

    $anchorScroll();

    ProjectsService.
    getProjectEstimatesByProjectId(projectId)
    .then(function(data) {
        Notifications.getNotificationsSummary()
        .then(function(response) {
            vm.notificationsCount = response.count;
            vm.unreadNotificationsCount = response.unreadCount;
            $rootScope.unreadNotificationsNumber = response.unreadCount;
        })
        .finally(function() {
            project = data.project;
            firms = data.firms;
            estimates = data.estimates;
            if (project.status === 'ESTIMATE_RECEIVED' || project.status !== 'WAITING') {
                $state.go('account.booking-detail', {
                    id: projectId
                });
            } else {
                vm.init();
            }
        });
    }, function(errorResponse) {
        //@TODO: Handle errors
        vm.isQuickassigned = true;
        $log.debug(errorResponse);
    });

    vm.init = function() {
        //Glue for data project
        vm.project = project;
        vm.firmCollection = firms;
        vm.estimateCollection = estimates;
        vm.description = project.taskDescription;
        if (vm.description) {
            var formattedDesc = String(vm.description).replace(/<[^>]+>/gm, '');
            if (formattedDesc.length > 20) {
                vm.descriptionShort = formattedDesc.substring(0, 20) + '...';
                vm.descExpandable = true;
            } else {
                vm.descriptionShort = formattedDesc;
            }
        }
        vm.taskDescription = $sce.trustAsHtml(project.taskDescription);
    };
}

ProjectReceivedEstimatesCtrl.$inject = ['$scope', '$log', '$state', '$uibModal', 'ProjectsService', '$anchorScroll',
 '$state', '$sce', '$rootScope', 'Notifications'];

(angular
    .module('RelayServicesApp.Projects')
).controller('ProjectReceivedEstimatesCtrl', ProjectReceivedEstimatesCtrl);
