'use strict';

function Configure($stateProvider) {
    //var AuthorizationCheck = require('../../services/authorization/check.js');

    $stateProvider.state('projects', {
        url: '/projects',
        abstract: true,
        templateUrl:'assets/templates/pages/partials/abstract.html',
        resolve : {
            'sessionStatus': require('../../services/session-status-resolve')
        }
    }).state('projects.detail', {
        url: '/detail/:id',
        templateUrl:'assets/templates/pages/projects/detail/index.html',
        controller: 'ProjectsDeatilCtrl as ProjectsDeatilCtrl'
    }).state('projects.estimates-summary', {
        url: '/estimates-summary',
        templateUrl:'assets/templates/pages/projects/estimates-summary.html'
    }).state('projects.request-received', {
        url: '/request-received/:id',
        templateUrl: 'assets/templates/pages/projects/received/index.html',
        controller: 'ProjectReceivedEstimatesCtrl as ProjectEstimatesReceived',
        params : {
            isQuickassigned : false
        },
    }).state('projects.estimates', {
        url: '/estimates/:id',
        templateUrl: (
            'assets/templates/pages/projects/create/estimates/index.html'
        ),
        controller: 'ProjectsCreateEstimatesCtrl as ProjectEstimates'
    }).state('projects.invoice', {
        url: '/invoice/:id',
        templateUrl: (
            'assets/templates/pages/projects/invoice/index.html'
        ),
        controller: 'ProjectInvoiceCtrl as ProjectInvoiceCtrl'
    });

    $stateProvider.state('projects.create', {
        url: '/create',
        templateUrl:'assets/templates/pages/projects/create/index.html',
        controller: 'ProjectsCreateCtrl as ProjectsCreateCtrl'
    }).state('projects.create.category', {
        url: '/category',
        templateUrl: (
            'assets/templates/pages/projects/create/category/index.html'
        ),
        controller: 'ProjectsCreateCategoryCtrl as ProjectCategory'
    }).state('projects.create.details', {
        url: '/details',
        templateUrl: (
            'assets/templates/pages/projects/create/details/index.html'
        ),
        controller: 'ProjectsCreateDetailsCtrl as ProjectDetails',
        requiresLogin: true
    });
}

Configure.$inject = ['$stateProvider'];

function Run() {

}

(angular
    .module('RelayServicesApp.Projects', [])
    .config(Configure)
).run(Run);
