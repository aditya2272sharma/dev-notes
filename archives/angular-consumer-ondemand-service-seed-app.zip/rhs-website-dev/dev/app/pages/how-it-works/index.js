'use strict';

function Configure($stateProvider) {

    $stateProvider.state('how-it-works', {
        url: '/how-it-works',
        controller: 'HowItWorksCtrl',
        controllerAs: 'HowItWorksCtrl',
        templateUrl: 'assets/templates/pages/how-it-works/index.html',
        resolve : {
            'sessionStatus': require('../../services/session-status-resolve')
        },
        params: {
            hasHero: true
        }
    });

}

Configure.$inject = ['$stateProvider'];

function Run() {
}

(angular
    .module('RelayServicesApp.HowItWorks', [])
    .config(Configure)
).run(Run);
