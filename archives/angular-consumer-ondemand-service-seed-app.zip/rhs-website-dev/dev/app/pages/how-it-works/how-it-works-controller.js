'use strict';

function HowItWorksCtrl($uibModal, $anchorScroll, ENVIRONMENT, ZipcodeInfoService, $rootScope) {
    var vm = this;

    vm.openAppsModal = function() {
        var modalInstance = $uibModal.open({
            animation: true,
            size: 'md',
            controller: 'ComingAppsModal',
            controllerAs: 'ComingAppsModalCtrl',
            templateUrl: 'assets/templates/components/coming-apps-modal/index.html'
        });

        modalInstance.result.then();
    };

    vm.init = function() {
        $anchorScroll();
        vm.hideCustom = false; // Flag for hiding custom project link
        updateScreenUIBasedOnUserZipCode();
    };

    vm.customProject = ENVIRONMENT.features.customProject;

    vm.init();

    // handle notification when zipcode serviceability updated notification
    $rootScope.$on('zipcode-service-updated-notification', function (event, data) {
        updateScreenUIBasedOnUserZipCode(); // update screen UI constant based on user zipcode
    });

    /**
     * Update home screen UI based on user zipcode.
     */
    function updateScreenUIBasedOnUserZipCode()
    {
        // disabling the update for SSv4
        // this will save us a location API call
        return;

        var browserZipCode = ZipcodeInfoService.getZipcode();
        if(browserZipCode && (browserZipCode.length === 5))
        {
            vm.hideCustom = ZipcodeInfoService.getServiceAvailabilityForZipcode();
        }
    }
}

HowItWorksCtrl.$inject = ['$uibModal', '$anchorScroll', 'ENVIRONMENT', 'ZipcodeInfoService', '$rootScope'];

(angular
	.module('RelayServicesApp.HowItWorks')
).controller('HowItWorksCtrl', HowItWorksCtrl);
