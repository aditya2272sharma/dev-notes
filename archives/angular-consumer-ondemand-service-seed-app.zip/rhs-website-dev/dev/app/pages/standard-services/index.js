'use strict';

function Configure($stateProvider) {

    $stateProvider.state('services', {
        url: '',
        abstract: true,
        templateUrl: 'assets/templates/pages/partials/abstract.html',
        resolve : {
            'sessionStatus': require('../../services/session-status-resolve')
        }
    }).state('services.categories', {
        url: '/services',
        templateUrl: 'assets/templates/pages/standard-services/popular-services/index.html',
        controller: 'ServicesCategoriesCtrl',
        controllerAs: 'ServicesCategoriesCtrl'
    }).state('services.category', {
        url: '/services/:category',
        templateUrl: 'assets/templates/pages/standard-services/category/index.html',
        controller: 'ServicesSubcategoryCtrl',
        controllerAs: 'ServicesSubcategoryCtrl',
        params:{
            hasHero: true,
            category: null,
            mainCategoryId: ''
        }
    }).state('services.packages', {
        url: '/services/packages/:id',
        templateUrl: 'assets/templates/pages/standard-services/service-packages/index.html',
        controller: 'ServicesPackagesCtrl',
        controllerAs: 'ServicesPackagesCtrl',
        params:{
            category: null
        }
    }).state('services.results', {
        url: '/services/:category/:subcategory/:categoryId?pId',
        params: {
            isSpecialProject: false,
            zipcode:''
        },
        templateUrl: 'assets/templates/pages/standard-services/results/index.html',
        controller: 'ServicesResultsCtrl',
        controllerAs: 'ServicesResultsCtrl'
        //requiresLogin: true
    });
}

Configure.$inject = ['$stateProvider'];

function Run() {
}

(angular
    .module('RelayServicesApp.StandardServices', [])
    .config(Configure)
).run(Run);
