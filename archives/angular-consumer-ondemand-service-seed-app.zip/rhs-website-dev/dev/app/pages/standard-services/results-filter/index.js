'use strict';

function StdServicesFilterCtrl(modalInstance) {
    var vm = this;

    vm.close = function() {
        modalInstance.close();
    };
}

StdServicesFilterCtrl.$inject = ['$uibModalInstance'];

(angular
    .module('RelayServicesApp.StandardServices')
).controller(
    'StdServicesFilterCtrl', StdServicesFilterCtrl
);
