'use strict';

function ServicesPackagesCtrl($state, modal, SettingsService,
    ProjectCategoriesService, $scope, $rootScope,
    LoginManagerService, sessionStatus, $window,
    ProjectsService, accountModalService, _, $anchorScroll) {
    var vm = this,
        project = {};
    $scope.projectId = $state.params.id;

    vm.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR
    };

    vm.init = function() {
        $anchorScroll();
        ProjectCategoriesService.subcategories($scope.projectId)
        .then(function(response) {
            vm.packages = response;
        }, function(error) {
            vm.messageLabel.CURRENT = error && error.message ? error.message : $scope.messageLabel.DEFAULT;
        });
    };

    vm.taskLocation = function(subcategory, title) {
        if (!LoginManagerService.getUser().isRegistered) {
            accountModalService.signInInit(false, function() {
                vm.selectLocation(subcategory, title);
            });
        } else {
            vm.selectLocation(subcategory, title);
        }
    };

    vm.selectLocation = function(subcategory, title) {
        var modalInstance = modal.open({
            animation: true,
            size: 'lg',
            controller: 'taskLocationCtrl',
            controllerAs: 'taskLocationCtrl',
            resolve: {
                projectTitle: function() {
                    return vm.packages.category.title;
                }
            },
            templateUrl: [
                'assets/templates/components/task-location/',
                'index.html'
            ].join('')
        });
        ProjectCategoriesService.setTaskDescription(_.find(vm.packages.subCategories, {'id' : subcategory.id}).description);
        modalInstance.result.then(function(locationResponse) {
            vm.createStandardProject(subcategory, title, locationResponse);
        });
    };

    /**
    * Create a project
    */
    vm.createStandardProject = function(subcategory, title, locationResponse) {
        project = {
            startdate: '2016-11-01',
            subcategory: subcategory.title,
            /*subcategoryid: subcategory.id,*/
            title: subcategory.title,
            street: _.trim([
                        locationResponse.streetNumber,
                        locationResponse.street
                    ].join(' ')) || locationResponse.address1,
            city: locationResponse.city,
            state: locationResponse.state,
            zipcode: locationResponse.zipcode,
            unitno: '',
            description: subcategory.title,
            size: 'small',
            servicetype: 'STANDARD',
            catalogid: subcategory.id
        };

        ProjectsService.create(project).then(function(response) {
            $state.go('services.results', {id: response.id});
        }, function(error) {
            vm.messageLabel.CURRENT = error && error.message ? error.message : vm.messageLabel.DEFAULT;
            //$anchorScroll();
        });
    };
    /**
    ******************Init****************
    */
    vm.init();

}
ServicesPackagesCtrl.$inject = [
    '$state', '$uibModal', 'SettingsService',
    'ProjectCategoriesService', '$scope', '$rootScope',
    'LoginManagerService', 'sessionStatus', '$window',
    'ProjectsService', 'accountModalService', '_', '$anchorScroll'
];

(angular
    .module('RelayServicesApp.StandardServices')
).controller('ServicesPackagesCtrl', ServicesPackagesCtrl);
