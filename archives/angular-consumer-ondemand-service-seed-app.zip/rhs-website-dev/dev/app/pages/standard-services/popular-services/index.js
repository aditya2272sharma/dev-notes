'use strict';

function ServicesCategoriesCtrl($rootScope, modal, SettingsService, NewProjectCategoriesService, LoginManagerService, ProjectsService, accountModalService, _, $state, $anchorScroll, $q, $filter, ENVIRONMENT, ZipcodeInfoService)
{
    var vm = this;
    vm.packages = [];
    vm.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR
    };

    vm.dom = {
        isShowListOfServicesSection: true,
        isShowPopularServicesSection: true
    };

    vm.errorProImage = SettingsService.AssetsPaths.DEFAULT_PROVIDER_IMAGE;
    vm.customProject = ENVIRONMENT.features.customProject;
    vm.portableScheduler = ENVIRONMENT.features.portableScheduler;


    vm.repairViewAllPageUrl = function() {
        $state.go('repair-view-all');
    };

    vm.init = function() {
        var repairObject = {};
        var topProducts = NewProjectCategoriesService.getRepairServiceOfferings();
        var warrantyObject = NewProjectCategoriesService.getWarrantiesInfo();
        var popularServices = NewProjectCategoriesService.popularCategoriesWithSubcategories();

        $q.all([
            topProducts,
            warrantyObject,
            popularServices
        ])
        .then(function(response) {
            vm.repairObject = angular.extend(response[0], {
                warranties: response[1]
            });
            vm.packages = response[2].maincategories;
        }, function(error) {
            vm.messageLabel.CURRENT = error && error.message ? error.message : vm.messageLabel.DEFAULT;
        });

        vm.hideCustom = false; // Flag for hiding custom project link
        updateScreenUIBasedOnUserZipCode(); // update screen UI constant based on user zipcode

        /*NewProjectCategoriesService.popularCategoriesWithSubcategories()
        .then(function(response) {
            vm.packages = response.maincategories;
        }, function(error) {
            vm.messageLabel.CURRENT = error && error.message ? error.message : vm.messageLabel.DEFAULT;
        });*/
    };

    //vm.taskLocation = function(subcategory, title) {
    vm.taskLocation = function(category, maincategory) {
        var categoryId = _.get(maincategory, 'id'),
            subcategoryId = _.get(category, 'catalogid'),
            categoryName = $filter('safeUrls')(_.get(maincategory, 'title')),
            subcategoryName = $filter('safeUrls')(_.get(category, 'title'));

        $state.go('services.results', {
            categoryId: subcategoryId,
            id: categoryId,
            category: categoryName,
            subcategory: subcategoryName
        });
        $anchorScroll();
    };
    vm.categoryPagebyId = function(category) {
        var categoryName = $filter('safeUrls')(_.get(category, 'title'));
        $state.go('services.category', {
            mainCategoryId: category.id,
            category: categoryName
        });
    };

    /**
    ******************Init****************
    */
    vm.init();

    vm.openNewServiceBookingForm = function(selectedProduct) {
        $state.go('repair-form', {
          referer: 'HomeNewCtrl',
          repairObject: vm.repairObject,
          selectedProduct: selectedProduct
        });
    };

    // handle notification when zipcode serviceability updated notification
    $rootScope.$on('zipcode-service-updated-notification', function (event, data) {
        updateScreenUIBasedOnUserZipCode(); // update screen UI constant based on user zipcode
    });

    /**
     * Update home screen UI based on user zipcode.
     */
    function updateScreenUIBasedOnUserZipCode()
    {
        var browserZipCode = ZipcodeInfoService.getZipcode();
        if(browserZipCode && (browserZipCode.length === 5))
        {
            var isServiceAvailableForZipcode = ZipcodeInfoService.getServiceAvailabilityForZipcode();
            console.log('isServiceAvailableForZipcode --> ' + isServiceAvailableForZipcode);

            if (isServiceAvailableForZipcode) // service is available for zipcode
            {
                vm.dom.isShowListOfServicesSection = true;
                vm.dom.isShowPopularServicesSection = false;
                vm.hideCustom = true;
            }
            else
            {
                vm.dom.isShowListOfServicesSection = false;
                vm.dom.isShowPopularServicesSection = true;
                vm.hideCustom = false;
            }
        }
    }
}

ServicesCategoriesCtrl.$inject = ['$rootScope', '$uibModal', 'SettingsService', 'NewProjectCategoriesService', 'LoginManagerService', 'ProjectsService', 'accountModalService', '_', '$state', '$anchorScroll', '$q', '$filter', 'ENVIRONMENT', 'ZipcodeInfoService'];

(angular
	.module('RelayServicesApp.StandardServices')
).controller('ServicesCategoriesCtrl', ServicesCategoriesCtrl);
