'use strict';
function ServicesResultsCtrl(CheckoutInfoService, $state, $scope, SettingsService, ProjectUpdateModalService,
    modal, ProjectsService, ProjectCategoriesService, $sce, moment, CategoryService,
    _, $rootScope, $window, LoginManagerService, ZipcodeInfoService, $anchorScroll, $filter, ENV, accountModalService,
    $q, locationService, CustomProjectService, ErrorHandler, NewProjectCategoriesService, $location) {

    var vm = this,
        //errorAddress = 'Given address isn\'t valid',
        projectId = $state.params.pId,
        demoFlag = false,
        logoutOnTest = false,
        category = $state.params.category,
        subcategory = $state.params.subcategory,
        categoryId = $state.params.categoryId,
        selectedZipcode = $state.params.zipcode,
        dateInfo,
        shouldForceSSv2 = false,
        shouldForceSSv1 = false;
    vm.stdServiceV2 = (ENV.features.stdServiceV2 === 'true');
    vm.stdServiceOverrides = (ENV.features.stdServiceOverrides === 'true');
    vm.feautreDraftProject = (ENV.features.feautreDraftProject === 'true');
    vm.showDraftProjectsCard = false;
    vm.serviceType = (vm.stdServiceV2 === false) ? 'STANDARD' : 'STANDARD_FIXED_PRICE';
    vm.availableDates = [];
    vm.dateOptions = {
        dateDisabled: disabled,
        // formatYear: 'yy',
        maxDate: moment().add(3, 'months'), // initial value for end-date for date-picker,
        minDate: moment().add(2, 'days'), // initial value for start-date,
        startingDay: 0,
        showWeeks: false
    };
    vm.dt = vm.dateOptions.minDate;
    vm.stdServiceV2Always = ENV.features.stdServiceV2Always;
    vm.stdServiceV1Always = ENV.features.stdServiceV1Always;
    vm.showWeAreGrowing = false;

    if (LoginManagerService.getUser().isRegistered) {
        demoFlag = true;
    }
    vm.isSpecialProject = $state.params.isSpecialProject;

    //$scope.subcategoryId = $state.params.id;
    vm.isZipcode = ZipcodeInfoService.getZipcode() ? true : false;

    vm.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR,
        NO_PROS_MSG: SettingsService.NO_PROS_FOR_ZIPCODE_ERROR
    };

    vm.defaultImage = SettingsService.AssetsPaths.DEFAULT_PROJECT_IMAGE;

    /**
     * Get current Zip code
     */
    function setGeolocation() {
        var deferred = $q.defer();
        var geolocation = $window.navigator && $window.navigator.geolocation;
        var zipCode = ZipcodeInfoService.getZipcode();

        if(zipCode) {
            if(zipCode.length === 5) {
                // All valid USA Zipcodes have 5 digits
                // The ones with 4 digits are always used with a leading '0'
                locationService.getlocation(zipCode)
                .then(function(response) {
                    vm.completeAddress = response;
                    vm.zipcode = zipCode;
                    deferred.resolve(zipCode);
                });
            } else {
                // Anything other than 5 digts will mean that it's not a valid
                // location in USA. We can reject serving such requests.
                deferred.reject(zipCode);
            }
        } else if (geolocation) {
            $window.navigator.geolocation
            .getCurrentPosition(function(position) {
                locationService
                .getAddressByLatLong(position.coords.latitude, position.coords.longitude)
                .then(function(response) {
                    // Anything other than 5 digts will mean that it's not a valid
                    // location in USA. The user could be out of home location or
                    // may be they don't have a GPS in their device.
                    if (response.zipCode.length !== 5) {
                        vm.messageLabel.CURRENT = vm.messageLabel.NO_PROS_MSG;
                        deferred.reject(response);
                    } else {
                        _.assign(geolocation, response);
                        vm.completeAddress = response;
                        if (selectedZipcode !== '' && selectedZipcode !== undefined) {
                            vm.zipcode = selectedZipcode;
                        } else {
                            vm.zipcode = ZipcodeInfoService.getZipcode();
                        }
                        if (!vm.isZipcode) {
                            vm.zipcode = vm.completeAddress.zipCode;
                        }
                        deferred.resolve(vm.zipcode);
                    }
              }, function(error) {
                  vm.messageLabel.CURRENT = error && error.message ? error.message : vm.messageLabel.DEFAULT;
                  deferred.reject(vm.zipcode);
              });
            });
        }
        return deferred.promise;
    }

    /**
     * Calling the firms api to get the list of firms
     */
    vm.init = function() {
        $anchorScroll();

        vm.isCardEstimateExist = true;
        vm.loggedInUser = LoginManagerService.getUser();
        
        NewProjectCategoriesService.getcategoriesbyid(categoryId)
        .then(function(response) {
            $scope.subcategoryId = response.catalogid;
            vm.nonStandardCatalogId = response.nonstandardcatalogid;
            if (!$scope.subcategoryId) {
                vm.isCardEstimateExist = false;
            }
            vm.taskDescription = $sce.trustAsHtml(response.description);
            vm.taskTitle = response.title;
            vm.subCategoryId = response.sku;
            vm.subTaskImage = response.imageurl ? response.imageurl : vm.defaultImage;
            vm.pathElements = [
                {
                    item: response.mainCategoryTitle,
                    state: {
                        name: 'services.category',
                        params: {
                            category: category,
                            id: response.mainCategoryId
                        }
                    }
                },
                {
                    item: response.title,
                    state: {
                        name: 'services.results',
                        params: {
                            category: category,
                            categoryId: categoryId,
                            subcategory: subcategory,
                            id: response.id
                        }
                    }
                }
            ];
            /*if (!ZipcodeInfoService.getZipcode()) {
                setGeolocation();
            } else {
                vm.zipcode = ZipcodeInfoService.getZipcode();
                vm.createProject();
            }*/
            setGeolocation().then(function(zipcode) {
                // force SSV2 flags
                // config is fetched from the array in present in package.json
                if (vm.stdServiceOverrides) {
                    shouldForceSSv2 = _.filter(vm.stdServiceV2Always, function(zip) {
                        return (parseInt(zipcode) === parseInt(zip));
                    });
                    if (shouldForceSSv2.length > 0) {
                        shouldForceSSv1 = false;
                        shouldForceSSv2 = true;
                        vm.stdServiceV2 = true;
                        vm.serviceType = 'STANDARD_FIXED_PRICE';
                    }
                    shouldForceSSv1 = _.filter(vm.stdServiceV1Always, function(zip) {
                        return (parseInt(zipcode) === parseInt(zip));
                    });
                    if (shouldForceSSv1.length > 0) {
                        shouldForceSSv1 = true;
                        shouldForceSSv2 = true;
                        vm.stdServiceV2 = false;
                        vm.serviceType = 'STANDARD';
                    }
                }
                locationService
                .getServiceability(zipcode, vm.serviceType)
                .then(function(serviceabilityResponse) {
                    // set project location
                    // if the project object exists, then simply override it
                    vm.project = vm.project || {};
                    vm.project.location = vm.project.location || {};
                    _.extend(vm.project.location, {
                        zipCode: serviceabilityResponse.zipCode,
                        state: serviceabilityResponse.state,
                        country: serviceabilityResponse.country
                    });
                    // Temporarily sending `categoryId` as placeholder
                    // Use `vm.subcategoryId` instead, when APIs ready
                    ProjectsService
                    .checkAvailability(categoryId, zipcode, vm.serviceType)
                    .then(function(response) {
                        vm.availableDates = response && response.data || [];
                        vm.dateOptions.maxDate = vm.availableDates[vm.availableDates.length - 1].date;
                        vm.dateOptions.minDate = vm.availableDates[0].date;
                        $rootScope.availableDates = vm.availableDates;
                        vm.dt = vm.dateOptions.minDate; 
                        // availableDates is the array containing the response
                        // data from Availability API. We'll have to pass this
                        // information from current page to the payments page
                        // via CheckoutInfoService.
                    })
                    .finally(function() {
                        // if (serviceabilityResponse.customSupport === true) {
                        //     // meaning - if zipcode belongs to areas
                        //     // impacted by Hurricane Irma, so a NS modal
                        //     ZipcodeInfoService
                        //     .setZipcode(serviceabilityResponse.zipCode, {
                        //         checkServiceability: false
                        //     });
                        //     CustomProjectService.openModal();
                        // } else {
                            if (projectId) {
                              vm.retrieveProject();
                            } else {
                              vm.createProject();
                            }
                        //}
                    });
                }, function(error) {
                    vm.messageLabel.NO_PROS_MSG = error.response && error.response.message || 'Unknown error occured';
                    ErrorHandler.displayZipCodeErrorMessage(error, vm);
                    // openModal - a method with misleading name that
                    // in fact scrolls the page to the overlay where a user
                    // can provide a new zipcode
                    // and, the error messages need to be set correctly
                    vm.openModal();
                });
            });
        }, function(error) {
            vm.messageLabel.CURRENT = error && error.message ? error.message : vm.messageLabel.DEFAULT;
        });
    };

    vm.openModal = function() {
        vm.isErrorpopVisible = false;
        vm.isZipcode = false;
        vm.card = null;
    };

    vm.openModal2 = function() {
        vm.showOverlay = true;
        vm.card = null;
    };

    vm.close = function() {
        vm.isErrorpopVisible = true;
        vm.locationError = false;
    };

    vm.close2 = function() {
        vm.showOverlay = false;
    };

    vm.createProject = function() {
        vm.locationResponse = {
            'subcategoryid': $scope.subcategoryId,
            'title': vm.taskTitle,
            'zipcode': vm.zipcode,
            'taskTitle': vm.taskTitle,
            'description': vm.taskTitle,
            'size': 'small',
            'servicetype': vm.serviceType,
            'show_availability' : true,
            'catalogid': $scope.subcategoryId
        };

        if (vm.isSpecialProject) {
            vm.locationResponse = _.assignIn(vm.locationResponse, ProjectsService.getProjectInfo());
        }

         vm.createStandardProject(vm.locationResponse);

    };
    vm.onlyNSServiceProPresent = false;

    vm.createStandardProject = function(locationResponse) {
        vm.onlyNSServiceProPresent = false;
        ProjectsService.create(locationResponse).then(function(response) {
            projectId = response.id;
            $rootScope.projectIdReference = projectId;
            ProjectsService.setProjectInfo(response);
            var oldProjectData = vm.project;
            vm.project = response;
            vm.locationError = false;
            $location.search('pId', projectId);
            if (response.firms) {
                vm.isCardEstimateExist = true;
            }
            var updatedInfo = { startdates: oldProjectData.preferredStartDates, timeSlots: oldProjectData.preferredSlots, id: projectId, show_availability: true };
            ProjectsService.update(updatedInfo, false).then(
              function(response) {
                vm.getEstimates();
              }
            );
           
        }, function(error) {
            if (error && error.message) {
                // locationError shows the error message in an <h3> tag
                // in the zip-code-edit-overlay
                vm.locationError = false;
                vm.card = false;
                if (logoutOnTest) {
                    vm.testingSignUp();
                }
                vm.messageLabel.CURRENT = error && error.message ? error.message : vm.messageLabel.DEFAULT;
            } else {
                vm.locationError = false;
            }
        });
    };

    /**
     * Checking whether any standard service available
     */
    vm.isOnlyNSServicePresent = function(firmArray) {
        var onlyNSPresent = true;
        if (firmArray) {
            _.forEach(firmArray, function(firm) {
                if (firm.packageDetails.serviceType === 'STANDARD') {
                    onlyNSPresent = false;
                }
            });
        } else {
            onlyNSPresent = false;
        }
        return onlyNSPresent;
    };

    /**
     * Calling estimates services with all the firmId's so all the prices will be received
     */
    vm.getEstimates = function() {
        vm.showDraftProjectsCard = false;
        //ProjectsService.askForProjectEstimations(projectId, firms, '2016-12-08')
        if (vm.project.serviceType === 'STANDARD_FIXED_PRICE') {
            ProjectsService
            .getUnifiedFixedPriceEstimatesByProjectId(projectId)
            .then(vm.getEstimatesSuccessCallback, vm.getEstimatesErrorCallback);
        } else {
            ProjectsService
            .getUnifiedEstimatesByProjectId(projectId)
            .then(vm.getEstimatesSuccessCallback, vm.getEstimatesErrorCallback);
        }
    };

    vm.getEstimatesErrorCallback = function(error) {
        ErrorHandler.displayEstimatesErrorMessage(error, vm);
    };

    vm.getEstimatesSuccessCallback = function(response) {
        ZipcodeInfoService
        .setZipcode(vm.zipcode, {
            checkServiceability: false
        });
        vm.card = response;
        $rootScope.estimateIdReference = response.estimateId;
        vm.isZipcode = true;
        vm.isCardEstimateExist = true;
        if (logoutOnTest) {
            vm.testingSignUp();
        }
        vm.onlyNSServiceProPresent = vm.isOnlyNSServicePresent(response.data);

        if (vm.project.serviceType === 'STANDARD') {
            vm.setProRateMessages(response.data);
            if (vm.feautreDraftProject) {
                if (response.count === 0) {
                    vm.showDraftProjectsCard = true;
                }
            }
        }

        if (vm.project.serviceType === 'STANDARD_FIXED_PRICE') {
            if (vm.feautreDraftProject) {
                if (response.count === 0) {
                    // Placeholder Code
                    // TODO: changes to enable Draft projects
                    // with SSv2, although only in case when
                    // response code is 400
                    vm.showDraftProjectsCard = true;
                }
            }
        }
    };

    vm.setProRateMessages = function(prosData) {

        var hasPackagePrice = false;
        if (prosData) {
            _.every(prosData, function(pros) {
                if (pros.packageDetails && pros.packageDetails.bid && pros.packageDetails.bid.price) {
                    hasPackagePrice = true;
                    return false;
                }
            });
        }
        if (prosData.length > 0 && !hasPackagePrice) {
            vm.showProMessage = false;
        } else if (prosData.length > 0 && hasPackagePrice) {
            vm.showProMessage = '';
        } else {
            vm.showProMessage = true;
        }
    };

    vm.openProviderProfile = function(providerId) {
        console.log (providerId);
    };

    vm.updateProjectStartDate = function() {
        var formattedDate = $filter('date')(vm.dt, 'yyyy-MM-dd');

        var updatedInfo = {
            'startdate': formattedDate,
            'id': projectId,
            'show_availability': true
        };
        ProjectsService.update(updatedInfo).then(function(response) {
            if (response.firms && response.firms.items.length > 0) {
                vm.getEstimates(response.firms.allFirms);
            }
        }, function(error) {
            vm.messageLabel.CURRENT = error && error.message ? error.message : vm.messageLabel.DEFAULT;
        });

    };

    vm.testingSignUp = function() {
        //if (LoginManagerService.getUser().isRegistered) {
        //LoginManagerService.logoutTest();
        //}
    };

    vm.createNSProjectAndAskEstimates = function(provider) {
        var defaultTimeSlot = '8:00 AM - 12:00 PM';
        var descriptionText = vm.taskDescription ? String(vm.taskDescription).replace(/<[^>]+>/gm, '') : '';
        var categoryId = $state.params.categoryId;
        var project = {
            /*subcategoryid: vm.project.category.id,*/
            title: vm.taskTitle,
            taskTitle: vm.taskTitle,
            zipcode: vm.zipcode,
            description: descriptionText,
            timeslot: defaultTimeSlot,
            catalogid: vm.nonStandardCatalogId,
            servicetype: 'NON_STANDARD',
            isstandardtononStandard: true,
            standardcatalogid: categoryId
        };

        dateInfo = {
            date: $filter('date')(vm.dt, 'yyyy-MM-dd'),
            timeSlot: defaultTimeSlot
        };

        ProjectsService.create(project).then(function(response) {
            ProjectUpdateModalService.openModal(response, dateInfo, function() {
                var firmIds = provider.id,
                    startDate = response.startDate;
                ProjectsService.
                askForProjectEstimations(response.id, firmIds, startDate)
                .finally(function() {
                    $state.go('projects.request-received', {id: response.id});
                });
            });
        }, function(error) {
            vm.messageLabel.CURRENT = error && error.message ? error.message : vm.messageLabel.DEFAULT;
        });
    };
    /**
     * Set next date available
     */
    vm.today = function() {
        var finaldate = moment().add(2, 'days');
        finaldate = finaldate.weekday() && finaldate.weekday() <= 6 ?
                    finaldate : finaldate.add(8 - (finaldate.weekday() || 7), 'days');
        vm.dt = finaldate._d;
    };

    /**
     * Open filters on responsive version
     */
    vm.openFilters = function() {
        var modalInstance = modal.open({
            animation: true,
            controller: 'StdServicesFilterCtrl',
            controllerAs: 'StdServicesFilterCtrl',
            templateUrl: [
                'assets/templates/pages/standard-services/results-filter/',
                'index.html'
            ].join('')
        });
        modalInstance.result.then(function() {
            //state.go('projects.create.details');
        });
    };

    /**
    ******************Date Picker****************
    */
    vm.popup2 = {
        opened: false
    };

    // Disable weekend selection
    function disabled(data) {
        var date = data.date,
            formattedDate = moment(date).format('YYYY-MM-DD'),
            filteredResults;
        filteredResults = _.filter(vm.availableDates, function(availableDate) {
            return (formattedDate === availableDate.date);
        });
        return filteredResults.length > 0 ? false : true;
    }

    vm.open2 = function() {
        vm.popup2.opened = true;
    };

    vm.proceedWithDraftProj = function() {
        var dateInfo = {
            date: $filter('date')(vm.project.startDate, 'yyyy-MM-dd'),
            timeSlot: vm.project.timeSlot
        };
        ProjectUpdateModalService.openModal(vm.project, dateInfo, function() {
            ProjectsService.waitForEstimates(vm.project.id)
            .finally(function() {
                $state.go('account.booking-detail', {id: vm.project.id});
            });
        });
    };

    vm.waitForEstimates = function() {
        if (!LoginManagerService.getUser().isRegistered) {
            accountModalService.signInInit(function() {
                vm.proceedWithDraftProj();
            }, false, true);
        } else {
            vm.proceedWithDraftProj();
        }
    };

    $rootScope.$on('ProCard:removeSelection', function() {
        _.each(vm.card.data, function(card) {
            card.selectedTimeRange = undefined;
        });
    });

    // Proceed to payment
    vm.performAcceptEstimate = function() {
        var projectId = $rootScope.projectIdReference,
            estimateId = $rootScope.estimateIdReference,
            decision = 'Accept';
        ProjectsService.acceptOrRejectProjectEstimation(projectId, estimateId, decision)
        .then(function(acceptRejectObject) {
            CheckoutInfoService.setCheckout({
                order: acceptRejectObject,
                project: projectId,
                firm: false,
                selectedDate: vm.project.startDate,
                selectedTime: vm.project.timeSlot,
                zipcode: vm.zipcode,
                availableDates: vm.availableDates
            });
            if (vm.guestCheckout) {
                $state.go('payment.guestCheckout');
            } else {
                $state.go('payment.checkout');
            }
        }, function(error) {
            vm.messageLabel.CURRENT = error && error.message ? error.message : vm.messageLabel.DEFAULT;
        });
    };

    vm.checkoutSingleEstimate = function() {
        if (!LoginManagerService.getUser().isRegistered) {
            accountModalService.signInInit(function() {
                ProjectsService.create(projectId).then(function(response) {
                    if (response.contact.name.split(' ')[0] === 'Anonymous') {
                        vm.guestCheckout = true;
                    }
                    vm.performAcceptEstimate();
                }, function(error) {
                    vm.messageLabel.CURRENT = error && error.message ? error.message : vm.messageLabel.DEFAULT;
                });
            }, false, true);
        } else {
            vm.performAcceptEstimate();
        }
    };

    vm.getZipcodeDetails = function(zipcode, zipcodeForm) {
        vm.locationError = false;
        vm.nonServiceableZipCodeErrorMessage = '';
        if (zipcode && zipcode.length === 5) {
            locationService.getServiceability(zipcode, vm.serviceType)
            .then(function(serviceabilityResponse) {
                vm.locationError = false;
                // set project location
                // if the project object exists, then simply override it
                vm.project = vm.project || {};
                vm.project.location = vm.project.location || {};
                _.extend(vm.project.location, {
                    zipCode: serviceabilityResponse.zipCode,
                    state: serviceabilityResponse.state,
                    country: serviceabilityResponse.country
                });

                // the following comment enclosed section updates the zip
                // and address on the navigation, please replace it if you
                // there is a better way to do that

                ///
                ZipcodeInfoService
                .setZipcode(serviceabilityResponse.zipCode, {
                    checkServiceability: false
                });
                $rootScope.$emit('close-user-location-popover', serviceabilityResponse);
                ///

                ProjectsService
                .checkAvailability(categoryId, zipcode, vm.serviceType)
                .then(function(response) {
                    vm.availableDates = response && response.data || [];
                    vm.dateOptions.maxDate = vm.availableDates[vm.availableDates.length - 1].date;
                    vm.dateOptions.minDate = vm.availableDates[0].date;
                    vm.dt = vm.dateOptions.minDate;
                })
                .finally(function() {
                    // if (serviceabilityResponse.customSupport === true) {
                    //     // meaning - if zipcode belongs to areas
                    //     // impacted by Hurricane Irma, so a NS modal
                    //     ZipcodeInfoService
                    //     .setZipcode(serviceabilityResponse.zipCode, {
                    //         checkServiceability: false
                    //     });
                    //     CustomProjectService.openModal();
                    // } else {
                        vm.createProject();
                        vm.close2();
                        // added this condition because there are places where
                        // we only need to get the details, without coupling it
                        // with a form
                        if (zipcodeForm) {
                            zipcodeForm.confirmZipCode.$setValidity('Zip Code', true);
                        }
                   // }
                });
            }, function(error) {
                ErrorHandler.displayZipCodeErrorMessage(error, vm, zipcodeForm);
            });
        }
    };

    vm.validateZipCodeLength = function(zipcode, zipcodeForm) {
        vm.locationError = false;
        vm.nonServiceableZipCodeErrorMessage = '';
        if (zipcode && zipcode.length === 5) {
            zipcodeForm.confirmZipCode.$setValidity('Zip Code', true);
        } else {
            zipcodeForm.confirmZipCode.$setValidity('Zip Code', false);
        }
    };

    vm.retrieveProject = function() {
        ProjectsService
        .getProjectByProjectId(projectId)
        .then(function(response) {
            ProjectsService.setProjectInfo(response);
            vm.project = response;
            vm.getEstimates();
        }, function(error) {
            vm.messageLabel.CURRENT = error;
        });
    };

    /**
    ******************Init****************
    */
    vm.init();

    // handle notification when zipcode serviceability updated notification
    $rootScope.$on('zipcode-service-updated-notification', function (event, data) {
        updateScreenUIBasedOnUserZipCode(); // update screen UI constant based on user zipcode
    });

    /**
     * Update home screen UI based on user zipcode.
     */
    function updateScreenUIBasedOnUserZipCode()
    {
        var browserZipCode = ZipcodeInfoService.getZipcode();
        if(browserZipCode && (browserZipCode.length === 5))
        {
            vm.zipcode = browserZipCode;
            vm.getZipcodeDetails(browserZipCode);
        }
    }

    // In case of signin/up, recreate the project with the new session
    $rootScope.$on('user:authentication:change', function(event, user) {
        // check whether the user session has changed
        if(user.isRegistered && !angular.equals(user, vm.loggedInUser)) {
            vm.loggedInUser = user;
            vm.createProject();
        }
    });
}

ServicesResultsCtrl.$inject = ['CheckoutInfoService', '$state', '$scope', 'SettingsService', 'ProjectUpdateModalService',
    '$uibModal', 'ProjectsService', 'ProjectCategoriesService', '$sce', 'moment', 'CategoryService',
    '_', '$rootScope', '$window', 'LoginManagerService', 'ZipcodeInfoService', '$anchorScroll', '$filter', 'ENVIRONMENT',
    'accountModalService', '$q', 'locationService', 'CustomProjectService', 'ErrorHandler', 'NewProjectCategoriesService', '$location'
];

(angular
    .module('RelayServicesApp.StandardServices')
).controller('ServicesResultsCtrl', ServicesResultsCtrl);
