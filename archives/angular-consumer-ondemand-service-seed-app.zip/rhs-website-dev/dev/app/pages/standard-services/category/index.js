'use strict';

function ServicesSubcategoryCtrl($state, $scope, $rootScope,
    CategoryService, $anchorScroll, $filter,
    _, Env, $sce, $q, NewProjectCategoriesService, ProjectsService, ZipcodeInfoService, LoginManagerService) {

    var vm = this,
        electricalCategory = 'electrician';

    vm.isElectrical = false;
    vm.portableScheduler = Env.features.portableScheduler;
    vm.customProject = Env.features.customProject;
    vm.askedForZipcode = false;
    vm.peTempObj = {};

    vm.init = function(filter) {
        // Get user location for project creation
        $rootScope.$broadcast('get:user:location');
        $anchorScroll();
        // cloned init method from `RepairServiceDetails`
        if (!LoginManagerService.getUser().isRegistered) {
            LoginManagerService.anonymousLogin();
        }

        $rootScope.$on('zipcode-service-updated-notification', function() {
            if(vm.askedForZipcode) {
                vm.taskParameters(vm.peTempObj.subcategory,
                    vm.peTempObj.categoryId);
            }
        });
        /*CategoryService.getCatalogByName($state.params.category)
            .then(function(response) {
                $scope.projectId = response.id;
                vm.packages = response;
                if (vm.packages.title.toLowerCase() === electricalCategory) {
                    vm.isElectrical = true;
                }
            }, function(error) {
                vm.messageLabel.CURRENT = error && error.message ? error.message : $scope.messageLabel.DEFAULT;
            });*/
        var standardCatalogsById = NewProjectCategoriesService
            .standardCatalogsById($state.params.mainCategoryId);
        $q.all([filter, standardCatalogsById])
        .then(function(res) {
            var filter = res[0];
            var response = res[1];
            var maincategories = response.maincategories && response.maincategories || [];
            var projectId = response.maincategories[0].id;
            if (maincategories.length > 1) {
                maincategories = maincategories.filter(function(item) {
                    var title = filter(item.title);
                    return (location.pathname.indexOf (title) > 0);
                });
                projectId = maincategories[0] && maincategories[0].id || projectId;
            }
            $scope.projectId = projectId;
            vm.packages = maincategories[0];
            if (vm.packages.title.toLowerCase() === electricalCategory) {
                vm.isElectrical = true;
            }
        }, function(error) {
            vm.messageLabel.CURRENT = error && error.message ? error.message : $scope.messageLabel.DEFAULT;
        });
    };

    $scope.trustSrc = function(src) {
        return $sce.trustAsResourceUrl(src);
    };

    vm.taskParameters = function(subcategory, categoryId) {
        // Cross checking for zipcode input
        var zipCode = ZipcodeInfoService.getZipcode();
        if( zipCode && zipCode.length === 5) {
            var categoryName = $state.params.category;
            var subcategoryName = $filter('safeUrls')(_.get(subcategory, 'title'));
            var projectTitle = subcategory.title;
            var projectData = {
                'subcategoryid': categoryId,
                'title': projectTitle,
                'zipcode': zipCode,
                'taskTitle': projectTitle,
                'description': subcategoryName,
                'size': 'small',
                'servicetype': 'STANDARD',
                'show_availability' : true,
                'catalogid': categoryId
            };

            ProjectsService.create(projectData).then(function(response) {
                var projectId = response.id;
                $rootScope.projectIdReference = projectId;
                vm.project = response;

                // $state.go('services.results', {
                //     category: categoryName,
                //     subcategory: subcategoryName,
                //     categoryId: categoryId,
                //     isSpecialProject: true,
                //     pId: projectId
                // });

                // Go to Scheduler page
                $state.go('repair-schedule', {
                    id: projectId,
                    catalogId: categoryId,
                    category: categoryName,
                    subcategory: subcategoryName
                });

            }, function(error) {
                if (error && error.message) {
                    vm.messageLabel.CURRENT = error && error.message ? error.message : vm.messageLabel.DEFAULT;
                }
            });
        } else {
            // Get user location forcefully for project creation
            vm.askedForZipcode = true;
            vm.peTempObj = {
                subcategory: subcategory,
                categoryId: categoryId
            };
            $rootScope.$broadcast('ask:zipcode');
        }
        
    };

    vm.taskLocation = function(subcategory, categoryId) {
        //var categoryId = _.get(subcategory, 'parentCategory.id');
        //var subcategoryId = _.get(subcategory, 'id');
        var categoryName = $filter('safeUrls')(_.get(subcategory, 'parentCategory.title'));
        var subcategoryName = $filter('safeUrls')(_.get(subcategory, 'title'));
        $state.go('services.results', {
            category: categoryName,
            subcategory: subcategoryName,
            categoryId: categoryId
        });
        $anchorScroll();
    };

    vm.init($q.resolve($filter('safeUrls')));
}

ServicesSubcategoryCtrl.$inject = [
    '$state', '$scope', '$rootScope',
    'CategoryService', '$anchorScroll', '$filter',
    '_', 'ENVIRONMENT', '$sce', '$q', 'NewProjectCategoriesService', 'ProjectsService', 'ZipcodeInfoService', 'LoginManagerService'
];

(angular
    .module('RelayServicesApp.StandardServices')
).controller('ServicesSubcategoryCtrl', ServicesSubcategoryCtrl);
