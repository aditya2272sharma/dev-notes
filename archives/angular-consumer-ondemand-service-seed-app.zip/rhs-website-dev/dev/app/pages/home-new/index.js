'use strict';

function HomeNewCtrl($scope, $rootScope, $anchorScroll, SettingsService, NewProjectCategoriesService, 
_, $state, $filter, $q, LoginManagerService, ZipcodeInfoService, ProjectsService)
{
    var vm = this;

    vm.packages = [];
    vm.repairObject = {};
    vm.askedForZipcode = false;
    vm.peTempObj = {};

    vm.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR
    };

    // Get user location for project creation
    $rootScope.$broadcast('get:user:location');

    var topProducts = NewProjectCategoriesService.getRepairServiceOfferings();
    var standardCatalogs = NewProjectCategoriesService.standardCatalogs();

    $q.all([
        topProducts,
        standardCatalogs
    ])
    .then(function(response) {
        vm.repairObject = angular.extend(response[0], {});
        vm.packages = response[1];
    }, function(error) {
        vm.messageLabel.CURRENT = error && error.message ? error.message : vm.messageLabel.DEFAULT;
    })
    .finally(function(){
         vm.init();
    });

    vm.init = function() {
        $anchorScroll();
        // cloned init method from `RepairServiceDetails`
        if (!LoginManagerService.getUser().isRegistered) {
            LoginManagerService.anonymousLogin();
        }

        $rootScope.$on('zipcode-service-updated-notification', function() {
            if(vm.askedForZipcode) {
                vm.taskParameters(vm.peTempObj.category,
                    vm.peTempObj.subcategory,
                    vm.peTempObj.categoryId);
            }
        });


        // other misc. initializations
        for (var category in vm.packages) {
            category.title = (category.title === 'Connected Living') ? 'Smart Home' : category.title;
        }
    };

    vm.taskParameters = function(category, subcategory, categoryId) {
        // Cross checking for zipcode input
        var zipCode = ZipcodeInfoService.getZipcode();
        if( zipCode && zipCode.length === 5) {
            var categoryName = $filter('safeUrls')(category);
            var subcategoryName = $filter('safeUrls')(_.get(subcategory, 'title'));
            var projectTitle = subcategory.title;
            var projectData = {
                'subcategoryid': categoryId,
                'title': projectTitle,
                'zipcode': zipCode,
                'taskTitle': projectTitle,
                'description': subcategoryName,
                'size': 'small',
                'servicetype': 'STANDARD',
                'show_availability' : true,
                'catalogid': categoryId
            };

            ProjectsService.create(projectData).then(function(response) {
                var projectId = response.id;
                $rootScope.projectIdReference = projectId;
                vm.project = response;
                
                // Go to Scheduler page
                $state.go('repair-schedule', {
                    id: projectId,
                    catalogId: categoryId,
                    category: categoryName,
                    subcategory: subcategoryName
                });

            }, function(error) {
                if (error && error.message) {
                    vm.messageLabel.CURRENT = error && error.message ? error.message : vm.messageLabel.DEFAULT;
                }
            });
        } else {
            // Get user location forcefully for project creation
            vm.askedForZipcode = true;
            vm.peTempObj = {
                category: category,
                subcategory: subcategory,
                categoryId: categoryId
            };
            $rootScope.$broadcast('ask:zipcode');
        }
        
    };
    
    
    vm.categoryPagebyId = function(category) {
        var categoryName = $filter('safeUrls')(_.get(category, 'title'));
        $state.go('services.category', {
            mainCategoryId: category.id,
            category: categoryName
        });
    };

    vm.gotoHARepair = function(index) {
        var repairObjects = vm.repairObject.topProducts;
        $state.go("repair-form", {
            referer: "HomeNewCtrl",
            repairObject: vm.repairObject,
            selectedProduct: repairObjects[index] || repairObjects[0]
        });
    }

}

HomeNewCtrl.$inject = ['$scope', '$rootScope', '$anchorScroll', 'SettingsService', 'NewProjectCategoriesService',
 '_', '$state', '$filter', '$q', 'LoginManagerService', 'ZipcodeInfoService', 'ProjectsService'];

(angular
    .module('RelayServicesAppRun.Home')
).controller('HomeNewCtrl', HomeNewCtrl);
