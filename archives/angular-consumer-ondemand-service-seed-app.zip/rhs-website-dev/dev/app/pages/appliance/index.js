'use strict';

function Configure($stateProvider) {
    $stateProvider.state('appliance', {
        url: '/appliance/:applname-repair',
        templateUrl: 'assets/templates/pages/appliance/main.html',
        controller: 'ApplianceCtrl as $ctrl',
        resolve : {
            'sessionStatus': require('../../services/session-status-resolve')
        }
    });

}

Configure.$inject = ['$stateProvider'];

function Run() {
}

(angular
    .module('RelayServicesAppRun.Appliance', [])
    .config(Configure)
).run(Run);
