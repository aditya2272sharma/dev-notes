'use strict';

function ApplianceCtrl(
  $anchorScroll,
  SettingsService,
  NewProjectCategoriesService,
  state,
  $scope,
  $q,
  _,
  $uibModal,
  $log,
  $rootScope,
  addressesService,
  ZipcodeInfoService,
  CookieManager,
  locationService
) {
  var vm = this;

  vm.messageLabel = {
    CURRENT: '',
    DEFAULT: SettingsService.Error.DEFAULT_ERROR
  };

  vm.init = function() {
    $anchorScroll();
    vm.selectedProduct = state.params.applname.toLowerCase();
    vm.repair = state.params.repairObject;
    vm.phonenumber = '1-888-236-1894';
    var topProducts = NewProjectCategoriesService.getRepairServiceOfferings();
    var warrantyObject = NewProjectCategoriesService.getWarrantiesInfo();
    CookieManager.setNavigationBarContactNumber(vm.phonenumber); // save new services phone number in the cookie

    $q.all([
      topProducts,
      warrantyObject
  ])
  .then(function(response) {
      vm.repairObject = angular.extend(response[0], {
          warranties: response[1]
      });
      vm.applianceDetails = vm.getApplianceDetails();
  }, function(error) {
      vm.messageLabel.CURRENT = error && error.message ? error.message : vm.messageLabel.DEFAULT;
  });
  };

  vm.getApplianceDetails = function() {
      var applianceDetails = _.filter(vm.repairObject.topProducts, function(item){
        return item.name.toLowerCase() === vm.selectedProduct;
      });
      return applianceDetails.length > 0 ? applianceDetails[0]: null;
  };

  vm.clickSchedule = function() {
    state.go('repair-form', {
      referer: 'ApplianceCtrl',
      repairObject: vm.repairObject,
      selectedProduct: vm.applianceDetails
    });
  };

  vm.learnMoreAboutTechTalk = function() {
    var size = 'md';
    var modalInstance = $uibModal.open({
        animation: true,
        ariaLabelledBy: 'modal-title',
        ariaDescribedBy: 'modal-body',
        templateUrl: 'assets/templates/components/tech-talk/learn-more-modal/learn-more-modal.html',
        controller: 'TechTalkLearnMoreModal',
        controllerAs: '$ctrl',
        size: size,
        resolve: {
        }
    });

    modalInstance.result.then(function (result) {
        vm.clickSchedule();
    }, function () {
        $log.info('Modal dismissed at: ' + new Date());
    });
};

  vm.init();

  // Hide the header pbx if its hidden
  $rootScope.$emit('show-hide-header-pbx', true);
}

ApplianceCtrl.$inject = [
  '$anchorScroll',
  'SettingsService',
  'NewProjectCategoriesService',
  '$state',
  '$scope',
  '$q',
  '_',
  '$uibModal',
  '$log',
  '$rootScope',
  'addressesService',
  'ZipcodeInfoService',
  'CookieManager',
  'locationService'
];

angular
  .module('RelayServicesAppRun.Appliance')
  .controller('ApplianceCtrl', ApplianceCtrl);
