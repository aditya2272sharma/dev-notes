'use strict';

function TermsController($scope, $window, $state, $anchorScroll) {
    var vm = this,
        tabParam = $state.params.tab;

    $scope.activeTabIndex = 0;
    if (tabParam) {
        $scope.activeTabIndex = parseInt(tabParam);
    }

    vm.openBuyerAgreement = function() {
        $scope.activeTabIndex = 1;
    };

    vm.openServiceProviderAgreement = function() {
        $scope.activeTabIndex = 2;
    };

    vm.openTermsOfUse = function() {
        $scope.activeTabIndex = 0;
    };

    vm.openServiceliveServiceGuarantee = function() {
        $window.open('https://www.searshomeservices.com/terms-of-use');
    };

    $anchorScroll();
}

TermsController.$inject = ['$scope', '$window', '$state', '$anchorScroll'];

(angular
    .module('RelayServicesApp.Terms')
).controller('TermsController', TermsController);
