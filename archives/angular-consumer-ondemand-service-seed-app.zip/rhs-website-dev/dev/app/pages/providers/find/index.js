'use strict';

function ProviderFindCtrl($scope, Provider) {

    var vm = this;

    $scope.setView = function(view) {
        $scope.view = {};
        $scope.view[view] = true;
    };

    $scope.initialize = function() {

        $scope.view = {list: true};
        $scope.resultsPerPage = 25;
        $scope.offset = 1;
        $scope.pageNumber = 1;
        $scope.totalResults = 145;
        $scope.minDistance = 15;
        $scope.maxDistance = 15;
        //$scope.results = Provider.list();

        Provider.list().then(vm.providerSucess, vm.providerError);
    };

    vm.providerSucess = function(response) {
        $scope.results = response;
    };

    vm.providerError = function(err) {
        console.log(err);
    };

    $scope.initialize();
}

ProviderFindCtrl.$inject = ['$scope', 'Provider'];

(angular
    .module('RelayServicesApp.Providers')
).controller('ProviderFindCtrl', ProviderFindCtrl);
