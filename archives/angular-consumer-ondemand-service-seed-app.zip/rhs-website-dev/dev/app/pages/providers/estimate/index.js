'use strict';
function ProvidersEstimateCtrl($scope) {
    $scope.init = function() {

    };

    $scope.init();
}

ProvidersEstimateCtrl.$inject = ['$scope'];

(angular
    .module('RelayServicesApp.Providers')
).controller('ProvidersEstimateCtrl', ProvidersEstimateCtrl);
