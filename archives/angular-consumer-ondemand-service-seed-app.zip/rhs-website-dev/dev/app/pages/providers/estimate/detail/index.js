'use strict';

function ProvidersEstimateDetailCtrl() {
}

ProvidersEstimateDetailCtrl.$inject = [];

(angular
    .module('RelayServicesApp.Providers')
).controller('ProvidersEstimateDetailCtrl', ProvidersEstimateDetailCtrl);
