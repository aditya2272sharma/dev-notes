'use strict';

function Configure($stateProvider) {

    $stateProvider.state('providers', {
        url: '/providers',
        abstract: true,
        templateUrl: 'assets/templates/pages/partials/abstract.html',
        resolve : {
            'sessionStatus': require('../../services/session-status-resolve')
        }
    }).state('providers.find', {
        url: '',
        controller: 'ProviderFindCtrl',
        templateUrl: 'assets/templates/pages/providers/find/index.html'
    });

    $stateProvider.state('providers.estimate', {
        url: '/estimate',
        abstract: true,
        templateUrl: 'assets/templates/pages/providers/estimate/index.html',
        controller: 'ProvidersEstimateCtrl',
        controllerAs: 'ProvidersEstimateCtrl',
        resolve : {
            'sessionStatus': require('../../services/session-status-resolve')
        }
    }).state('providers.estimate.detail', {
        url: '/detail',
        templateUrl: (
            'assets/templates/pages/providers/estimate/detail/index.html'
        ),
        controller: 'ProvidersEstimateDetailCtrl',
        controllerAs: 'ProvidersEstimateDetailCtrl',
    }).state('providers.estimate.preview', {
        url: '/preview',
        templateUrl: (
            'assets/templates/pages/providers/estimate/preview/index.html'
        )
    }).state('providers.estimate.summary', {
        url: '/summary',
        templateUrl: (
            'assets/templates/pages/providers/estimate/summary/index.html'
        )
    });

    $stateProvider.state('firms', {
        url: '/firms',
        abstract: true,
        controller: 'ProviderProfileCtrl as ProviderProfileCtrl',
        params: {
            id: null,
            serviceType: 'NON_STANDARD'
        },
        resolve : {
            'sessionStatus': require('../../services/session-status-resolve')
        },
        templateUrl: 'assets/templates/pages/providers/profile/index.html'
    }).state('firms.about', {
        url: '/about/:id?serviceType',
        controller: 'ProviderProfileAboutCtrl',
        requiresLogin: true,
        dismissDestination: 'home.new',
        templateUrl: 'assets/templates/pages/providers/profile/about/index.html',
        params: {
            hasHero: true,
            serviceType: ''
        }
    }).state('firms.reviews', {
        url: '/reviews/:id?serviceType',
        controller: 'ProviderProfileReviewsCtrl',
        requiresLogin: true,
        dismissDestination: 'home.new',
        controllerAs: 'ProviderProfileReviewsCtrl',
        templateUrl: (
            'assets/templates/pages/providers/profile/reviews/index.html'
        ),
        params: {
            hasHero: true,
            serviceType: ''
        }
    });

    $stateProvider.state('providers.profile', {
        url: '/profile',
        abstract: true,
        controller: 'ProviderProfileCtrl as ProviderProfileCtrl',
        params: {
            id: null,
            serviceType: 'NON_STANDARD'
        },
        templateUrl: 'assets/templates/pages/providers/profile/index.html'
    }).state('providers.profile.about', {
        url: '/about/:id',
        controller: 'ProviderProfileAboutCtrl',
        requiresLogin: true,
        dismissDestination: 'home.new',
        controllerAs: 'ProviderProfileAboutCtrl',
        templateUrl: 'assets/templates/pages/providers/profile/about/index.html',
        params: {
            hasHero: true,
            serviceType: ''
        }
    }).state('providers.profile.reviews', {
        url: '/reviews/:id',
        controller: 'ProviderProfileReviewsCtrl',
        requiresLogin: true,
        dismissDestination: 'home.new',
        controllerAs: 'ProviderProfileReviewsCtrl',
        templateUrl: (
            'assets/templates/pages/providers/profile/reviews/index.html'
        ),
        params: {
            hasHero: true,
            serviceType: 'NON_STANDARD'
        }
    });

}

Configure.$inject = ['$stateProvider'];

function Run() {
}

(angular
    .module('RelayServicesApp.Providers', [])
    .config(Configure)
).run(Run);
