'use strict';

function ProviderProfileReviewsCtrl(modal, $scope) {
    var vm = this;

    vm.initialize = function() {
        $scope.setSection('reviews');
    };

    vm.initialize();

    vm.openReviews = function() {
        var modalInstance = modal.open({
            animation: true,
            controller: 'reviewsDetailCtrl',
            controllerAs: 'reviewsDetailCtrl',
            templateUrl: [
                'assets/templates/pages/providers/profile/',
                'reviews-detail.html'
            ].join('')
        });

        modalInstance.result.then(function() {
            //state.go('projects.create.details');
        });

    };
}

ProviderProfileReviewsCtrl.$inject = ['$uibModal', '$scope'];

(angular
    .module('RelayServicesApp.Providers')
).controller('ProviderProfileReviewsCtrl', ProviderProfileReviewsCtrl);
