'use strict';

function ProviderProfileCtrl($scope, Provider, $stateParams,
    SettingsService, LoginManagerService, $filter) {
    var vm = this;
    $scope.errorAuthorImage = SettingsService.AssetsPaths.DEFAULT_AVATAR_IMAGE;
    $scope.isNumber = angular.isNumber;
    vm.serviceType = $stateParams.serviceType;
    $scope.setSection = function(value) {
        $scope.section = {};
        $scope.section[value] = true;
    };

    vm.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR
    };

    $scope.unauthorized = false;

    /**
     * Calls provider service.
     */
    $scope.initialize = function() {
        $scope.setSection('about');
        $scope.popover = {
            url: 'assets/templates/pages/providers/profile/about/services.html'
        };
        Provider.getProviderById($stateParams.id, $stateParams.serviceType).then(vm.providerSucess, vm.providerError);
    };

    /**
     * Provider service successful response.
     * @param  {Object} response All the profile info
     */
    vm.providerSucess = function(response) {
        vm.provider = response;
        vm.providerName = $filter('safeUrls')(response.title);
    };

    /**
     * Provider service error response.
     * @param  {Object} error response
     */
    vm.providerError = function(error) {
        vm.messageLabel.CURRENT = error.message ? error.message : vm.messageLabel.DEFAULT;
        if (error.status === 401) {
            $scope.unauthorized = true;
        }
    };

    vm.authorize = function() {
        if (!LoginManagerService.getUser().isRegistered) {
            LoginManagerService.anonymousLogin()
            .then(function() {
                $scope.initialize();
            }, function(error) {
                if (error) {
                    vm.messageLabel.CURRENT = error && error.message ? error.message : vm.messageLabel.DEFAULT;
                }
            });
        }
    };

    $scope.initialize();
}

ProviderProfileCtrl.$inject = [
    '$scope', 'Provider', '$stateParams', 'SettingsService',
    'LoginManagerService', '$filter'];

(angular
    .module('RelayServicesApp.Providers')
).controller('ProviderProfileCtrl', ProviderProfileCtrl);
