'use strict';

function ReviewsDetailCtrl(modalInstance) {
    var vm = this;
    vm.close = function() {
        modalInstance.close();
    };
}

ReviewsDetailCtrl.$inject = ['$uibModalInstance'];

(angular
    .module('RelayServicesApp.Providers')
).controller('ReviewsDetailCtrl', ReviewsDetailCtrl);
