'use strict';

function ProviderProfileAboutCtrl($scope) {
    var vm = this;

    vm.initialize = function() {
        $scope.setSection('about');
    };

    vm.initialize();
}

ProviderProfileAboutCtrl.$inject = ['$scope'];

(angular
    .module('RelayServicesApp.Providers')
).controller('ProviderProfileAboutCtrl', ProviderProfileAboutCtrl);
