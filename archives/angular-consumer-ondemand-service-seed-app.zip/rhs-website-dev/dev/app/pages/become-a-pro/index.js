'use strict';

function Configure($stateProvider) {

    $stateProvider.state('become-a-pro', {
        url: '/become-a-pro',
        controller: 'BecomeAProCtrl',
        controllerAs: 'BecomeAProCtrl',
        templateUrl: 'assets/templates/pages/become-a-pro/index.html',
        params: {
            hasHero: true,
        },
        resolve : {
            'sessionStatus': require('../../services/session-status-resolve')
        }
    });
}

Configure.$inject = ['$stateProvider'];

function Run() {
}

(angular
    .module('RelayServicesApp.becomeAPro', [])
    .config(Configure)
).run(Run);
