'use strict';

function BecomeAProCtrl($anchorScroll) {
    var vm = this;

    vm.scrollTo = function() {
        $anchorScroll();
    };

    vm.scrollTo();
}

BecomeAProCtrl.$inject = ['$anchorScroll'];

(angular
	.module('RelayServicesApp.becomeAPro')
).controller('BecomeAProCtrl', BecomeAProCtrl);
