'use strict';

function Configure($stateProvider) {

    $stateProvider.state('ratings', {
        url: '/ratings',
        abstract: true,
        templateUrl: 'assets/templates/pages/partials/abstract.html',
        resolve : {
            'sessionStatus': require('../../services/session-status-resolve')
        }
    });

    $stateProvider.state('ratings.providers', {
        url: '/providers',
        abstract: true,
        templateUrl: 'assets/templates/pages/ratings/providers/index.html',
        controller: 'RateCtrl',
        controllerAs: 'RateCtrl'
    }).state('ratings.providers.ratepros', {
        url: '/ratepros?reviewToken&title',
        templateUrl: 'assets/templates/pages/ratings/providers/rate-pros/index.html',
        controller: 'RateProCtrl',
        controllerAs: 'RateProCtrl',
        params: {
            hasHero: true
        }
    });

}

Configure.$inject = ['$stateProvider'];

function Run() {
}

(angular
    .module('RelayServicesApp.Ratings', [])
    .config(Configure)
).run(Run);
