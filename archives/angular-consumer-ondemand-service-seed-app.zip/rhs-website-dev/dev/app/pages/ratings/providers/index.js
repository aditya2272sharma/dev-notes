'use strict';

function RateCtrl($scope, $state, LoginManagerService, accountModalService) {
    var vm = this,
        projectTitle = $state.params.title;

    /**
     * Getting the project info
     */
    vm.init = function() {
        vm.projectTitle = projectTitle;
    };

    /**
    ******************Init****************
    */
    vm.init();
}

RateCtrl.$inject = ['$scope', '$state', 'LoginManagerService', 'accountModalService'];

(angular
    .module('RelayServicesApp.Ratings')
).controller('RateCtrl', RateCtrl);
