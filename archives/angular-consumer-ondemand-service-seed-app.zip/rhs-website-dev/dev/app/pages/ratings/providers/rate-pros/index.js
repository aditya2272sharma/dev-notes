'use strict';

function RateProCtrl(Reviews, $scope, $state, SettingsService, _) {
    var vm = this,
        questionnaire = {};
    $scope.projectId  = $state.params.id;
    $scope.project = {};
    $scope.reviewToken = $state.params.reviewToken;

    vm.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR,
        SUCCESS: ''
    };
    vm.errorProImage = SettingsService.AssetsPaths.DEFAULT_PROVIDER_IMAGE;
    vm.selectProFlag = true;
    vm.alreadyRated = false;
    vm.firstLoad = true;

    /**
     * Getting the questionnaire service which contains provider info as well
     */
    vm.init = function() {
        if (!$scope.reviewToken) {
            // the user is not authorized to arrive at a review page without
            // a reviewToken, we'll make the error message more verbose later
            vm.messageLabel.CURRENT = SettingsService.Error.DEFAULT_ERROR;
        }

        Reviews.getQuestionnaire({
            reviewToken: $scope.reviewToken
        }).then(function(response) {
            vm.providers = response.companyDetails;
            questionnaire = response;
        }, function(error) {
            vm.messageLabel.CURRENT = error && error.message ? error.message : vm.messageLabel.DEFAULT;
        });
    };

    /**
     * Checking if one checkbox is selected at least
     */
    $scope.checkSelected = function() {
        $scope.someSelected = Object.keys(vm.selectedOptions).some(function(key) {
            return vm.selectedOptions[key];
        });
    };

    /**
     * Assigning true or false to the checkbox on ng-change event
     */
    vm.onCheckBoxSelected = $scope.checkSelected;

    /**
     * Sending selected pros/technicians to be rated
     */
    vm.sendProsChecked = function() {
        vm.ratingSelected = false;
        vm.selectedProsTech = [];
        _.forIn(vm.selectedOptions, function(value, key) {
            if (value) {
                vm.selectedProsTech.push(key);
            }
        });
        // show ratings block
        vm.selectProFlag = false;
        $scope.buildQuestions();
    };

    /**
     * Get questions and build rating view
     */
    $scope.buildQuestions = function() {
        var currentProTech = {};
        vm.proTechList = [];
        if (!questionnaire.questions) {
            $scope.messageLabel.CURRENT = $scope.messageLabel.DEFAULT;
        } else {
            vm.questions = questionnaire.questions;
            for (var i = 0; i < vm.selectedProsTech.length; i++) {
                currentProTech = Reviews.getProTechById(vm.selectedProsTech[i]);
                currentProTech.rating = [];
                vm.proTechList.push(currentProTech);
            }
        }
    };

    vm.starRatingClicked = function() {
        vm.ratingSelected = false;
        var ratingNumber = 0;
        vm.validationOk = false;
        vm.firstLoad = false;
        _.forEach(vm.proTechList, function(value) {
            _.forEach(value.rating, function(key) {
                if (key !== undefined) {
                    ratingNumber++;
                }
            });
        });
        if (ratingNumber === vm.questions.length * vm.proTechList.length) {
            vm.ratingSelected = true;
        }
    };

    /**
     * Validating answers before sending them
     */
    vm.submitRate = function() {
        var ratingNumber = 0;
        vm.validationOk = false;
        vm.firstLoad = false;
        _.forEach(vm.proTechList, function(value) {
            _.forEach(value.rating, function(key) {
                if (key !== undefined) {
                    ratingNumber++;
                }
            });
        });
        if (ratingNumber === vm.questions.length * vm.proTechList.length) {
            vm.validationOk = true;
        }
        if (vm.validationOk) {
            vm.sendReviews();
        }
    };

    /**
     * Sending reviews to the service
     */
    vm.sendReviews = function() {
        var requestData = [],
            questionSet = [],
            questionValues = {};
        _.forEach(vm.questions, function(project, index) {
            questionSet = [];
            _.forEach(vm.proTechList, function(value, key) {
                questionValues = {
                    'rating': value.rating[index],
                    'firmId': value.firmId,
                    'comments': vm.reviewComments ? vm.reviewComments[key] : ''
                };
                if (value.providerId) {
                    questionValues.providerId = value.providerId;
                }
                questionSet.push(questionValues);
            });
            requestData.push({
                'questionId': project.id,
                'reviewDetails': questionSet
            });
        });
        Reviews.addProReview($scope.reviewToken, requestData).then(function() {
            vm.messageLabel.SUCCESS = SettingsService.Success.RATINGS_SUCCESS;
            vm.alreadyRated = true;
        }, function(error) {
            if (error) {
                vm.messageLabel.CURRENT = error && error.message ? error.message : vm.messageLabel.DEFAULT;
            }
        });
    };
    /**
    ******************Init****************
    */
    vm.init();
}

RateProCtrl.$inject = ['Reviews', '$scope', '$state', 'SettingsService', '_'];

(angular
    .module('RelayServicesApp.Ratings')
).controller('RateProCtrl', RateProCtrl);
