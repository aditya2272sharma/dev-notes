'use strict';

function Configure($stateProvider) {
    $stateProvider.state('account', {
        url: '/account',
        abstract: true,
        templateUrl:'assets/templates/pages/partials/abstract.html'
    }).state('account.my-account', {
        url: '/my-account',
        templateUrl: 'assets/templates/pages/account/my-account/index.html',
        controller: 'MyAccountCtrl as MyAccountCtrl',
        requiresLogin: true,
        dismissDestination: 'home.new',
        resolve : {
            'sessionStatus': require('../../services/session-status-resolve')
        }
    }).state('account.myaccount', {
        url: '/myaccount',
        templateUrl: 'assets/templates/pages/account/myAccount/index.html',
        controller: 'MyAccountCtrl as MyAccountCtrl',
        params: {
            hasHero: true
        }
    }).state('account.my-bookings', {
        url: '/my-service-requests/:page',
        templateUrl: 'assets/templates/pages/account/myBookings/index.html',
        controller: 'MyBookingsCtrl as MyBookingsCtrl',
        requiresLogin: true,
        dismissDestination: 'home.new',
        resolve : {
            'sessionStatus': require('../../services/session-status-resolve')
        }
    }).state('account.booking-detail', {
        url: '/my-service-request/:id',
        templateUrl: 'assets/templates/pages/account/myBookings/bookingDetail/index.html',
        controller: 'BookingDetailCtrl as BookingDetailCtrl',
        requiresLogin: true,
        dismissDestination: 'home.new',
        resolve : {
            'sessionStatus': require('../../services/session-status-resolve')
        }
    }).state('account.estimate-summary', {
        url: '/my-service-request/estimate-summary/:id',
        templateUrl: 'assets/templates/pages/account/myBookings/estimate-summary/index.html',
        controller: 'EstimateSummaryCtrl as EstimateSummaryCtrl',
        requiresLogin: true,
        dismissDestination: 'home.new',
        resolve : {
            'sessionStatus': require('../../services/session-status-resolve')
        }
    }).state('account.my-projects', {
        url: '/my-projects',
        templateUrl: 'assets/templates/pages/account/myProjects/index.html',
        controller: 'MyProjectsCtrl as MyProjectsCtrl',
        params: {
            hasHero: true
        },
        resolve : {
            'sessionStatus': require('../../services/session-status-resolve')
        }
    }).state('account.notifications', {
        url: '/notifications/:page',
        templateUrl: 'assets/templates/pages/account/notifications/index.html',
        controller: 'NotificationsCtrl as NotificationsCtrl',
        requiresLogin: true,
        dismissDestination: 'home.new',
        resolve : {
            'sessionStatus': require('../../services/session-status-resolve')
        }
    }).state('mobile-login', {
        url: '/mobile-login',
        templateUrl: 'assets/templates/pages/account/mobile-signin/index.html',
        controller: 'AccountMobileSignInCtrl as AccountMobileSignInCtrl',
        resolve : {
            'sessionStatus': require('../../services/session-status-resolve')
        }
    }).state('mobile-signup', {
        url: '/mobile-signup',
        templateUrl: 'assets/templates/pages/account/mobile-signup/index.html',
        controller: 'AccountMobileSignUpCtrl as AccountMobileSignUpCtrl',
        resolve : {
            'sessionStatus': require('../../services/session-status-resolve')
        }
    }).state('mobile-recover', {
        url: '/mobile-recover',
        templateUrl: 'assets/templates/pages/account/mobile-recover/index.html',
        controller: 'MobileAccountRecoverCtrl as MobileAccountRecoverController',
        resolve : {
            'sessionStatus': require('../../services/session-status-resolve')
        }
    }).state('newpass', {
        url: '/newpass',
        templateUrl: 'assets/templates/pages/account/changePassword/index.html',
        controller: 'AccountChangePasswordCtrl as AccountChangePasswordCtrl',
        dismissDestination: 'home.new',
        resolve : {
            'sessionStatus': require('../../services/session-status-resolve')
        }
    }).state('account.popover', {
        url: '/notifications/popover',
        templateUrl: 'assets/templates/pages/account/notifications/popover/index.html',
        controller: 'NotifPopoverCtrl as NotifPopoverCtrl',
        resolve : {
            'sessionStatus': require('../../services/session-status-resolve')
        }
    });
}

Configure.$inject = ['$stateProvider'];

function Run() {
}

(angular
    .module('RelayServicesApp.Account', [])
    .config(Configure)
).run(Run);
