'use strict';

function AccountSignInCtrl($window, modalInstance, LoginManagerService, SettingsService, selectFlow,
vcRecaptchaService, Environment) {
    var vm = this;

    switch (selectFlow) {
        case 'guest-checkout':
            vm.guestCheckoutFlow = true;
            break;
        case 'guest-custom':
            vm.guestCustomProjectFlow = true;
            break;
    }
    vm.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR
    };

    vm.recaptchaApiKey = SettingsService.Keys.RECAPTCHA_API_KEY;
    vm.featurePasswordRecovery = Environment.features.featurePasswordRecovery;
    if (Environment.name === 'prod') {
        vm.recaptchaApiKey = SettingsService.Keys.RECAPTCHA_PROD_API_KEY;
    }

    vm.setWidgetId = function(id) {
        vm.widgetId = id;
    };

    /**
     * Signs user in
     */
    vm.signIn = function(form) {
        if (form.$valid) {
            vm.loginData = {
                'username': vm.username,
                'password': vm.password,
                'recaptchaToken' : vcRecaptchaService.getResponse(vm.widgetId)
            };
            LoginManagerService.login(vm.loginData).then(vm.loginSuccess, vm.loginError);
        }
    };

    vm.guestLogin = function(form) {
        if (form.$valid) {
            vm.loginSuccess();
        }
    };

    /**
     * Success response of signin service
     */
    vm.loginSuccess = function() {
        modalInstance.close();
    };

    /**
     * Error response of signin service
     * @param  {Object} error -  Error response
     */
    vm.loginError = function(error) {
        vm.messageLabel.CURRENT = error.message ? error.message : vm.messageLabel.DEFAULT;
        vcRecaptchaService.reload(vm.widgetId);
    };

    vm.go = function(where) {
        modalInstance.dismiss(where);
    };

    vm.close = function() {
        modalInstance.dismiss();
    };

    vm.goToTermsOfUse = function () {
        $window.open(SettingsService.URLS.SEARS_TERMS_OF_USE_URL, '_blank');
    };

    vm.goToShopYourWayProgramTerms = function () {
        $window.open(SettingsService.URLS.SYW_PROGRAM_TERMS_URL, '_blank');
    };

    vm.goToPrivacyPolicy = function () {
        $window.open(SettingsService.URLS.SEARS_PRIVACY_POLICY_URL, '_blank');
    };
}

AccountSignInCtrl.$inject = ['$window', '$uibModalInstance', 'LoginManagerService', 'SettingsService', 'selectFlow',
'vcRecaptchaService', 'ENVIRONMENT'];

(angular
    .module('RelayServicesApp.Account')
).controller('AccountSignInCtrl', AccountSignInCtrl);
