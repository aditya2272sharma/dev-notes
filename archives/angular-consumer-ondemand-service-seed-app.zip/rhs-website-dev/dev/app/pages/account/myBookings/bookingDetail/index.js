  'use strict';

function BookingDetailCtrl(ProjectsService, SettingsService, Reviews,
    $state, $anchorScroll, Provider,
    CheckoutInfoService, $window, modal, Env,
    $sce, $filter, addressesService, $rootScope, ProjectUpdateModalService, $q) {
    var vm = this,
        projectId = $state.params.id,
        estimate,
        firmDetails,
        selectedTimeSlot,
        selectedDate,
        locationZipCode,
        // totalPrice = acceptedBid.price + acceptedBid.tax (only used for gluing it to view)
        totalPrice = 0,
        projectStatus = SettingsService.ProjetStatus;

    vm.onErrorProjectImage = SettingsService.AssetsPaths.DEFAULT_PROJECT_IMAGE;
    vm.loadInfo = false;
    vm.isStandard = false;
    vm.cancelBtn = true; // flag to decide to show or hide cancel button
    vm.rateProBtn = false;
    vm.showOrderDetails = true; // flag to enable/disable min-history pane on the right
    vm.showServiceDateTime = false;
    vm.descriptionExpanded = false;
    vm.estimateReceived = false;
    vm.hideRescheduleButton = false; // show/hide rescheudle button based on project state
    vm.proEstimate = '';
    vm.featureReschedule = (Env.features.featureReschedule === 'true');
    vm.cancelRescheduleBtn = false;
    vm.proRescheduleInitiated = false;
    vm.projectStatus = projectStatus;
    vm.projectCompletePendingClaim = false;
    vm.FormValidation = SettingsService.FormValidation;
    vm.showTransientStatus = false; // Shows status for Draft projects (in Transient state)
    vm.showServiceLocation = true;
    vm.showEditServiceLocation = true; // Edit Service Location was a feature in test back then
    vm.availableDates = []; // will contain the list of valid dates after calling availability API
    vm.showServiceLocation = true; // service location for tech-talk project has to be hidden
    vm.showFirm = true; // assuming a project has already been accepted by a firm in most of the cases

    vm.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR,
        DRAFT_STATUS: ''
    };
    vm.unauthorized = false;
    vm.firm = {
        count: 0,
        data: []
    };

    /**
     * Verifying draft API state
     */
    vm.preInit = function() {
        $anchorScroll();
        (ProjectsService
        .getProjectByProjectId(projectId, '.myservicelive_detailspage')
      ).then(function(project) {
            vm.project = project;
            vm.pathElements = [
                {
                    item: 'My ServiceLive Requests',
                    state: {
                        name: 'account.my-bookings',
                        params: {
                            category: vm.project.category,
                            id: vm.project.category.id
                        }
                    }
                },
                {
                    item: vm.project.title,
                    state: {
                        name: 'account.my-bookings',
                        params: {
                            category: vm.project.category,
                            categoryId: vm.project.category.id,
                            subcategory:  vm.project.category.subcategory,
                            id: vm.project.id
                        }
                    }
                }
            ];
            if (vm.project.serviceType === SettingsService.ServiceTypes.STANDARD ||
                vm.project.serviceType === SettingsService.ServiceTypes.STANDARD_FIXED_PRICE ||
                vm.project.serviceType === SettingsService.ServiceTypes.REPAIR ||
                vm.project.serviceType === SettingsService.ServiceTypes.TECHTALK
              ) {
                vm.isStandard = true;
            } else {
                vm.loadInfo = true;
            }
            if (vm.project.serviceType === SettingsService.ServiceTypes.TECHTALK) {
                vm.showServiceLocation = false;
            }

            // hide reschedule button on booking detail screen.
            if (vm.project.status === SettingsService.ProjetStatus.PROJECT_CANCELLED ||
                vm.project.status === SettingsService.ProjetStatus.PROJECT_EXPIRED ||
                vm.project.serviceType === SettingsService.ServiceTypes.TECHTALK){
                vm.hideRescheduleButton = true;
            }

            if (vm.project.location && vm.project.location.addressId !== '0') {
                vm.showEditServiceLocation = true;
            } else {
                vm.showEditServiceLocation = false;
            }
            selectedDate = vm.project.startDate;
            selectedTimeSlot = vm.project.timeSlot;
            locationZipCode = vm.project.location.zipCode;
            vm.project = vm.project;
            vm.firm.serviceType = vm.project.serviceType;
            vm.loadInfo = true;
            vm.project.consolidatedDate = (function(date) {
                if (date === moment(new Date()).format('YYYY-MM-DD')) {
                    return 'Today';
                } else {
                    return moment(date).format('[Last] dddd ll');
                }
            })(vm.project.startDate);
            vm.resolvePrerequisites(project)
            .then(function() {
                vm.formatProjectDescription();
                if (project.serviceOrderId === null) {
                    vm.loadInfo = true;
                    vm.hideRescheduleButton = true;
                    vm.cancelBtn = false;
                    vm.showTransientStatus = true;
                    vm.showEditServiceLocation = false;
                    if (project.status !== 'CANCELLED') {
                        vm.messageLabel.DRAFT_STATUS = [
                            'We have submitted your project.',
                            ' We are awaiting firm\'s response'
                        ].join('');
                    } else {
                        vm.messageLabel.DRAFT_STATUS = 'You\'ve cancelled this project';
                    }
                    return;
                } else {
                    vm.init();
                }
            });

        });
    };

    /**
     * Getting project information
     */
    vm.init = function() {
        (ProjectsService
        .getProjectEstimatesByProjectId(projectId)
        ).then(function(estimateObject) {
            estimate = [];
            firmDetails = [];
            vm.providerName = '';
            if (estimateObject.estimates && estimateObject.estimates.data || estimateObject.estimates.count !== 0) {
                estimate = estimateObject.estimates.data;
            }
            if (estimateObject.firms && estimateObject.firms.data && estimateObject.firms.count !== 0) {
                firmDetails = estimateObject.firms.data;
                vm.firm = $filter('filter')(firmDetails, {id:estimate[0].id})[0];
                vm.providerName = $filter('safeUrls')(vm.firm.title);
            }
            angular.extend(vm.project, estimateObject.project);
            
            // Format timeslots when specific timeslot hasn't been accepted
            var timeSlot = vm.project.timeSlot.trim();
            if ((timeSlot === "-" || timeSlot === "") && angular.isArray(vm.project.preferredSlots)) {
                vm.project.timeSlot = vm.project.preferredSlots.join(', ');
            }
            // Calculate order total including tax
            // A truthy `acceptedBid` implies the order has received an estimate
            // A payment is valid if we have an estimate
            // `bid` price alone doesn't guarantee that this order will be booked
            if (estimate[0] && estimate[0].acceptedBid) {
                totalPrice = estimate[0].acceptedBid.price;
                totalPrice += (estimate[0].acceptedBid.tax) ? estimate[0].acceptedBid.tax : 0;
            }

            vm.proEstimate = {
                estimate: estimate[0],
                firm: firmDetails[0],
                project: estimateObject.project,
                estimatesCount: estimate.length,
                firmsCount: firmDetails.length,
                orderTotal: totalPrice
            };
            vm.initEstimate();
        }, function(error) {
            if (error) {
                vm.messageLabel.CURRENT = error.message ? error.message : vm.messageLabel.DEFAULT;
                if (error.status === 401) {
                    vm.unauthorized = true;
                }
            }
        });
    };

    vm.initEstimate = function() {
        vm.estimateData = estimate;
        estimate.forEach(function(e) {
            if (e.status === projectStatus.PROJECT_ACCEPTED ||
                e.status === projectStatus.PROJECT_REJECTED ||
                e.status === projectStatus.PROJECT_DECLINED ||
                e.status === projectStatus.PROJECT_NEW ||
                vm.project.status === projectStatus.PROJECT_CANCELLED ||
                vm.project.status === projectStatus.PROJECT_EXPIRED) {

                vm.showOrderDetails = true;
            }
            if (!e.status && vm.project.status === projectStatus.PROJECT_WAITING) {
                vm.showOrderDetails = true;
            }
            if (vm.isStandard || (!vm.isStandard && e.status === projectStatus.PROJECT_ACCEPTED)) {
                vm.showServiceDateTime = true;
            }
            if (e.status === projectStatus.PROJECT_NEW && !vm.isStandard) {
                vm.estimateReceived = true;
            }
        });
        if (vm.project.serviceType === SettingsService.ServiceTypes.STANDARDV3 ||
            vm.project.serviceType === SettingsService.ServiceTypes.TECHTALK) {
            // we don't get estimate sub status in case of TT & SSv3 projects
            // Therefore, the only way around this problem to show date & time
            // is to explicitly check for the project status

            // As of now, Rescheduling isn't supported on TT I believe.
            // Note that we might face issues with date/time in case of rescheduling
            if (vm.project.status === projectStatus.PROJECT_CANCELLED ||
                vm.project.status === projectStatus.PROJECT_COMPLETE ||
                vm.project.status === projectStatus.PROJECT_COMPLETE_FAIL ||
                vm.project.status === projectStatus.PROJECT_DECLINED ||
                vm.project.status === projectStatus.PROJECT_EXPIRED) {
                vm.showServiceDateTime = false;
            } else {
                vm.showServiceDateTime = true;
            }
        }
        if (vm.project.status === projectStatus.PROJECT_CANCELLED ||
            vm.project.status === projectStatus.PROJECT_COMPLETE ||
            vm.project.status === projectStatus.PROJECT_COMPLETE_FAIL ||
            vm.project.status === projectStatus.PROJECT_DECLINED ||
            vm.project.status === projectStatus.PROJECT_EXPIRED) {

            vm.cancelBtn = false;
        } else {
            vm.cancelBtn = true;
        }
        if (vm.project.status === projectStatus.ESTIMATE_REJECTED) {
            vm.cancelBtn = true;
        }
        if (vm.project.status === projectStatus.RESCHEDULE_INITIATED) {
            vm.cancelRescheduleBtn = true;
        }
        if (vm.project.status === projectStatus.RESCHEDULE_INITIATED_BY_PROVIDER) {
            vm.proRescheduleInitiated = true;
        }
        if (vm.project.status === projectStatus.COMPLETE_PENDING_CLAIM) {
            vm.projectCompletePendingClaim = true;
        }
        if (vm.project.status === projectStatus.PROJECT_COMPLETE ||
            vm.project.status === projectStatus.PROJECT_COMPLETE_FAIL) {
            (Reviews
            .getReview(projectId)
            ).then(function(response) {
                if (response) {
                    vm.rateProBtn = false;
                } else {
                    vm.rateProBtn = true;
                }
            });
        }
        if (vm.project.status === projectStatus.ESTIMATE_UPDATED ||
                vm.project.status === projectStatus.PROJECT_COMPLETE ||
                vm.project.status === projectStatus.PROJECT_COMPLETE_FAIL ||
                vm.project.status === projectStatus.COMPLETE_PENDING_CLAIM ||
                vm.project.status === projectStatus.RESCHEDULE_INITIATED ||
                vm.project.status === projectStatus.PROVIDER_CHECK_IN ||
                vm.project.status === projectStatus.PROJECT_WAITING ||
                vm.project.status === projectStatus.RESCHEDULE_INITIATED_BY_PROVIDER) {
            vm.hideRescheduleButton = true;
        }
        if (!vm.isStandard) {
            if (vm.project.status === projectStatus.PROJECT_WAITING || vm.project.status === projectStatus.ESTIMATE_RECEIVED ||
                    vm.project.status === projectStatus.ESTIMATE_ACCEPTED ||
                    vm.project.status === projectStatus.ESTIMATE_REJECTED) {
                vm.hideRescheduleButton = true;
            }
        }
        if (vm.project.status === projectStatus.PROJECT_COMPLETE ||
                vm.project.status === projectStatus.PROJECT_COMPLETE_FAIL ||
                vm.project.status === projectStatus.COMPLETE_PENDING_CLAIM ||
                vm.project.status === projectStatus.PROVIDER_CHECK_IN ||
                vm.project.status === projectStatus.PROJECT_CANCELLED) {
            vm.showEditServiceLocation = false;
        }

        // For NS, SSv2 & SSv3, if the project hasn't been accepted
        // or if it has been released, the estimates data returns `[]`
        // which we can look into & determine the status 
        if (!vm.estimateData || !vm.estimateData[0]) {
            // we should hide the reschedule button, otherwise we'll see
            // a modal without a provider name, without price + tax 
            // vm.hideRescheduleButton = true;
        }

        // In STANDARD_FIXED_PRICE projects we receive multiple estimates
        // for a single project.
        // if (vm.project.serviceType === SettingsService.ServiceTypes.STANDARD_FIXED_PRICE) {
        if (vm.estimateData.length > 1) {
            vm.firm.title = '';
        }
        // }
    };

    vm.formatProjectDescription = function() {
        if (vm.project.serviceType === SettingsService.ServiceTypes.NON_STANDARD) {
            if (vm.project.taskDescription) {
                vm.description = $sce.trustAsHtml(vm.project.taskDescription);
            } else if (vm.project.taskDescription) {
                vm.description = $sce.trustAsHtml(vm.project.category.subCategoryDescription);
            }
        } else {
            if (vm.project.category.subCategoryDescription) {
                vm.description = $sce.trustAsHtml(vm.project.category.subCategoryDescription);
            }
        }
        if (vm.description && String(vm.description).length > 482) {
            vm.descExpandable = true;
        }
    };

    vm.estimateAccept = function(acceptRejectObject, firm, updatedDate, updatedTimeSlot) {

        CheckoutInfoService.setCheckout({
            order: acceptRejectObject,
            project: projectId,
            firm: firm,
            selectedTime: updatedTimeSlot,
            selectedDate: updatedDate,
            zipcode: locationZipCode,
            availableDates: vm.availableDates
        });

        $state.go('payment.checkout');
    };

    vm.estimateReject = function() {
        $window.location.reload();
    };

    vm.estimateRejectAndReselect = function() {
        var project = {
            /*subcategoryid: vm.project.category.id,*/
            title: vm.project.category.title,
            taskTitle: vm.project.title,
            addressline1: vm.project.location.addressLine1,
            zipcode: vm.project.location.zipCode,
            images: vm.project.images,
            description: vm.project.taskDescription,
            servicetype: SettingsService.ServiceTypes.NON_STANDARD,
            catalogid: vm.project.category.rowid
        };
        ProjectsService.createCustomProject(project).then(function(response) {
            ProjectsService.getProjectEstimatesFirms(response.id).then(function(responseDet) {
                if (responseDet.items.length > 0) {
                    $state.go('projects.estimates', {id: response.id});
                }
            });
        }, function(error) {
            vm.messageLabel.CURRENT = error.message ? error.message : vm.messageLabel.DEFAULT;
        });
    };

    vm.estimateRejectAndCancel = function() {
        $state.go('account.my-bookings');
    };

    vm.estimateError = function() {
        //$log.debug(errorResponse);
    };

    vm.showCancelServiceConfirm = function() {
        var modalInstance = modal.open({
            animation: true,
            size: 'sm',
            controller: 'cancelServiceCtrl',
            controllerAs: 'cancelServiceCtrl',
            resolve: {
                project: function() {
                    return projectId;
                }
            },
            templateUrl: [
                'assets/templates/components/cancel-service/',
                'index.html'
            ].join('')
        });

        modalInstance.result.then(function() {
            $window.location.reload();
        }, function(cancelStatus) {
            if (cancelStatus) {
                $state.go($state.current, {}, {reload: true});
            }
        });
    };

    vm.showCancelServiceConfirm = function(event) {
        event.target.disabled = true;
        (ProjectsService
        .getProjectByProjectId(projectId)
        ).then(function(projectObject) {
            if (projectObject.status !== projectStatus.PROJECT_CANCELLED) {
                var modalInstance = modal.open({
                    animation: true,
                    size: 'sm',
                    controller: 'cancelServiceCtrl',
                    controllerAs: 'cancelServiceCtrl',
                    resolve: {
                        project: function() {
                            return projectId;
                        }
                    },
                    templateUrl: [
                        'assets/templates/components/cancel-service/',
                        'index.html'
                    ].join('')
                });

                modalInstance.result.then(function() {
                    $window.location.reload();
                }, function(cancelStatus) {
                    if (cancelStatus) {
                        $state.go($state.current, {}, {reload: true});
                    }
                });
            }else {
                vm.messageLabel.CURRENT =  vm.messageLabel.CANCEL;
            }
            event.target.disabled = false;
        }, function(error) {
            vm.messageLabel.CURRENT = error.message ? error.message : vm.messageLabel.DEFAULT;
            event.target.disabled = false;
        });
    };

    vm.showRescheduleConfirm = function() {
        var projectDetails = {
            estimateObject: estimate[0],
            projectObject: vm.project,
            firms: vm.firm
        };
        var modalInstance = modal.open({
            animation: true,
            size: 'lg',
            controller: 'RescheduleYourAppointment',
            controllerAs: 'RescheduleYourAppointment',
            resolve: {
                project: function() {
                    return projectDetails;
                },
                availableDates: function() {
                    // The resolution here calls the availability API for `reschedule`
                    // And, this isn't the regular `/availability` API.
                    return ProjectsService.checkRescheduleAvailability(vm.project.id);
                }
            },
            templateUrl: [
                'assets/templates/components/reschedule/reschedule-your-appointment/',
                'index.html'
            ].join('')
        });

        modalInstance.result.then(function() {
            $window.location.reload();
        });
    };

    vm.showProReschedule = function() {
        var modalInstance = modal.open({
            animation: true,
            size: 'md',
            controller: 'proRescheduleCtrl',
            controllerAs: 'proRescheduleCtrl',
            resolve: {
                project: function() {
                    return estimate;
                }
            },
            templateUrl: [
                'assets/templates/components/reschedule/pro-reschedule/',
                'index.html'
            ].join('')
        });

        modalInstance.result.then(function() {
            $window.location.reload();
        });
    };

    vm.cancelReschedule = function() {
        var modalInstance = modal.open({
            animation: true,
            size: 'md',
            controller: 'CancelReschedule',
            controllerAs: 'CancelReschedule',
            resolve: {
                project: function() {
                    return projectId;
                }
            },
            templateUrl: [
                'assets/templates/components/reschedule/cancel-reschedule/index.html'
            ].join('')
        });

        modalInstance.result.then(function() {
            $window.location.reload();
        });
    };
    vm.showImages = function() {
        vm.buttonDisabled = true;
        var modalImg = modal.open({
            animation: true,
            size: 'md',
            controller: 'proconImages',
            controllerAs: 'proconImages',
            resolve: {
                project: function() {
                    return projectId;
                }
            },
            templateUrl: [
                'assets/templates/components/provider-consumer-image-modal/index.html'
            ].join('')
        });
        modalImg.result.then(function() {
            $window.location.reload();
        })
        .finally(function() {
            vm.buttonDisabled = false;
        });
    };
    vm.showEstimateActionFailedMsg = function() {
        vm.messageLabel.CURRENT = vm.messageLabel.DEFAULT;
    };

    vm.showGallery = function(openImageIndex) {
        modal.open({
            animation: true,
            windowClass: 'photo-detail',
            controller: 'DetailsGalleryCtrl as DetailsGalleryController',
            templateUrl: 'assets/templates/pages/account/myBookings/detail-gallery/index.html',
            resolve: {
                projectImages: function() {
                    return {
                        'images' : vm.project.images,
                        'openIndex': openImageIndex
                    };
                }
            }
        });
    };

    vm.editServiceLocation = function() {
        vm.showEditServiceLocation = false;
        var dateInfo = {
            date: $filter('date')(vm.project.startDate, 'yyyy-MM-dd'),
            timeSlot: vm.project.timeSlot
        };
        var enableEditServiceLocation = function() {
            vm.showEditServiceLocation = true;
        };
        ProjectUpdateModalService.openModal(vm.project, dateInfo, function() {
            enableEditServiceLocation();
            vm.preInit();
            $rootScope.$broadcast('address:change');
        }, enableEditServiceLocation, enableEditServiceLocation, {
            nsUpdateModal: false,
            title: 'Edit Service Location',
            currentAddressId: vm.project.location.addressId,
            editServiceOrder: true
        });
    };

    /**
     * Hide the firms for released orders
     */
    vm.changeFirmVisibility  = function() {
      vm.showFirm = false;
    };

    /**
     * In future, this method can be used to resolve all prerequisites &
     * dependencies. To resolve multiple dependencies use `$q.all` and
     * resolved responses will be available in an array format
     * refer: https://toddmotto.com/promises-angular-q
     */
    vm.resolvePrerequisites = function(project) {
        var deferred = $q.defer();
        ProjectsService
        .checkAvailability(
            project.category.id,  // same as subcategoryId
            project.location.zipCode,
            project.serviceType
        )
        .then(function(response) {
            // The response is collected here to pass it onto the Payments Page
            // Because, serviceType & Category Id can't always be passed to it
            vm.availableDates = response && response.data || [];
            $rootScope.availableDates = response && response.data || [];
            deferred.resolve();
        }, function() {
            deferred.reject();
        });
        return deferred.promise;
    };

    vm.preInit();
}

BookingDetailCtrl.$inject = [
    'ProjectsService', 'SettingsService', 'Reviews',
    '$state', '$anchorScroll', 'Provider',
    'CheckoutInfoService', '$window', '$uibModal', 'ENVIRONMENT',
    '$sce', '$filter', 'addressesService', '$rootScope',
    'ProjectUpdateModalService', '$q'
];

(angular
    .module('RelayServicesApp.Account')
).controller('BookingDetailCtrl', BookingDetailCtrl);
