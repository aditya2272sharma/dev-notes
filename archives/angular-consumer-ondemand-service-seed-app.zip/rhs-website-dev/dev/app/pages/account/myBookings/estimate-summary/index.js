'use strict';

function EstimateSummaryCtrl(EstimateActionsService, SettingsService, $state,
    EstimateSummaryInfoService, ProjectsService, moment,
    $anchorScroll, CheckoutInfoService, $sce, _, ENV) {
    var vm = this,
    projectStatus = SettingsService.ProjetStatus;
    vm.rejectDropdownOptions = SettingsService.EstimateRejectDropdownOptions;
    vm.estimate = '';
    vm.project = '';
    vm.isButtonEnable = 'false';
    vm.featurePaymentsV2 = (ENV.features.featurePaymentsV2 === 'true');
    vm.init = function() {
        if (!EstimateSummaryInfoService.hasEstimateSummary()) {
            $state.go('account.booking-detail', {id: $state.params.id});
        } else {
            var estimateInfo = EstimateSummaryInfoService.getEstimateSummary();
            vm.estimate = estimateInfo.estimate;
            vm.project = estimateInfo.project;
            vm.firm = estimateInfo.firm;
            vm.availableDates = estimateInfo.availableDates;
            if (vm.project.status === projectStatus.ESTIMATE_RECEIVED || vm.project.status === projectStatus.ESTIMATE_UPDATED) {
                vm.isButtonEnable = 'true';
            }
            vm.computerGeneratedTxt = SettingsService.EstimateSummary.COMPUTER_GENERATED_PAGE_TXT;
            $anchorScroll();
            (ProjectsService
                    .getEstimateSummary(vm.project.id, vm.estimate.bid.estimateId)
            ).then(function(estimateSummary) {
                vm.summary = estimateSummary;
                var i = 0;
                var j = 0;
                _.forEach(vm.summary.parts, function(eachPart) {
                    if (vm.summary.parts[i].description) {
                        vm.summary.parts[i].description = $sce.trustAsHtml
                        (eachPart.description.replace(/(?:\r\n|\r|\n)/g, '</br>'));
                    }
                    if (vm.summary.parts[i].additionalDetails) {
                        vm.summary.parts[i].additionalDetails = $sce.trustAsHtml
                        (eachPart.additionalDetails.replace(/(?:\r\n|\r|\n)/g, '</br>'));
                    }
                    i = i + 1;
                });
                _.forEach(vm.summary.labortasks, function(eachlabortask) {
                    if (vm.summary.labortasks[j].description) {
                        vm.summary.labortasks[j].description = $sce.trustAsHtml
                        (eachlabortask.description.replace(/(?:\r\n|\r|\n)/g, '</br>'));
                    }
                    if (vm.summary.labortasks[j].additionalDetails) {
                        vm.summary.labortasks[j].additionalDetails = $sce.trustAsHtml
                        (eachlabortask.additionalDetails.replace(/(?:\r\n|\r|\n)/g, '</br>'));
                    }
                    j = j + 1;
                });
                if (vm.summary.comments) {
                    vm.summary.comments = $sce.trustAsHtml(vm.summary.comments.replace(/(?:\r\n|\r|\n)/g, '</br>'));
                }
                if (vm.summary && vm.summary.estimateDate) {
                    vm.invoiceDate = moment(vm.summary.estimateDate).format('ddd[,] MMM D[,] YYYY');
                }
            });
        }
    };

    vm.loadServiceRequestDetails = function() {
        $state.go('account.booking-detail', {id: $state.params.id});
    };

    vm.acceptEstimate = function() {
        if (vm.featurePaymentsV2) {
            EstimateActionsService.acceptRejectEstimateWithoutDate('Accept', vm.estimate, vm.project, vm.availableDates);
        } else {
            EstimateActionsService.acceptRejectEstimate('Accept', vm.estimate, vm.project, vm.availableDates);
        }
    };

    /*vm.rejectEstimate = function() {
        EstimateActionsService.acceptRejectEstimate('Reject', vm.estimate, vm.project);
    };*/

    vm.rejectEstimate = function(selectedName) {
        if (SettingsService.EstimateRejectOptions.CREATE === selectedName) {
            EstimateActionsService.rejectEstimateAndCreateNewProject(
                vm.project, vm.estimate.bid.estimateId);
        } else if (SettingsService.EstimateRejectOptions.CANCEL === selectedName) {
            EstimateActionsService.rejectEstimateAndCancelProject(
                vm.project.id, vm.estimate.bid.estimateId);
            $state.go($state.current, {}, {reload: true});
        }  else if (SettingsService.EstimateRejectOptions.REJECT === selectedName) {
            EstimateActionsService.rejectTheEstimate(
               vm.project.id, vm.estimate.bid.estimateId);
            $state.go($state.current, {}, {reload: true});
        }
    };

    vm.goToCheckout = function() {
        var order = {
            id: vm.project.orderId,
            price: vm.estimate.bid.price,
            tax: vm.estimate.bid.tax
        };
        CheckoutInfoService.setCheckout({
            order: order,
            project: vm.project.id,
            firm: vm.estimate,
            zipcode: vm.project.location.zipCode,
            selectedTime: vm.project.timeSlot,
            selectedDate: vm.project.startDate,
            isNSFlow: true,
            availableDates: vm.availableDates
        });

        $state.go('payment.checkout');
    };

    vm.init();
}

EstimateSummaryCtrl.$inject = [
    'EstimateActionsService', 'SettingsService', '$state',
    'EstimateSummaryInfoService', 'ProjectsService', 'moment',
    '$anchorScroll', 'CheckoutInfoService', '$sce', '_', 'ENVIRONMENT'
];

(angular
    .module('RelayServicesApp.Account')
).controller('EstimateSummaryCtrl', EstimateSummaryCtrl);
