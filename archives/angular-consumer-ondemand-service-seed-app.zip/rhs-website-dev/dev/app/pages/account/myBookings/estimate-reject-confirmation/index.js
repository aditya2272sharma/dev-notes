'use strict';

function RejectConfirmationController($scope, $uibModalInstance, callback,
    SettingsService, projectDetails, ProjectsService, estimateDetails, EstimateActionsService, $state) {
    var vm = this;
    vm.rejectDropdownOptions = SettingsService.EstimateRejectDropdownOptions;

    $scope.messageLabel = {
        CURRENT: ''
    };

    vm.close = function() {
        $uibModalInstance.dismiss();
    };

    vm.rejectEstimate = function(selectedName) {

        if (SettingsService.EstimateRejectOptions.CREATE === selectedName) {
            EstimateActionsService.rejectEstimateAndCreateNewProject(
                projectDetails, estimateDetails.bid.estimateId);
            vm.close();
        } else if (SettingsService.EstimateRejectOptions.CANCEL === selectedName) {
            EstimateActionsService.rejectEstimateAndCancelProject(
                projectDetails.id, estimateDetails.bid.estimateId);
            vm.close();
        }  else if (SettingsService.EstimateRejectOptions.REJECT === selectedName) {
            EstimateActionsService.rejectTheEstimate(
                projectDetails.id, estimateDetails.bid.estimateId);
            $state.go($state.current, {}, {reload: true});
            vm.close();
        }
    };

    /*vm.rejectEstimatedetails = function(action) {
        (ProjectsService.acceptOrRejectProjectEstimation
            (projectDetails.id, estimateDetails.bid.estimateId, 'Reject')).then(function() {
            var cancelService = {
                projectId: projectDetails.id,
                reason: 'Product Damaged',
                comment: 'Product Damaged'
            };
            (ProjectsService.getCancelMessageByProjectId(projectDetails.id))
            .then(function(cancelMessage) {
                cancelService.amount = cancelMessage.charge;
                (ProjectsService.cancel(cancelService)).then(function() {
                    if (action === 'Create') {
                        vm.createNewCustomProject();
                    } else {
                        $state.go($state.current, {}, {reload: true});
                    }
                    vm.close();
                });
            });
        });
    };*/

    vm.createNewCustomProject = function() {
        var project = {
            title: projectDetails.title,
            taskTitle: projectDetails.title,
            addressline1: projectDetails.location.addressLine1,
            zipcode: projectDetails.location.zipCode,
            images: projectDetails.images,
            description: projectDetails.taskDescription,
            servicetype: 'NON_STANDARD',
            catalogid: projectDetails.category.rowid
        };
        ProjectsService.createCustomProject(project).then(function(response) {
            ProjectsService.getProjectEstimatesFirms(response.id).then(function(responseDet) {
                if (responseDet.items.length > 0) {
                    $state.go('projects.estimates', {id: response.id});
                }
            });
        });
    };
}

RejectConfirmationController.$inject = ['$scope', '$uibModalInstance', 'callback',
'SettingsService', 'projectDetails', 'ProjectsService', 'estimateDetails', 'EstimateActionsService', '$state'];
(angular
    .module('RelayServicesApp.Components')
).controller('RejectConfirmationController', RejectConfirmationController);
