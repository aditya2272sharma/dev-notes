'use strict';

function MyBookingsCtrl(LoginManagerService, ProjectViewService,
     SettingsService, $anchorScroll, $state, ENVIRONMENT, _, moment) {
    var vm = this,
        projectStatus = SettingsService.ProjetStatus;

    vm.maxSize = 12;
    vm.showPagination = false;
    vm.currentPage = $state.params.page || 1;
    vm.maxPageNo = 5;
    vm.onErrorUserImage = SettingsService.AssetsPaths.DEFAULT_AVATAR_IMAGE;
    vm.onErrorProjectImage = SettingsService.AssetsPaths.DEFAULT_PROJECT_IMAGE;
    vm.customProject = ENVIRONMENT.features.customProject;
    vm.myRequestsMessage = SettingsService.Messages.LOADING;

    vm.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR,
        DRAFT_STATUS: ''
    };
    /** Init function calls user information and user project info **/

    vm.init = function() {
        vm.userInfo = LoginManagerService.getUser();
        $anchorScroll();
        ProjectViewService.projectview(vm.currentPage).then(vm.myProjectsSuccess, vm.myProjectsError);
    };

    /**
    *   Successfull response of my projects service
    *   @param {object} response - Response with user projects info
    **/
    vm.myProjectsSuccess = function(response) {
        vm.userProjects = response;
        vm.totaluserProjectItems = response.totalCount;
        //vm.maxSize = response.count;
        if (Number(vm.totaluserProjectItems) === 0) {
            vm.myRequestsMessage = SettingsService.Messages.NO_PROJECTS_CREATED;
        }
        if (vm.totaluserProjectItems > vm.maxSize) {
            vm.showPagination = true;
            vm.myRequestsMessage = '';
        }
    };

    vm.pageChanged = function() {
        //ProjectViewService.projectview(vm.currentPage).then(vm.myProjectsSuccess, vm.myProjectsError);
        $state.go('account.my-bookings', {page : vm.currentPage});
    };

    /**
     * Error response of my projects service
     * @param  {Object} error -  Error response
     */
    vm.myProjectsError = function(error) {
        vm.serverError = true;
        vm.messageLabel.CURRENT = error && error.message ? error.message : SettingsService.Error.DEFAULT_ERROR;
        vm.myRequestsMessage = vm.messageLabel.CURRENT;
    };

    vm.showServiceTimeSlot = function(project) {
        if (project.serviceType === SettingsService.ServiceTypes.STANDARD ||
                project.serviceType === SettingsService.ServiceTypes.REPAIR ||
                project.serviceType === SettingsService.ServiceTypes.STANDARD_FIXED_PRICE) {
            vm.showTime = true;
            if (project.status === projectStatus.PROJECT_WAITING) {
                vm.showTime = false;
            }

        } else if (project.serviceType === SettingsService.ServiceTypes.NON_STANDARD) {
            vm.showTime = true;
            if (project.status === projectStatus.PROJECT_WAITING ||
                project.status === projectStatus.ESTIMATE_RECEIVED) {

                vm.showTime = false;

            } else if (project.status === projectStatus.PROJECT_CANCELLED ||
                project.status === projectStatus.PROJECT_EXPIRED) {

                if (project.estimate.status === projectStatus.PROJECT_NEW ||
                    project.estimate.status === null || project.estimate.status === projectStatus.PROJECT_DECLINED) {

                    vm.showTime = false;
                }
            }
            if (project.status === projectStatus.PROVIDER_CHECK_IN) {
                if (project.estimate.status === projectStatus.PROVIDER_CHECK_IN_ESTIMATE_UPDATED) {
                    project.status = projectStatus.ESTIMATE_UPDATED;
                }
            }
        }

        // for `my-service-requests` page, the projectView API hasn't been updated
        // therefore, it continues to show `CONFIRMED` as status even for `ACCEPTEd`
        // orders, and also we don't get estimate sub status in case of TT & SSv3 projects
        // There is no definitive way to fix the issue in https://trello.com/c/Vi3l7PUL/

        // As of now, Rescheduling isn't supported on TT I believe.
        // Note that we might face issues with date/time in case of rescheduling

        if (project.startDate === null) {
            if (project.preferredStartDates && project.preferredStartDates.length >= 1) {
                _.each(project.preferredStartDates, function(date, index) {
                    project.preferredStartDates[index] = moment(date).format('ddd[,] MMM D[,] YYYY');
                });
                project.formattedStartDate = project.preferredStartDates.join(', ');
                project.timeSlot = project.preferredSlots.join(', ');
                vm.showTime = true;
            }
        }

        return vm.showTime;
    };

    vm.showFirmDetails = function(project) {
        if (project.estimate) {
            if (project.serviceType === SettingsService.ServiceTypes.STANDARD_FIXED_PRICE) {
                return false;
            }
            if (project.startDate === null) {
                return false;
            }
            return true;
        }
    };

    vm.init();
}

MyBookingsCtrl.$inject = ['LoginManagerService', 'ProjectViewService', 'SettingsService',
'$anchorScroll', '$state', 'ENVIRONMENT', '_', 'moment'];

(angular
    .module('RelayServicesApp.Account')
).controller('MyBookingsCtrl', MyBookingsCtrl);
