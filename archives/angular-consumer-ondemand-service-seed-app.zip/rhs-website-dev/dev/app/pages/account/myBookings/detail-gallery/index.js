'use strict';

function DetailsGalleryCtrl(modalInstance, projectImages) {
    var vm = this;
    vm.images = projectImages.images;
    vm.openIndex = projectImages.openIndex;
}

DetailsGalleryCtrl.$inject = ['$uibModalInstance', 'projectImages'];

(angular
    .module('RelayServicesApp.Account')
).controller('DetailsGalleryCtrl', DetailsGalleryCtrl);
