'use strict';

function NotifPopoverCtrl() {
    var vm = this;

    vm.init = function() {
    };

    vm.init();

}

(angular
    .module('RelayServicesApp.Account')
).controller('NotifPopoverCtrl', NotifPopoverCtrl);
