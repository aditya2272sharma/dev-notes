'use strict';

function NotificationsCtrl($state, Notifications, SettingsService, $rootScope) {
    var vm = this;

    vm.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR
    };

    vm.maxSize = 10;
    vm.currentPage = $state.params.page || 1;
    vm.maxPageNo = 5;

    vm.goToNotificationDetail = function(notification) {
        Notifications.readNotification(notification.id).then(function() {
            if (notification.read === false) {
                notification.read = true;
                if ($rootScope.unreadNotificationsNumber > 0) {
                    --$rootScope.unreadNotificationsNumber;
                }
            }
            var projectId = notification.metaData.id ? notification.metaData.id : notification.metaData.projectId;
            if (projectId) {
                $state.go('account.booking-detail', {id: projectId});
            } else {
                $state.reload();
            }
        });
    };

    vm.pageChanged = function() {
        $state.go('account.notifications', {page : vm.currentPage});
    };

    vm.init = function() {
        Notifications.getNotificationsSummary()
        .then(function(response) {
            vm.notificationsCount = response.count;
        }, function(response) {
            vm.messageLabel.CURRENT = response.message ? response.message : vm.messageLabel.DEFAULT;
        });

        Notifications.getNotificationsByUser(vm.currentPage)
        .then(function(response) {
            vm.notifications = response.data;
        }, function(response) {
            vm.messageLabel.CURRENT = response.message ? response.message : vm.messageLabel.DEFAULT;
        });
    };

    vm.init();

}

NotificationsCtrl.$inject = ['$state', 'Notifications', 'SettingsService', '$rootScope'];

(angular
    .module('RelayServicesApp.Account')
).controller('NotificationsCtrl', NotificationsCtrl);
