'use strict';

function AccountChangePasswordCtrl($location, LoginManagerService, accountModalService, SettingsService, $state,
$rootScope) {
    var vm = this;
    vm.passResetSuccess = false;
    vm.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR
    };

    vm.init = function() {
        // jscs:disable
        vm.linkValidationData = {
            'username': $location.search().logonid,
            'authToken' : $location.search().auth_token
        };// jscs:enable
        LoginManagerService.validateLink(vm.linkValidationData).then(function() {
            vm.passResetSuccess = true;
        }, function(response) {
            vm.messageLabel.CURRENT = response.message ? response.message : vm.messageLabel.DEFAULT;
        });
    };

    vm.change = function(form) {
        if (form.$valid) {
            // jscs:disable
            vm.newPasswordData = {
                'username': $location.search().logonid,
                'authToken' : $location.search().auth_token,
                'newPassword' : vm.password
            };// jscs:enable
            LoginManagerService.changePassword(vm.newPasswordData).then(function() {
                vm.passResetSuccess = true;
                delete vm.linkValidationData.authToken;
                delete vm.newPasswordData.authToken;
            }, function(response) {
                vm.messageLabel.CURRENT = (response && response.message) ? response.message : vm.messageLabel.DEFAULT;
            });
        }
    };

    vm.signIn = function() {
        $state.go('home.new');
        accountModalService.signInInit();
    };

    function validate (event) {
        var fieldValue = event.target.value;
        vm.firstname = $rootScope.firstName;
        vm.lastname = $rootScope.lastName;
        vm.email = $rootScope.email;

        if (!fieldValue) {
            vm.passwordValidationError = 'Password is required';
            return;
        }

        if (fieldValue.length < 8) {
            vm.passwordValidationError = 'Password too small';
            return;
        }

        if (!/[A-z]/.test(fieldValue)) {
            vm.passwordValidationError = 'Must contain letters';
            return;
        }

        if (!/[0-9]/.test(fieldValue)) {
            vm.passwordValidationError = 'Password must contain numbers';
            return;
        }

        if (fieldValue.indexOf(vm.firstname) > -1 || fieldValue.indexOf(vm.lastname) > -1) {
            vm.passwordValidationError = 'Password must not be\/contain your name';
            return;
        }

        if (fieldValue.indexOf(vm.email) > -1) {
            vm.passwordValidationError = 'Password must not be\/contain your Email Id';
            return;
        }

        if (/([0-9a-zA-Z])\1{3,}/gi.test(fieldValue)) {
            vm.passwordValidationError = 'Can\'t repeat same character more than 3 times in a row';
            return;
        }

        if (/([?!\s])/gi.test(fieldValue)) {
            vm.passwordValidationError = 'No spaces, ! or ?';
            return;
        }
        /*
        // More rules can be added as per requirement
        if (/[~!@#$%^&*()_+=-`<>/]/.test(fieldValue)) {
            ngModel.$setValidity('passwordValidation', false);
            scope.passwordValidationError = 'Password must contain special characters';
            return undefined;
        }
        */
        vm.passwordValidationError = null;
    }
    vm.validate = validate;

}

AccountChangePasswordCtrl.$inject = ['$location', 'LoginManagerService', 'accountModalService', 'SettingsService', '$state',
'$rootScope'];

(angular
    .module('RelayServicesApp.Account')
).controller('AccountChangePasswordCtrl', AccountChangePasswordCtrl);
