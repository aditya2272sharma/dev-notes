'use strict';

function MyAccountCtrl(LoginManagerService, SettingsService, $anchorScroll,
PaymentMethodsService, $rootScope) {
    var vm = this;
    vm.onErrorUserImage = SettingsService.AssetsPaths.DEFAULT_AVATAR_IMAGE;
    vm.hideTitle = true;
    /**
     * Init function calls user information
     */
    vm.init = function() {
        $anchorScroll();
        vm.section = 'personal-info';
        vm.userInfo = LoginManagerService.getUser();
    };

    vm.setCard = function(card) {
        return PaymentMethodsService.editDefault(
            card.id,
            true
        ).then(function() {
            vm.init();
            $rootScope.$broadcast('PaymentMethodsService:onCardChanged');
        }).catch(function(error) {
            vm.messageLabel.CURRENT = (error &&
                error.message
            ) || '';
        });
    };

    vm.init();

}

MyAccountCtrl.$inject = ['LoginManagerService', 'SettingsService', '$anchorScroll',
    'PaymentMethodsService',
    '$rootScope'
];

(angular
    .module('RelayServicesApp.Account')
).controller('MyAccountCtrl', MyAccountCtrl);
