'use strict';

function AccountRecoverCtrl(modalInstance, LoginManagerService, SettingsService,
    vcRecaptchaService, Environment) {
    var vm = this;
    vm.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR
    };
    vm.successRecover = false;
    vm.error = false;
    vm.email = '';

    vm.recaptchaApiKey = SettingsService.Keys.RECAPTCHA_API_KEY;
    if (Environment.name === 'prod') {
        vm.recaptchaApiKey = SettingsService.Keys.RECAPTCHA_PROD_API_KEY;
    }

    vm.setWidgetId = function(id) {
        vm.widgetId = id;
    };

    vm.go = function(where) {
        modalInstance.dismiss(where);
    };

    vm.recover = function(form) {
        if (form.$valid) {
            vm.recoverData = {
                'username': vm.email,
                'recaptchaToken' : vcRecaptchaService.getResponse(vm.widgetId)
            };
            LoginManagerService.recoverPassword(vm.recoverData).then(function() {
                vm.successRecover = true;
            }, function(response) {
                vm.messageLabel.CURRENT = response.message ? response.message : vm.messageLabel.DEFAULT;
                vcRecaptchaService.reload(vm.widgetId);
            });
        }
    };

    vm.close = function() {
        modalInstance.dismiss();
    };
}

AccountRecoverCtrl.$inject = ['$uibModalInstance', 'LoginManagerService', 'SettingsService',
'vcRecaptchaService', 'ENVIRONMENT'];

(angular
    .module('RelayServicesApp.Account')
).controller('AccountRecoverCtrl', AccountRecoverCtrl);
