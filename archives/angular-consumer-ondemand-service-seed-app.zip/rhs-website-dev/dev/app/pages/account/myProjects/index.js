'use strict';

function MyProjectsCtrl(LoginManagerService, ProjectsService, SettingsService) {
    var vm = this;

    vm.onErrorUserImage = SettingsService.AssetsPaths.DEFAULT_AVATAR_IMAGE;
    vm.onErrorProjectImage = SettingsService.AssetsPaths.DEFAULT_PROJECT_IMAGE;

    /**
     * Init function calls user information as well as user project info
     */
    vm.init = function() {
        vm.userInfo = LoginManagerService.getUser();
        ProjectsService.getProjectsByUser().then(vm.myProjectsSuccess, vm.myProjectsError);
    };

    /**
     * Success response of my projects service
     * @param  {Object} response -  Response that contains user project info
     */
    vm.myProjectsSuccess = function(response) {
        vm.userProjects = response;
    };

    /**
     * Error response of my projects service
     * @param  {Object} error -  Error response
     */
    vm.myProjectsError = function(error) {
        vm.messageLabel = error;
    };

    vm.init();
}

MyProjectsCtrl.$inject = ['LoginManagerService', 'ProjectsService', 'SettingsService'];

(angular
    .module('RelayServicesApp.Account')
).controller('MyProjectsCtrl', MyProjectsCtrl);
