'use strict';

function AccountMobileSignUpCtrl($window, modalInstance, LoginManagerService, SettingsService, $state,
    vcRecaptchaService, Environment) {
    var vm = this;
    vm.pwdStandardsFailed = false;

    vm.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR
    };

    vm.popover = {
        password : 'assets/templates/pages/account/signup/popover-password-standards.html'
    };

    vm.uagent = $window.navigator.userAgent.toLowerCase();

    vm.recaptchaApiKey = SettingsService.Keys.RECAPTCHA_API_KEY;
    if (Environment.name === 'prod') {
        vm.recaptchaApiKey = SettingsService.Keys.RECAPTCHA_PROD_API_KEY;
    }

    vm.setWidgetId = function(id) {
        vm.widgetId = id;
    };
    vm.termsofuse = function() {
        if (vm.uagent.search('iphone') > -1) {
            window.webkit.messageHandlers.showTermsOfUse();
        } else {
            // jshint undef:false
            Android.showTermsOfUse();
        }
    };

    /*vm.signUp = function(form) {
        vm.pwdStandardsFailed = false;
        vm.messageLabel.CURRENT = '';
        if (form.$valid) {
            if (vm.featureRecaptcha === 'true') {
                vm.registerData = {
                    'username': vm.email,
                    'password': vm.password,
                    'cpassword': vm.passwordConfirm,
                    'acceptconditions': true,
                    'firstname': vm.firstname,
                    'lastname': vm.lastname,
                    'contact': vm.phone,
                    'recaptchaToken' : vcRecaptchaService.getResponse(vm.widgetId)
                };
            } else {
                vm.registerData = {
                    'username': vm.email,
                    'password': vm.password,
                    'cpassword': vm.passwordConfirm,
                    'acceptconditions': true,
                    'firstname': vm.firstname,
                    'lastname': vm.lastname,
                    'contact': vm.phone
                };
            }
            LoginManagerService.register(vm.registerData).then(vm.registerSuccess, vm.registerError);
        }
    };*/
    // jshint unused:false
    vm.signUp = function(form) {
        var messageToPost = {'reCaptchaToken': vcRecaptchaService.getResponse(vm.widgetId),
            'username': vm.email, 'password': vm.password, 'cpassword': vm.passwordConfirm,
            'firstname': vm.firstname, 'lastname': vm.lastname, 'contact': vm.phone, 'acceptconditions': true};

        if (vm.uagent.search('iphone') > -1) {
            window.webkit.messageHandlers.doMobileSignUp.postMessage(messageToPost);
        } else {
            //tslint:disable
            // jshint undef:false
            Android.doMobileSignUp(JSON.stringify(messageToPost));
            //tslint:enable
        }
    };

    vm.signIn = function() {
        $state.go('mobile-login');
    };
    vm.registerSuccess = function() {
        vm.close();
    };

    vm.registerError = function(error) {
        vm.messageLabel.CURRENT = error && error.message ? error.message : vm.messageLabel.DEFAULT;
        if (SettingsService.Error.SIGNUP_PASSWORD_STD_ERROR === vm.messageLabel.CURRENT) {
            vm.pwdStandardsFailed = true;
        }
        vcRecaptchaService.reload(vm.widgetId);
    };

    vm.goToTermsOfUse = function() {
        $window.open('terms', '_blank');
    };

    function validate (event) {
        if (!vm.email) {
            vm.passwordValidationError = 'Provide your email first';
            return;
        }
        var fieldValue = event.target.value;
        var mailId = vm.email.split('@')[0];

        if (!fieldValue) {
            vm.passwordValidationError = 'Password is required';
            return;
        }

        if (fieldValue.length < 8) {
            vm.passwordValidationError = 'Password too small';
            return;
        }

        if (!/[A-z]/.test(fieldValue)) {
            vm.passwordValidationError = 'Must contain letters';
            return;
        }

        if (!/[0-9]/.test(fieldValue)) {
            vm.passwordValidationError = 'Password must contain numbers';
            return;
        }

        if (fieldValue.indexOf(vm.firstname) > -1 || fieldValue.indexOf(vm.lastname) > -1) {
            vm.passwordValidationError = 'Password must not be\/contain your name';
            return;
        }

        if (fieldValue.indexOf(mailId) > -1) {
            vm.passwordValidationError = 'Password must not be\/contain your Email Id';
            return;
        }

        if (/([0-9a-zA-Z])\1{3,}/gi.test(fieldValue)) {
            vm.passwordValidationError = 'Can\'t repeat same character more than 3 times in a row';
            return;
        }

        if (/([?!\s])/gi.test(fieldValue)) {
            vm.passwordValidationError = 'No spaces, ! or ?';
            return;
        }

        /*
        // More rules can be added as per requirement
        if (/[~!@#$%^&*()_+=-`<>/]/.test(fieldValue)) {
            ngModel.$setValidity('passwordValidation', false);
            scope.passwordValidationError = 'Password must contain special characters';
            return undefined;
        }
        */
        vm.passwordValidationError = null;
    }
    vm.validate = validate;
}

AccountMobileSignUpCtrl.$inject = ['$window', '$uibModal', 'LoginManagerService', 'SettingsService', '$state',
'vcRecaptchaService', 'ENVIRONMENT'];

(angular
    .module('RelayServicesApp.Account')
).controller('AccountMobileSignUpCtrl', AccountMobileSignUpCtrl);
