'use strict';

function AccountMobileSignInCtrl(LoginManagerService, SettingsService,
vcRecaptchaService, Environment, $window, $state) {
    var vm = this;
    vm.uagent = $window.navigator.userAgent.toLowerCase();
    vm.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR
    };

    vm.recaptchaApiKey = SettingsService.Keys.RECAPTCHA_API_KEY;
    if (Environment.name === 'prod') {
        vm.recaptchaApiKey = SettingsService.Keys.RECAPTCHA_PROD_API_KEY;
    }

    vm.setWidgetId = function(id) {
        vm.widgetId = id;
    };

    vm.signIn = function(form) {
        if (form.$valid) {
            if (vm.uagent.search('android') > -1) {
                Android.doMobileLogin(vcRecaptchaService.getResponse(vm.widgetId), vm.username, vm.password);
            } else {
                //tslint:disable
                var messageToPost = {'reCaptchaToken': vcRecaptchaService.getResponse(vm.widgetId),
                    'username': vm.username, 'password': vm.password};
                window.webkit.messageHandlers.doMobileLogin.postMessage(messageToPost);
            }
            // else {
                // Android.doMobileLogin(vcRecaptchaService.getResponse(vm.widgetId), vm.username, vm.password);
            // }
        }
    };
    vm.signup = function() {
        $state.go('mobile-signup');
    };
    vm.forgotpass = function() {
        $state.go('mobile-recover');
    };
    vm.guestLogin = function(form) {
        if (form.$valid) {
            vm.loginSuccess();
        }
    };
    vm.loginError = function(error) {
        vm.messageLabel.CURRENT = error.message ? error.message : vm.messageLabel.DEFAULT;
        vcRecaptchaService.reload(vm.widgetId);
    };

}

AccountMobileSignInCtrl.$inject = ['LoginManagerService', 'SettingsService',
'vcRecaptchaService', 'ENVIRONMENT', '$window', '$state'];

(angular
    .module('RelayServicesApp.Account')
).controller('AccountMobileSignInCtrl', AccountMobileSignInCtrl);
