'use strict';

function MobileAccountRecoverCtrl($state, SettingsService, vcRecaptchaService,
Environment, LoginManagerService) {
    var vm = this;
    vm.email = '';
    vm.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR
    };
    vm.successRecover = false;
    vm.recaptchaApiKey = SettingsService.Keys.RECAPTCHA_API_KEY;
    if (Environment.name === 'prod') {
        vm.recaptchaApiKey = SettingsService.Keys.RECAPTCHA_PROD_API_KEY;
    }
    vm.signin = function() {
        $state.go('mobile-login');
    };
    vm.setWidgetId = function(id) {
        vm.widgetId = id;
    };
    vm.recover = function(form) {
        if (form.$valid) {
            vm.recoverData = {
                'username': vm.email,
                'recaptchaToken' : vcRecaptchaService.getResponse(vm.widgetId)
            };
            LoginManagerService.recoverPassword(vm.recoverData).then(function() {
                vm.successRecover = true;
            }, function(response) {
                vm.messageLabel.CURRENT = response.message ? response.message : vm.messageLabel.DEFAULT;
                vcRecaptchaService.reload(vm.widgetId);
            });
        }
    };
}

MobileAccountRecoverCtrl.$inject = ['$state', 'SettingsService',
'vcRecaptchaService', 'ENVIRONMENT', 'LoginManagerService'];

(angular
    .module('RelayServicesApp.Account')
).controller('MobileAccountRecoverCtrl', MobileAccountRecoverCtrl);
