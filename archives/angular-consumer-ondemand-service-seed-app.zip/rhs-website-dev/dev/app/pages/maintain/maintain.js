'use strict';

function MaintainController(SettingsService) {
    var vm = this;
    vm.searsHomeMaintainPageUrl = SettingsService.URLS.SEARS_HOME_MAINTAIN_PAGE_URL;
}

MaintainController.$inject = ['SettingsService'];

(angular
    .module('RelayServicesApp.Maintain')
).controller('MaintainController', MaintainController);
