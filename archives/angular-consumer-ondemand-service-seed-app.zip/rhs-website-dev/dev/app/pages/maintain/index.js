'use strict';

function Configure($stateProvider) {

    $stateProvider.state('maintain', {
        url: '/maintain',
        templateUrl: 'assets/templates/pages/maintain/index.html',
        controller: 'MaintainController as $maintain',
        resolve : {
            'sessionStatus': require('../../services/session-status-resolve')
        }
    });
}

Configure.$inject = ['$stateProvider'];

function Run() {
}

(angular
    .module('RelayServicesApp.Maintain', [])
    .config(Configure)
).run(Run);
