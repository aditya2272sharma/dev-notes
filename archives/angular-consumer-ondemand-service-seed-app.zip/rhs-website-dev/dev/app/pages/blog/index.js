'use strict';

function Configure($stateProvider) {

    $stateProvider.state('blog2', {
        url: '/a-comparison-of-3-smart-thermostats',
        templateUrl: 'assets/templates/pages/blog/a-comparison-of-3-smart-thermostats.html',
        controller: 'BlogController as BlogController'
    }).state('blog', {
        url: '/how-to-improve-home-security',
        templateUrl: 'assets/templates/pages/blog/how-to-improve-home-security.html',
        controller: 'BlogController as BlogController'
    });
}

Configure.$inject = ['$stateProvider'];

function Run() {
}

(angular
    .module('RelayServicesApp.blog', [])
    .config(Configure)
).run(Run);
