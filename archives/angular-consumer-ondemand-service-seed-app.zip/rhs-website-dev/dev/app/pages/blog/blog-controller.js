'use strict';

function BlogController($anchorScroll) {

    $anchorScroll();

}
BlogController.$inject = ['$anchorScroll'];

(angular
    .module('RelayServicesApp.blog')
).controller('BlogController', BlogController);
