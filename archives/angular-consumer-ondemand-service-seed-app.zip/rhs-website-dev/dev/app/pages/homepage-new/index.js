"use strict";

function HomePageNewCtrl(
  $scope,
  $rootScope,
  $anchorScroll,
  SettingsService,
  NewProjectCategoriesService,
  _,
  $uibModal,
  $log,
  $state,
  Env,
  $q,
  $filter,
  CookieManager,
  ZipcodeInfoService
) {
  var vm = this;

  vm.packages = [];

  vm.portableScheduler = Env.features.portableScheduler;
  vm.bookAServiceBanner = Env.features.bookAServiceBanner;
  vm.guaranteeBanner = Env.features.guaranteeBanner;
  vm.earnPointsBanner = Env.features.earnPointsBanner;
  vm.customProject = Env.features.customProject;
  vm.maintainVertical = Env.features.featureMaintainVertical;
  vm.isSSV3 = false;
  vm.dom = {
    isShowListOfServicesSection: false,
    isShowPopularServicesSection: true
  }
  vm.messageLabel = {
    CURRENT: "",
    DEFAULT: SettingsService.Error.DEFAULT_ERROR
  };

  vm.init = function() {
    $anchorScroll();
    var repairObject = {};
    vm.phonenumber = "1-888-236-1894";
    var topProducts = NewProjectCategoriesService.getRepairServiceOfferings();
    var warrantyObject = NewProjectCategoriesService.getWarrantiesInfo();
    var standardCatalogs = NewProjectCategoriesService.standardCatalogs();

    $q.all([topProducts, warrantyObject, standardCatalogs]).then(
      function(response) {
        vm.repairObject = angular.extend(response[0], {
          warranties: response[1]
        });
        vm.packages = response[2].maincategories;
        
      },
      function(error) {
        vm.messageLabel.CURRENT =
          error && error.message ? error.message : vm.messageLabel.DEFAULT;
      }
    );

    updateScreenUIBasedOnUserZipCode(); // update screen UI constant based on user zipcode
  };

  vm.openNewServiceBookingForm = function(selectedProduct) {
    $state.go("repair-form", {
      referer: "HomePageNewCtrl",
      repairObject: vm.repairObject,
      selectedProduct: selectedProduct
    });
  };

  vm.clickSchedule = function() {
    $state.go("repair-form", {
      referer: "ApplianceCtrl",
      repairObject: vm.repairObject,
      selectedProduct: vm.repairObject.topProducts[0]
    });
  };

  vm.learnMoreAboutTechTalk = function() {
    var size = "md";
    var modalInstance = $uibModal.open({
      animation: true,
      ariaLabelledBy: "modal-title",
      ariaDescribedBy: "modal-body",
      templateUrl:
        "assets/templates/components/tech-talk/learn-more-modal/learn-more-modal.html",
      controller: "TechTalkLearnMoreModal",
      controllerAs: "$ctrl",
      size: size,
      resolve: {}
    });

    modalInstance.result.then(
      function(result) {
        if(result)
          vm.clickSchedule();
      },
      function() {
        $log.info("Modal dismissed at: " + new Date());
      }
    );
  };

  vm.taskParameters = function(category, subcategory, categoryId) {
    var categoryName = $filter('safeUrls')(category);//$filter('safeUrls')(_.get(subcategory, 'parentCategory.title'));
    var subcategoryName = $filter('safeUrls')(subcategory);
    return $state.href('services.results', {
        category: categoryName,
        subcategory: subcategoryName,
        categoryId: categoryId
    });
};

vm.categoryPage = function(category) {
    var categoryName = $filter('safeUrls')(category.title);
    $state.go('services.category', {
        category: categoryName
    });
    //$anchorScroll();
};

vm.categoryPagebyId = function(category) {
    var categoryName = $filter('safeUrls')(_.get(category, 'title'));
    switch (categoryName) {
        case 'home-appliances':
            $state.go('repair-form', {});
            break;

        default:
            $state.go('services.category', {
                mainCategoryId: category.id,
                category: categoryName
            });
            break;
    }
};

vm.repairViewAllPageUrl = function() {
    $state.go('repair-view-all');
};

  vm.init();

  // handle notification when zipcode serviceability updated notification
  $rootScope.$on("zipcode-service-updated-notification", function(event, data) {
    updateScreenUIBasedOnUserZipCode(); // update screen UI constant based on user zipcode
  });

  /**
   * Update home screen UI based on user zipcode.
   */
  function updateScreenUIBasedOnUserZipCode() {
    var browserZipCode = ZipcodeInfoService.getZipcode();
    if (browserZipCode && browserZipCode.length === 5) {
      var isServiceAvailableForZipcode = ZipcodeInfoService.getServiceAvailabilityForZipcode();

      if (isServiceAvailableForZipcode) {
        vm.isSSV3 = true;
        vm.dom.isShowPopularServicesSection = false;
        CookieManager.setNavigationBarContactNumber(vm.phonenumber); // save new services phone number in the cookie
        // Hide the header pbx if its hidden
        $rootScope.$emit("show-hide-header-pbx", true);
      } else {
        vm.isSSV3 = false;
        vm.dom.isShowPopularServicesSection = true;
        CookieManager.setNavigationBarContactNumber("1-800-497-6154"); // save old services phone number in the cookie
        // Hide the header pbx if its hidden
        $rootScope.$emit("show-hide-header-pbx", false);
      }
    }
  }
}

HomePageNewCtrl.$inject = [
  "$scope",
  "$rootScope",
  "$anchorScroll",
  "SettingsService",
  "NewProjectCategoriesService",
  "_",
  "$uibModal",
  "$log",
  "$state",
  "ENVIRONMENT",
  "$q",
  "$filter",
  "CookieManager",
  "ZipcodeInfoService"
];

angular
  .module("RelayServicesAppRun.Home")
  .controller("HomePageNewCtrl", HomePageNewCtrl);
