'use strict';

function Configure($stateProvider) {
    $stateProvider.state('generic-error', {
        url: '/error',
        controller: 'GenericErrorPageCtrl',
        controllerAs: 'GenericErrorPageCtrl',
        templateUrl: 'assets/templates/pages/generic-error-page/generic-error-page.html',
        resolve : {
            'sessionStatus': require('../../services/session-status-resolve')
        },
        params: {
            hasHero: true
        }
    }).state('page-not-found', {
        url: '/page-not-found',
        controller: 'PageNotFoundCtrl',
        controllerAs: 'PageNotFoundCtrl',
        templateUrl: 'assets/templates/pages/generic-error-page/page-not-found.html',
        resolve : {
            'sessionStatus': require('../../services/session-status-resolve')
        },
        params: {
            hasHero: true
        }
    });
}

function GenericErrorPageCtrl($anchorScroll) {
    var vm = this;

    vm.init = function() {
        $anchorScroll();
    };

    vm.init();
}

function PageNotFoundCtrl($anchorScroll) {
    var vm = this;

    vm.init = function() {
        $anchorScroll();
    };

    vm.init();
}

function Run() {
}

Configure.$inject = ['$stateProvider'];
GenericErrorPageCtrl.$inject = ['$anchorScroll'];
PageNotFoundCtrl.$inject = ['$anchorScroll'];

angular
.module('RelayServicesApp.GenericError', [])
.config(Configure)
.controller('GenericErrorPageCtrl', GenericErrorPageCtrl)
.controller('PageNotFoundCtrl', PageNotFoundCtrl)
.run(Run);
