'use strict';

function Configure($stateProvider) {

    $stateProvider.state('rapid-response', {
        url: '/rapid-response',
        templateUrl: 'assets/templates/pages/rapid-response/index.html',
        params: {
            hasHero: true
        }
    });

}

Configure.$inject = ['$stateProvider'];

function Run() {
}

(angular
    .module('RelayServicesApp.RapidResponse', [])
    .config(Configure)
).run(Run);
