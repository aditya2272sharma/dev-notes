'use strict';

function TechTalkLandingController(moment, state, $rootScope, $filter, SettingsService,
    BreadcrumbService, ProjectsService, LoginManagerService, accountModalService,
    CheckoutInfoService, ZipcodeInfoService, _, DateTimeValidationService) {

    if (!angular.isString(state.params.projectId) ||
        state.params.projectId.length === 0 ||
        !angular.isObject(state.params.acceptRejectObject)) {
        state.go('home.new'); // redirect user to home screen. if required data is missing.
    }

    var vm = this,
        projectId = state.params.projectId,
        zipcode = ZipcodeInfoService.getZipcode(),
        project = state.params.project,
        location = state.params.location,
        catalogId = state.params.catalogId;

    vm.name = state.params.name; // this is for hold appliance name
    vm.projectData = {};
    vm.project = project;
    vm.location = location;
    vm.availableDates = [];
    vm.guestCheckout = false;
    vm.availableTimeSlotsIndex = 0;
    vm.isCallNowOptionAvailable = false; //bydefault hide call not
    vm.scheduleCall = {
        selectedDate: moment()._d,
        selectedTime: '',
        availableTimeSlots: [],
        isOpened: false
    };

    vm.dom = {};
    vm.dateOptions = {
        dateDisabled: function (data) {
            var date = data.date,
                formattedDate = moment(date).format('YYYY-MM-DD'),
                filteredResults;
            filteredResults = _.filter(vm.availableDates, function(availableDate) {
                return (formattedDate === availableDate.date);
            });
            return filteredResults.length > 0 ? false : true;
        },
        maxDate: moment().add(8, 'days'),
        minDate: moment(),
        startingDay: 0,
        showWeeks: false
    };

    /** Error Messages **/
    vm.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR,
        NO_PROS_MSG: SettingsService.NO_PROS_FOR_ZIPCODE_ERROR
    };

    /** Get breadcrumb details **/
    vm.breadcrumbDetails = BreadcrumbService.getTaskDescription();

    vm.pathElements = [{
        item: 'Services',
        state: {
            name: 'repair-form'
        }
    }, {
        item: SettingsService.ServiceTypes.REPAIR,
        disabled: true
    }];


    vm.openCalendar = function() {
        vm.scheduleCall.isOpened = true;
    };

    /**
     * update available timeslots based on selected calendar date.
     * @param {Object} selectedDate
     */
    vm.calendarDateChanged = function() {
        vm.scheduleCall.availableTimeSlots = DateTimeValidationService
            .getTimeRangesFromDate(vm.availableDates, moment(vm.scheduleCall.selectedDate).format('YYYY-MM-DD'));
        vm.isCurrentDateSelected = vm.checkCurrentDateSelected(); //Checks whether current date is selected
        vm.initTimeSlots(); // Initialize time slots again
    };

    vm.scheduleCallTimeChanged = function() {
        console.log('Selected time --> ' + vm.scheduleCall.selectedTime);
    };

    vm.dom.scheduleTechTalkButtonClicked = function() {
        vm.updateDateTime()
        .then(function(){
            if (!LoginManagerService.getUser().isRegistered) {
                var updatedInfo = {
                    'startdates': vm.projectData.preferredStartDates,
                    'timeSlots': vm.projectData.preferredSlots,
                    'id': vm.projectData.id,
                    'show_availability': true
                };
                ProjectsService.create(ProjectsService.prepareProjectData(vm.projectData))
                .then(function(response){
                    updatedInfo.id = response.id;
                    ProjectsService.update(updatedInfo)
                    .then(function(projectObject) {
                        vm.projectData = projectObject;
                        vm.performAcceptEstimate();
                    });
                });
            } else {
                vm.performAcceptEstimate();
            }
        });
    };

    vm.performAcceptEstimateOld = function() {
        ProjectsService
        .getUnifiedFixedPriceEstimatesByProjectId(vm.projectData.id)
        .then(function(acceptRejectObject) {
            ProjectsService
            .acceptOrRejectProjectEstimation(vm.projectData.id, acceptRejectObject.estimateId, 'Accept')
            .then(function(acceptRejectObject) {
              CheckoutInfoService.setCheckout({
                  order: acceptRejectObject,
                  project: vm.projectData.id,
                  firm: false,
                  selectedDate: vm.scheduleCall.selectedDate,
                  selectedTime: vm.scheduleCall.selectedTime,
                  zipcode: zipcode,
                  availableDates: vm.availableDates
              });
              if (vm.guestCheckout) {
                  state.go('payment.guestCheckout');
              } else {
                  state.go('payment.checkout');
              }
            }, function(error) {
                vm.messageLabel.CURRENT = error && error.message ? error.message : vm.messageLabel.DEFAULT;
            });
        }, function(error) {
            vm.messageLabel.CURRENT = error.status !== 200
            ? 'Sorry, we don\'t have any technicians available. But we are constantly growing our network so do check back with us soon' 
            : vm.messageLabel.DEFAULT;
        });
    };

    vm.performAcceptEstimate = function() {
        ProjectsService
        .getUnifiedFixedPriceEstimatesByProjectId(vm.projectData.id)
        .then(function(acceptRejectObject) {
            CheckoutInfoService.setCheckout({
                estimateId: acceptRejectObject.estimateId,
                project: vm.projectData.id,
                firm: false,
                pricing: acceptRejectObject,
                selectedDate: vm.scheduleCall.selectedDate,
                selectedTime: vm.scheduleCall.selectedTime,
                zipcode: zipcode,
                availableDates: vm.availableDates
            });
            
            state.go('payment.checkout');
        }, function(error) {
            vm.messageLabel.CURRENT = error.status !== 200
            ? 'Sorry, we don\'t have any technicians available. But we are constantly growing our network so do check back with us soon' 
            : vm.messageLabel.DEFAULT;
        });
    }
    /**
     * Return formatted schedule call selected date.
     * @param {String} format
     */
    vm.dom.formattedCalendarDate = function(format) {
        return moment(vm.scheduleCall.selectedDate).format(format);
    };
    /**
     * Handles techTalkCallNowButtonClicked
     * @param undefined
     */
    vm.dom.techTalkCallNowButtonClicked = function () {
        vm.updateDateTime()
        .then(function () {
            if (!LoginManagerService.getUser().isRegistered) {
                var updatedInfo = {
                    'startdates': vm.projectData.preferredStartDates,
                    'timeSlots': vm.projectData.preferredSlots,
                    'id': vm.projectData.id,
                    'show_availability': true
                };
                ProjectsService.create(ProjectsService.prepareProjectData(vm.projectData))
                .then(function(response){
                    updatedInfo.id = response.id;
                    ProjectsService.update(updatedInfo)
                    .then(function(projectObject) {
                        vm.projectData = projectObject;
                        vm.performAcceptEstimate();
                    });
                });
            } else {
                vm.performAcceptEstimate();
            }
        });
    };

    vm.updateDateTime = function () {
        var updatedInfo = {
            'startdates': $filter('date')(vm.scheduleCall.selectedDate, 'yyyy-MM-dd'),
            'timeslots': vm.scheduleCall.selectedTime,
            'id': vm.projectData.id,
            'show_availability': true
        };
        return ProjectsService.update(updatedInfo).then(function(response) {
            vm.projectData = response;
        }, function(error) {
            vm.messageLabel.CURRENT = error && error.message ? error.message : vm.messageLabel.DEFAULT;
        });
    };

    /**
     * Checks for current date selected
     * to dynamically disable invalid timeslots
     */
    vm.checkCurrentDateSelected = function() {
        var format = 'YYYY-MM-DD';
        var formattedDate = vm.dom.formattedCalendarDate(format);
        var currentDate = moment().format(format);
        return moment(formattedDate).isSame(currentDate) || false;
    };

    /**
     * Refactored/Extracted the code for timeslot selection
     * and enabling the call now link
     * according to the date selected
     */
    vm.initTimeSlots = function() {
        vm.scheduleCall.selectedTime = "";
        vm.availableTimeSlotsIndex = 0;
        var formattedDate = vm.dom.formattedCalendarDate('YYYY-MM-DD');
        if (moment(formattedDate).isSame(vm.dateOptions.minDate) && vm.checkCurrentDateSelected()) {
            var systemMinutes = moment().format('m');
            var min = ( (systemMinutes >=0 && systemMinutes < 15) || (systemMinutes >=45 && systemMinutes <= 59) ) ? '30' : '00'; // get minutes from current date
            var hour = ( (systemMinutes >=0 && systemMinutes < 15) ) ? parseInt(moment().format('h')) : parseInt(moment().format('h')) + 1;
            var ampm = moment().format('A');
            if(hour <= 12)
            {
                hour = hour.toString();
                if ((hour === '12') && (min === '00'))
                {
                    ampm = (ampm === 'AM') ? 'PM' : 'AM';
                }
            }
            else if(hour > 12)
            {
                hour = '1';
            }
            var time = hour + ':' + min + ' ' + ampm;
            //console.log('time --> ' + time);
            var timeSlotItems = vm.availableDates[0].timeSlots;
            if (angular.isArray(timeSlotItems)) {
                vm.availableTimeSlotsIndex = _.findIndex(timeSlotItems, function(availableTimeSlots) {
                    return (time === availableTimeSlots.fromTime);
                });

                if ((vm.availableTimeSlotsIndex !== -1) && (timeSlotItems.length > vm.availableTimeSlotsIndex)) {
                    vm.scheduleCall.selectedTime = (timeSlotItems[vm.availableTimeSlotsIndex].fromTime + ' - ' + timeSlotItems[vm.availableTimeSlotsIndex].toTime);
                    vm.isCallNowOptionAvailable = true; // set show call now option true, if timeslot available based on current time.
                }

                // Check whether the current time is before the timeslots
                if(vm.availableTimeSlotsIndex === -1) {
                    var format = 'YYYY-MM-DD h:m A';
                    //get starting hour from API
                    var fromHour = parseInt(timeSlotItems[0].fromTime);

                    var time = moment().unix();
                    var beforeTime = moment(formattedDate + " " + fromHour + ":00 AM", format).unix();
                    if(time < beforeTime) {
                        vm.availableTimeSlotsIndex = 0; //show all the timeslots
                    }
                }
            }
        }
    };

    vm.init = function() {
        vm.isCurrentDateSelected = vm.checkCurrentDateSelected();
        ProjectsService
        .getProjectByProjectId(projectId)
        .then(function(projectObject) {
            vm.projectData = projectObject;

            // Note: catalogId is actually serviceCode here
            ProjectsService
            .checkAvailability(catalogId, zipcode, projectObject.serviceType)
            .then(function(response) {
                vm.availableDates = response && response.data || [];
                vm.dateOptions.maxDate = vm.availableDates[vm.availableDates.length - 1].date;
                vm.dateOptions.minDate = vm.availableDates[0].date;
                vm.scheduleCall.selectedDate = moment(vm.dateOptions.minDate)._d;

                // reload available timeslots based on availability dates
                vm.scheduleCall.availableTimeSlots = DateTimeValidationService
                .getTimeRangesFromDate(vm.availableDates, moment(vm.scheduleCall.selectedDate).format('YYYY-MM-DD'));

                // Initialize time slots
                vm.initTimeSlots();
            });
        }, function(error) {
            if (error) {
                vm.messageLabel.CURRENT = error.message ? error.message : vm.messageLabel.DEFAULT;
            }
        });
    };

    vm.init();
}

TechTalkLandingController.$inject = ['moment', '$state', '$rootScope', '$filter', 'SettingsService',
    'BreadcrumbService', 'ProjectsService', 'LoginManagerService', 'accountModalService',
    'CheckoutInfoService', 'ZipcodeInfoService', '_', 'DateTimeValidationService'];

(angular.module('RelayServicesApp.TechTalk'))
.controller('TechTalkLandingController', TechTalkLandingController);
