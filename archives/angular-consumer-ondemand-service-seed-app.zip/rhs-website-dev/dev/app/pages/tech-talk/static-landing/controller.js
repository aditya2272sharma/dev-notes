'use strict';

function TechTalkStaticLandingController(state, $rootScope, ZipcodeInfoService, $anchorScroll) {
    var vm = this;

    // Get user location for project creation
    $rootScope.$broadcast('get:user:location');
    $anchorScroll();
    vm.gotoTechTalkAppointment = function() {
        // Cross checking for zipcode input
        var zipCode = ZipcodeInfoService.getZipcode();
        if( zipCode && zipCode.length === 5) {
            state.go('tech-talk-appointment');
        } else {
            $rootScope.$broadcast('ask:zipcode');
        }
    }
}
TechTalkStaticLandingController.$inject = ['$state', '$rootScope', 'ZipcodeInfoService', '$anchorScroll'];
angular.module('RelayServicesApp.TechTalk')
.controller('TechTalkStaticLandingController', TechTalkStaticLandingController);
