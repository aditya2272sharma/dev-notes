'use strict';

function TTAppointmentController(
    $rootScope,
    SettingsService,
    $scope,
    _,
    LoginManagerService,
    $q,
    ZipcodeInfoService,
    locationService,
    $window,
    Projects,
    state,
    NewProjectCategoriesService,
    ErrorHandler,
    $anchorScroll,
    BreadcrumbService,
    $filter,
    $sce,
    moment,
    DTService,
    CheckoutInfoService,
    topProducts,
    repairProduct,
    project
) {
    var vm = this;

    var selectedProblemType, contactNumber;

    vm.serviceType = SettingsService.ServiceTypes.TECHTALK;
    vm.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR,
        NO_PROS_MSG: SettingsService.NO_PROS_FOR_ZIPCODE_ERROR
    };
    vm.FormValidation = SettingsService.FormValidation || {};

    // Check for the appliances details resolved properly
    if (!topProducts.status || !repairProduct.status) {
        vm.messageLabel.CURRENT = vm.messageLabel.DEFAULT;
        return;
    }

    vm.hideSubContent = false;
    vm.locationError = false;
    vm.nonServiceableZipCodeErrorMessage = '';

    // reference (1): dev/app/pages/repair/repair-product/index.js
    vm.defaultApplianceName = 'appliance';
    vm.applianceName = vm.defaultApplianceName;
    var repairObject = {};

    // reference (2): dev/app/pages/repair/repair-service-details/index.js
    vm.symptomDesc = '';
    vm.hideApplianceSelection = false;
    vm.disableSubmitOnZipChange = false;
    vm.showSymptomDesc = false;
    vm.skuCode = '';
    vm.projectData = null;
    vm.disableContinueButton = false;
    // if the user is coming from payment page
    // handle the existing project data
    vm.existingProject = (project.status) ? project.data : false;

    // Initialization related to TT scheduler
    vm.availableDates = [];
    vm.availableTimeSlotsIndex = 0;
    vm.scheduleCall = {
        // selectedDate: moment()._d,
        selectedDate: '',
        selectedTime: '',
        availableTimeSlots: [],
        isOpened: false
    };
    vm.showTTScheduleSelectedMessage = false;
    vm.dateFormat = DTService.dateFormat;

    vm.dom = {};
    vm.dateOptions = {
        dateDisabled: function(data) {
            var date = data.date,
                formattedDate = moment(date).format(vm.dateFormat),
                filteredResults;
            filteredResults = _.filter(vm.availableDates, function(
                availableDate
            ) {
                return formattedDate === availableDate.date;
            });
            return (data.mode === 'day') && (filteredResults.length > 0 ? false : true);
        },
        maxDate: moment().add(8, 'days'),
        minDate: moment(),
        startingDay: 0,
        showWeeks: false
    };

    /** Get breadcrumb details **/
    vm.breadcrumbDetails = BreadcrumbService.getTaskDescription();
    vm.pathElements = [
        {
            item: 'Home',
            state: {
                name: 'tech-talk-static-landing'
            }
        }
    ];

    $anchorScroll(); // SLT-170

    vm.init = function() {
        if (!LoginManagerService.getUser().isRegistered) {
            LoginManagerService.anonymousLogin();
        }

        // Handle zipcode related processing
        checkInitializeUserLocation();

        var initial = true;
        if(vm.existingProject) {
            vm.selectedProduct = getApplianceDetails(vm.existingProject.appliance)[0];
            initial = false;
            vm.contactNumber = (vm.existingProject.contact) ? vm.existingProject.contact.phone : "";
        } else {
            // Set repair object/appliance
            vm.repairProduct = repairProduct.data;
            var problemSkus = vm.repairProduct.problemSkuMap;
            populateProblemOptions(problemSkus);

            // select the first product as default if the user
            // lands on this page directly
            vm.selectedProduct = vm.repair[0];
            initial = true;
        }

        if (vm.selectedProduct) {
            vm.setRepairProduct(vm.selectedProduct, initial);
        }
    };

    var getApplianceDetails = function(applianceName) {
        var regex = new RegExp(applianceName, "i");
        return _.filter(vm.repair, function(appliance) {
            return appliance.name.match(regex);
        });
    }

    var checkInitializeUserLocation = function() {
        var zipcode = ZipcodeInfoService.getZipcode();
        if (!zipcode) {
            $rootScope.$broadcast('ask:zipcode');
            zipcode = ZipcodeInfoService.getZipcode();
        }
        vm.zipcode = zipcode;
        getZipcodeDetails(vm.zipcode);
    };

    var populateProblemOptions = function(problemSkus) {
        var problemSkuMap = [];
        var skuCode = '';
        for (var key in problemSkus) {
            if (skuCode === '') {
                skuCode = problemSkus[key].sku;
            }
            problemSkuMap.push({
                key: key,
                value: problemSkus[key].catalogId,
                catalogid: problemSkus[key].catalogId
            });
        }
        vm.skuCode = skuCode;
        vm.problemSKUMappedList = problemSkuMap;

        if(vm.existingProject) {
            var problemIndex = _.findIndex(problemSkuMap, function(problem) {
                return problem.key === vm.existingProject.problem;
            });
            if(problemIndex > -1) {
                vm.selectedProblemType = vm.problemSKUMappedList[problemIndex];
                vm.skuCode = vm.problemSKUMappedList[problemIndex].sku;
            }
        }
    };

    vm.setRepairProduct = function(data, initial) {
        vm.selected = data.merchCode;
        vm.selectedRepairProduct = data.merchCode;
        vm.selFromTopBrand = data.merchCode;
        vm.selectedData = data;
        vm.productName = data.name;
        vm.selectedCategoryId = data.id;
        vm.selectFromAllProducts = '';
        vm.repairProductBrand = null;
        vm.applianceName = vm.productName;
        // when we change a selected appliance, we need to hide the sub-content
        // and clear the merch code
        vm.hideSubContent = true;
        vm.selectedMerchCode = null;
        vm.selectedProblemType = '';
        vm.hideSubContent = true;

        // Load realtime data on appliance selection
        // except the page initialization
        if (!initial) {
            vm.repairProduct = null;
        }

        submitProductDetails();
    };

    var submitProductDetails = function() {
        var repairProductDetails = {
            product: vm.selectedRepairProduct,
            productName: vm.productName,
            selectedData: vm.selectedData,
            selectedCategoryId: vm.selectedCategoryId,
            topProduct: vm.selFromTopBrand,
            productFromAll: vm.selectFromAllProducts,
            address: vm.address
        };
        initializeSubContent(repairProductDetails);
    };

    var initializeSubContent = function(repairProductDetails) {
        // cloned init method from `RepairServiceDetails`
        if (vm.repairProduct) {
            vm.hideSubContent = false;
        } else {
            NewProjectCategoriesService.getSSV3ProductType(
                repairProductDetails.product,
                vm.serviceType
            ).then(
                function(repairObject) {
                    vm.repairProduct = repairObject;

                    vm.hideSubContent = false;
                    vm.productDetails = repairProductDetails;

                    populateProblemOptions(repairObject.problemSkuMap);
                    getAvailability();
                },
                function(error) {
                    vm.messageLabel.CURRENT = error.message
                        ? error.message
                        : vm.messageLabel.DEFAULT;
                }
            );
        }
    };

    /**
     * On timeslot selection
     */
    vm.scheduleCallTimeChanged = function() {
        console.log('Selected time --> ' + vm.scheduleCall.selectedTime);
        vm.showTTScheduleSelectedMessage = true;
        updateSelectMessage();
    };

    /**
     * On selection of the timeslot
     * update the message and display it
     */
    var updateSelectMessage = function() {
        var message = SettingsService.Messages.TT_SCHEDULE_SELECTED;
        var timeSelected = vm.scheduleCall.selectedTime.replace('-', '~');
        if (checkCurrentDateSelected()) {
            message = message.replace('$DATE_SELECTED', '<b>today</b>');
        } else {
            var dateSelected = moment(vm.scheduleCall.selectedDate).format(
                'MM/DD'
            );
            message = message.replace(
                '$DATE_SELECTED',
                'on <b>' + dateSelected + '</b>'
            );
        }
        message = message.replace('$TIME_SELECTED', timeSelected);
        vm.ttScheduleSelectedMessage = $sce.trustAsHtml(message);
    };

    /**
     * Get available dates and their respective
     * timeslots for particular SKU and area
     */
    var getAvailability = function() {
        vm.skuCode = (vm.existingProject) ? vm.existingProject.category.serviceCode : vm.skuCode;
        Projects.checkAvailability(vm.skuCode, vm.zipcode, vm.serviceType).then(
            function(response) {
                vm.availableDates = (response && response.data) || [];
                vm.dateOptions.maxDate =
                    vm.availableDates[vm.availableDates.length - 1].date;
                vm.dateOptions.minDate = vm.availableDates[0].date;
                vm.disableContinueButton = false;
                vm.showTTScheduleSelectedMessage = false;
                vm.messageLabel.CURRENT = '';

                if(vm.existingProject) {
                    var suggestedDateTime = state.params.suggestedDateTime;
                    if(suggestedDateTime) {
                        preSelectDateTime(
                            suggestedDateTime.date,
                            DTService.getTimeSlotsFragments(suggestedDateTime.timeSlot),
                            suggestedDateTime.timeSlotIndex
                        );
                    }
                } else {
                    // Initialize time slots
                    initTimeSlots();
                }
            },
            function(error) {
                vm.disableContinueButton = true;
                vm.messageLabel.CURRENT =
                    error && error.message
                        ? error.message
                        : vm.messageLabel.DEFAULT;
            }
        ).finally(function(){
            if(vm.availableDates && vm.availableDates.length === 0) {
                vm.disableContinueButton = true;
                vm.messageLabel.CURRENT = 'Sorry! Timeslots are not available right now. Please check back later.';
            }
        });
    };

    /**
     * Checks for current date selected
     * to dynamically disable invalid timeslots
     */
    var checkCurrentDateSelected = function() {
        var format = vm.dateFormat;
        var formattedDate = vm.dom.formattedCalendarDate(format);
        var currentDate = moment().format(format);
        return moment(formattedDate).isSame(currentDate) || false;
    };

    /**
     * Initializing timeslots
     * which includes disabling of the invalid timeslots
     * in case of current date selected
     */
    var initTimeSlots = function() {
        vm.scheduleCall.selectedTime = '';
        vm.availableTimeSlotsIndex = 0;
        var formattedDate = vm.dom.formattedCalendarDate(vm.dateFormat);
        var currentDate = moment().format(vm.dateFormat);
        // Check if the current date is selected
        // before disabling the previous invalid timeslots
        if (checkCurrentDateSelected()) {
            // Get valid available timeslots
            var todaysAvailableTimeSlot = DTService.getTodaysAvailableTimeSlot(
                vm.availableDates
            );
            vm.availableTimeSlotsIndex = todaysAvailableTimeSlot.timeSlotIndex;
        } else if (moment(formattedDate).isBefore(currentDate)) {
            // Disable timeslots for all the dates selected
            // before the current date (Edge case)
            vm.availableTimeSlotsIndex = -1;
        }
    };

    vm.dom.techTalkCallNowButtonClicked = function() {
        getMostRecentDateTimeSlotAvailable();
    };

    var getMostRecentDateTimeSlotAvailable = function() {
        var nextAvailableDateTime = DTService.getNextValidDateTime(
            vm.availableDates
        );

        if (nextAvailableDateTime && nextAvailableDateTime.timeSlotIndex > -1) {
            var timeSlotObj = DTService.getTimeSlotsFragments(
                nextAvailableDateTime.timeSlot
            );
            preSelectDateTime(
                nextAvailableDateTime.date,
                timeSlotObj,
                nextAvailableDateTime.timeSlotIndex
            );
        }
    };

    var preSelectDateTime = function(newDate, newTimeSlot, newTimeSlotIndex) {
        vm.scheduleCall.selectedDate = moment(newDate)._d;
        vm.calendarDateChanged();
        vm.scheduleCall.selectedTime =
            newTimeSlot.fromTime + ' - ' + newTimeSlot.toTime;
        vm.availableTimeSlotsIndex = newTimeSlotIndex;
        vm.scheduleCallTimeChanged();
    };

    vm.openCalendar = function() {
        vm.scheduleCall.isOpened = true;
    };

    /**
     * update available timeslots based on selected calendar date.
     * @param {Object} selectedDate
     */
    vm.calendarDateChanged = function() {
        vm.scheduleCall.availableTimeSlots = DTService.getTimeRangesFromDate(
            vm.availableDates,
            moment(vm.scheduleCall.selectedDate).format(vm.dateFormat)
        );
        vm.showTTScheduleSelectedMessage = false;
        initTimeSlots(); // Initialize time slots again
    };

    /**
     * Return formatted schedule call selected date.
     * @param {String} format
     */
    vm.dom.formattedCalendarDate = function(format) {
        return moment(vm.scheduleCall.selectedDate).format(format);
    };

    var isAddressValid = function(isAddressValid, address) {
        if (isAddressValid) {
            vm.isValidAddress = true;
            vm.address = address;
        } else {
            vm.isValidAddress = false;
            vm.address = '';
        }
    };

    /**
     * Check for button status - enabled/disabled
     */
    vm.checkRepairStatus = function() {
        if (
            vm.isValidAddress &&
            vm.zipcode &&
            vm.selectedRepairProduct &&
            vm.selectedProblemType &&
            !vm.disableSubmitOnZipChange &&
            !vm.disableContinueButton &&
            vm.scheduleCall.selectedTime.length > 0 &&
            vm.contactNumber
        ) {
            return false;
        }
        return true;
    };

    vm.updateProblemType = function() {
        // catalogid now arrives in the problemSKUMap
        // therefore, the following doesn't apply
       // selectedProblemType = JSON.parse(vm.selectedProblemType);
        vm.catalogid = vm.selectedProblemType.catalogid;
        if (vm.selectedProblemType.key === 'Other') {
            vm.showSymptomDesc = true;
        } else {
            vm.showSymptomDesc = false;
        }
    };

    var createTechTalkProject = function() {
        // as per the ssv4 flow
        var project = {
            catalogid: vm.catalogid,
            zipcode: vm.zipcode,
            description: vm.symptomDesc,
            problem: vm.selectedProblemType.key, // the model contains an object, so we can't use it
            servicetype: vm.serviceType,
            appliance: vm.applianceName // e.g. Refrigerator
        };

        return Projects.create(project);
    };

    vm.goToPaymentPage = function() {
        var selectedTimeSlotObj = DTService.getTimeSlotsFragments(
            vm.scheduleCall.selectedTime
        );
        // check for real-time validity of
        // the timeslot selected
        if (
            !checkCurrentDateSelected() ||
            (selectedTimeSlotObj &&
                DTService.isValidTimeSlotSelected(selectedTimeSlotObj.toTime))
        ) {
            var updatedInfo = {
                startdates: $filter('date')(
                    vm.scheduleCall.selectedDate,
                    'yyyy-MM-dd'
                ),
                timeSlots: vm.scheduleCall.selectedTime,
                id: 0, // will update it afterwards before project updation
                show_availability: true
            };

            // For registered user, update contact number
            if (LoginManagerService.getUser().isRegistered) {
                updatedInfo.contactnumber = vm.contactNumber;
            }

            if(vm.existingProject && vm.applianceName === vm.existingProject.appliance) {
                // update the project as long as the same appliance selected
                updatedInfo.id = vm.existingProject.id;
                updatedInfo.description = vm.symptomDesc;
                if(vm.selectedProblemType.key !== vm.existingProject.problem) {
                    updatedInfo.problem = vm.selectedProblemType.key;
                }
                Projects.update(updatedInfo).then(function(projectObject) {
                    vm.projectData = projectObject;
                    performAcceptEstimate();
                });
            } else {
                createTechTalkProject().then(function(response) {
                    updatedInfo.id = response.id;
                    Projects.update(updatedInfo).then(function(projectObject) {
                        vm.projectData = projectObject;
                        performAcceptEstimate();
                    });
                });
            }
        } else {
            // if the timeslot selected got stale
            // show Modal box with error message
            console.log(
                'Invalid Timeslot Selected: ' + vm.scheduleCall.selectedTime
            );
            DTService.showTTValidityCheckModal(vm.skuCode, vm.zipcode).then(
                ttValiditySuccessCallBack,
                function() {
                    console.info('Modal dismissed at: ' + new Date());
                    vm.calendarDateChanged();
                }
            );
        }
    };

    vm.isCallNowOptionAvailable = function() {
        return vm.availableDates.length === 0;
    }

    var performAcceptEstimate = function() {
        Projects.getUnifiedFixedPriceEstimatesByProjectId(
            vm.projectData.id
        ).then(
            function(acceptRejectObject) {
                vm.disableContinueButton = false;
                CheckoutInfoService.setCheckout({
                    estimateId: acceptRejectObject.estimateId,
                    project: vm.projectData.id,
                    firm: false,
                    pricing: acceptRejectObject,
                    selectedDate: vm.scheduleCall.selectedDate,
                    selectedTime: vm.scheduleCall.selectedTime,
                    zipcode: vm.zipcode,
                    availableDates: vm.availableDates,
                    contactNumber: vm.contactNumber // for use on payment page for anonymous
                });

                state.go('payment.checkout');
            },
            function(error) {
                vm.messageLabel.CURRENT =
                    error.status !== 200
                        ? "Sorry, we don't have any technicians available. But we are constantly growing our network so do check back with us soon"
                        : vm.messageLabel.DEFAULT;
                vm.disableContinueButton = true;
            }
        );
    };

    var ttValiditySuccessCallBack = function(response) {
        console.info('Modal dismissed with: ' + JSON.stringify(response));
        if (response && response.date && response.timeSlot) {
            var newTimeslotObj = DTService.getTimeSlotsFragments(
                response.timeSlot
            );
            if (newTimeslotObj) {
                preSelectDateTime(
                    response.date,
                    newTimeslotObj,
                    response.timeSlotIndex
                );
            }
        }
    };

    var getZipcodeDetails = function(zipcode) {
        vm.locationError = false;
        vm.nonServiceableZipCodeErrorMessage = '';
        if (zipcode && zipcode.length === 5) {
            locationService.getServiceability(zipcode, vm.serviceType).then(
                function(response) {
                    vm.locationError = false;
                    vm.messageLabel.CURRENT = '';
                    vm.nonServiceableZipCodeErrorMessage = '';
                    vm.disableSubmitOnZipChange = false;
                    vm.hideApplianceSelection = false;
                    ZipcodeInfoService.setZipcode(zipcode, {
                        checkServiceability: false
                    });
                    vm.address = {
                        zipCode: response.zipCode,
                        city: response.city,
                        state: response.state
                    };
                    isAddressValid(true, vm.address);
                    ZipcodeInfoService.setServiceability(true);
                    getAvailability();
                    $rootScope.$emit('show-hide-header-pbx', false);
                },
                function(error) {
                    ZipcodeInfoService.setZipcode(zipcode, {
                        checkServiceability: false
                    });
                    ErrorHandler.displayZipCodeErrorMessage(
                        { status: 404 },
                        vm
                    );
                    vm.messageLabel.CURRENT =
                        vm.nonServiceableZipCodeErrorMessage;
                    vm.disableSubmitOnZipChange = true;
                    vm.hideApplianceSelection = true;
                    ZipcodeInfoService.setServiceability(false);
                }
            );
        }
    };

    // handle notification when zipcode serviceability updated notification
    $rootScope.$on('zipcode-service-updated-notification', function() {
        // update screen UI constant based on user zipcode
        updateScreenUIBasedOnUserZipCode();
    });

    function updateScreenUIBasedOnUserZipCode() {
        var browserZipCode = ZipcodeInfoService.getZipcode();
        if (
            browserZipCode &&
            browserZipCode.length === 5 &&
            vm.zipcode != browserZipCode
        ) {
            getZipcodeDetails(browserZipCode);
            vm.zipcode = browserZipCode;
            vm.nonServiceableZipCodeErrorMessage = '';
        }
    }

    // Set repair objects/appliances and do initialization
    vm.repair = topProducts.data;
    vm.init();
}

TTAppointmentController.$inject = [
    '$rootScope',
    'SettingsService',
    '$scope',
    '_',
    'LoginManagerService',
    '$q',
    'ZipcodeInfoService',
    'locationService',
    '$window',
    'ProjectsService',
    '$state',
    'NewProjectCategoriesService',
    'ErrorHandler',
    '$anchorScroll',
    'BreadcrumbService',
    '$filter',
    '$sce',
    'moment',
    'DateTimeValidationService',
    'CheckoutInfoService',
    'topProducts',
    'repairProduct',
    'project'
];

angular
    .module('RelayServicesApp.TechTalk')
    .controller('TTAppointmentController', TTAppointmentController);
