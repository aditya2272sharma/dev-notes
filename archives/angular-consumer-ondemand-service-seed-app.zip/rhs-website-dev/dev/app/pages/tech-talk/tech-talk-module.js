'use strict';

function Configure($stateProvider) {
  $stateProvider
    .state('tech-talk-static-landing', {
      // catalogId is actually service code here
      url: '/techtalk',
      templateUrl: 'assets/templates/pages/tech-talk/static-landing/view.html',
      controller: 'TechTalkStaticLandingController as ctrl',
      params: {},
      resolve : {
        'sessionStatus': require('../../services/session-status-resolve')
      }
    })
    .state('tech-talk-landing', {
      // catalogId is actually service code here
      url: '/techtalk/:catalogId/project/:projectId',
      templateUrl: 'assets/templates/pages/tech-talk/landing/view.html',
      controller: 'TechTalkLandingController as ctrl',
      params: {
        acceptRejectObject: {
          discount: null,
          estimateId: null,
          price: null,
          tax: null
        },
        project: {},
        location: {},
        name: ''
      }
    })
    .state('tech-talk-appointment', {
      url: '/techtalk-appointment',
      templateUrl: 'assets/templates/pages/tech-talk/appointment/index.html',
      controller: 'TTAppointmentController as $ctrl',
      params: {
        projectId: null,
        suggestedDateTime: null
      },
      resolve: {
        'sessionStatus': require('../../services/session-status-resolve'),

        topProducts: ['NewProjectCategoriesService', '_', function(NewProjectCategoriesService, _) {
          return NewProjectCategoriesService.getTTRepairServiceOfferings().then(
            function(response) {
              var filteredProducts = _.filter(response.topProducts,
              function(product){
                // filter out microwave for techtalk from response
                return !product.name.match(/microwave/i);
              });
              return { status: true, data: filteredProducts };
            },
            function(error) {
              return { status: false, errorMsg: error && error.message };
            }
          );
        }],
        repairProduct: [
          'topProducts',
          'NewProjectCategoriesService',
          'SettingsService',
          '$stateParams',
          function(
          topProducts,
          NewProjectCategoriesService,
          SettingsService,
          state
        ) {
          if (!isNaN(parseInt(state.projectId))) {
            return { status: true, data: {} };
          }
          return NewProjectCategoriesService.getSSV3ProductType(
            topProducts.data[0].merchCode,
            SettingsService.ServiceTypes.TECHTALK
          ).then(
            function(response) {
              return { status: true, data: response };
            },
            function(error) {
              return { status: false, errorMsg: error && error.message };
            }
          );
        }],
        project: [
          '$stateParams',
          'ProjectsService',
          function(state, ProjectsService) {
            if (!isNaN(parseInt(state.projectId))) {
              return ProjectsService
                  .getProjectByProjectId(state.projectId)
                  .then(function(response) {
                      return {'status': true, 'data': response};
                  }, function(err) {
                      return {'status': false, 'data': ''};
                  });
            } else {
                return {'status': false, 'data': ''};
            }
          }
        ]
      }
    })
    .state('tech-talk-confirm', {
      url: '/techtalk-confirmation/:projectId',
      templateUrl: 'assets/templates/pages/tech-talk/confirmation/view.html',
      controller: 'TechTalkConfirmationController as ctrl',
      resolve: {
        sessionStatus: require('../../services/session-status-resolve')
      }
    });
}

Configure.$inject = ['$stateProvider'];

function Run() {}

(angular
  .module('RelayServicesApp.TechTalk', [])
  .config(Configure))
  .run(Run);
