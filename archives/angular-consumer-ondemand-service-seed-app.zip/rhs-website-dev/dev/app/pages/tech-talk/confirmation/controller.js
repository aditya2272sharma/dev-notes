'use strict';

function TechTalkConfirmationController($state, BreadcrumbService, ProjectsService, SettingsService,
    ZipcodeInfoService, $anchorScroll) {
    var vm = this,
        projectId = $state.params.projectId,
        zipcode = ZipcodeInfoService.getZipcode(),
        catalogId = $state.params.catalogId,
        guestCheckout = false;

    vm.projectData = {};
    vm.phoneNumber =  '';

    /** Error Messages **/
    vm.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR,
        NO_PROS_MSG: SettingsService.NO_PROS_FOR_ZIPCODE_ERROR
    };

    vm.dom = {
    };

    vm.init = function() {
        $anchorScroll(); // scrolls the page to the top
        // get project details based on projectid
        ProjectsService.getProjectByProjectId(projectId)
        .then(function(projectObject) {
            vm.projectData = projectObject;
            vm.phoneNumber = projectObject.contact.phone;

            /** Get breadcrumb details **/
            vm.breadcrumbDetails = BreadcrumbService.getTaskDescription();
        
            vm.pathElements = [{
                item: 'Home',
                state: {
                    name: 'home'
                }
            }, {
                item: 'Home Appliances',
                disabled: true
            }, {
                item: vm.projectData.title,
                disabled: true
            }];
        }, function(error) {
            if (error) {
                vm.messageLabel.CURRENT = error.message ? error.message : vm.messageLabel.DEFAULT;
            }
        });
    };

    vm.init();
}

TechTalkConfirmationController.$inject = ['$state', 'BreadcrumbService', 'ProjectsService', 'SettingsService',
    'ZipcodeInfoService', '$anchorScroll'];

(angular.module('RelayServicesApp.TechTalk')).controller(
        'TechTalkConfirmationController', TechTalkConfirmationController);
