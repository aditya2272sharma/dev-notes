'use strict';

function NewServiceOfferingsController($rootScope, SettingsService, $scope, _, repairHelpLineModalService,
    LoginManagerService, RepairService, Uploads, $q, ZipcodeInfoService,
    ENVIRONMENT, locationService, $window, accountModalService, Projects, state,
    NewProjectCategoriesService, ErrorHandler, $anchorScroll) {
    // in the absence of a clear idea about the differences in new repair flow
    // a.k.a. ssv3/v4, most of the code here is mere duplication of repair modal
    // with very tweaks in places

    var vm = this;
    var techtalkSKUDetails, techTalkCataglogId, techTalkCataglogIndex, selectedProblemType;

    techtalkSKUDetails = null;
    techTalkCataglogId = null;
    techTalkCataglogIndex = -1;

    vm.serviceType = SettingsService.ServiceTypes.STANDARDV3;
    vm.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR,
        NO_PROS_MSG: SettingsService.NO_PROS_FOR_ZIPCODE_ERROR
    };
    vm.hideSubContent = true;
    vm.locationError = false;
    vm.nonServiceableZipCodeErrorMessage = '';

    // reference (1): dev/app/pages/repair/repair-product/index.js
    vm.defaultApplianceName = 'appliance';
    vm.applianceName = vm.defaultApplianceName;
    vm.Brands = '';
    vm.error = {
        repairNotSelected: false
    };

    // changes for ssv4 HA flow [start]
    var repairObject = {};
    var topProducts = NewProjectCategoriesService.getRepairServiceOfferings();
    var warrantyObject = NewProjectCategoriesService.getWarrantiesInfo();
    var popularServices = NewProjectCategoriesService.standardCatalogs();
    // changes for ssv4 HA flow [end]

    if (JSON.stringify(state.params.repairObject) === '{}' &&
        JSON.stringify(state.params.selectedProduct) === '{}') {
        // state.go('home.new');
    } else {
        vm.selectedProduct = state.params.selectedProduct;
        vm.repair = state.params.repairObject;
    }

    // reference (2): dev/app/pages/repair/repair-service-details/index.js
    vm.maxImages = 5;
    vm.images = [];
    vm.symptomDesc = '';
    vm.modelNumber = '';
    vm.hideApplianceSelection = false;
    vm.loadingFile = false;
    vm.popOverUrl = 'assets/templates/pages/new-service-offerings/wtd-popup.html';
    vm.applianceTypePopoverTemplateUrl = 'assets/templates/pages/new-service-offerings/appliance-type-popover.html';

    vm.disableSubmitOnZipChange = false;
    vm.applianceTypes = SettingsService.AppliaceTypes;
    vm.applianceType = vm.applianceTypes[0].value || 'freestanding';
    vm.applianceSubtype = '';
    vm.showSymptomDesc = false;
    $anchorScroll(); // SLT-170

    vm.init = function() {
        vm.getZipcodeDetails(vm.zipcode);
        if (vm.productDetails) {
            vm.selectedAddress = vm.productDetails.address.zipCode;
            vm.mCode = vm.productDetails.product;
        }
        vm.warranties = vm.repair.warranties;
        if (vm.productDetails) {
            vm.populateSelectedValues();
        }
        if (!vm.selectedProduct) {
            // select the first product as default if the user
            // lands on the ssv3 page directly
            vm.selectedProduct = vm.repair.topProducts[0];
        }
        if (vm.selectedProduct) {
            vm.setRepairProduct(vm.selectedProduct);
            var isTopProdcut = false;
            _.each(vm.repair.topProducts, function(eachProduct) {
                if (vm.selectedProduct.name === eachProduct.name) {
                    isTopProdcut = true;
                }
            });
            if (isTopProdcut === false) {
                vm.selectFromAllProducts = JSON.stringify(vm.selectedProduct);
                vm.changeRepairSelection();
            }
        }
    };

    vm.setRepairProduct = function(data) {
        vm.selected = data.merchCode;
        vm.selectedRepairProduct = data.merchCode;
        vm.selFromTopBrand = data.merchCode;
        vm.selectedData = data;
        vm.Brands = data.allBrands;
        vm.productName = data.name;
        vm.selectedCategoryId = data.id;
        vm.selectFromAllProducts = '';
        vm.repairProductBrand = null;
        vm.applianceName = vm.productName;
        // when we change a selected appliance, we need to hide the sub-content
        // and clear the merch code
        vm.hideSubContent = true;
        vm.selectedWarranty = null;
        vm.selectedWarrantyKey = null;
        vm.selectedMerchCode = null;
        vm.selectedProblemType = "";
        //select 'No Coverage' by default
        vm.repairProduct = null;
        if (angular.isArray(vm.warranties) && vm.warranties.length > 0) {
            vm.setWarrantyType(vm.warranties[0]);
            vm.setWarrantyTypeAndSubmitProductDetails(vm.warranties[0]);
        }
    };

    vm.changeRepairSelection = function() {
        //vm.Brands = vm.repair.productDetails[vm.selectFromAllProducts].allBrands;
        //vm.productName = vm.repair.productDetails[vm.selectFromAllProducts].name;
        //vm.selectedCategoryId = vm.repair.productDetails[vm.selectFromAllProducts].id;
        if (vm.selectFromAllProducts) {
            var parsedProduct = JSON.parse(vm.selectFromAllProducts);
            vm.Brands = parsedProduct.allBrands;
            vm.productName = parsedProduct.name;
            vm.selectedCategoryId = parsedProduct.id;
            vm.selectedRepairProduct = parsedProduct.merchCode;
            vm.applianceName = vm.productName;
        } else {
            vm.Brands = null;
            vm.applianceName = vm.defaultApplianceName;
        }
        vm.selected = null;
        vm.selectedData =  null;
        vm.repairProductBrand = null;
        vm.selFromTopBrand = null;
    };

    vm.setWarrantyType = function(selectWarranty) {
        vm.selectedWarranty = selectWarranty.status;
        vm.selectedWarrantyKey = selectWarranty.id;
    };

    vm.submitProductDetails = function() {
        var repairProductDetails = {
            product: vm.selectedRepairProduct,
            productName: vm.productName,
            selectedData: vm.selectedData,
            selectedCategoryId: vm.selectedCategoryId,
            topProduct: vm.selFromTopBrand,
            productFromAll: vm.selectFromAllProducts,
            brand: vm.repairProductBrand,
            address: vm.address,
            warrantyType: vm.selectedWarranty
        };
        switch (vm.selectedWarrantyKey) {
            case 0:
                vm.initializeSubContent(repairProductDetails);
                break;
            case 1:
            case 2:
            case 3:
            case 4:
                repairHelpLineModalService.openModal(repairProductDetails);
                break;
            default:
                break;
        }
    };

    vm.isAddressValid = function(isAddressValid, address) {
        if (isAddressValid) {
            vm.isValidAddress = true;
            vm.address = address;
        } else {
            vm.isValidAddress = false;
            vm.address = '';
        }
    };

    vm.checkRepairStatus = function() {
        if (vm.isValidAddress &&
            vm.zipcode &&
            vm.selectedRepairProduct &&
            vm.selectedProblemType &&
            vm.selectedWarranty &&
            !vm.disableSubmitOnZipChange) {
            return false;
        }
        return true;
    };

    vm.close = function() {
    };

    vm.populateSelectedValues = function() {
        vm.repairProductBrand = vm.productDetails.brand;
        vm.selectedRepairProduct = vm.productDetails.product;
        if (vm.productDetails.selectedData) {
            vm.setRepairProduct(vm.productDetails.selectedData);
        } else {
            vm.selectFromAllProducts = vm.productDetails.productFromAll;
            vm.changeRepairSelection();
        }
        vm.selectedWarranty = vm.productDetails.warrantyType;
        vm.repairProductBrand = vm.productDetails.brand;
    };

    vm.changeApplianceSelection = function(applianceTypeData) {
        var problemSkuMap = [];
        for (var key in applianceTypeData.problemSkuMap) {
            problemSkuMap.push({
                key: key,
                value: applianceTypeData.problemSkuMap[key].catalogId,
                catalogid: applianceTypeData.problemSkuMap[key].catalogId
            })
        }
        vm.problemSKUMappedList = problemSkuMap;
        vm.problemList = applianceTypeData.problems;
        vm.catalogid = applianceTypeData.id;
        vm.selectedMerchCode = applianceTypeData.merchCode;
        vm.selectedProblemType = null;
        vm.mCode = applianceTypeData.merchCode;
        vm.applianceSubtype = applianceTypeData.name;
        if (applianceTypeData.skuDetails) {
            vm.skuDetails = applianceTypeData.skuDetails;
            // after we introduced SKUs for tech talk, we shouldn't pass 9999
            // instead we should pass the proper catalogId
            techtalkSKUDetails = vm.skuDetails.filter(function (item, index) {
                if (item.serviceType === 'TECH_TALK') {
                    techTalkCataglogIndex = index;
                    return true;
                }
            });
            if (techtalkSKUDetails && techtalkSKUDetails.length > 0) {
                techTalkCataglogId = techtalkSKUDetails[0].catalogId;
                // when calling liquidity/price to get prices, the tech talk sku
                // doesn't have the price information for it's corresponding catalogId
                // in the liquidity API, therefore, we need to `delete` it
                // delete vm.skuDetails[techTalkCataglogIndex];
                vm.skuDetails.splice(techTalkCataglogIndex, 1);
            } else {
                techTalkCataglogId = 99999;
                techtalkSKUDetails = [];
            }
        }
    };

    /**
     * Upload images component
     * @param {string} file
     */
    vm.upload = function(file) {
        if (file !== null) {
            vm.loadingFile = true;
            Uploads.uploadFile(file).then(function(response) {
                vm.loadingFile = false;
                vm.images.push(response.data.url);
            }, function(error) {
                vm.loadingFile = false;
                vm.messageLabel.CURRENT = error.message ? error.message : vm.messageLabel.DEFAULT;
            });
        }
    };

    /**
     * Removes image from images array and remove DOM element
     * @param  {number} index Image index
     * @param  {Object} event click event
     */
    vm.deleteImage = function(index, event) {
        event.target.parentElement.remove();
        vm.images.splice(index, 1);
        vm.disabledSelect = false;
    };

    /**
     * Validates more than 5 images are uploaded at the same time
     */
    vm.validateImage = function() {
        vm.disabledSelect = false;
        if (vm.images.length >= vm.maxImages - 1) {
            vm.disabledSelect = true;
        }
    };

    /**
     * Old implementation to take the user to SKU selection page
     * Keeping it for last moment decision reversals
     */
    vm.goToSKUSelectionPage = function() {
        state.go('repair-sku', {
            project: {
                catalogid: vm.catalogid,
                zipcode: vm.zipcode,
                description: vm.symptomDesc,
                images: vm.images,
                brand: vm.productDetails.brand,
                problem: vm.selectedProblemType,
                warrantytype: vm.productDetails.warrantyType,
                modelnumber: vm.modelNumber,
                servicetype: SettingsService.ServiceTypes.STANDARDV3,
                skuDetails: vm.skuDetails,
                appliance: vm.applianceName,//vm.selectedRepairProduct,
                appliancetype: vm.applianceType,
                appliancesubtype: vm.applianceSubtype,//vm.selectedMerchCode,
                appliancename: vm.applianceName,
                appliancesubtypename: vm.applianceSubtype
            },
            name: vm.productName
        });
    };

    vm.goToRepairPreviewPage = function() {
        state.go('repair-preview', {
            project: {
                catalogid: vm.catalogid,
                zipcode: vm.zipcode,
                description: vm.symptomDesc,
                images: vm.images,
                brand: vm.repairProductBrand,
                problem: vm.selectedProblemType,
                warrantytype: vm.productDetails.warrantyType,
                modelnumber: vm.modelNumber,
                servicetype: SettingsService.ServiceTypes.STANDARDV3,
                skuDetails: vm.skuDetails,
                appliance: vm.applianceName,//vm.selectedRepairProduct,
                appliancetype: vm.applianceType,
                appliancesubtype: vm.applianceSubtype,//vm.selectedMerchCode,
                appliancename: vm.applianceName,
                appliancesubtypename: vm.applianceSubtype
            },
            name: vm.productName,
            catalogId: techTalkCataglogId,
            techtalkSKUDetails: techtalkSKUDetails,
            id: 'decision',
            location: vm.address
        });
    };

    vm.updateProblemType = function() {
        // catalogid now arrives in the problemSKUMap
        // therefore, the following doesn't apply
        selectedProblemType = JSON.parse(vm.selectedProblemType);
        vm.catalogid = selectedProblemType.catalogid;
        if (selectedProblemType.key === 'Other') {
            vm.showSymptomDesc = true;
        } else {
            vm.showSymptomDesc = false;
        }
    };

    vm.createRepairProject = function() {

        // as per the ssv4 flow
        vm.applianceSubtype = ''; // the sub-type has to be empty
        vm.productDetails.warrantyType = 'No Coverage'; // default is: No warranty
        var project = {
            catalogid: vm.catalogid,
            zipcode: vm.zipcode,
            description: vm.symptomDesc,
            images: vm.images,
            brand: vm.repairProductBrand, // brand is optional
            problem: selectedProblemType.key, // the model contains an object, so we can't use it
            warrantytype: 'No Coverage',
            modelnumber: vm.modelNumber, // model number is optional
            servicetype: SettingsService.ServiceTypes.STANDARDV3,
            appliance: vm.applianceName,// e.g. Refrigerator
            appliancetype: vm.applianceType,
            appliancesubtype: '', // not required for ssv4 flow
        };

        return Projects.create(project);
    };

    vm.goToRepairSchedulePage = function() {
        vm.createRepairProject()
        .then(function(response) {
            state.go('repair-schedule', {
                id: response.id,
                catalogId: vm.catalogid
            });
        });
    };



    // New methods declared to simulate `Continue` button click in repair modal
    // cloned from original method declared in: `RepairProductController`
    vm.setWarrantyTypeAndSubmitProductDetails = function(selectWarranty) {
        vm.hideSubContent = true;
        vm.setWarrantyType(selectWarranty);
        vm.submitProductDetails();
    };

    vm.initializeSubContent = function(repairProductDetails) {
        // cloned init method from `RepairServiceDetails`
        if (!LoginManagerService.getUser().isRegistered) {
            LoginManagerService.anonymousLogin();
        }
        if(vm.repairProduct) {
            vm.hideSubContent = false;
        } else {
            NewProjectCategoriesService
            .getSSV3ProductType(repairProductDetails.product, SettingsService.ServiceTypes.STANDARDV3)
            .then(function(repairObject) {
                vm.repairProduct = repairObject;
                if (vm.repairProduct.problems) {
                    vm.hideApplianceSelection = true;
                    vm.problemList = vm.repairProduct.problems;
                    vm.catalogid = repairProductDetails.selectedCategoryId;
                } else {
                    vm.repairProductList = vm.repairProduct.productTypes;
                }
                vm.hideSubContent = false;
                vm.productDetails = repairProductDetails;
                if (angular.isArray(vm.repairProduct.productTypes) && vm.repairProduct.productTypes.length > 0) {
                    vm.changeApplianceSelection(vm.repairProduct.productTypes[0]);
                }
                var problemSkuMap = [];
                for (var key in repairObject.problemSkuMap) {
                    problemSkuMap.push({
                        key: key,
                        value: repairObject.problemSkuMap[key].catalogId,
                        catalogid: repairObject.problemSkuMap[key].catalogId
                    })
                }
                vm.problemSKUMappedList = problemSkuMap;
            }, function(error) {
                vm.messageLabel.CURRENT = error.message ? error.message : vm.messageLabel.DEFAULT;
            });
        }
    };

    var setGeolocation = function() {
        var deferred = $q.defer();
        var geolocation = $window.navigator && $window.navigator.geolocation;

        vm.zipcode = ZipcodeInfoService.getZipcode();
        if (vm.zipcode) {
            deferred.resolve(vm.zipcode);
        } else if (geolocation) {
            $window.navigator.geolocation
            .getCurrentPosition(function(position) {
                locationService
                .getAddressByLatLong(position.coords.latitude, position.coords.longitude)
                .then(function(response) {
                    _.assign(geolocation, response);
                    vm.completeAddress = response;
                    vm.zipcode = vm.completeAddress.zipCode;
                    deferred.resolve(vm.zipcode);
                }, function(error) {
                    vm.messageLabel.CURRENT = error && error.message ? error.message : vm.messageLabel.DEFAULT;
                    deferred.reject(vm.zipcode);
                });
            }, function(error){
                return deferred.reject(error);
            });
        } else {
            deferred.reject(vm.zipcode);
        }
        return deferred.promise;
    };

    vm.getZipcodeDetails = function(zipcode, form) {
        vm.locationError = false;
        vm.nonServiceableZipCodeErrorMessage = '';
        if (zipcode && zipcode.length === 5) {
            locationService.getlocation(zipcode, vm.serviceType)
            .then(function(response) {
                vm.locationError = false;
                ZipcodeInfoService.setZipcode(zipcode, {checkServiceability: false});
                vm.address = {
                    zipCode: response.zipCode,
                    city: response.city,
                    state: response.state
                };
                vm.isAddressValid(true, vm.address);
                ZipcodeInfoService.setServiceability(true);
                $rootScope.$emit('show-hide-header-pbx', false);
            }, function(error) {
                ZipcodeInfoService.setZipcode(zipcode, {checkServiceability: false});
                ErrorHandler.displayZipCodeErrorMessage(error, vm, form);
                ZipcodeInfoService.setServiceability(false);
            });
        }
    };

    // handle notification when zipcode serviceability updated notification
    $rootScope.$on('zipcode-service-updated-notification', function () {
        // update screen UI constant based on user zipcode
        updateScreenUIBasedOnUserZipCode();
    });

    function updateScreenUIBasedOnUserZipCode() {
        var browserZipCode = ZipcodeInfoService.getZipcode();
        if(browserZipCode && (browserZipCode.length === 5))
        {
            vm.zipcode = browserZipCode;
            vm.nonServiceableZipCodeErrorMessage = '';
            if(ZipcodeInfoService.getServiceAvailabilityForZipcode())
            {
                vm.disableSubmitOnZipChange = false;
            } else {
                vm.disableSubmitOnZipChange = true;
                ErrorHandler.displayZipCodeErrorMessage({status: 404}, vm, $scope.problemDescriptionForm);
            }
        }
    }

    $q.all([
        topProducts,
        warrantyObject,
        popularServices
    ])
    .then(function(response) {
        vm.repair = angular.extend(response[0], {
            warranties: response[1]
        });
        vm.packages = response[2].maincategories;
        setGeolocation()
        .finally(function(){
            vm.init();
        });
    }, function(error) {
        vm.messageLabel.CURRENT = error && error.message ? error.message : vm.messageLabel.DEFAULT;
    })
    .finally(function(response){
        console.log(response);
    });
}

NewServiceOfferingsController.$inject = ['$rootScope', 'SettingsService', '$scope', '_', 'repairHelpLineModalService',
    'LoginManagerService', 'RepairService', 'UploadsService', '$q', 'ZipcodeInfoService',
    'ENVIRONMENT', 'locationService', '$window', 'accountModalService', 'ProjectsService', '$state',
    'NewProjectCategoriesService', 'ErrorHandler', '$anchorScroll'];

angular
.module('RelayServicesApp.NewServices', [])
.controller('NewServiceOfferingsController', NewServiceOfferingsController);
