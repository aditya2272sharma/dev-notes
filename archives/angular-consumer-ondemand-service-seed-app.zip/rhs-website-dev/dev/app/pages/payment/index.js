'use strict';

function Configure($stateProvider) {

    $stateProvider.state('payment', {
        url: '/payment',
        abstract: true,
        templateUrl: 'assets/templates/pages/partials/abstract.html'
    }).state('payment.checkout', {
        url: '/checkout',
        templateUrl: 'assets/templates/pages/payment/checkout/index.html',
        controller: 'PaymentCheckoutCtrl',
        controllerAs: 'PaymentCheckoutCtrl',
        resolve : {
            'checkoutInfo': (
                require('../../services/payments/checkout-info-resolve')
            ),
            'project': ['checkoutInfo', 'ProjectsService',
                function(checkoutInfo, ProjectsService){
                    if (!isNaN(parseInt(checkoutInfo.project))) {
                        return ProjectsService
                            .getProjectByProjectId(checkoutInfo.project)
                            .then(function(response) {
                                return {'status': true, 'data': response};
                            }, function(err) {
                                return {'status': false, 'data': ''};
                            });
                    } else {
                        return {'status': false, 'data': ''};
                    }
                }
            ]
        }
    }).state('payment.guestCheckout', {
        url: '/guest-checkout',
        templateUrl: 'assets/templates/pages/payment/guest-checkout/index.html',
        controller: 'PaymentGuestCheckoutCtrl',
        controllerAs: 'PaymentGuestCheckoutCtrl',
        resolve : {
            'sessionStatus': require('../../services/session-status-resolve'),
            'checkoutInfo': (
                require('../../services/payments/checkout-info-resolve')
            )
        }
    }).state('payment.orderConfirmation', {
        url: '/order-confirmation',
        templateUrl: 'assets/templates/pages/payment/confirmation/index.html',
        controller: 'PaymentConfirmationCtrl',
        controllerAs: 'PaymentConfirmationCtrl',
        resolve : {
            'sessionStatus': require('../../services/session-status-resolve'),
            'checkoutInfo': (
                require('../../services/payments/checkout-info-resolve')
            )
        }
    }).state('payment.orderConfirmationWithID', {
        url: '/order-confirmation/:id',
        templateUrl: 'assets/templates/pages/payment/confirmation-with-id/index.html',
        controller: 'PaymentConfirmationWithIDCtrl',
        controllerAs: 'PaymentConfirmationWithIDCtrl',
        params: {
            'price': 0,
            'tax': 0,
            'total': 0
        },
        resolve : {
            'sessionStatus': require('../../services/session-status-resolve')
        }
    }).state('payment.techTalkOrderConfirmationWithID', {
        url: '/techtalk-order-confirmation/:id',
        templateUrl: 'assets/templates/pages/payment/confirmation-with-id/tech-talk-order-confirmation.html',
        controller: 'PaymentConfirmationWithIDCtrl',
        controllerAs: 'PaymentConfirmationWithIDCtrl',
        params: {
            'price': 0,
            'tax': 0,
            'total': 0
        },
        resolve : {
            'sessionStatus': require('../../services/session-status-resolve')
        }
    });

}

Configure.$inject = ['$stateProvider'];

function Run() {
}

(angular
    .module('RelayServicesApp.Payment', [])
    .config(Configure)
).run(Run);
