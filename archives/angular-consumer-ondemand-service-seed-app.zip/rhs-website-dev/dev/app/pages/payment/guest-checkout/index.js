'use strict';

function PaymentGuestCheckoutCtrl(
    state, _, checkoutInfo, paymentProcessService, SettingsService,
     CheckoutInfoService, sessionStatus, moment, BreadcrumbService, $anchorScroll,
     paymentMethodsService, $braintree, braintreeValue, addressesService, $rootScope,
     ProjectsService, OrderSummaryFixed, $filter, $scope, $window
    ) {
    var ctrl = this,
        addressEvent = 'address:change';

    ctrl.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR,
        NO_CARD: SettingsService.Error.NO_CARD_ERROR,
        NO_PAYMENT: SettingsService.Error.PAYMENT_ERROR,
        NO_BILLING_ADDRESS: SettingsService.Error.BILLING_ADDRESS_ERROR
    };

    ctrl.init = function() {
        $anchorScroll();
        ctrl.cost = (function(order) {
            return {
                //price: order.price - order.tax,
                price: order.price,
                tax: order.tax,
                //total: order.price + order.tax
                total: order.price
            };
        })(checkoutInfo && checkoutInfo.order || {});
        ctrl.checkoutDetails = {
            orderid: (checkoutInfo &&
            checkoutInfo.order && checkoutInfo.order.id
            ) || 0,
            amount: parseFloat(ctrl.cost.total).toFixed(2)
        };

        ctrl.providerId = checkoutInfo.firm.firmId;
        ctrl.completeProject = checkoutInfo.firm;

        ctrl.timeSelected = checkoutInfo.selectedTime.label;
        ctrl.dateSelected = moment(checkoutInfo.selectedDate).format('ddd[,] MMM D[,] YYYY');
        ctrl.today = new Date();
        ctrl.yearList = paymentMethodsService.YearList();
        ctrl.monthList = paymentMethodsService.MonthList();

        ctrl.newCard = {
            isNew: true,
            nonce: Date.now(),
            number: '',
            cardholderName: '',
            expirationMonth: parseInt(ctrl.monthList[0]),
            expirationYear: parseInt(ctrl.yearList[1]),
            cvv: '',
            isDefault: true
        };

        ctrl.newAddress = {
            name: '',
            addressLine1: '',
            addressLine2: '',
            contactNo: '5551234567',
            city: '',
            state: '',
            zipcode: '',
            country: 'US'
        };

        ctrl.getBreadcrumb();
    };

    ctrl.getBreadcrumb = function() {
        ctrl.bcInfo = BreadcrumbService.getTaskDescription();
    };

    ctrl.addNewCard = function() {
        braintreeValue.requestToken(true).then(function(res) {

            braintreeValue.setToken(res);

            $braintree.getClientToken().then(function(token) {
                var client = new $braintree.api.Client({
                    clientToken: token
                });

                client.tokenizeCard({
                    number: ctrl.newCard.number,
                    cardholderName: ctrl.newCard.cardholderName,
                    // You can use either expirationDate
                    // expirationDate: ctrl.new.expiration,
                    // or expirationMonth and expirationYear
                    expirationMonth: ctrl.newCard.expirationMonth,
                    expirationYear: ctrl.newCard.expirationYear,
                    // CVV if required
                    cvv: ctrl.newCard.cvv
                }, function(err, nonce) {
                    // Send nonce to your server

                    paymentMethodsService.register(nonce).then(function() {
                        ctrl.newCard = undefined;
                        ctrl.initCard();
                    }).catch(function(error) {
                        ctrl.messageLabel.CURRENT = (error &&
                            error.message
                        ) || ctrl.messageLabel.DEFAULT;
                    });
                });

            }).catch(function(error) {
                ctrl.messageLabel.CURRENT = error && error.message ? error.message : ctrl.messageLabel.DEFAULT;
                $anchorScroll();
            });
        });
    };

    ctrl.initCard = function() {
        paymentMethodsService.list().then(function(response) {
            ctrl.cardsList = response;
            ctrl.cardModel = (
                ctrl.cardModel && _.find(response, ctrl.cardModel)
            ) || _.find(response, {default: true});
            ctrl.checkoutDetails.cardid = ctrl.cardModel.id;

            //Once card id is ready, we can add the address
            ctrl.addNewAddress();

        });
    };

    ctrl.initAddress = function() {
        addressesService.list().then(function(response) {
            ctrl.addressList = response;
            ctrl.addressModel = (
                ctrl.addressModel && _.find(response, ctrl.addressModel)
            ) || _.first(response);
            ctrl.checkoutDetails.addressid = ctrl.addressModel.id;
            //Once address id is ready, we can place the order
            ctrl.placeOrder();
        });
    };

    ctrl.addNewAddress = function() {
        // @TODO: Apply token when API allows it.
        if (ctrl.useLocationAddress) {
            var mirrorAddress = {
                fullname: 'Billing address',
                addressline1: ctrl.addressLine1,
                addressline2: ctrl.addressLine2,
                city: ctrl.completeProject.location.city,
                state: ctrl.completeProject.location.state,
                zipcode: ctrl.completeProject.location.zip,
                country: 'US'
            };
            ctrl.newAddress = mirrorAddress;
        }
        return addressesService.insert(
            new addressesService.Address(ctrl.newAddress)
        ).then(function() {
            ctrl.newAddress = undefined;
            ctrl.initAddress();
            $rootScope.$broadcast(addressEvent);
        }, function(error) {
            ctrl.messageLabel.CURRENT = error && error.message ? error.message : ctrl.messageLabel.DEFAULT;
            $anchorScroll();
        });
    };

    ctrl.setBillingAddress = function(address) {
        ctrl.billingAddress = address;
    };

    ctrl.processPayment = function() {

        if (ctrl.addressLine2 === undefined) {
            ctrl.addressLine2 = '';
        }
        var otterDate = $filter('date')(checkoutInfo.selectedDate, 'yyyy-MM-dd');

        var updatedInfo = {
            addressline1: ctrl.addressLine1,
            addressline2: ctrl.addressLine2,
            timeslot: checkoutInfo.selectedTime,
            startdate: otterDate,
            id: ctrl.completeProject.projectId
        };

        ProjectsService.update(updatedInfo)
            .then(function(response) {
            //console.info('Project updated. Response: ', response);
            ctrl.projectUpdated = response;
            ctrl.addNewCard();
        }, function(error) {
            //@TODO: Check preloader "removing" in component
            var preloaderElement = document.getElementsByClassName('preloader')[0];
            preloaderElement.parentElement.removeChild(preloaderElement);
            document.body.style.overflow = 'auto';
            //@TODO: Check this in vkew
            if (error) {
                ctrl.messageLabel.CURRENT = error && error.message ? error.message : ctrl.messageLabel.DEFAULT;
            }
        });
    };

    ctrl.placeOrder = function() {
        ctrl.completeProject.location.addressLine1 = ctrl.addressLine1;
        if (ctrl.addressLine2 === undefined) {
            ctrl.addressLine2 = '';
        }
        ctrl.completeProject.location.addressLine2 = ctrl.addressLine2;
        ctrl.completeProject.location.phone = ctrl.phone;
        ctrl.completeProject.location.email = ctrl.email;

        /*if (!ctrl.billingAddress) {
            ctrl.messageLabel.CURRENT = ctrl.messageLabel.NO_BILLING_ADDRESS;
            $anchorScroll();
        }else {*/
        paymentProcessService.charge(ctrl.checkoutDetails).then(function() {
            CheckoutInfoService.setCheckout({
                firm: checkoutInfo.firm,
                order: ctrl.cost,
                timeSelected: checkoutInfo.selectedTime.label,
                dateSelected: checkoutInfo.selectedDate
            });
            state.go('payment.orderConfirmation');
        }, function() {
            //console.log(error);
            //ctrl.messageLabel.CURRENT = error && error.message ? error.message : ctrl.messageLabel.DEFAULT;
            var preloaderElement = document.getElementsByClassName('preloader')[0];
            preloaderElement.parentElement.removeChild(preloaderElement);
            if (ctrl.checkoutDetails.cardid) {
                ctrl.messageLabel.CURRENT = ctrl.messageLabel.NO_PAYMENT;
                $anchorScroll();
            } else {
                ctrl.messageLabel.CURRENT = ctrl.messageLabel.NO_CARD;
                $anchorScroll();
            }
            document.body.style.overflow = 'auto';
        });
        //}
    };

    ctrl.init();

    angular.element($window).bind('scroll', OrderSummaryFixed.scrollCallback);

    $scope.$on('$destroy', function() {
        angular.element($window).unbind('scroll', OrderSummaryFixed.scrollCallback);
    });
}

PaymentGuestCheckoutCtrl.$inject = [
'$state', '_', 'checkoutInfo', 'PaymentProcessService',
'SettingsService', 'CheckoutInfoService', 'sessionStatus',
'moment', 'BreadcrumbService', '$anchorScroll', 'PaymentMethodsService',
'$braintree', 'braintreeValue', 'addressesService', '$rootScope',
'ProjectsService', 'OrderSummaryFixed', '$filter', '$scope', '$window'
];

(angular
.module('RelayServicesApp.Payment')
).controller('PaymentGuestCheckoutCtrl', PaymentGuestCheckoutCtrl);
