'use strict';

function PaymentConfirmationCtrl(checkoutInfo, ProjectsService, SettingsService,
    $anchorScroll, moment, $filter) {
    var vm = this;
    /**
     * Getting info to show in order confirmation
     */
    vm.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR
    };

    vm.init = function() {
        vm.providerName = '';
        vm.completeProject = {
            projectId: checkoutInfo.project
        };
        if (checkoutInfo.firm) {
            vm.providerName = $filter('safeUrls')(checkoutInfo.firm.title);
            vm.completeProject = checkoutInfo.firm;
        }
        vm.projectDate = moment(checkoutInfo.dateSelected).format('ddd[,] MMM D[,] YYYY');
        vm.projectTimeSlot = checkoutInfo.timeSelected;
        $anchorScroll();

        vm.cost = checkoutInfo.order;
        vm.taxPercentage = (vm.cost.tax * 100 / vm.cost.price).toFixed(2);
        if (!vm.completeProject.serviceType) {
            (ProjectsService
                .getProjectByProjectId(vm.completeProject.projectId)
            ).then(function(projectObject) {
                vm.project = projectObject;
                vm.completeProject = projectObject;
            });
        } else {
            vm.project = vm.completeProject;
        }
    };

    /**
    ******************Init****************
    */
    vm.init();
}

PaymentConfirmationCtrl.$inject = [
    'checkoutInfo', 'ProjectsService', 'SettingsService',
    '$anchorScroll', 'moment', '$filter'];

(angular
	.module('RelayServicesApp.Payment')
).controller('PaymentConfirmationCtrl', PaymentConfirmationCtrl);
