'use strict';

function PaymentConfirmationWithIDCtrl(ProjectsService, SettingsService, $sce,
    $anchorScroll, moment, $filter, $state, _, Notifications, $rootScope, LoginManagerService) {
    var vm = this;
    vm.params = $state.params;
    /**
     * Getting info to show in order confirmation
     */
    vm.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR
    };
    vm.showBookingDetails = true;

    vm.init = function() {
         var loggedInUser = LoginManagerService.getUser();
         vm.isGuest = loggedInUser.isGuest || false;

        (ProjectsService
            .getProjectEstimatesByProjectId(vm.params.id)
        ).then(function(projectObject) {
            Notifications.getNotificationsSummary()
            .then(function(response) {
                vm.notificationsCount = response.count;
                vm.unreadNotificationsCount = response.unreadCount;
                $rootScope.unreadNotificationsNumber = response.unreadCount;
            })
            .finally(function() {
                vm.project = projectObject.project;
                if (vm.project.preferredSlots && vm.project.preferredSlots.length > 0) {
                    if(vm.project.preferredSlots.length === vm.project.preferredStartDates.length) {
                        vm.projectDateTimes = '';
                        var preferredDateTimes = [];
                        var preferredDates = vm.project.preferredStartDates;
                        _.each(vm.project.preferredSlots, function(preferredSlot, index) {
                            var dateTime = moment(preferredDates[index]).format('MM[/]DD[/]YY');
                            dateTime += ' ' + preferredSlot;
                            preferredDateTimes.push(dateTime);
                        });
                        vm.projectDateTimes = $sce.trustAsHtml(preferredDateTimes.join('<br />'));
                    } else {
                        vm.projectTimeSlot = vm.project.preferredSlots.join(', ');
                        vm.projectDate = vm.project.preferredStartDates.join(', ');
                    }
                } else {
                    vm.projectTimeSlot = vm.project.timeSlot;
                    vm.projectDate = moment(vm.project.startDate).format('ddd[,] MMM D[,] YYYY');
                }
                vm.cost = vm.cost || {};
                vm.cost.price = _.get(projectObject, 'estimates.data[0].bid.displayPrice', 0);
                vm.taxPercentage = _.get(projectObject, 'estimates.data[0].bid.displayTax', 0);
                vm.taxPercentage = Number(vm.taxPercentage).toFixed(2);
                vm.cost.total = Number(vm.cost.price) + Number(vm.taxPercentage);
                vm.cost.total = vm.cost.total.toFixed(2);

                if (projectObject.estimates.data.length === 0) {
                    vm.cost.price = vm.params.price;
                    vm.taxPercentage = Number(vm.params.tax).toFixed(2);
                    vm.cost.total = vm.params.total;
                }
                vm.providerName = '';
                vm.project.overview = '';
                vm.project.rating = '';
                vm.project.id = _.get(projectObject, 'firms.data[0].id', 0);
                vm.project.projectTitle = vm.project.title;
                vm.project.title = '';
                // Do not pick Provider Name from `firms.data` for
                // `STANDARD_FIXED_PRICE` projects, as these are merely posted
                // but aren't accepted immediately after project creation
                if (vm.project.serviceType !== SettingsService.ServiceTypes.STANDARD_FIXED_PRICE) {
                    vm.providerName = _.get(projectObject, 'firms.data[0].title', '');
                    vm.project.overview = _.get(projectObject, 'firms.data[0].overview', '');
                    vm.project.rating = _.get(projectObject, 'firms.data[0].rating', 0);
                    vm.project.title = vm.providerName;
                } else {
                    vm.showBookingDetails = false;
                }
            });
        }, function(error) {
            vm.messageLabel.CURRENT = error && error.message ? error.message : SettingsService.Error.DEFAULT_ERROR;
            $state.go('generic-error');
        });
        $anchorScroll();
    };

    vm.init();
}

PaymentConfirmationWithIDCtrl.$inject = [
    'ProjectsService', 'SettingsService', '$sce',
    '$anchorScroll', 'moment', '$filter', '$state', '_',
    'Notifications', '$rootScope', 'LoginManagerService'];

(angular
	.module('RelayServicesApp.Payment')
).controller('PaymentConfirmationWithIDCtrl', PaymentConfirmationWithIDCtrl);
