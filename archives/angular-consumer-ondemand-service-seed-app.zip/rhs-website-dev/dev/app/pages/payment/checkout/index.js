'use strict';

function PaymentCheckoutCtrl(
    state,
    checkoutInfo,
    paymentProcessService,
    SettingsService,
    CheckoutInfoService,
    project,
    moment,
    BreadcrumbService,
    $anchorScroll,
    ProjectsService,
    OrderSummaryFixed,
    $filter,
    $scope,
    $rootScope,
    $window,
    NewBillingAddress,
    NewServiceLocation,
    NewPaymentMethod,
    $braintree,
    braintreeValue,
    PaymentAddressesService,
    addressesService,
    PaymentMethodsService,
    ProjectDateTimeModalService,
    DTService,
    ENV,
    _,
    ZipcodeInfoService,
    LoginManagerService,
    $timeout
) {
    var ctrl = this,
        isNewAddress = false,
        isNewPaymentMethod = false,
        isNewServiceLocation = false,
        isServiceLocationAvail = false;
    ctrl.selectedPaymentCard = '';
    ctrl.isLocationAddresChecked = false;
    ctrl.isBookingInProgress = false;
    ctrl.messageLabel = {
        CURRENT: '',
        DEFAULT: SettingsService.Error.DEFAULT_ERROR,
        NO_CARD: SettingsService.Error.NO_CARD_ERROR,
        NO_PAYMENT: SettingsService.Error.PAYMENT_ERROR
    };
    ctrl.showCalendarControl = true;
    ctrl.serviceType = '';
    ctrl.timeRanges = DTService.timeRanges;
    ctrl.stdServiceV2 = ENV.features.stdServiceV2 === 'true';
    ctrl.isDatePanelOpen = true;
    ctrl.availableDates = [];
    ctrl.isTechTalk = false;
    ctrl.serviceContact = '';
    ctrl.isRegistered = false;
    ctrl.isCustInfoOpen = false;
    ctrl.dateOptions = {
        dateDisabled: function disabled(data) {
            // Disable weekend selection
            // Disable dates which aren't part of the availableDates Array
            var date = data.date,
                formattedDate = moment(date).format('YYYY-MM-DD'),
                filteredResults;

            // loop through and check if current date
            // is present in the availableDates array
            filteredResults = _.filter(ctrl.availableDates, function(
                availableDate
            ) {
                return formattedDate === availableDate.date;
            });
            // if the date is present, the length will be always > 0
            return filteredResults.length > 0 ? false : true;
        },
        // formatYear: 'yy',
        maxDate: moment().add(3, 'months'), // initial value for end-date for date-picker
        minDate: moment().add(2, 'days'), // initial value for start-date
        startingDay: 0,
        showWeeks: false
    };

    if (!project.status) {
        ctrl.messageLabel.CURRENT = 'Invalid Project';
        return;
    }

    ctrl.acceptEstimate = function(projectId) {
        ProjectsService.acceptOrRejectProjectEstimation(
            projectId,
            checkoutInfo.estimateId,
            'Accept'
        )
            .then(function(acceptRejectObject) {
                ctrl.checkoutDetails.orderid = acceptRejectObject.id;
            })
            .catch(function(error) {
                ctrl.messageLabel.CURRENT =
                    (error && error.message) || ctrl.messageLabel.DEFAULT;
            });
    };

    ctrl.proceedToInlineSignUp = function() {
        ctrl.isDatePanelOpen = false;
        ctrl.dateTimeTouched = true;
        ctrl.showCalendarControl = false;
        ctrl.isCustInfoOpen = true;
    };

    ctrl.init = function() {
        ctrl.scrollTop();
        var loggedInUser = LoginManagerService.getUser();
        ctrl.isRegistered = loggedInUser.isRegistered;
        ctrl.isGuest = loggedInUser.isGuest || false;
        ctrl.email = loggedInUser.email || '';
        ctrl.proceedToInlineSignUp();

        // Disable zipcode changes on payment page
        $rootScope.$emit('disable-zipcode-updation', true);

        ctrl.project = project.data;
        ctrl.timeSlotPreferences = [];
        _.each(ctrl.project.preferredSlots, function(item, index) {
            ctrl.timeSlotPreferences[index] = {
                timeSlot: item,
                date: moment(ctrl.project.preferredStartDates[index]).format(
                    'ddd, L'
                )
            };
        });
        ctrl.serviceType = ctrl.project.serviceType;
        ctrl.isTechTalk =
            ctrl.serviceType === SettingsService.ServiceTypes.TECHTALK;
        ctrl.isSSV3 =
            ctrl.serviceType === SettingsService.ServiceTypes.STANDARDV3;
        var contactPhone = ctrl.project.contact
            ? ctrl.project.contact.phone
            : '';
        ctrl.serviceContact = checkoutInfo.contactNumber || contactPhone;
        ctrl.decideShowCalendar();

        // Accept project estimates for registered users
        if (ctrl.isRegistered && !checkoutInfo.isNSFlow) {
            ctrl.acceptEstimate(checkoutInfo.project);
        }

        ctrl.cost = (function(order) {
            // tax can be either a number or null
            // isNaN(null) returns false
            // also, Number(null) returns 0
            // can't use them here
            if (!order.tax) {
                order.tax = 0;
            }
            return {
                //price: order.price - order.tax,
                price: order.price,
                tax: order.tax,
                total: order.price + order.tax
                // total: order.price
            };
        })(
            (!checkoutInfo.isNSFlow &&
                checkoutInfo.firm &&
                checkoutInfo.firm.packageDetails.bid) ||
                (checkoutInfo.isNSFlow && checkoutInfo.order) ||
                checkoutInfo.pricing ||
                {}
        );
        ctrl.checkoutDetails = {
            orderid:
                (checkoutInfo && checkoutInfo.order && checkoutInfo.order.id) ||
                0,
            amount: parseFloat(ctrl.cost.total).toFixed(2)
        };

        ctrl.providerId = '';
        ctrl.providerName = '';
        ctrl.completeProject = checkoutInfo.firm;

        ctrl.zipcode = ZipcodeInfoService.getZipcode();
        ctrl.isNSFlow = checkoutInfo.isNSFlow;
        ctrl.nsServiceLocation =
            (checkoutInfo.firm && checkoutInfo.firm.location) || null;

        if (checkoutInfo.availableDates) {
            // availableDates is the array containing the response data from Availability API
            // We pass this information from the previous pages to payments page via CheckoutInfoService
            ctrl.availableDates = checkoutInfo.availableDates || [];
            ctrl.dateOptions.maxDate =
                ctrl.availableDates[ctrl.availableDates.length - 1].date;
            ctrl.dateOptions.minDate = ctrl.availableDates[0].date;
        }

        if (checkoutInfo.selectedTime) {
            // in certain checkouts e.g. NS estimate update flow,
            // the timeslot is passed as a string instead of an object
            // thus, the label isn't set
            if (checkoutInfo.selectedTime.label) {
                ctrl.selectedTimeSlot = checkoutInfo.selectedTime.label;
            } else {
                ctrl.selectedTimeSlot = checkoutInfo.selectedTime;
            }
            ctrl.selectedTimeSlotModel = DTService.getTimeRange(
                ctrl.selectedTimeSlot
            );
            ctrl.timeSelected = ctrl.selectedTimeSlot;
        }

        // if a selected date is present, then use the values
        // else, show set it to Calendar's default min date
        // Note: Calendar's min date = Date present at 0th index from Availability API response data

        if (checkoutInfo.selectedDate) {
            ctrl.selectedDate = moment(checkoutInfo.selectedDate).format(
                'ddd[,] MMM D[,] YYYY'
            );
            ctrl.dt = moment(checkoutInfo.selectedDate)._d;
        } else {
            ctrl.selectedDate = moment(ctrl.dateOptions.minDate).format(
                'ddd[,] MMM D[,] YYYY'
            );
            ctrl.dt = moment(ctrl.dateOptions.minDate)._d;
        }

        // set the formatted date as the new value in the ceheckoutInfo object
        checkoutInfo.selectedDate = ctrl.selectedDate;
        ctrl.dateSelected = ctrl.selectedDate;

        ctrl.getBreadcrumb();
        ctrl.decideShowCalendar();

        NewPaymentMethod.resetpaymentMethod();
        NewBillingAddress.resetBillingAddress();
        NewServiceLocation.resetServiceLocation();

        //Listen for authenticated user
        $rootScope.$on('user:authentication:change', function(event, user) {
            //Assign authenticated data if exists
            ctrl.isRegistered = user.isRegistered;
            ctrl.email = LoginManagerService.getUser().email;
            ctrl.processRegisteredUser();
        });
    };

    ctrl.decideShowCalendar = function() {
        // showing or hiding the calendar control and the time-slot selection
        // based on the project type
        if (
            ctrl.serviceType === SettingsService.ServiceTypes.STANDARDV3 ||
            ctrl.serviceType === SettingsService.ServiceTypes.STANDARD ||
            ctrl.serviceType === SettingsService.ServiceTypes.TECHTALK
        ) {
            ctrl.showCalendarControl = false;
        } else {
            ctrl.showCalendarControl = true;
        }
    };

    ctrl.openDateTimeModal = function() {
        ctrl.project = checkoutInfo.project;
        ProjectDateTimeModalService.openModal(ctrl.project, function(
            serviceDate,
            serviceTime
        ) {
            ctrl.selectedDate = moment(serviceDate).format(
                'ddd[,] MMM D[,] YYYY'
            );
            ctrl.selectedTimeSlot = serviceTime;
        });
    };

    ctrl.scrollTop = function() {
        // This method was written with the intention of
        // scrolling the page to each Accordion Header in
        // the Payments V2 page. But as the sections were
        // small & fit in a single view port, this method
        // wasn't customized further.
        $anchorScroll();
    };

    ctrl.setAddress = function(address) {
        ctrl.checkoutDetails.addressid = address;
    };

    ctrl.setCard = function(card) {
        if (card && card.id) {
            ctrl.checkoutDetails.cardid = card.id;
            ctrl.messageLabel.CURRENT = '';
            ctrl.paymentMethodValid = true;
            ctrl.paymentMethodContinue = true;
            ctrl.selectedPaymentCard = card;
            ctrl.checkoutDetails.cvv = card.cvv;
        }
        ctrl.scrollTop();
    };

    ctrl.enableCardForCVV = function(card) {
        if (ctrl.checkoutDetails.cardid === card.id) {
            if (card && card.cvv) {
                ctrl.selectedPaymentCard.cvv = card.cvv;
            }
            ctrl.selectedCard = {
                number: '**** **** **** ' + card.lastNumbers,
                expiry: card.expiremonth + '/' + card.expireyear.substring(2, 4)
            };
            return true;
        } else {
            return false;
        }
    };

    ctrl.setBillingAddress = function(address) {
        ctrl.billingAddress = address;
        if (address && address.addressline1) {
            ctrl.newbillingAddressValid = true;
            ctrl.newbillingAddressContinue = true;
        }
    };

    ctrl.setServiceLocation = function(location) {
        ctrl.serviceLocation = location;
        if (location && location.addressline1) {
            ctrl.newServiceLocationsValid = true;
        }
    };

    ctrl.startProcessPayment = function() {
        if (!checkoutInfo.selectedDate || !checkoutInfo.selectedTime) {
            if (!ctrl.selectedDate || !ctrl.selectedTimeSlot) {
                ctrl.openDateTimeModal();
                return;
            }
        }
        var isLocationExist = false;
        var otterDate = moment(ctrl.selectedDate).format('YYYY-MM-DD'),
            newServiceLocationDetails = NewServiceLocation.getServiceLocation(),
            newServiceLocationDetailsList = NewServiceLocation.getServiceLocationList(),
            updatedInfo = {
                id: checkoutInfo.project
            };

        // In case of invalid selected timeslot,
        // set it as first timeslot available
        if (
            angular.isString(ctrl.selectedTimeSlot) &&
            (ctrl.selectedTimeSlot.trim() === '-' ||
                ctrl.selectedTimeSlot.trim() === '')
        ) {
            ctrl.selectedTimeSlot = ctrl.timeRanges[0].value;
        }

        // In case of SSV3 or standard/PE flow, no need to update
        // selected dates and timeslots again
        if (
            !ctrl.isSSV3 &&
            ctrl.serviceType !== SettingsService.ServiceTypes.STANDARD
        ) {
            updatedInfo.startdates = otterDate;
            updatedInfo.timeslots = ctrl.selectedTimeSlot;
        }

        if (!ctrl.isTechTalk) {
            if (ctrl.addressLine2 === undefined) {
                ctrl.addressLine2 = '';
            }
            /*var updatedInfo = {
                addressline1: ctrl.addressLine1,
                addressline2: ctrl.addressLine2,
                timeslot: checkoutInfo.selectedTime,
                startdate: otterDate,
                id: ctrl.completeProject.projectId,
                phone: ctrl.phone
            };*/
            if (newServiceLocationDetails.addressLine1) {
                isLocationExist = true;
                updatedInfo.addressline1 =
                    newServiceLocationDetails.addressLine1;
                updatedInfo.addressline2 =
                    newServiceLocationDetails.addressLine2;
                updatedInfo.phone =
                    newServiceLocationDetails.phone ||
                    newServiceLocationDetails.contactNo;
            } else {
                updatedInfo.addressid = newServiceLocationDetailsList.addressid;
            }
            var isNewAddressPresent = false;
            isNewAddressPresent = ctrl.isAddressPresent(
                newServiceLocationDetails
            );
            if (isNewAddressPresent) {
                var mirrorAddress = {
                    fullname:
                        newServiceLocationDetails.firstname +
                        ' ' +
                        newServiceLocationDetails.lastname,
                    addressline1: newServiceLocationDetails.addressLine1,
                    addressline2: newServiceLocationDetails.addressLine2,
                    city: newServiceLocationDetails.city,
                    state: newServiceLocationDetails.state,
                    zipcode: newServiceLocationDetails.zipcode,
                    country: 'US',
                    firstname: newServiceLocationDetails.firstname,
                    lastname: newServiceLocationDetails.lastname,
                    contactNo:
                        newServiceLocationDetails.phone ||
                        newServiceLocationDetails.contactNo
                };
                addressesService
                    .insert(new addressesService.Address(mirrorAddress))
                    .then(
                        function(response) {
                            updatedInfo.addressid = response.id;
                            ctrl.ProcessPaymentUpdate(updatedInfo);
                        },
                        function(error) {
                            ctrl.addressInsertError =
                                error && error.message
                                    ? error.message
                                    : ctrl.messageLabel.DEFAULT;
                        }
                    );
            } else {
                ctrl.ProcessPaymentUpdate(updatedInfo);
            }
        } else {
            updatedInfo.contactnumber =
                checkoutInfo.contactNumber || ctrl.serviceContact || '';
            ctrl.ProcessPaymentUpdate(updatedInfo);
        }
    };

    ctrl.ProcessPaymentUpdate = function(updatedInfo) {
        ProjectsService.updateCustomProject(updatedInfo).then(
            function(response) {
                //console.info('Project updated. Response: ', response);
                ctrl.projectUpdated = response;
                ctrl.processPayment(updatedInfo);
            },
            function(error) {
                //@TODO: Check preloader "removing" in component
                // var preloaderElement = document.getElementsByClassName('preloader')[0];
                // preloaderElement.parentElement.removeChild(preloaderElement);
                // document.body.style.overflow = 'auto';
                //@TODO: Check this in vkew
                if (error) {
                    ctrl.messageLabel.CURRENT =
                        error && error.message
                            ? error.message
                            : ctrl.messageLabel.DEFAULT;
                }
            }
        );
    };

    ctrl.addNewAddress = function() {
        var newAddress = NewBillingAddress.getBillingAddress();
        if (newAddress.addressLine1) {
            return PaymentAddressesService.insert(
                new PaymentAddressesService.Address(newAddress)
            )
                .then(function(response) {
                    ctrl.setBillingAddress(response);
                    ctrl.newBillingAddressId = response.id;
                    $rootScope.$broadcast('billing:address:added');
                    ctrl.startProcessPayment();
                })
                .catch(function(error) {
                    ctrl.messageLabel.CURRENT =
                        (error && error.message) || ctrl.messageLabel.DEFAULT;
                });
        } else {
            ctrl.startProcessPayment();
        }
    };

    ctrl.addNewPaymentMethod = function(newCard) {
        braintreeValue.requestToken(newCard.isDefault).then(function(res) {
            braintreeValue.setToken(res);

            $braintree
                .getClientToken()
                .then(function(token) {
                    var client = new $braintree.api.Client({
                        clientToken: token
                    });

                    client.tokenizeCard(
                        {
                            number: newCard.number,
                            cardholderName: newCard.cardholderName,
                            // You can use either expirationDate
                            // expirationDate: ctrl.new.expiration,
                            // or expirationMonth and expirationYear
                            expirationMonth: newCard.expirationMonth,
                            expirationYear: newCard.expirationYear,
                            // CVV if required
                            cvv: newCard.cvv
                        },
                        function(err, nonce) {
                            // Send nonce to your server
                            //console.log(err, nonce);
                            PaymentMethodsService.register(nonce)
                                .then(function(response) {
                                    newCard.id = response.id;
                                    ctrl.setCard(newCard);
                                    ctrl.addNewAddress(ctrl.billingAddress);
                                    NewPaymentMethod.resetpaymentMethod();
                                    // $rootScope.$broadcast('payment:method:added');
                                })
                                .catch(function(error) {
                                    ctrl.messageLabel.CURRENT =
                                        (error && error.message) ||
                                        ctrl.messageLabel.DEFAULT;
                                });
                        }
                    );
                })
                .catch(function() {
                    //console.log(error);
                });
        });
    };

    ctrl.bookService = function() {
        ctrl.messageLabel.CURRENT = '';
        var selectedTimeSlotObj = DTService.getTimeSlotsFragments(
            ctrl.project.preferredSlots[0]
        );
        // Check for valid timeslot selected
        // in case of techtalk
        if (
            ctrl.isTechTalk &&
            DTService.isCurrentDate(ctrl.project.preferredStartDates[0]) &&
            (selectedTimeSlotObj &&
                !DTService.isValidTimeSlotSelected(selectedTimeSlotObj.toTime))
        ) {
            DTService.showTTValidityCheckModal(ctrl.project.category.serviceCode, ctrl.zipcode).then(
                ttValiditySuccessCallBack,
                function() {
                    console.info('Modal dismissed at: ' + new Date());
                    ttValiditySuccessCallBack();
                }
            );
        } else {
            ctrl.isBookingInProgress = true;
            var newCard = NewPaymentMethod.getPaymentMethod();
            if (newCard.number) {
                ctrl.addNewPaymentMethod(newCard);
            } else {
                ctrl.startProcessPayment();
            }
        }
    };

    var ttValiditySuccessCallBack = function(response) {
        if (response && response.date && response.timeSlot) {
            goBackToAppointmentPage(response);
        } else {
            goBackToAppointmentPage();
        }
    }

    var goBackToAppointmentPage = function(suggestedTimeObj) {
        var paramObj = { projectId: checkoutInfo.project };
        if(suggestedTimeObj) {
            paramObj.suggestedDateTime = suggestedTimeObj;
        }

        state.go('tech-talk-appointment', paramObj);
    }

    ctrl.useLocationAsAddressAndProcessPayment = function() {
        if (ctrl.addressLine2 === undefined) {
            ctrl.addressLine2 = '';
        }
        var selectedServiceLocationAddress = NewServiceLocation.getServiceLocationList();
        var selectedAddress1 = selectedServiceLocationAddress.addressLine1;
        var selectedAddress2 = selectedServiceLocationAddress.addressLine2;
        var selectedCity = selectedServiceLocationAddress.city;
        var selectedState = selectedServiceLocationAddress.state;
        var selectedZipcode = selectedServiceLocationAddress.zipcode;
        var mirrorAddress = {
            fullname: 'Billing address',
            addressline1: selectedAddress1,
            addressline2: selectedAddress2,
            city: selectedCity,
            state: selectedState,
            zipcode: selectedZipcode,
            country: 'US'
        };
        PaymentAddressesService.insert(
            new PaymentAddressesService.Address(mirrorAddress)
        ).then(function(response) {
            ctrl.setAddress(response.id);
            ctrl.processPayment();
        });
    };

    ctrl.isAddressPresent = function(givenAddress) {
        var isAddressFound = false;
        if (givenAddress.addressLine1) {
            if (givenAddress.addressLine1 !== '') {
                isAddressFound = true;
            }
        }
        return isAddressFound;
    };

    ctrl.processPayment = function(updatedInfo) {
        if (ctrl.completeProject) {
            ctrl.completeProject.location.addressLine1 = ctrl.addressLine1;
            ctrl.completeProject.location.addressLine2 = ctrl.addressLine2;
            ctrl.completeProject.location.phone = ctrl.phone || ctrl.contactNo;
            ctrl.completeProject.location.contactNo =
                ctrl.phone || ctrl.contactNo;
            ctrl.completeProject.location.email = ctrl.email;
        }
        if (ctrl.addressLine2 === undefined) {
            ctrl.addressLine2 = '';
        }
        var selectedServiceLocationAddress = NewServiceLocation.getServiceLocationList();
        var newLocationAddress = NewServiceLocation.getServiceLocation();
        if (ctrl.isAddressPresent(newLocationAddress)) {
            if (checkoutInfo.firm) {
                checkoutInfo.firm.location.addressLine1 =
                    newLocationAddress.addressLine1;
                checkoutInfo.firm.location.addressLine2 =
                    newLocationAddress.addressLine2;
                checkoutInfo.firm.location.city = newLocationAddress.city;
                checkoutInfo.firm.location.state = newLocationAddress.state;
                checkoutInfo.firm.location.zipcode = newLocationAddress.zipcode;
            }
            ctrl.checkoutDetails.addressid = updatedInfo.addressid;
        } else {
            if (checkoutInfo.firm) {
                checkoutInfo.firm.location.addressLine1 =
                    selectedServiceLocationAddress.addressLine1;
                checkoutInfo.firm.location.addressLine2 =
                    selectedServiceLocationAddress.addressLine2;
                checkoutInfo.firm.location.city =
                    selectedServiceLocationAddress.city;
                checkoutInfo.firm.location.state =
                    selectedServiceLocationAddress.state;
                checkoutInfo.firm.location.zipcode =
                    selectedServiceLocationAddress.zipcode;
            }
            ctrl.checkoutDetails.addressid =
                selectedServiceLocationAddress.addressid;
        }
        if (!ctrl.isLocationAddresChecked) {
            ctrl.checkoutDetails.addressid = ctrl.billingAddress.id;
            if (ctrl.newBillingAddressId) {
                ctrl.checkoutDetails.addressid = ctrl.newBillingAddressId;
            }
        }

        ctrl.checkoutDetails.cvv = ctrl.selectedPaymentCard.cvv
            ? ctrl.selectedPaymentCard.cvv
            : ctrl.checkoutDetails.cvv;

        paymentProcessService
            .charge(ctrl.checkoutDetails)
            .then(
                function() {
                    $timeout(function() {
                        NewServiceLocation.resetServiceLocation();
                        NewServiceLocation.resetServiceLocationList();
                        switch (ctrl.serviceType) {
                            case SettingsService.ServiceTypes.TECHTALK:
                                state.go('payment.techTalkOrderConfirmationWithID', {
                                    id: checkoutInfo.project,
                                    price: ctrl.cost.price,
                                    tax: ctrl.cost.tax,
                                    total: ctrl.cost.total
                                });
                                break;
                            default:
                                state.go('payment.orderConfirmationWithID', {
                                    id: checkoutInfo.project,
                                    price: ctrl.cost.price,
                                    tax: ctrl.cost.tax,
                                    total: ctrl.cost.total
                                });
                        }
                    }, 300);
                },
                function(error) {
                    // var preloaderElement = document.getElementsByClassName('preloader')[0];
                    // preloaderElement.parentElement.removeChild(preloaderElement);
                    if (ctrl.checkoutDetails.cardid) {
                        ctrl.messageLabel.CURRENT =
                            error && error.message
                                ? error.message
                                : ctrl.messageLabel.NO_PAYMENT;
                        ctrl.scrollTop();
                    } else {
                        ctrl.messageLabel.CURRENT = ctrl.messageLabel.NO_CARD;
                        ctrl.scrollTop();
                    }
                    // document.body.style.overflow = 'auto';
                }
            )
            .finally(function() {
                ctrl.isBookingInProgress = false;
            });
    };

    ctrl.getBreadcrumb = function() {
        var taskDescription = BreadcrumbService.getTaskDescription();
        _.each(taskDescription, function(item) {
            item.disabled = true;
        });
        ctrl.bcInfo = taskDescription;
    };

    ctrl.isServiceLocationChecked = function(ischecked) {
        if (ischecked) {
            ctrl.isLocationAddresChecked = true;
            ctrl.newbillingAddressValid = true;
            ctrl.newbillingAddressContinue = true;
        } else {
            ctrl.isLocationAddresChecked = false;
            //console.log(ctrl.billingAddress);
            if (ctrl.billingAddress === undefined) {
                ctrl.newbillingAddressValid = false;
                ctrl.newbillingAddressContinue = false;
            }
        }
    };

    ctrl.trackPaymentFormChanges = function(newInitiated, formValid) {
        isNewPaymentMethod = newInitiated;
        if (newInitiated) {
            if (formValid) {
                ctrl.paymentMethodValid = true;
            } else {
                ctrl.paymentMethodValid = false;
            }
            ctrl.paymentMethodContinue = false;
        } else {
            ctrl.paymentMethodValid = false;
            ctrl.paymentMethodContinue = false;
            if (ctrl.checkoutDetails.cardid && ctrl.selectedPaymentCard) {
                ctrl.validateCVVForSelectedPayment(ctrl.selectedPaymentCard);
            }
            NewPaymentMethod.resetpaymentMethod();
        }
        return ctrl.paymentMethodValid;
    };

    ctrl.validateCVVForSelectedPayment = function(card) {
        if (card.type.name === 'AMEX') {
            if (card.cvv && card.cvv.length === 4) {
                ctrl.paymentMethodValid = true;
                ctrl.paymentMethodContinue = true;
            } else {
                ctrl.paymentMethodValid = false;
                ctrl.paymentMethodContinue = false;
            }
        } else {
            if (card.cvv && card.cvv.length === 3) {
                ctrl.paymentMethodValid = true;
                ctrl.paymentMethodContinue = true;
            } else {
                ctrl.paymentMethodValid = false;
                ctrl.paymentMethodContinue = false;
            }
        }
    };

    ctrl.trackServiceAddrChanges = function(
        newAddrReqInitiated,
        isFormValid,
        setServiceLocation
    ) {
        if (setServiceLocation) {
            ctrl.newServiceLocationValid = true;
            ctrl.newServiceLocationContinue = true;
            isServiceLocationAvail = true;
        } else if (newAddrReqInitiated) {
            isNewServiceLocation = true;
            ctrl.newServiceLocationValid = false;
            ctrl.newServiceLocationContinue = false;
        } else if (isNewServiceLocation) {
            if (isFormValid) {
                ctrl.newServiceLocationValid = true;
            } else {
                ctrl.newServiceLocationValid = false;
            }
            ctrl.newServiceLocationContinue = false;
        }
    };

    ctrl.trackServiceContactChanges = function(isFormValid) {
        if (isFormValid) {
            ctrl.newServiceContactValid = true;
        } else {
            ctrl.newServiceContactValid = false;
        }
    };

    ctrl.init();

    angular.element($window).bind('scroll', OrderSummaryFixed.scrollCallback);

    $scope.$on('$destroy', function() {
        angular
            .element($window)
            .unbind('scroll', OrderSummaryFixed.scrollCallback);
    });

    $scope.$on('new:billing:address:canceled', function() {
        ctrl.newbillingAddressValid = false;
        ctrl.newbillingAddressContinue = false;
        if (ctrl.billingAddress.id) {
            ctrl.newbillingAddressValid = true;
            ctrl.newbillingAddressContinue = true;
        }
        isNewAddress = false;
        NewBillingAddress.resetBillingAddress();
    });

    $scope.$on('new:billing:address', function() {
        ctrl.newbillingAddressValid = false;
        ctrl.newbillingAddressContinue = false;
        isNewAddress = true;
    });

    $scope.$on('valid:billing:address:form', function() {
        if (isNewAddress) {
            ctrl.newbillingAddressValid = true;
            ctrl.newbillingAddressContinue = false;
        }
    });
    $scope.$on('invalid:billing:address:form', function() {
        if (isNewAddress) {
            ctrl.newbillingAddressValid = false;
            ctrl.newbillingAddressContinue = false;
        }
    });
    ctrl.onNewServiceLocationCancelled = function(serviceAddressCancelEvent) {
        if (serviceAddressCancelEvent) {
            ctrl.newServiceLocationValid = false;
            ctrl.newServiceLocationContinue = false;
            isNewServiceLocation = false;
            if (isServiceLocationAvail) {
                ctrl.newServiceLocationValid = true;
                ctrl.newServiceLocationContinue = true;
            }
            NewServiceLocation.resetServiceLocation();
        }
    };

    ctrl.proceedToSrvLocation = function() {
        ctrl.isSrvLocPanelOpen = true;
        ctrl.isCustInfoOpen = false;
    };

    ctrl.proceedAfterRegistration = function() {
        ctrl.isCustInfoOpen = false;
        if (ctrl.isTechTalk) {
            ctrl.proceedToCards();
        } else {
            ctrl.proceedToSrvLocation();
        }
    };

    ctrl.processRegisteredUser = function() {
        var loggedInUser = LoginManagerService.getUser();
        ctrl.isRegistered = loggedInUser.isRegistered;
        ctrl.isGuest = loggedInUser.isGuest || false;
        ctrl.prepareDataForProjectCreation();
        ProjectsService.create(ctrl.project, false)
            .then(function(response) {
                checkoutInfo.project = response.id;
                var updatedInfo = ctrl.prepareDataForProjectUpdation(
                    response.id
                );

                ProjectsService.update(updatedInfo, false).then(function(
                    response
                ) {
                    ctrl.acceptEstimate(response.id);
                });

                if (ctrl.isTechTalk) {
                    ctrl.proceedToCards();
                } else {
                    ctrl.proceedToSrvLocation();
                }
            })
            .catch(function(error) {
                ctrl.messageLabel.CURRENT =
                    (error && error.message) || ctrl.messageLabel.DEFAULT;
            });
    };

    ctrl.prepareDataForProjectCreation = function() {
        ctrl.project.catalogId = ctrl.project.category.rowid || 0;
        ctrl.project.zipcode = ctrl.project.location.zipCode;
        var timeSlot = ctrl.project.timeSlot.trim();
        ctrl.project.timeslot = timeSlot === '-' ? '' : ctrl.project.timeSlot;
        ctrl.project.servicetype = ctrl.serviceType;
        // For avoiding duplicate title text
        delete ctrl.project.title;
    };

    ctrl.prepareDataForProjectUpdation = function(projectId) {
        var updatedInfo = {
            startdates: ctrl.project.preferredStartDates,
            timeSlots: ctrl.project.preferredSlots,
            id: projectId,
            show_availability: true
        };

        if (ctrl.isTechTalk) {
            // For TechTalk update the contact number too
            // from the previous appointment page
            updatedInfo.contactnumber = checkoutInfo.contactNumber;
        }

        return updatedInfo;
    };

    ctrl.showLogin = function() {
        ctrl.isCustInfoOpen = true;
        ctrl.scrollTop();
    };

    ctrl.editDatePanel = function() {
        ctrl.showCalendarControl = true;
        ctrl.dateTimeTouched = false;
        ctrl.isDatePanelOpen = true;
    };

    ctrl.proceedToCards = function() {
        if (!ctrl.isTechTalk && !ctrl.newServiceLocationValid) {
            return false;
        }
        // else if (ctrl.isTechTalk && !ctrl.newServiceContactValid) {
        //     return false;
        // }
        ctrl.isSrvLocPanelOpen = false;
        ctrl.isPaymentMethodListOpen = true;
        ctrl.serviceLocationTouched = true;
        if (ctrl.addressLine2 === undefined) {
            ctrl.addressLine2 = '';
        }
        if (ctrl.isTechTalk) {
            ctrl.selectedAddressLine = [
                ctrl.email,
                $filter('bcTelephone')(ctrl.serviceContact, 'format')
            ].join(', ');
        } else {
            var selectedServiceLocationAddress = NewServiceLocation.getServiceLocationList();
            ctrl.selectedAddressLine = [
                selectedServiceLocationAddress.addressLine1 +
                    (selectedServiceLocationAddress.addressLine2 || ''),
                selectedServiceLocationAddress.city,
                selectedServiceLocationAddress.state,
                selectedServiceLocationAddress.zipcode
            ].join(', ');
            if (ctrl.selectedAddressLine.length > 60) {
                ctrl.selectedAddressLine =
                    ctrl.selectedAddressLine.substring(0, 57) + '...';
            }
        }
    };

    ctrl.proceedToBillingAddr = function() {
        if (!ctrl.paymentMethodValid) {
            return false;
        }
        ctrl.isPaymentMethodListOpen = false;
        ctrl.isBillingAddrOpen = true;
        ctrl.cardDetailsTouched = true;
    };

    ctrl.proceedToPayment = function() {
        if (!ctrl.newbillingAddressValid) {
            return false;
        }
        ctrl.billingAddressTouched = true;
        ctrl.isBillingAddrOpen = false;
        if (!ctrl.isLocationAddresChecked) {
            ctrl.selectedBillingAddressLine = [
                ctrl.billingAddress.addressline1 +
                    (ctrl.billingAddress.addressline2 || ''),
                ctrl.billingAddress.city,
                ctrl.billingAddress.state,
                ctrl.billingAddress.zipcode
            ].join(', ');
        } else {
            ctrl.selectedBillingAddressLine = ctrl.selectedAddressLine;
        }
        if (ctrl.selectedBillingAddressLine.length > 60) {
            ctrl.selectedBillingAddressLine =
                ctrl.selectedBillingAddressLine.substring(0, 57) + '...';
        }
        ctrl.shouldDisableCheckoutBtn();
        ctrl.scrollTop();
    };

    ctrl.shouldDisableCheckoutBtn = function() {
        if (ctrl.isBookingInProgress) {
            return true;
        }
        if (
            ctrl.isTechTalk &&
            // ctrl.newServiceContactValid &&
            ctrl.newbillingAddressValid &&
            ctrl.newbillingAddressContinue &&
            ctrl.paymentMethodValid &&
            ctrl.paymentMethodContinue &&
            ctrl.dateTimeTouched &&
            ctrl.isRegistered &&
            ctrl.serviceLocationTouched &&
            ctrl.cardDetailsTouched &&
            ctrl.billingAddressTouched
        ) {
            return false;
        } else if (
            !ctrl.isTechTalk &&
            ctrl.newServiceLocationValid &&
            ctrl.newServiceLocationContinue &&
            ctrl.newbillingAddressValid &&
            ctrl.newbillingAddressContinue &&
            ctrl.paymentMethodValid &&
            ctrl.paymentMethodContinue &&
            ctrl.dateTimeTouched &&
            ctrl.isRegistered &&
            ctrl.serviceLocationTouched &&
            ctrl.cardDetailsTouched &&
            ctrl.billingAddressTouched
        ) {
            return false;
        }
        return true;
    };

    /**
     ******************Date Picker****************
     */

    ctrl.popup2 = {
        opened: false
    };

    ctrl.open2 = function() {
        ctrl.popup2.opened = true;
    };

    ctrl.updateProjectStartDate = function() {
        var formattedDate = moment(ctrl.dt).format('ddd[,] MMM D[,] YYYY');
        checkoutInfo.selectedDate = formattedDate;
        ctrl.selectedDate = formattedDate;
        ctrl.timeRanges = DTService.getTimeRangesFromDate(
            ctrl.availableDates,
            moment(ctrl.dt).format('YYYY-MM-DD')
        );
    };

    ctrl.updateTimeSlot = function() {
        checkoutInfo.selectedTime =
            (ctrl.selectedTimeSlotModel && ctrl.selectedTimeSlotModel.value) ||
            ctrl.selectedTimeSlotModel;
        ctrl.selectedTimeSlot = checkoutInfo.selectedTime;
    };

    ctrl.isDateTimeInvalid = function() {
        if (ctrl.project) {
            if (
                ctrl.project.serviceType ===
                    SettingsService.ServiceTypes.STANDARDV3 ||
                ctrl.project.serviceType ===
                    SettingsService.ServiceTypes.STANDARD
            ) {
                return false;
            }
        }
        var validity1 = DTService.isDateTimeInvalid(
            ctrl.selectedDate,
            ctrl.selectedTimeSlot
        );
        var validity2 = DTService.isDateTimeInvalid(
            checkoutInfo.selectedDate,
            checkoutInfo.selectedTime
        );
        return validity1 || validity2;
    };
}

PaymentCheckoutCtrl.$inject = [
    '$state',
    'checkoutInfo',
    'PaymentProcessService',
    'SettingsService',
    'CheckoutInfoService',
    'project',
    'moment',
    'BreadcrumbService',
    '$anchorScroll',
    'ProjectsService',
    'OrderSummaryFixed',
    '$filter',
    '$scope',
    '$rootScope',
    '$window',
    'NewBillingAddress',
    'NewServiceLocation',
    'NewPaymentMethod',
    '$braintree',
    'braintreeValue',
    'PaymentAddressesService',
    'addressesService',
    'PaymentMethodsService',
    'ProjectDateTimeModalService',
    'DateTimeValidationService',
    'ENVIRONMENT',
    '_',
    'ZipcodeInfoService',
    'LoginManagerService',
    '$timeout'
];

angular
    .module('RelayServicesApp.Payment')
    .controller('PaymentCheckoutCtrl', PaymentCheckoutCtrl);
