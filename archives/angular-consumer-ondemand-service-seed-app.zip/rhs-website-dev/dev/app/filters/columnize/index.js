'use strict';

function Columnize(_) {
    return _.memoize(_.chunk);
}

Columnize.$inject = ['_'];

(angular
    .module('RelayServicesApp.Filters')
).filter('columnize', Columnize);
