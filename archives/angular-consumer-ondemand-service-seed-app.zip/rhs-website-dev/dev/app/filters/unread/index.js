'use strict';
function Unread() {
    return function(input) {
        var out = [];
        angular.forEach(input, function(item) {
            if (item.read === false) {
                out.push(item);
            }
        });
        return out;
    };
}

Unread.$inject = [];

(angular
.module('RelayServicesApp.Filters')
).filter('unread', Unread);
