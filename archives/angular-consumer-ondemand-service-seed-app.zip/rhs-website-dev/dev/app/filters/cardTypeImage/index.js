'use strict';

function CardTypeImage() {
    return function(_type) {
        var type = ({
            'American Express': 'amex',
            'Discover': 'discover',
            'Diners Club': 'diners',
            'MasterCard': 'mc',
            'Maestro': 'maestro',
            'JCB': 'jcb',
            'Visa': 'visa'
        })[_type];
        return 'assets/img/cc-' + type + '.png';
    };
}

(angular
    .module('RelayServicesApp.Filters')
).filter('cardTypeImage', CardTypeImage);
