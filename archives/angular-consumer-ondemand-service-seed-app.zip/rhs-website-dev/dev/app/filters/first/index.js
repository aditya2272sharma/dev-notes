'use strict';

function First(_) {
    return _.memoize(_.take);
}

First.$inject = ['_'];

(angular
    .module('RelayServicesApp.Filters')
).filter('first', First);
