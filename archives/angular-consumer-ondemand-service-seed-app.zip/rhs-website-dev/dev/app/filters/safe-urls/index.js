'use strict';

function SafeURLs() {
    return function(input, separator) {
        separator = separator || '-';

        return input.replace(/[^a-zA-Z ]/g, '').replace(/\s+/g, separator).toLowerCase();
    };
}

(angular
    .module('RelayServicesApp.Filters')
).filter('safeUrls', SafeURLs);
