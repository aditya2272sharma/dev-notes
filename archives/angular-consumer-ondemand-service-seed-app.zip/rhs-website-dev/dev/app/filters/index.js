'use strict';

function Configure() {
}

function Run() {
}

(angular
    .module('RelayServicesApp.Filters', [])
    .config(Configure)
).run(Run);
