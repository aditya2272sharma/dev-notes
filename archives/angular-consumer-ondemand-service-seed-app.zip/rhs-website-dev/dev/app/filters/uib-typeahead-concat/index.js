'use strict';

function Concat() {
    return function(input, viewValue) {
        if (!viewValue || !viewValue.length) {
            return input;
        }
        if (input && input.length) {
            var viewValObj = {
                name: viewValue,
                isCustom: true
            };
            if (!(input.length === 1 && input[0].name === viewValue)) {
                input.unshift(viewValObj);
            }
            return input;
        } else {
            return [];
        }
    };
}

Concat.$inject = [];

(angular
    .module('RelayServicesApp.Filters')
).filter('concat', Concat);
