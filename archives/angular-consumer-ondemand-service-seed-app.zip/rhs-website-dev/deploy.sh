#!/bin/bash


function getEtag() {
    etag=$(
        JSON="$1" python - <<END
import os
import json
data = json.loads(os.environ['JSON'])

print data['ETag']

END
    )
    echo $etag
}

filename=relayservices-content.zip

echo "Copying the zip $filename to s3"
aws s3 cp $filename s3://rhs-static-resources/bundles/rhs-website/

json=`aws s3api head-object --bucket rhs-static-resources --key bundles/rhs-website/$filename`
etag=$(getEtag "$json")

echo "Etag: $etag"

aws deploy create-deployment --application-name rhs-cd-staging --deployment-config-name CodeDeployDefault.OneAtATime --deployment-group-name rhs-web-app --description "deply static files" --s3-location bucket=rhs-static-resources,bundleType=zip,eTag=$etag,key=bundles/rhs-website/$filename
