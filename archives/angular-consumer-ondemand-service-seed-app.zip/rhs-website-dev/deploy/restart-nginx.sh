#!/bin/bash

# service nginx stop
systemctl stop nginx

rm -rf /tmp/s3_cache

# service nginx start
systemctl start nginx

if (( $(ps -ef | grep -v grep | grep nginx | wc -l ) > 0 ))
then
    exit 0
else
    exit 1
fi
