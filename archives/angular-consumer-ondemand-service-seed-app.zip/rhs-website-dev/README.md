# ServiceLive D2C Web portal
Welcome to the 2016 Relay Services Web Site. The document contains instructions to setup and run the RHS Website, information regarding environments, site architecture, names of contributors and features.


## Target Browsers

- IE9+
- Firefox 38+
- Chrome 42+
- Safari 8+
- Opera 30+

### Style Guide

The official styleguide is available to look at / modify in the repository under the URL.

* `/styleguide` e.g. https://qaservices.shoprelay.com/styleguide

## Setting up your local machine
#### Prerequisites:
* Any text editor like `atom` or `sublime`. If you're using intelliJ, make sure to install `nodejs`, `grunt/gulp` and `web` specific plugins.
* `nodejs`: install from web
* `npm`: comes by default with the nodejs binary distribution. After installing nodejs, update the `npm` version by executing `npm update` in the console. npm is the package manager that downloads and installs nodejs packages and libraries.
* `gulp`: Gulp is our build tool which executes the build script present in `gulpfile.js` present at the **root level** of the working directory. You must install it globally. Therefore, execute `npm install -g gulp`.
* **Mac/Linux users** - A global installation can fail in a *nix operating system. A quick way to avoid this will be using `sudo` while making global(`-g`) installations. A better solution is to [fix npm permissions](https://docs.npmjs.com/getting-started/fixing-npm-permissions). 

### Other pre-req

* Download Pro App: https://tsfr.io/zoztkv
* Bookmark Pro portal: http://198.203.224.12/MarketFrontend/homepage.action
* Credentials for above: *will be made available upon request*

##### Sublime Text / Atom setup
 * The instruction for Sublime holds good for Atom as well.
 * In order to follow the standard code styling for JavaScript, Install `Sublime linter`. SublimeLinter is a plugin for Sublime Text 3 that provides a framework for linting code. SublimeLinter can help you write cleaner, better, more bug-free code.
 * Similarly, install the corresponding plugins for `jscs` and `jshint`

###### URLs
 * [Sublime​Linter](http://www.sublimelinter.com/en/latest/)
 * [Sublime​Linter-jscs](https://packagecontrol.io/packages/SublimeLinter-jscs)
 * [Sublime​Linter-jscs](https://github.com/SublimeLinter/SublimeLinter-jshint)

#### Setup
* Clone the repository into your local drive. Default branch is set to `dev`. Pull the latest changes: `git pull --rebase`
* Go to the console. `cd` into the working directory.
* Execute `npm install` to install the dependencies.

#### Proxy setup
* If the remote API doesn't have CORS enabled, you can rely on json-proxy already part of the dev dependencies.
* The `package.json` contains a `start` command in `scripts`

#### Running the server
##### If you're on a **Mac**
 - Execute `npm start` directly and it'll start the local server as well as the proxy server to route the requests to staging.

##### If you're on **windows**
 - Go to start menu and search for `nodejs command prompt`
 - Open two instances of the nodejs command prompt window and `CD` into the working directories in both.
 - In one instance, run `gulp local`
 - In another instance, run the proxy server by running `npm start`

**Note:**
* The Gulp command automatically launches the `Karma` test server and then, the `http://localhost:9000` test site.
* You do not need to restart the server after making changes to the source code. Gulp watches for changes in source files automatically.
* If your changes don't reflect in the site or the browser doesn't auto-refresh after few seconds of code change, go to console & observe if there were any errors.
* If you see an error in the console or your build stopped mid way because of any errors, copy the error message and report this issue to any of the FE devs.
* You might occasionally see a warning about license fields. Ignore them.

|Build type/Environment|Command to execute|Environment Identifier/Flag|URL|
|---|---|---|---|
|LOCAL|`gulp local`|`N/A`|http://localhost:9000|
|TEST|`gulp test`|`N/A`|`N/A`|`N/A`|
|PREDEV|`gulp --env=predev`|`--env=predev`|https://predevservices.shoprelay.com/ |
|DEV (alternative)|`gulp build:dev`|`N/A`||
|DEV|`gulp --env=dev`|`--env=dev`|https://devservices.shoprelay.com/ |
|QA/STAGING|`gulp --env=qa`|`--env=qa`|https://qaservices.shoprelay.com/ |
|PILOT|`gulp --env=pilot`|`--env=pilot`||
|PREPRD|`unknown`|`unknown`| https://prodservices.shoprelay.com/ |
|PROD|`gulp --env=prod`|`--env=prod`|https://www.servicelive.com |

#### Trigger a build on boxes

- If you've access to `app.codeship.com/sears-home-services`, you can directly go there, scroll & locate your last build & initiate a fresh build on UI.
- If you do not have access to it, then the easiest way around this is to bump the version number in `package.json` on line no. 3.
- Make sure to follow the [SemVer](http://semver.org/) guidelines while bumping.
- Ideally, you'll have to update the last few digits e.g. `"version": "0.0.1"` into `"version": "0.0.2"`

#### Simulating enviornments to mimic & test build failures on dev/qa/prod boxes

* There might be occassions when the build succeeds to execute in your local & fails on Prod or QA or Dev servers.
* Root causes of such failures are often incorrectly written code
* There are some extra gulp tasks e.g. `ugligy` that run only on such boxes.
* To simulate the environment, you can open your `gulpfile` & go to line: 52, where we set the environment.

```
environment = argv.env || LOCAL_ENVIRONMENT,
```

* Force set the variable to your desired environment e.g. `'dev'` or `'qa'`. Also, note that the values are always strings.

```
environment = 'qa'; //argv.env || LOCAL_ENVIRONMENT,
```

Alternatively, you can set an enviornment variable called `env`, but that'll be the hard way to deal with the problems.

#### How to Login into localhost

1. Go to `package.json`
2. Go to line number 143 (where API maps for `localhost`)
3. **Change the domain to** `qaservices.shoprelay.com`
4. And, on line number 147. **Make the `port` empty. Note that without empty ports, you won't be able to connect to those servers.**
```js
    "api": {
        "protocol": "http",
        "domain": "localhost", // change this to `qaservices.shoprelay.com`
        "context": "api/v1/",
        "port": "9090" // change it to empty pair of quotes""
    }
```
5. **Note**: Do not leave trailing commans. Do not add/leave comments in the json file. It throws errors.
6. Go to `dev/app/services/session-status-resolve.js`
7. line number 14, add it like below

```js
if (typeof(cookies.get('token')) !== 'undefined' || true) {...}
```
* Then restart both gulp & proxy server, run `gulp local` and `npm start` in their respective windows. Mac users can `ctrl+c` and re-execute `npm start` in their terminal.
* On your browser, go to `https://qaservices.shoprelay.com/`. Sign in with your credentials and refresh the page.
* Go back to your development tab & refresh a couple of times.
* Tada!!! You're logged in.
* **Don't forget** to undo your changes before committing, or carefully exclude/unstage the files.

#### Test cases, Lint and Dev build breakage

You might occasionally observe that -

* because of too many linting errors the dev environment breaks. 
* also, sometimes the build fails to trigger the `watch` cycle because of errors in test spec files

**Caution:** As a responsible developer, one's job is to ideally fix the errors. The following instructions are meant to unblock you from issues mentioned above & aren't meant for regular development work. Please remember that test case failures & lint errors can break the staging & prod builds too & shall not be allowed during code review.

**To unblock yourself from Lint & Test case failures:**

```js
// open the gulpfile & change
gulp.watch(devPaths.app + '**/*.js', ['browserify', 'lint', 'jscs']);
// to 
gulp.watch(devPaths.app + '**/*.js', ['browserify']);
//and, comment `test`
// i.e. from
'serve', 'test', 'watch', 'url');
//to
'serve',/*'test',*/'watch','url');
```
  
    

## the `Bizniss` logic
* To know Project Status & the corresponding intended behaviour refer this [Google Doc](https://docs.google.com/spreadsheets/d/11aG2Xa-nikfJLp0qd_pYVgIALtv0NIW3RDRVK3wsb_A/edit?usp=sharing)
* The complete flow chart is present in the root with the name `Untitled Diagram.xml`, use a service like `https://www.draw.io/` to view the flow chart.

## Service Order Statuses

|Code|Status|
|---|---|
|'100'|'Draft'| 
|'105'|'Deleted'| 
|'110'|'Routed'|
|'120'|'Cancelled'| 
|'125'|'Voided'|
|'130'|'Expired'|
|'150'|'Accepted'|
|'155'|'Active'|
|'160'|'Completed'|
|'165'|'Pending Cancel'|
|'170'|'Problem'|
|'180'|'Closed'|

## Creating a Non-Standard(NS) Project with Multiple Estimates

Steps:

- Book any NS project
- Go to Pro portal
- Login with b2c user credentials
- Click on Service Order Monitor
- Go to Search
- Select `Service Order ID` from the multi-select and copy-paste the SO ID in the text field adjacent to it
- Click `Add`, and click `Search`
- On the filtered result, check if the Project status says 'STATE: POSTED'
- If above is true, click `Edit Service Order`
- Click on the `Providers` Tab
- You'll see a list of Providers
- Tick as many as you wish. **Don't forget to Tick the listem item with 'Tim C'**

```
Tim C. (User Id# 23161) 
Company ID# 17123
```

- Click on `Next` and provide a Price and click next
- Scroll to bottom of the page
- Leave the Checkbox unchecked
- Accept the T&Cs (without reading, because Sachin says so)
- Click Post Service Order
- If you want to provide estimates for `HSH` & `Tim C` both, then:
  - Open your pro app
  - First, login with the user crenentials for HSH (HomeSweetHomeTheatre)
  - Provide the estimate and log out
  - Second, enter Tim C's credentials (ask Sachin for credentials)
	 - Provide estimates again
- Go back to the ServiceLive portal
- Refresh the window to see your latest Project status
- Also observe the estimates API response and it should contain
  - Multiple Firms
  - Multiple Estimates

## Draft feature

1. Crate a draft order. You can use the zip `56003` for creating one (Yes, Sarjapur Rd. Mohit lives there).
2. Go to Pro portal & Login with buyer creds a.k.a. B2C creds
3. Go to Service Order Monitor & search with SO
4. Click on the search results & you'll see an `Edit Order` button
5. Go to Provider tab
6. Post to Following ID : Company ID# 49434
7. Click all 'Next' buttons & accept T&Cs **without reading**.

The above steps will **post the order to the particular provider**.

Then you'll have to login using the 49434 Provider's ID (for credentials, contact Kamlesh) & complete the steps as any Normal NS Order.

## Geolocation & Google Utils APIs

Ideally all HTML5 compatible browsers should provide the `geolocation` API which returns the sensor details.

**Example** - 

```js
navigator
.geolocation
.getCurrentPosition(function(position) {
    console.log(position);
})
```

This should return you an object which is an instance of `Position` class.

The output from above operation looks like:

```js
{  
    coords:  {
      accuracy: 30
      altitude: null
      altitudeAccuracy: null
      heading: null
      latitude: 12.927273999999999
      longitude: 77.6754971
      speed: null
      __proto__: Coordinates
    }
    timestamp: 1515120483767
}
```

- Google API Utility services allow you to fetch location by using Lattitude and Longitude
- `googleApiUtilsService.getCurrentPosition()` will determine your current `Position`
    - i.e. `Lattitude` and `Longitude`
- `googleApiUtilsService.getAddressByLatLong()`
  - takes `lat` and `lng` as inputs
  - returns the *complete address* & *final address*
  - We need to pass the response from `getCurrentPosition()` to `getAddressByLatLong(...)`
  - e.g. `getAddressByLatLong(position.lat, position.lng)`

**Sample Code Snippet** - 

```js
function setGeolocation() {
    // for a new user, use the HTML5 geolocation API
    var geolocation = $window.navigator && $window.navigator.geolocation;
    if (geolocation) {
        googleApiUtilsService.getCurrentPosition()
        .then(function(position) {
            googleApiUtilsService
            .getAddressByLatLong(position.lat, position.lng)
            .then(function(response) {
                _.assign(geolocation, response);
                locationFetchSuccessCallBack(response);
                zipCode = angular.isString(response.finalAddress.zipcode) ? response.finalAddress.zipcode : '';
                if(zipCode.length === 5) {
                    ZipcodeInfoService
                    .setZipcode(zipCode, {
                        checkServiceability: false
                    });
                } else {
                    // Ask user to provide his/her zipcode
                }
            });
        });
    }
}
```

## Setting GPS in Chrome

#### Access sensor controls

To access the Chrome DevTools sensor controls:

- Open the DevTools main menu, then
- Under More Tools, click on Sensors
- Setting up dev tools: https://developers.google.com/web/tools/chrome-devtools/device-mode/device-input-and-sensors

|City|Lat|Long|
|---|---|---|
| Albuquerque, New Mexico | 35.113281 | -106.6056 |
| Hoffman Estates, Illinois | 42.062992 | -88.1227 |

 
# Documentation

* For all other kinds of documentations, please visit: https://wiki.intra.sears.com/confluence
* and, use the search field to type your query.
* For example:
* *IRP documentation:* https://wiki.intra.sears.com/confluence/display/PRFENG/IRP+Mobile+API
* look for: `x-irp-debug:  localhost-127.0.0.1|1513597711603-irDQp3CcUO|sears`

## Git Flow

Clone the repo:

`$ git clone git@bitbucket.org:zemoga/sea-relay-services.git /path/to/localProjectName`

`$ cd /path/to/localProjectName`
  
### Create a feature branch, tied to the jira ticket you are working on

`$ git checkout -b branchName`

  
### Rebase master into your feature branch

`$ git pull origin master:master`

`$ git rebase master`

### Push the feature branch to Bitbucket

`$ git push origin branchName`

### Create the pull request in Bitbucket and assign a peer(s) reviewer for merge.
