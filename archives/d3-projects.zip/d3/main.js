var
  main = d3.select('#main'),
  // color = d3.scaleOrdinal(d3.schemeCategory20),
  xMax = d3.max(window.nodes, function(d){
    return d.x;
  }),
  valueMax = d3.max(window.nodes, function(d){
    return d.value;
  }),
  yMax = d3.max(window.nodes, function(d){
    return d.y;
  }),
  color = d3.scaleLinear()
    .domain([0, valueMax])
    .range(['red', 'green', 'blue']),
  height = 500,
  width = 700,
  svg = main.append('svg').attr("width", width).attr("height", height),
  circles = svg
  .selectAll('circle')
  .data(window.nodes)
  .enter()
  .append('circle')
  .attr("r", 1)
  .attr('fill', "#ccc")
  .attr('cx', function(d){
    return d.x;
  })
  .attr('cy', function(d){
    return d.y;
  })

;
  
  var simulation = d3
    .forceSimulation(window.nodes)
    .force('charge', d3.forceManyBody().strength(-20))
    .force('center', d3.forceCenter(width/2, height/2))
    .force('x', d3.forceX(width/2).strength(0.02))
    // .force('x', d3.forceX(height/2))
    .force('y', d3.forceY(height/2).strength(0.002))
    .force('collide', d3.forceCollide(valueMax))
    .force('radius', function(d){
        return d.value;
    })
    .nodes(window.nodes)
    .on('tick', function(){
      circles
          .transition()
          .ease(Math.sqrt)
          .duration(100050)
          .attr('r', function(d){
            return d.value
          })
         .attr("cx", function(d) {
           if(d.value < 20) {
             return d.x + 50;
           }
           return d.x + 100;
         })
         .attr("cy", function(d) { 
           if(d.value < 30) {
             return 40;
           }
           return 150;
         })
         .attr('fill', function(d){
           return color(d.value);
         })
         ;
    })
