https://qaservices.shoprelay.com/

Took workflow session from Dnyaneshwar & Ranjeet (From Danababu's Team), Testers



Will meet with Sachin & Jeevan (devs) from Sailesh's team for Dev KT.


staging swagger-ui url
https://qaservices.shoprelay.com/api/v1/swagger-ui.html#!

staging url
https://qaservices.shoprelay.com/
