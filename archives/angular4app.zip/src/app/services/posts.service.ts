import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
// import 'rxjs/add/operartor/map';

@Injectable()

export class PostsService {
  constructor(private http: HttpClient) {
    console.log('posts service initialized');
  }
  
  getPosts() {
    return this.http.get('https://jsonplaceholder.typicode.com/posts');
      // .map(response => res.json());
  }
  
  getGithubUserProfile() {
    return this.http.get('https://api.github.com/users/aditya2272sharma');
    // return this.http.get('https://api.github.com/users/seeschweiler');
  }
}
