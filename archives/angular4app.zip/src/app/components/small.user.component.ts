import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'small-user-component',
  template: `
    <div>
      <h3>Small User</h3>
      <h2>Hello {{user.name}}</h2>
      <ul>
        <li><strong>Age:</strong>{{user.age}}</li>
        <li><strong>Status:</strong>{{user.working ? 'Works here' : 'No longer works here'}}</li>
      </ul>
    </div>
  `,
  styleUrls: []
})

export class SmallUserComponent implements OnInit{
  @Input() user: user;
  @Input() title: string;
  
  constructor() {
    // this.title = 'app';
    // this.user = {
    //   name: 'Steve',
    //   age: 12,
    //   working: false
    // };
  }

  ngOnInit(): void {}
}
