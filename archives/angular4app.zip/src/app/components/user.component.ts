import { Component, Input, OnInit } from '@angular/core';
import { PostsService } from '../services/posts.service';

@Component({
  selector: 'user-component',
  templateUrl: 'user.component.html',
  styleUrls: [],
  providers: [
    PostsService
  ]
})

export class UserComponent implements OnInit{
  @Input() user: user;
  @Input() title: string;
  getGithubUserProfile: object;
  
  constructor(private postsService: PostsService) {
    // this.title = 'app';
    // this.user = {
    //   name: 'Steve',
    //   age: 12,
    //   working: false
    // };
    this.postsService.getGithubUserProfile().subscribe(data => {
      console.log("github user data", data);
      this.getGithubUserProfile = data;
    }, err => {
      console.log('Error occurred', err);
    })
  }

  ngOnInit(): void {
    
  
  }
}
