import { Component, Input, OnInit } from '@angular/core';
import { PostsService } from '../services/posts.service';

@Component({
  selector: 'posts-component',
  templateUrl: 'posts.component.html',
  styleUrls: [],
  providers: [
    PostsService
  ]
})

export class PostsComponent implements OnInit{
  posts: object;
  
  constructor(private postsService: PostsService) {
    this.postsService.getPosts().subscribe(data => {
      console.log("posts data", data);
      this.posts = data;
    }, err => {
      console.log('Error occurred', err);
    });
  }
}
