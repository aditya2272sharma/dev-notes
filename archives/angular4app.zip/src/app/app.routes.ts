import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { UserComponent } from './components/user.component';
import { PostsComponent } from './components/posts.component';


const appRoutes: Routes = [
  {
    path: '',
    component: AppComponent,
    children: [
      {
        path: 'user',
        component: UserComponent
      },
      {
        path: 'posts',
        component: PostsComponent
      },
    ]
  },
];

export const routing: ModuleWithProviders = RouterModule.forRoot(appRoutes);
