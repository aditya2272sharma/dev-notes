import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title: string;
  userData: userData;

  constructor(){
    this.title = 'app';
    this.userData = {
      name: 'Steve',
      age: 12,
      working: false,
      // height: '5.6'
    };
  }
}

interface userData {
    name: string;
    age: number;
    working: boolean;
}
