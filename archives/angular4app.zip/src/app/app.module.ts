import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';


import { AppComponent } from './app.component';
import { UserComponent } from './components/user.component';
import { SmallUserComponent } from './components/small.user.component';
import { PostsComponent } from './components/posts.component';
import { routing } from './app.routes';



@NgModule({
  declarations: [
    AppComponent,
    UserComponent,
    SmallUserComponent,
    PostsComponent
  ],
  imports: [
    BrowserModule,
    HttpModule,
    HttpClientModule,
    routing
    // RouterModule.forRoot(routing)
  ],
  exports: [
    RouterModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
