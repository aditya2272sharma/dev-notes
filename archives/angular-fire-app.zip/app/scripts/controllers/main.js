'use strict';

/**
 * @ngdoc function
 * @name fashinApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the fashinApp
 */
angular.module('fashinApp')
  .controller('MainCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
