'use strict';

/**
 * @ngdoc function
 * @name fashinApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the fashinApp
 */
angular.module('fashinApp')
  .controller('AboutCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
