'use strict';

describe('Service: DataMassage', function () {

  // load the service's module
  beforeEach(module('fashinscoopApp'));

  // instantiate service
  var DataMassage;
  beforeEach(inject(function (_DataMassage_) {
    DataMassage = _DataMassage_;
  }));

  it('should do something', function () {
    expect(!!DataMassage).toBe(true);
  });

});
