'use strict';

describe('Directive: uploadImages', function () {

  // load the directive's module
  beforeEach(module('fashinscoopApp'));

  var element,
    scope;

  beforeEach(inject(function ($rootScope) {
    scope = $rootScope.$new();
  }));

  it('should make hidden element visible', inject(function ($compile) {
    element = angular.element('<upload-images></upload-images>');
    element = $compile(element)(scope);
    expect(!!element).toBe(true);
  }));
});
