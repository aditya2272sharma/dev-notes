'use strict';

describe('Controller: ViewWithIdCtrl', function () {

  // load the controller's module
  beforeEach(module('fashinscoopApp'));

  var ViewWithIdCtrl,
    scope;

  // Initialize the controller and a mock scope
  beforeEach(inject(function ($controller, $rootScope) {
    scope = $rootScope.$new();
    ViewWithIdCtrl = $controller('ViewwithidCtrl', {
      $scope: scope
      // place here mocked dependencies
    });
  }));

  it('should attach a list of awesomeThings to the scope', function () {
    expect(ViewWithIdCtrl.awesomeThings.length).toBe(3);
  });
});
