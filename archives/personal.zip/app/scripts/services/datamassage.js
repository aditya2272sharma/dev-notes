'use strict';

/**
 * @ngdoc service
 * @name fashinscoopApp.DataMassage
 * @description
 * # dataMassage
 * Service in the fashinscoopApp.
 */
angular.module('fashinscoopApp')
  .service('DataMassage', function () {
    // AngularJS will instantiate a singleton by calling "new" on this function
    function _sanitizeProductData (productData) {

      if (!isNaN(productData.assestivePrice)) {
        // data type double
        productData.assestivePrice = parseFloat(productData.assestivePrice);
      }

      if (!isNaN(productData.discount)) {
        // data type double
        productData.discount = parseFloat(productData.discount);
      }

      if (!isNaN(productData.price)) {
        // data type double
        productData.price = parseFloat(productData.price);
      }

      if (!isNaN(productData.unitsInStock)) {
        productData.unitsInStock = parseInt(productData.unitsInStock, 10);
      }

      /* jshint ignore:start */
      // jscs:disable
      // work arounds for old data <starts>
      productData.genre = [];
      productData.gener.forEach(function(genre, index) {
        productData.genre[index] = genre.itemName;
      });
      // jscs errors: requireCamelCaseOrUpperCaseIdentifiers: All identifiers
      // must be camelCase or UPPER_CASE
      // http://jscs.info/rule/requireCamelCaseOrUpperCaseIdentifiers
      productData.availableSizes = productData['available_sizes'];
      productData.metaTagTitle = productData['meta_tag_title'];
      // work arounds for old data <ends>
      // jscs:enable
      /* jshint ignore:end */
      
      
      return productData;
    }
    return {
      sanitizeProductData: _sanitizeProductData
    };
  });
