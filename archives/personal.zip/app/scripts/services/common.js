'use strict';

/**
 * @ngdoc service
 * @name fashinscoopApp.common
 * @description
 * # common
 * Service in the fashinscoopApp.
 */
angular.module('fashinscoopApp')
  .service('common', [
    '$rootScope',
    function ($rootScope) {
      // global private variables
      var firebase, db;

      firebase = window.firebase;
      db = firebase.database();

      // AngularJS will instantiate a singleton by calling "new" on this function
      function _generateRandomId () {

        if (!$rootScope.authData) {
          throw 'Error: Unauthorized attempt. Please login again.';
        }

        // var stringToEncode = [
        //   + new Date(),
        //   Math.random(),
        //   $rootScope.authData.email,
        //   $rootScope.authData.displayName,
        //   $rootScope.authData.uid
        // ].join('');
        // return window.btoa(stringToEncode);

        // turns out firebase has it's own unique
        // key generator. we don't have to
        // re-invent the wheel
        return $rootScope.rootRef.push().key;
      }

      function _submitProduct(product, action, callback) {
        if (!product.$id) {
          return;
        }

        var key, ref; 

        key = product.$id;
        ref = db.ref('/sellers/products/' + key);
        action = action || '';
        callback = callback || angular.noop;
        /* jshint ignore:start */
        // jscs:disable
        // might contain work arounds for old data <starts>
        product.available_sizes = product.availableSizes;
        if (product.genre) {
          product.genre.forEach(function (itemName, index) {
            product.gener[index] = {
              'id': index,
              'itemName': itemName
            };
          });
        }
        delete product.$$conf;
        delete product.$id;
        delete product.$priority;
        delete product.$resolved;
        // work arounds for old data <ends>
        // jscs:enable
        /* jshint ignore:end */
        ref.set(product)
          .then(function (response) {
            console.log('Success', response);
            window.alert('Successfully completed:' + action);
            callback(response);
          });
      } 

      return {
        generateRandomId: _generateRandomId,
        submitProduct: _submitProduct
      };
  }]);
