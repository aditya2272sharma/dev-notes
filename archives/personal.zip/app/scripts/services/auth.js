'use strict';

/**
 * @ngdoc service
 * @name fashinscoopApp.auth
 * @description
 * # auth
 * Service in the fashinscoopApp.
 */
angular.module('fashinscoopApp')
  .service('auth', function () {
    // AngularJS will instantiate a singleton by calling "new" on this function
    return {
      login: function () {
        console.log('login');
      }
    };
  });
