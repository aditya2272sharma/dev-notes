'use strict';

/**
 * @ngdoc directive
 * @name fashinscoopApp.directive:uploadImages
 * @description
 * # uploadImages
 */
angular.module('fashinscoopApp')
  .directive('uploadImages', [
    '$location',
    '$rootScope',
    'common',
    function ($location, $rootScope, common) {
      return {
        templateUrl: 'views/uploadImages.html',
        restrict: 'E',
        link: function postLink($scope, element, attrs) {
          // element.text('this is the uploadImages directive');
          angular.noop($scope, element, attrs);
          $scope.validateImage = function () {
            // add ngf-validate-fn="validateImage()"
            // for validating images
            if (!$scope.product.productImg) {
              return true;
            }

            var currentImageLength = 0;

            for(var i=1; i<=5; i++) {
              var imgPath = 'imgUrl' + i;
              if (imgPath in $scope.product.productImg) {
                currentImageLength++;
              }
            }

            if (currentImageLength >= 5) {
              window.alert('Max image upload limit of 5 has been reached.');
              return false;
            }

          };

          $scope.uploadToStorage = function(file) {
            $rootScope
              .currentStorageRef
              .child(common.generateRandomId())
              .put(file)
              .then(function (snapshot) {
                angular.extend(snapshot, file);
                window.alert('File uploaded successfully to:', snapshot.metadata.fullPath);
                console.log('Uploaded a blob or file!', snapshot);
                $scope.mapUploadedImagesToProduct(snapshot);
              });
          };

          $scope.mapUploadedImagesToProduct = function(snapshot) {
            var key = '';
            if (!$scope.product.productImg) {
              $scope.product.productImg = {};
            }
            if (!$scope.product.productImages) {
              $scope.product.productImages = [];
            }
            
            // find where the current index stands
            // for the image we just pushed

            for(var i=1; i<=5; i++) {
              key = 'imgUrl' + i;
              if (key in $scope.product.productImg) {
                continue;
              } else {
                break;
              }
            }

            // Documentation:

            // snapshot.metadata.downloadURLs
            // type: array, contains all image paths

            // snapshot.metadata.fullPath;
            // type: string, contains last image's path

            $scope.product.productImg[key] = {
              name: snapshot.name,
              size: snapshot.bytesTransferred,
              url: snapshot.metadata.downloadURLs[0]
            };

            $scope.product.productImages.push(snapshot.metadata.downloadURLs[0]);
            
            // bad way to determine if the product already exists
            if ($scope.product.$id) {
              common.submitProduct($scope.product, 'Upload images');
            }
          };

          $scope.thumbNailClick = function (item, index) {
            // TODO: Implement thumbNailClick in future
            angular.noop(item, index);
          };
        }
      };
  }]);
