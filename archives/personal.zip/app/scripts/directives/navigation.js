'use strict';

/**
 * @ngdoc directive
 * @name fashinscoopApp.directive:navigation
 * @description
 * # navigation
 */
angular.module('fashinscoopApp')
  .directive('navigation', ['$rootScope', function ($rootScope) {
    return {
      templateUrl: 'views/navigation.html',
      restrict: 'E',
      // link: function postLink(scope, element, attrs) {
      link: function postLink($scope) {
        $scope.authenticated = false;
        // element.text('this is the navigation directive');
        $scope.html5Mode = false;
        $scope.$on('event:authenticated', function(){
          $scope.authenticated = true;
        });
        $scope.$on('event:unauthorized', function(){
          $scope.authenticated = false;
        });

        $scope.logout = function() {
          $rootScope.$broadcast('event:logout');
        };
      }
    };
  }]);
