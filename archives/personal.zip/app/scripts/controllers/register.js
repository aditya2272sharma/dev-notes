'use strict';

/**
 * @ngdoc function
 * @name fashinscoopApp.controller:RegisterCtrl
 * @description
 * # RegisterCtrl
 * Controller of the fashinscoopApp
 */
angular.module('fashinscoopApp')
  .controller('RegisterCtrl', [
    '$scope',
    '$rootScope',
    '$location',
    function ($scope, $rootScope, $location) {
      var firebase = window.firebase || {};

      angular.noop($scope, $rootScope, $location);
      angular.noop(firebase);

      $scope.showRegistrationError = false;

      $scope.login = function() {
        $location.path('/');
      };

      $scope.createUser = function() {
        firebase.auth()
        .createUserWithEmailAndPassword($scope.email, $scope.password)
        .then(function(response){
          console.log('Registration Succeeded: ', response);
          $location.path('/');
        })
        .catch(function(registrationError) {
          // Handle Errors here.
          $scope.registrationError = registrationError;
          $scope.showRegistrationError = true;
          console.log('Registration Failed: ', registrationError);
        });
      };

      // warning: $scope.register is meant for a different purpose
      // it's internal & hence, shouldn't be user overridden
      $scope.registerUser = function() {
        // kept for future to do some validations here
        $scope.createUser();
      };
  }]);
