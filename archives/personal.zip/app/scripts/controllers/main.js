'use strict';

/**
 * @ngdoc function
 * @name fashinscoopApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the fashinscoopApp
 */
angular.module('fashinscoopApp')
  .controller('MainCtrl', [
    '$scope',
    '$rootScope',
    '$location',
    function ($scope, $rootScope, $location) {
      $scope.authenticated = false;
      $scope.showLoginSection = false;
      $scope.authData = $rootScope.authData;
      
      if ($rootScope.authData) {
        $scope.authenticated = true;
        $scope.showLoginSection = false;
      } else {
        $scope.authenticated = false;
        $scope.showLoginSection = true;
      }
      
      $scope.add = function() {
        $location.path('/add');
      };

      $scope.view = function() {
        $location.path('/view');
      };

      $scope.register = function() {
        $location.path('/register');
      };

      $scope.logout = function() {
        $rootScope.$broadcast('event:logout');
      };
      
      $scope.$on('event:authenticated', function(){
        $scope.authenticated = true;
        $scope.showLoginSection = false;
        $scope.authData = $rootScope.authData;
      });

      $scope.$on('event:unauthorized', function(){
        $scope.authenticated = false;
        $scope.showLoginSection = true;
        $scope.authData = $rootScope.authData;
      });

      $scope.signIn = function() {
        $rootScope.authService
        .$signInWithEmailAndPassword($scope.email, $scope.password)
        .then(function(authData) {
          $rootScope.authData = authData;
          $rootScope.$broadcast('event:authenticated');
        }).catch(function(error) {
          console.error('Authentication failed:', error);
          $rootScope.authData = null;
          $scope.showLoginSection = true;
        });
      };

      $scope.forgotPassword = function() {
        var firebase, actionCodeSettings;
        
        firebase = window.firebase;
        actionCodeSettings = {};
        actionCodeSettings = {
          url: 'https://www.example.com/?email=user@example.com'
        };

        if (!$scope.email) {
          window.alert('Please provide an email first!');
          return;
        }

        firebase
        .auth()
          .sendPasswordResetEmail($scope.email, actionCodeSettings)
        .then(function () {
          window.alert('The password reset instructions have been sent to the registered email');
        })
        .catch(function (error) {
          console.log('Password reset Error:', error);
        });
      };
    }]);
