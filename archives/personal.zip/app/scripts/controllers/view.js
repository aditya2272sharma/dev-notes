'use strict';

/**
 * @ngdoc function
 * @name fashinscoopApp.controller:ViewCtrl
 * @description
 * # ViewCtrl
 * Controller of the fashinscoopApp
 */
angular.module('fashinscoopApp')
  .controller('ViewCtrl', [
    '$scope',
    '$rootScope',
    '$location',
    '$firebaseArray',
    '$firebaseObject',
    function ($scope, $rootScope, $location, $firebaseArray, $firebaseObject) {
      // all unauthorized users should be redirected to home
      if ($rootScope.authData === null) {
        $location.path('/');
      }

      // all variables are private
      var firebase, db, ref, _snapshot;
      
      firebase = window.firebase || {};
      db = firebase.database();
      ref = db.ref('/sellers/products');

      angular.noop($scope, $rootScope, $location, $firebaseArray, $firebaseObject);
      angular.noop(firebase, db, ref, _snapshot);

      $firebaseArray(ref.orderByChild('sellerId'))
      .$loaded()
      .then(function(allProducts) {
        $scope.allProducts = allProducts; // populated object
      });
      // use ref.limitToLast(<insert number here>) for pagination
      // e.g. ref.orderByChild('sellerId').limitToLast(10)
      // more on this: https://firebase.google.com/docs/database/web/lists-of-data

      this.view = function (productId) {
        $location.path('/view/' + productId);
      };

      this.edit = function (productId) {
        $location.path('/edit/' + productId);
      };

      this.delete = function (productId) {
        var decision = window.confirm('Deleted products can\'t be recovered. Are you sure you want to delete?');
        if (decision) {
          ref.child(productId)
          .remove()
          .then(function(response) {
            console.log('Successfully Deleted: ', productId, ' from /sellers/products.', response);
          });
        }
      };

      // let the following commented code stay

      // ref
      // .orderByChild('name')
      // // .orderByKey()
      // .once('value')
      // .then(function (snapshot) {
      //   _snapshot = snapshot;
      // })
      // .then(function(data) {
      //   // All promises succeeded.
      //   $scope.allProducts = data;
      // })
      // .catch(function(error){
      //   console.log('Firebase Error', error);
      // }); //.limitToLast(10)

      // de-funct
      // fetching a single product
      // ref
      // .child('Cela1PE5eh-2017-12-13-22-37-18')
      // .once('value')
      // .then(function (snapshot) {
      //   console.log('snapshot captured: ', snapshot);
      // })
      // .then(function(data) {
      //   console.log('single product fetched: ', data);
      // })
      // .catch(function(error){
      //   console.log('Firebase Error', error);
      // });
      
      // var reqArr = $firebaseArray( db.ref().child('sellers').child('products').child('Cela1PE5eh-2017-12-13-22-37-18'));
      // var reqObj = $firebaseObject( db.ref().child('sellers').child('products').child('Cela1PE5eh-2017-12-13-22-37-18'));
      // console.log('reqArr', reqArr);
      // console.log('reqObj', reqObj);
      
      // var reqObj = $firebaseObject( db.ref('sellers/products'));
      // console.log('reqObj', reqObj);
    }]);
