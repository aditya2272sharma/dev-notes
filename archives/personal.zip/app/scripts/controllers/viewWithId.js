'use strict';

/**
 * @ngdoc function
 * @name fashinscoopApp.controller:ViewwithidCtrl
 * @description
 * # ViewwithidCtrl
 * Controller of the fashinscoopApp
 */
angular.module('fashinscoopApp')
  .controller('ViewwithidCtrl', [
    '$scope',
    '$rootScope',
    '$routeParams',
    '$location',
    '$firebaseArray',
    '$firebaseObject',
    function ($scope, $rootScope, $routeParams, $location, $firebaseArray, $firebaseObject) {
      // all unauthorized users should be redirected to home
      if ($rootScope.authData === null) {
        $location.path('/');
      }
      // all variables are private
      var firebase, db, ref, _snapshot;
      
      firebase = window.firebase || {};
      db = firebase.database();
      ref = db.ref('/sellers/products/' + $routeParams.productId);

      angular.noop($scope, $rootScope, $routeParams, $location, $firebaseArray, $firebaseObject);
      angular.noop(firebase, db, ref, _snapshot);
      
      $firebaseObject(ref).$loaded().then(function(product) {
        $scope.product = product; // populated object
      });

      $scope.edit = function(productId) {
        $location.path('/edit/' + productId);
      };
  }]);
