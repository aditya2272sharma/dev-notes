'use strict';

/**
 * @ngdoc function
 * @name fashinscoopApp.controller:AddCtrl
 * @description
 * # AddCtrl
 * Controller of the fashinscoopApp
 */
angular.module('fashinscoopApp')
  .controller('AddCtrl', [
    '$scope',
    '$rootScope',
    'constants',
    '$q',
    '$routeParams',
    '$location',
    '$firebaseArray',
    '$firebaseObject',
    'DataMassage',
    'common',
    function ($scope, $rootScope, constants, $q, $routeParams, $location, $firebaseArray,
      $firebaseObject, DataMassage, common) {

      // all unauthorized users should be redirected to home
      if ($rootScope.authData === null) {
        $location.path('/');
      }
      // all variables are private
      var _productData, firebase, db, ref, _snapshot, productId;

      firebase = window.firebase || {};
      db = firebase.database();
      _productData = {};
      $scope.product = {};

      // to bypass lint, pass all extra arguments into this
      angular.noop(_productData, firebase, db, ref, _snapshot);
      angular.noop($scope, $rootScope, constants);
      angular.noop($q, $routeParams, $location, $firebaseArray, $firebaseObject);
      angular.noop(DataMassage);

      $scope.CONST = constants;

      $scope.init = function() {
        if ($routeParams.productId && $location.path().indexOf('edit') > -1) {
          productId = $routeParams.productId;
          $scope.currentAction = 'Edit/Update Product';
          ref = db.ref('/sellers/products/' + $routeParams.productId);
          $firebaseObject(ref)
            .$loaded()
            .then(function(productData) {
              $scope.product = DataMassage.sanitizeProductData(productData);
              console.log('Edit Product: Product updated successfully', $scope.product);
              $scope.genderSelectionChanged();
              $rootScope.currentStorageRef = firebase.storage().ref('sellers/products/' + productData.$id);
            });
        } else {
          productId = common.generateRandomId();
          $scope.currentAction = 'New Product Creation';
          ref = db.ref('/sellers/products/').child(productId).push();
          ref.set({})
          .then(function (response) {
            console.log('Add Product: Product Key set successfully', response);
          });
          // ref = db.ref('/sellers/products/' + productId);


          
          $rootScope.currentStorageRef = firebase.storage().ref('sellers/products/' + productId);
        }
      };

      $scope.calculateEffectivePrice = function () {
        $scope.product.assestivePrice = $scope.product.price - (($scope.product.price * $scope.product.discount) / 100);
      };

      $scope.genderSelectionChanged = function () {
        switch ($scope.product.gender) {
          case 'Male':
            $scope.genreData = constants.maleGenres;
            $scope.subGenreData = constants.maleSubGenre;
            break;

          case 'Female':
            $scope.genreData = constants.femaleGenres;
            $scope.subGenreData = constants.femaleSubGenre;
            break;

          case 'Unisex':
            $scope.genreData = constants.uniSexGenres;
            $scope.subGenreData = constants.unisexSubGenre;
            break;

          default:
            break;
        }
      };

      $scope.setGenre = function () {
        $scope.product.genre = $scope.productGenre;
      };

      $scope.setSubGenre = function () {
        $scope.product.subgenre = $scope.productSubGenre;
      };

      $scope.selectedSizeChanged = function (event, size) {
        var index = 0;
        if (event.target.checked) {
          $scope.product.availableSizes.push(size);
        } else {
          index = $scope.product.availableSizes.indexOf(size);
          $scope.product.availableSizes.splice(index, 1);
        }
      };

      $scope.isSelectedSize = function (size) {
        if (!$scope.product.availableSizes) {
          return false;
        }

        var filteredResults = [];
        filteredResults = $scope.product.availableSizes.filter(function(item) {
          return (item === size);
        });
        return (filteredResults.length > 0);
      };
      
      $scope.submitData = function() {
        // create a deep copy so that the references don't get messed up
        _productData = angular.copy($scope.product);
        common.submitProduct(_productData, $scope.currentAction, function (response) {
          angular.noop(response);
        });
      };

      // initialize when the user auth information has been retrieved
      $scope.$on('event:authenticated', function () {
        $scope.init();
      });

      // let this be here as a reference for the corresponding test suite
      // this.awesomeThings = [
      //   'HTML5 Boilerplate',
      //   'AngularJS',
      //   'Karma'
      // ];

    }]);
  
      
      
      
      
