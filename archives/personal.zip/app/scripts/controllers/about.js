'use strict';

/**
 * @ngdoc function
 * @name fashinscoopApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the fashinscoopApp
 */
angular.module('fashinscoopApp')
  .controller('AboutCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
