'use strict';

/**
 * @ngdoc function
 * @name fashinscoopApp.controller:LoginCtrl
 * @description
 * # LoginCtrl
 * Controller of the fashinscoopApp
 */
angular.module('fashinscoopApp')
  .controller('LoginCtrl', ['$scope', function ($scope) {
    $scope.signIn = function () {
      console.log('hello');
    };
  }]);
