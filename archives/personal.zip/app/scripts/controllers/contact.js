'use strict';

/**
 * @ngdoc function
 * @name fashinscoopApp.controller:ContactCtrl
 * @description
 * # ContactCtrl
 * Controller of the fashinscoopApp
 */
angular.module('fashinscoopApp')
  .controller('ContactCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
