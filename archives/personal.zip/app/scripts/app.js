'use strict';

var firebase = firebase || {};

/**
 * @ngdoc overview
 * @name fashinscoopApp
 * @description
 * # fashinscoopApp
 *
 * Main module of the application.
 */
angular
  .module('fashinscoopApp', [
    'ngAnimate',
    'ngCookies',
    'ngResource',
    'ngRoute',
    'ngSanitize',
    'ngTouch',
    'ngTagsInput',
    'ngFileUpload',
    'firebase'
  ])
  .constant('apiKey', 'AIzaSyDVPRr075fAigw1XZbXvGHLkdcnkyn5owE')
  .constant('authDomain', 'https://fashinscoop.firebaseapp.com/')
  .constant('databaseURL', 'https://fashinscoop.firebaseio.com')
  .constant('projectId', 'fashinscoop')
  .constant('storageBucket', 'fashinscoop.appspot.com')
  .constant('messagingSenderId', '573057148764')
  .config(['$routeProvider', '$locationProvider', function ($routeProvider, $locationProvider) {

    $routeProvider
      .when('/', {
        templateUrl: 'views/main.html',
        controller: 'MainCtrl',
        controllerAs: 'main'
      })
      .when('/about', {
        templateUrl: 'views/about.html',
        controller: 'AboutCtrl',
        controllerAs: 'about'
      })
      .when('/login', {
        templateUrl: 'views/login.html',
        controller: 'LoginCtrl',
        controllerAs: 'login'
      })
      .when('/contact', {
        templateUrl: 'views/contact.html',
        controller: 'ContactCtrl',
        controllerAs: 'contact'
      })
      .when('/add', {
        templateUrl: 'views/add.html',
        controller: 'AddCtrl',
        controllerAs: 'add'
      })
      .when('/edit/:productId', {
        templateUrl: 'views/add.html',
        controller: 'AddCtrl',
        controllerAs: 'add'
      })
      .when('/view', {
        templateUrl: 'views/view.html',
        controller: 'ViewCtrl',
        controllerAs: 'view'
      })
      .when('/view/:productId', {
        templateUrl: 'views/viewWithId.html',
        controller: 'ViewwithidCtrl',
        controllerAs: 'viewWithId'
      })
      .when('/register', {
        templateUrl: 'views/register.html',
        controller: 'RegisterCtrl',
        controllerAs: 'register'
      })
      .otherwise({
        redirectTo: '/'
      });

      $locationProvider.html5Mode(false);
      // $locationProvider.html5Mode(true);
      // $locationProvider.html5Mode(true).hashPrefix('!');
  }])
  .run([
    '$rootScope',
    '$location',
    '$route',

    // all firebase configurations
    'apiKey',
    'authDomain',
    'databaseURL',
    'storageBucket',
    'messagingSenderId',

    // all angularfire / firebase imports
    '$firebaseAuth',
    '$firebaseArray',
    '$firebaseObject',
    '$firebaseStorage',
    function ($rootScope, $location, $route,
      apiKey, authDomain, databaseURL, storageBucket, messagingSenderId,
      $firebaseAuth, $firebaseArray, $firebaseObject, $firebaseStorage) {

      // just to bypass the linters
      angular.noop($rootScope, $location, $route,
        apiKey, authDomain, databaseURL, storageBucket, messagingSenderId,
        $firebaseAuth, $firebaseArray, $firebaseObject, $firebaseStorage);

      firebase.initializeApp({
        apiKey: apiKey,
        authDomain: authDomain,
        databaseURL: databaseURL,
        storageBucket: storageBucket,
        messagingSenderId: messagingSenderId
      });

      firebase.auth().setPersistence(firebase.auth.Auth.Persistence.LOCAL);
      $rootScope.authObj = firebase.auth();
      $rootScope.authService = $firebaseAuth($rootScope.authObj);

      $rootScope.rootRef = firebase.database().ref();
      $rootScope.authService.$onAuthStateChanged(function (authData) {
        if (authData) {
          $rootScope.authData = authData;
          $rootScope.$broadcast('event:authenticated');
          if ($location.path().length <= 3) {
            // $location.path('/view');
            $route.reload();
          }
        } else {
          console.log('Case: Unauthenticated User.');
          $rootScope.authData = null;
          $rootScope.$broadcast('event:unauthorized');
          // $location.path('/');
          $route.reload();
        }
      });

      $rootScope.$on('event:logout', function(){
        $rootScope.authService
        .$signOut()
        .then(function(response){
          console.log('Successfully logged out', response);
          $rootScope.$broadcast('event:unauthorized');
          $location.path('/');
        });
      });
  }]);
