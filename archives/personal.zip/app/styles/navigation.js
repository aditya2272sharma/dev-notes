import React, {StyleSheet, Dimensions, PixelRatio} from "react-native";
const {width, height, scale} = Dimensions.get("window"),
    vw = width / 100,
    vh = height / 100,
    vmin = Math.min(vw, vh),
    vmax = Math.max(vw, vh);

export default StyleSheet.create({
    "navbar-brandfashinscoop-logo": {
        "position": "relative",
        "top": -50
    },
    "container logo": {
        "height": 55,
        "marginBottom": -1.5,
        "backgroundImage": "url(/images/logo.svg)",
        "backgroundRepeat": "no-repeat",
        "backgroundPosition": "center center",
        "backgroundSize": 200
    },
    "navbar": {
        "marginBottom": 0
    },
    "navbar-fixed-left": {
        "width": 140,
        "borderRadius": 0,
        "position": "absolute",
        "left": 0,
        "top": 50,
        "bottom": "100%"
    },
    "navbar-fixed-left navbar-nav > li": {
        "float": "none",
        "width": 139
    },
    "navbar-fixed-left + container": {
        "paddingLeft": 160
    },
    "navbar-fixed-left navbar-nav > li > dropdown-menu": {
        "marginTop": -50,
        "marginLeft": 140
    }
});