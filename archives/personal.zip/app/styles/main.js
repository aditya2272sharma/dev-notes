import React, {StyleSheet, Dimensions, PixelRatio} from "react-native";
const {width, height, scale} = Dimensions.get("window"),
    vw = width / 100,
    vh = height / 100,
    vmin = Math.min(vw, vh),
    vmax = Math.max(vw, vh);

export default StyleSheet.create({
    "browsehappy": {
        "marginTop": 0.2,
        "marginRight": 0,
        "marginBottom": 0.2,
        "marginLeft": 0,
        "background": "#ccc",
        "color": "#000",
        "paddingTop": 0.2,
        "paddingRight": 0,
        "paddingBottom": 0.2,
        "paddingLeft": 0
    },
    "body": {
        "paddingTop": 0,
        "paddingRight": 0,
        "paddingBottom": 0,
        "paddingLeft": 0
    },
    "header": {
        "paddingLeft": 15,
        "paddingRight": 15,
        "marginBottom": 10
    },
    "marketing": {
        "paddingLeft": 15,
        "paddingRight": 15,
        "marginTop": 40,
        "marginRight": 0,
        "marginBottom": 40,
        "marginLeft": 0
    },
    "footer": {
        "paddingLeft": 10,
        "paddingRight": 10,
        "paddingTop": 12,
        "paddingBottom": 9,
        "color": "#777",
        "borderTop": "1px solid #e5e5e5",
        "position": "fixed",
        "left": 0,
        "right": 0,
        "bottom": 0,
        "background": "linear-gradient(to bottom, #eee 0%,#ddd 100%)"
    },
    "header h3": {
        "marginTop": 0,
        "marginBottom": 0,
        "lineHeight": 40,
        "paddingBottom": 19
    },
    "container-narrow > hr": {
        "marginTop": 30,
        "marginRight": 0,
        "marginBottom": 30,
        "marginLeft": 0
    },
    "jumbotron": {
        "textAlign": "center",
        "borderBottom": "1px solid #e5e5e5"
    },
    "jumbotron btn": {
        "fontSize": 21,
        "paddingTop": 14,
        "paddingRight": 24,
        "paddingBottom": 14,
        "paddingLeft": 24
    },
    "marketing p + h4": {
        "marginTop": 28
    },
    "li": {
        "listStyle": "none"
    },
    "text-ellipsis": {
        "textOverflow": "ellipsis",
        "whiteSpace": "nowrap",
        "overflow": "hidden",
        "maxHeight": "100%",
        "maxWidth": "100%"
    },
    "text-ellipsis:hover": {
        "overflow": "visible"
    },
    "maincontainer": {
        "paddingBottom": 80
    },
    "maincontainer-fluid": {
        "paddingBottom": 80
    },
    "container": {
        "paddingBottom": 80
    },
    "button[disabled]": {
        "opacity": 0.6
    },
    "input-validation": {
        "fontSize": 0.75,
        "color": "#d00"
    },
    "label sup": {
        "color": "#d00"
    },
    "multi-checkbox-selector": {
        "marginTop": 0,
        "marginRight": 0,
        "marginBottom": 10,
        "marginLeft": 0,
        "paddingTop": 0,
        "paddingRight": 0,
        "paddingBottom": 0,
        "paddingLeft": 0
    },
    "multi-checkbox-selector li": {
        "paddingTop": 10,
        "paddingRight": 5,
        "paddingBottom": 0,
        "paddingLeft": 10,
        "borderRadius": 5
    },
    "multi-checkbox-selector li:hover": {
        "backgroundColor": "#d2e9da"
    },
    "multi-checkbox-selector liselected": {
        "backgroundColor": "#d2e9da"
    },
    "large-list-items-wrapper": {
        "paddingTop": 0,
        "paddingRight": 0,
        "paddingBottom": 0,
        "paddingLeft": 0,
        "marginTop": 0,
        "marginRight": 0,
        "marginBottom": 0,
        "marginLeft": 0
    },
    "large-list-items-wrapper li": {
        "paddingTop": 3,
        "paddingRight": 2,
        "paddingBottom": 3,
        "paddingLeft": 2,
        "fontSize": 0.75,
        "lineHeight": 2.5
    },
    "large-list-items-wrapper li:nth-child(2n)": {
        "backgroundColor": "#f7f9fa"
    },
    "large-list-items-wrapper li:nth-child(2n+1)": {
        "backgroundColor": "#e1f3da"
    },
    "large-list-items-wrapper li:nth-child(2n+2)": {},
    "large-list-items-wrapper lihead": {
        "fontWeight": "bold",
        "backgroundColor": "#2e788a",
        "color": "#fff",
        "fontSize": 12
    },
    "large-list-items-wrapper li span": {
        "maxHeight": 36,
        "overflow": "hidden"
    },
    "upload-image-section": {
        "height": 300,
        "width": 400,
        "marginTop": 0,
        "marginRight": "auto",
        "marginBottom": 0,
        "marginLeft": "auto"
    }
});