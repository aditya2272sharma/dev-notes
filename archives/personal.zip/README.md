# fashinscoop

This project is generated with [yo angular generator](https://github.com/yeoman/generator-angular)
version 0.15.1.

- The application was created by siphoning code from https://github.com/firebase/firereader into the aforementioned
- Further, firebase libraries were added, alongside yarn and bower shrink wrap to ensure consistency across platforms
- Developers are advised to avoid using `^` in the versions in `package.json` and `bower.json`. `~` should be used instead
- Best approach will be to use Yarn to add libraries.

## Prerequisite

Following items need to be installed before going ahead

- yarn (latest)
- npm@4.2.0 (use `npm install -g npm@4.2.0` to downgrade)
- node@6.0.0 (use nvm if you want to downgrade to an older version)
- bower@1.7.7 (this is to ensure the bower-shrinkwrap-resolver works correctly)
    - Read more: https://www.npmjs.com/package/bower-shrinkwrap-resolver
- atom, or sublime, or visual studio code or any suitable text editor
- nodejs command prompt on windows
- bash shell or terminal in *nix operating systems
- `yeoman` generator (always use yeoman for generating services, directives or routes, it automatically wiredeps & generates test cases )

## Build & development

- Run `yarn` to install all **stable** libraries from npm
- Run `bower install` to install all bower packages (includes bootstrap css and js libraries like jquery)
- Run `grunt` for building and `grunt serve` for preview.

## Testing

- Running `grunt test` will run the unit tests with karma.
- https://github.com/angular/angular-seed#end-to-end-testing


### Firebase Migration

Reference Materials:
  1. https://github.com/firebase/angularfire/blob/master/docs/reference.md
  2. https://firebase.google.com/docs/reference/js/
  3. https://www.firebase.com/docs/web/libraries/angular/guide/
  4. https://medium.com/google-developers/the-single-biggest-angular-and-firebase-code-smell-and-how-to-fix-it-a0d1ef96ca65

Steps

- Documentation for firebase & angularfire versions used in this app
- https://www.firebase.com/docs/web/libraries/angular/api.html
- https://www.firebase.com/docs/web/libraries/angular/api.html#angularfire-firebasearray-addnewdata
- The above documentations may stand obsolete. The migration guide has to be followed for all discrepancies.
- https://firebase.google.com/support/guides/firebase-web
- Also, observe the google groups for discussion
- https://groups.google.com/forum/#!topic/firebase-angular/
- Authentication / Session Persistence
- https://firebase.google.com/docs/auth/web/auth-state-persistence
- More on managing Promises in firebase
- https://firebase.googleblog.com/2016/01/keeping-our-promises-and-callbacks_76.html

- Creating Data Layer & Using AngularFire to manipulate the reference
- https://kieldev.wordpress.com/2017/01/15/firebase-real-time-database-using-angularjs/



#### Other errors
- `auth.onAuthStateChanged is not a function`
    - https://github.com/firebase/angularfire/issues/743
    - https://groups.google.com/forum/#!topic/firebase-angular/ARzgNWcrIiY
- Firebase Password Reset
    - https://firebase.google.com/docs/reference/js/firebase.auth.Auth#sendPasswordResetEmail
  

## Helpful Links

Please go through the following tutorials before getting started

- https://github.com/yeoman/generator-angular
- https://scotch.io/tutorials/pretty-urls-in-angularjs-removing-the-hashtag
- https://scotch.io/tutorials/getting-started-with-browserify
- https://bootsnipp.com/snippets/5lapE
- https://css-tricks.com/snippets/css/truncate-string-with-ellipsis/
- http://jshint.com/docs/
- http://jscs.info/rule/

The application was created referring to the examples listed in the offcial repo:

- https://github.com/firebase/angularfire

Further, refer the following examples:

- https://github.com/firebase/firereader
- https://github.com/angular/angular-seed

The SVG logo was generated from the PNG image on https://image.online-convert.com/convert-to-svg.


## Node JS command prompt Bower Install issues

Before executing `bower install` in windows (NodeJS command prompt), execute the following two statements in NodeJS command prompt.
They will set the path variable for GIT, so that you don't get the `Bower: ENOGIT Git is not installed or not in the PATH` error.


```sh
set PATH=%PATH%;C:\Program Files (x86)\Git
set PATH=%PATH%;C:\Program Files (x86)\Git\bin
```

ref: https://stackoverflow.com/a/23179102/2458438
