'use strict';

describe('Service: NLPAspectsSelected', function () {

  // load the service's module
  beforeEach(module('buySmaartApp'));

  // instantiate service
  var NLPAspectsSelected;
  beforeEach(inject(function (_NLPAspectsSelected_) {
    NLPAspectsSelected = _NLPAspectsSelected_;
  }));

  it('should do something', function () {
    expect(!!NLPAspectsSelected).toBe(true);
  });

});
