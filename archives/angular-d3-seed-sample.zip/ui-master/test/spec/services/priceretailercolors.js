'use strict';

describe('Service: priceRetailerColors', function () {

  // load the service's module
  beforeEach(module('buySmaartApp'));

  // instantiate service
  var priceRetailerColors;
  beforeEach(inject(function (_priceRetailerColors_) {
    priceRetailerColors = _priceRetailerColors_;
  }));

  it('should do something', function () {
    expect(!!priceRetailerColors).toBe(true);
  });

});
