'use strict';

describe('Service: MetaInformation', function () {

  // load the service's module
  beforeEach(module('buySmaartApp'));

  // instantiate service
  var MetaInformation;
  beforeEach(inject(function (_MetaInformation_) {
    MetaInformation = _MetaInformation_;
  }));

  it('should do something', function () {
    expect(!!MetaInformation).toBe(true);
  });

});
