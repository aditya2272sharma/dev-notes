'use strict';

describe('Service: timerangepicker', function () {

  // load the service's module
  beforeEach(module('buySmaartApp'));

  // instantiate service
  var timerangepicker;
  beforeEach(inject(function (_timerangepicker_) {
    timerangepicker = _timerangepicker_;
  }));

  it('should do something', function () {
    expect(!!timerangepicker).toBe(true);
  });

});
