##Requirements
    - node js
    - ruby
    - compass
    - grunt
    - bower
##app folder 
It holds all the UI related files
###bower_components folder
Whenever we require a third party component we install it using bower install --save package name. We are not required to include js or css files related to this in index.html
###email-templates
Email templates are maintained here. Individual email template are foldered.
###fonts
It contains .eot, .svg, .ttf, .woff files related to the fonts and custom font icons for buysmmart.
###images/ignore
We will maintain individual static images in this folder. The images that are added outside ignore is removed from the build.
###scripts
We will maintain all the js scripts
####app.js
We have a reference of this in index.html. It will initialize the application. Social login configurations will be done here, Server URL's are configured here currently it is relative, NLP filters default options are initialized here, ng-routing configurations are also here and angular dependencies are included here.
####controllers
All the control files related to views are maintained here.
#####accordianInit.js:
It will initialize the accordion for static pages.
#####CompareDefault.js:
It holds the controller for the compare defaults (when no phones are added to compare)
#####CompareResults.js:
It holds the controller for compare results view (when more than one phone is compared)
#####contactUs.js:
It holds the controller for contact us view.
#####DiscoveryDashboard.js:
It holds the controller for discovery dashboard view. We have a pageSize variable here that will define how many items are need to be rendered into page(currently it is 6). We have an animation plug-in that helps in animation. It uses winMax.
#####Feedback.js: `moved to quarantine`
~~It holds the controller for feedback view. It will render using **feed-back** directive.~~
#####header.js:
It holds the controller for header part. It will render using **global-header** directive. If we want to add any social login we need to configure in app.js and point to authenticate function in the header with the provider name(currently it is facebook, google). We are using satellizer vendor component for centralization social login.
#####login.js:
We are not using this currently.
#####main.js:
It is a controller for launching page. We hard coded default categories filter options in this page(selfie lovers, business travellers etc..)
#####product.js:
It holds the controller for product details view. It contains two controllers for product details page, it only renders the outline of product details. For product body controller, it controls sentiment scores, price graph, technical specifications, smaart pulse, video review and similar phones. This will also controls product overlay content.
#####register.js:
We are not using this currently.
#####SmaartView.js:
This will control the smaart view. It has page size option currently pointing to 30 items. When ever the user clicks on smaart compare in compare results view we will open the smaart view with compared items only.
#####wishlist.js:
This will control the wishlist view.From the wishlisted items we will get the individual products.
####directives
This holds all the directives in individual files.
#####angular-slider.js:
This is custom slider component we used to render and control the sliders in filters.
#####angular-treemap.js:
Its out-dated and need to be removed.
#####feedBack.js:
It provides a directive **feed-back** and renders the feedback overlay. The controller for this template is at controller/Feedback.js
#####globalFooter.js:
It provides a directive **global-footer** and renders the footer part.
#####globalHeader.js:
It provides a directive **global-header** and renders the header part. The controller for this template is at controller/header.js
#####globalSteps.js:
It provides a directive **global-steps** and renders the steps part.
#####hideuponOnechild.js:
This directive will hide the HTML element when it contains only child.
#####linegraph.js:
It is used to render the price graph in the product details page.
#####marimekkochart.js:
This is used to render the smaart view in product details page.
#####mobileOptions.js:
It provides a directive **mobile-ooptions** and renders, controlls the mobile options.
#####navBar.js:
It provides a directive **nav-bar** and renders, controllers the navigation bar.
#####NLPfilters.js:
It provides a directive **nlp-filters** and renders, controlls the NLP filters part. We are using in launching page and modify search.
#####numberOnly.js:
This directive will restrict input field for number.
#####poopoverPosition.js:
It will align the popover to the respective div. It make sure that it will not overflow from the screen.
#####pricePopup.js:
It provides a directive **price-popup** and renders the price popup overlay.
#####productBody.js:
It provides a directive **product-body** and renders the product details body part/ Product oveerlay body part. The controller for this template is at controller/product.js
#####readMore.js:
It provides a directive **read-more** link for the HTML element which handles its control when line exceeds 4.
#####roundProgress.js:
It provides a directive **round-progress** and renders the donut model progress bar.
#####searchResults.js:
It provides a directive **search-results** and renders the search results popover used in launching page and search in header.
#####stckCompare.js:
It provides a directive **stick-compare** and renders the selected compare items in the div.
####fliters
#####currencyFormat.js:
It provide filters
       - **currecnyFormat**: It will formats and displays the price information.
       - **numberFormat**: It formats the number into Indian currency values.
       - **validateNgsrc**: It validates ng-src string has valid image URL or not
#####isolderDate.js:
It provides a filter **isolderDate** and returns whether the date is older than current date or not.
####services
#####api.js:
It provides api service that will communicate with the backend and returns the response to the respective component.
#####enums.js:
Removed ~~It is not using anywhere we can remove it after validating.~~
#####metainformation.js:
We are not using anywhere.
#####mockdataservice.js:
Removed ~~It is used to mock data. But currently we are not using it.~~
#####priceretailercolors.js:
It provide the service which returns color map of the retailers for the price graph.
#####timerangepicker.js:
It returns time ranges and its respective keys for price graph.
###styles
####main.scss:
It contains two sets of break points one is $mq-breakpoints used in static pages, and second set
- bs-Mb320768(): mobile view from 320 to 767px
- bs-Mb7681179(): tablet view from 768 to 1179px
        and the other greater than 1180px is considered as desktop view.
        we used these breakpoints in launching page, discovery dashboard, smart view, compare pages, wishlist, header, footer.

Icons used in buysmaart font icons is included here. All the fonts used in the application are included(roboto). All the remaining sass files are included. all the sass files are classified according to the page and parts in their corresponding folders.
###views
It contains HTML templates.

##To enable tablets.
In the globalheader.html Category section in displayed none. This should be enabled. (Clicks in categorys is not implementd).
In discovery dashboard change the listmain class as listmain_vertical. the tiles will be rendered for tablets.
