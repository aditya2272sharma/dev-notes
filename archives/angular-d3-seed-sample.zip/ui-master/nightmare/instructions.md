# Automation Testing using NightmareJS

* Nightmare is a simple automation testing tool that uses `Electron` which performs better than `PhantomJS`.
* The API is the simplest observed so far & is based around the trusted selenium web driver
* GIT repo: https://github.com/segmentio/nightmare
* URL: http://www.nightmarejs.org/

*Note*
* Nondeterministic erros in automation tests is common & is expected.
  * If any test fails, quarantine it & move ahead.
  * Plan to fix the failures in next sprint/release
* Limit tests to key work flows only
* *Do not* test complex business logics in automation
* If you spot gaps/errors/typo in this document, it becomes your responsibility to fix it & raise a PR for it.



## Run your first test
Go to the `nightmare` directory and perform the following
```js
# install the required packages first
$ npm install

# to run the tests
$ node index.js

# to log all messages while running the tests
$ DEBUG=nightmare*  & node index.js

```
### Debug Flags
* All nightmare messages: `DEBUG=nightmare*` (currently suggested in the instructions)
* Only actions: `DEBUG=nightmare:actions*`
* Only logs: `DEBUG=nightmare:log*`
