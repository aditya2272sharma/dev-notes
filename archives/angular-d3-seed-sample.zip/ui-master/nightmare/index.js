var Nightmare = require('nightmare');
var expect = require('chai').expect; // jshint ignore:line
var vo = require('vo');
var config = require('./config');
var cheerio = require('cheerio');

var website = config.website['prod']; // or choose config['local'] to test production website


vo(function* () {

  var nightmare = Nightmare({
    show: true,
    waitTimeout: 1000 // in ms
  });


  var link = yield nightmare
    .goto( website ) //go to the website
    .wait('div.header-section') // wait until the element 'div.header-section' appears on the page
    .wait('input.headerSearchField') // wait until the element 'input.headerSearchField' appears on the page
    .type('input.headerSearchField', 'iPhone 6s \r') // type into the selected element 'input.headerSearchField'
    .wait('ul.search-result-items') // wait until the results show up in the list
    .wait('li.single-item')
    .click('li.single-item a.single-container-item') //click on the link inside the list-item
    .wait(".TileHolder") // wait until the title in the description page appears
    .evaluate(function () {
      return document.location.href; // return the url of the page
    });
  yield nightmare.end();

  return link;

})(function (err, link) { // callback that executes after the yield is finished
  if (err) return console.log(err);
  expect(link).to.contain('iPhone');
});

