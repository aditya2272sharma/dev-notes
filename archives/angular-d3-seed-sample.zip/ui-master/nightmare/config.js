module.exports = {
  website: {
    "local": "http://localhost:7272",
    "prod": "http://buysmaart.com"
  }
}