/**
 * Generated script for New Relic Synthetics
 * Generated using se-builder with New Relic Synthetics Formatter
 *
 * Welcome to the Synthetics JavaScript IDE - Browser Edition
 * You can think of it like node.js lite. Everything you'd expect to find in a
 * node.js environment is also available here, with a few notable exceptions:
 *
 * - 'require' is limited to a useful subset of modules, get the full list from
 *   https://docs.newrelic.com/docs/synthetics/new-relic-synthetics/scripting-monitors/writing-scripted-browsers
 *
 * - We've added a few top-level vars to the scope, all starting with '$':
 *
 *     $browser - Synthetics-flavored WebDriver session for browser automation
 *     $driver - Main WebDriver public API module
 *     $http - 'request' node.js module (for making HTTP requests)
 *     $util - Common tools to aid with grunt work
 *
 * Feel free to explore, or check out the full documentation for details:
 * https://docs.newrelic.com/docs/synthetics/new-relic-synthetics/scripting-monitors/writing-scripted-browsers
 *
 * Find examples(more useful than documentation):
 * https://discuss.newrelic.com/c/synthetics/synthetics-scripts
 *
 */

/**
 *  declare all utilities, HELPER FUNCTIONS and global requisites
 */

var assert = require('assert');

var _ = require('lodash'); //lodash is a very useful utility library ref: http://devdocs.io/lodash
var UserAgent = "default"; // Change to any User Agent you want to use. Leave as "default" or empty to use the Synthetics default.
var By = $driver.By;

function log ( msg ) {
  var elapsedSecs = (new Date() - startTime) / 1000.0;
  console.log('Step ' + thisStep + ': ' + elapsedSecs.toFixed(1) + 's: ' + msg);
  thisStep++;
}
function isElementSelected ( el ) {
  return $browser.findElement(el).isSelected();
}
function isTextPresent ( text ) {
  return $browser.findElement(By.tagName('html')).getText()
  .then(function (wholetext) {
    return wholetext.indexOf(text) != -1;
  });
}


/** CONFIGURATIONS **/

var DefaultTimeout = 10000; // Script-wide timeout for wait and waitAndFind functions (in ms)
var startTime = new Date();
var thisStep = 0;

// keep all element-ids, constants, cached-elements and other variables in this single Javascript object. creating multiple elements can pollute the global namespace
var VARS = {
  "home_page": {
    "title": "Mobile phone recommendations using Artificial Intelligence",
    "url": "http://buysmaart.com",
    "discover_button": {
      "cached": null,
      "id": "showPhones",
      "text": "SHOW ME THE SMARTPHONES"
    }
  },
  "discoveryDashboard": {
    "title": "Find the best mobile phones for your needs",
    "url": "http://buysmaart.com/DiscoveryDashboard"
  }
};



/**** THE ACTOION BEGINS HERE ****/
log('init');

// Setting User Agent is not then-able, so we do this first (if defined and not default)
if ((typeof UserAgent !== 'undefined') && (UserAgent != 'default')) {
  $browser.addHeader('User-Agent', UserAgent);
  log('Setting User-Agent to ' + UserAgent);
}

// Get browser capabilities and do nothing with it, so that we start with a then-able command
$browser.getCapabilities().then(function () {
})


.then(function(){
  log('get home: ' + VARS.home_page.url );
  return $browser.get(VARS.home_page.url);
})


.then(function () {
  log('Title VARS.title');
  return $browser.getTitle();
})
.then(function (title) {
  VARS.title = VARS.home_page.url + ': ' + title;
  log('Title assetion:');
  log('expected:' + VARS.home_page.title);
  log('received:' + title);
  log('pass:' + assert( VARS.home_page.title, title ));
})


.then(function(){
  log('findElement By.id:' + VARS.home_page.discover_button.id);
  $browser.sleep(100);
  VARS.home_page.discover_button.cached = By.id( VARS.home_page.discover_button.id );
  return $browser.findElement( VARS.home_page.discover_button.cached );
})


.then(function( element ){
  log('click element:' + element);
  $browser.executeScript("arguments[0].click();", element);

  //by this time, angular $digest has already destroyed the cached element
  //therefore, we've to query that again & return it to next chained callback
  VARS.home_page.discover_button.cached = $driver.By.id( VARS.home_page.discover_button.id );
  return $browser.findElement( VARS.home_page.discover_button.cached );
})


.then(function( element ){
  log('sleep 500ms+200ms for animation & re-rendering');
  $browser.sleep(500); //to account for the jquery animation timeout of 500ms
  $browser.sleep(700); //additional sleep to allow rendering
  
  $browser.findElement( By.id( VARS.home_page.discover_button.id ) )
  .then( function (element) {
    log('scroll into view');
    $browser.executeScript("arguments[0].scrollIntoView(true);", element);
    element.getText()
    .then(function ( text ) {
      if( text == VARS.home_page.discover_button.text ){
        log('VARS.home_page.discover_button.text success');
      } else {
        log('VARS.home_page.discover_button.text failure');
        $browser.takeScreenshot();
      }
    }, DefaultTimeout);

    return element;
  })
  .then( function( element){
    log('second button click');
    $browser.executeScript("arguments[0].click();", element);
  })
  .then(function ( ) {
    return $browser.wait(function() { 
      log('waiting for redirection');
      return $browser.getCurrentUrl();
    })
    .then(function (url) {
      log('expected url:' + VARS.discoveryDashboard.url);
      log('obtained url:' + url);
      return url == VARS.discoveryDashboard.url;
    }, DefaultTimeout);
  });
})


.then(function(){
  //Find a link whose display text is `DISCOVER SMARTPHONES` and click that link.
  //$browser.findElement($driver.By.linkText("DISCOVER SMARTPHONES")).click();
  return true;
});


