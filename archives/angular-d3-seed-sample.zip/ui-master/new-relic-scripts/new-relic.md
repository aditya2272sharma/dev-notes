#Introduction

## Reference Material
* [New Relic Synthetics Product Tour](https://www.youtube.com/watch?v=Pt9liDR3zWo)
* [Introduction to New Relic Synthetics](http://code.tutsplus.com/tutorials/introduction-to-new-relic-synthetics--cms-22899)
* [Crash Course in APM: Monitor Performance, Troubleshoot, & Optimize Apps: William Li @nginxconf 2014](https://www.youtube.com/watch?v=DTlHy-yZUYA)
* [Scripted Browser API reference](https://docs.newrelic.com/docs/synthetics/new-relic-synthetics/scripting-monitors/writing-scripted-browsers)
  * [Examples](https://discuss.newrelic.com/c/synthetics/synthetics-scripts)
  * [The Big Example](https://discuss.newrelic.com/t/big-example-created-using-se-builder-and-nr-synthetics-formatter/12823)
  * [New Relic Synthetics formatter for Selenium-builder](https://github.com/sschwartzman/newrelic-synthetics-sebuilder)
* []()


## Setting up Monitors
### Ping
> Caution:
> Make sure to ignore visits (in Analytics data) from the following locations. We've not yet figured out ways to prevent counting New Relic hits.

* Dublin, Ireland
* Singapore
* Frankfurt, Germany
* Portland, OR
* Tokyo, Japan
* Sydney, Australia
* São Paulo, Brazil
* San Francisco, CA
* Washington, DC
