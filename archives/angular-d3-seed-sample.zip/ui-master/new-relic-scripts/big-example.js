
/**
 * Generated script for New Relic Synthetics
 * Generated using se-builder with New Relic Synthetics Formatter
 *
 * Welcome to the Synthetics JavaScript IDE - Browser Edition
 * You can think of it like node.js lite. Everything you'd expect to find in a
 * node.js environment is also available here, with a few notable exceptions:
 *
 * - 'require' is limited to a useful subset of modules, get the full list from
 *   https://docs.newrelic.com/docs/synthetics/new-relic-synthetics/scripting-monitors/writing-scripted-browsers
 *
 * - We've added a few top-level vars to the scope, all starting with '$':
 *
 *     $browser - Synthetics-flavored WebDriver session for browser automation
 *     $driver - Main WebDriver public API module
 *     $http - 'request' node.js module (for making HTTP requests)
 *     $util - Common tools to aid with grunt work
 *
 * Feel free to explore, or check out the full documentation for details:
 * https://docs.newrelic.com/docs/synthetics/new-relic-synthetics/scripting-monitors/writing-scripted-browsers
 */

/** CONFIGURATIONS **/

// Script-wide timeout for wait and waitAndFind functions (in ms)
var DefaultTimeout = 10000;
// Change to any User Agent you want to use.
// Leave as "default" or empty to use the Synthetics default.
var UserAgent = "default";

/** HELPER FUNCTIONS **/

var assert = require('assert'),
  By = $driver.By,
  startTime = new Date(),
  thisStep = 0,
  VARS = {};
var log = function(msg) {
    var elapsedSecs = (new Date() - startTime) / 1000.0;
    console.log('Step ' + thisStep + ': ' + elapsedSecs.toFixed(1) + 's: ' + msg);
    thisStep++;
};
// 1st log is sometimes ignored for some reason, so this is a dummy
log('init');
function isAlertPresent() {
  try {
    var thisAlert = $browser.switchTo().alert();
    return true;
  } catch (err) { return false; }
}
function isElementSelected(el) { return $browser.findElement(el).isSelected(); }
function isTextPresent(text) {
  return $browser.findElement(By.tagName('html')).getText()
  .then(function (wholetext) {
    return wholetext.indexOf(text) != -1;
  });
}

/** BEGINNING OF SCRIPT **/

// Setting User Agent is not then-able, so we do this first (if defined and not default)
if ((typeof UserAgent !== 'undefined') && (UserAgent != 'default')) {
  $browser.addHeader('User-Agent', UserAgent);
  log('Setting User-Agent to ' + UserAgent);
}

// Get browser capabilities and do nothing with it, so that we start with a then-able command
$browser.getCapabilities().then(function () { })

.then(function () {
  log('get "http://www.google.com"');
  return $browser.get("http://www.google.com");
})

.then(function () {
  log('get "http://saucelabs.com/test/guinea-pig/"');
  return $browser.get("http://saucelabs.com/test/guinea-pig/");
})

.then(function () {
  log('clickElement "i am a link"');
  return $browser.waitForAndFindElement(By.linkText("i am a link"), DefaultTimeout); })
.then(function (el) { $browser.actions().click(el).perform(); })

.then(function () {
  log('storeTitle VARS.title');
  return $browser.getTitle(); })
  .then(function (title) {
  VARS.title = '' + title;
})

.then(function () {
  log('waitForTitle VARS.title');
  return $browser.wait(function() {
    return $browser.getTitle(); })
  .then(function (title) {
    return title == VARS.title;
  }, DefaultTimeout);
})

.then(function () {
  log('verifyTitle VARS.title');
  return $browser.getTitle(); })
  .then(function (title) {
  if (title != VARS.title) {
    console.log('verifyTitle failed');
    $browser.takeScreenshot();
  }
})

.then(function () {
  log('verifyTitle !"asdf"');
  return $browser.getTitle(); })
  .then(function (title) {
  if (title == "asdf") {
    console.log('!verifyTitle failed');
    $browser.takeScreenshot();
  }
})

.then(function () {
  log('assertTitle VARS.title');
  return $browser.getTitle(); })
  .then(function (title) {
    assert.equal(title, VARS.title, 'assertTitle failed');
})

.then(function () {
  log('assertTitle !"asdf"');
  return $browser.getTitle(); })
  .then(function (title) {
    assert.notEqual(title, "asdf", '!assertTitle failed');
})

.then(function () {
  log('storeCurrentUrl VARS.url');
  return $browser.getCurrentUrl(); })
  .then(function (url) {
  VARS.url = '' + url;
})

.then(function () {
  log('waitForCurrentUrl VARS.url');
  return $browser.wait(function() {
    return $browser.getCurrentUrl(); })
  .then(function (url) {
    return url == VARS.url;
  }, DefaultTimeout);
})

.then(function () {
  log('verifyCurrentUrl VARS.url');
  return $browser.getCurrentUrl(); })
  .then(function (url) {
  if (url != VARS.url) {
    console.log('verifyCurrentUrl failed');
    $browser.takeScreenshot();
  }
})

.then(function () {
  log('verifyCurrentUrl !"http://google.com"');
  return $browser.getCurrentUrl(); })
  .then(function (url) {
  if (url == "http://google.com") {
    console.log('!verifyCurrentUrl failed');
    $browser.takeScreenshot();
  }
})

.then(function () {
  log('waitForCurrentUrl !"http://google.com"');
  return $browser.wait(function() {
    return $browser.getCurrentUrl(); })
  .then(function (url) {
    return url != "http://google.com";
  }, DefaultTimeout);
})

.then(function () {
  log('assertCurrentUrl VARS.url');
  return $browser.getCurrentUrl(); })
  .then(function (url) {
    assert.equal(url, VARS.url, 'assertCurrentUrl failed');
})

.then(function () {
  log('assertCurrentUrl !"http://google.com"');
  return $browser.getCurrentUrl(); })
  .then(function (url) {
    assert.notEqual(url, "http://google.com", '!assertCurrentUrl failed');
})

.then(function () {
  log('storeText VARS.text');
  return $browser.findElement(By.id("i_am_an_id")); })
  .then(function (el) { return el.getText(); })
  .then(function (text) {
  VARS.text = '' + text;
})

.then(function () {
  log('waitForText VARS.text');
  return $browser.wait(function() {
    return $browser.findElement(By.id("i_am_an_id")); })
  .then(function (el) { return el.getText(); })
  .then(function (text) {
    return text == VARS.text;
  }, DefaultTimeout);
})

.then(function () {
  log('verifyText VARS.text');
  return $browser.findElement(By.id("i_am_an_id")); })
  .then(function (el) { return el.getText(); })
  .then(function (text) {
  if (text != VARS.text) {
    console.log('verifyText failed');
    $browser.takeScreenshot();
  }
})

.then(function () {
  log('waitForText !"not " + VARS.text');
  return $browser.wait(function() {
    return $browser.findElement(By.id("i_am_an_id")); })
  .then(function (el) { return el.getText(); })
  .then(function (text) {
    return text != "not " + VARS.text;
  }, DefaultTimeout);
})

.then(function () {
  log('verifyText !"not " + VARS.text');
  return $browser.findElement(By.id("i_am_an_id")); })
  .then(function (el) { return el.getText(); })
  .then(function (text) {
  if (text == "not " + VARS.text) {
    console.log('!verifyText failed');
    $browser.takeScreenshot();
  }
})

.then(function () {
  log('assertText VARS.text');
  return $browser.findElement(By.id("i_am_an_id")); })
  .then(function (el) { return el.getText(); })
  .then(function (text) {
    assert.equal(text, VARS.text, 'assertText failed');
})

.then(function () {
  log('assertText !"not " + VARS.text');
  return $browser.findElement(By.id("i_am_an_id")); })
  .then(function (el) { return el.getText(); })
  .then(function (text) {
    assert.notEqual(text, "not " + VARS.text, '!assertText failed');
})

.then(function () {
  log('storeTextPresent VARS.text_is_present');
  isTextPresent("I am another div").then(function (bool) { VARS.text_is_present = bool; });
})

.then(function () {  VARS.text_present = '' + "I am another div"; })

.then(function () {
  log('waitForTextPresent VARS.text_present');
  $browser.wait(function () {
     return isTextPresent(VARS.text_present).then(function (bool) { return bool; });
  }, DefaultTimeout);
})

.then(function () {
  log('verifyTextPresent VARS.text_present');
  isTextPresent(VARS.text_present).then(function (bool) {
    if (!bool) {
      log('verifyTextPresent failed');
      $browser.takeScreenshot();
    }
  });
})

.then(function () {
  log('waitForTextPresent !"not " + VARS.text_present');
  $browser.wait(function () {
     return isTextPresent("not " + VARS.text_present).then(function (bool) { return !bool; });
  }, DefaultTimeout);
})

.then(function () {
  log('verifyTextPresent !"not " + VARS.text_present');
  isTextPresent("not " + VARS.text_present).then(function (bool) {
    if (bool) {
      log('!verifyTextPresent failed');
      $browser.takeScreenshot();
    }
  });
})

.then(function () {
  log('assertTextPresent VARS.text_present');
  isTextPresent(VARS.text_present).then(function (bool) {
    assert.ok((bool), 'assertTextPresent failed');
  });
})

.then(function () {
  log('assertTextPresent !"not " + VARS.text_present');
  isTextPresent("not " + VARS.text_present).then(function (bool) {
    assert.ok((!bool), 'assertTextPresent failed');
  });
})

.then(function () {
  log('storeBodyText VARS.body_text');
  return $browser.findElement($driver.By.tagName('body')); })
  .then(function (el) { return el.getText(); })
  .then(function (text) {
  VARS.body_text = '' + text;
})

.then(function () {
  log('waitForBodyText VARS.body_text');
  return $browser.wait(function() {
    return $browser.findElement($driver.By.tagName('body')); })
  .then(function (el) { return el.getText(); })
  .then(function (text) {
    return text == VARS.body_text;
  }, DefaultTimeout);
})

.then(function () {
  log('verifyBodyText VARS.body_text');
  return $browser.findElement($driver.By.tagName('body')); })
  .then(function (el) { return el.getText(); })
  .then(function (text) {
  if (text != VARS.body_text) {
    console.log('verifyBodyText failed');
    $browser.takeScreenshot();
  }
})

.then(function () {
  log('waitForBodyText !"not " + VARS.body_text');
  return $browser.wait(function() {
    return $browser.findElement($driver.By.tagName('body')); })
  .then(function (el) { return el.getText(); })
  .then(function (text) {
    return text != "not " + VARS.body_text;
  }, DefaultTimeout);
})

.then(function () {
  log('verifyBodyText !"not " + VARS.body_text');
  return $browser.findElement($driver.By.tagName('body')); })
  .then(function (el) { return el.getText(); })
  .then(function (text) {
  if (text == "not " + VARS.body_text) {
    console.log('!verifyBodyText failed');
    $browser.takeScreenshot();
  }
})

.then(function () {
  log('assertBodyText VARS.body_text');
  return $browser.findElement($driver.By.tagName('body')); })
  .then(function (el) { return el.getText(); })
  .then(function (text) {
    assert.equal(text, VARS.body_text, 'assertBodyText failed');
})

.then(function () {
  log('assertBodyText !"not " + VARS.body_text');
  return $browser.findElement($driver.By.tagName('body')); })
  .then(function (el) { return el.getText(); })
  .then(function (text) {
    assert.notEqual(text, "not " + VARS.body_text, '!assertBodyText failed');
})

.then(function () {
  log('storePageSource VARS.page_source');
  return $browser.getPageSource(); })
  .then(function (source) {
  VARS.page_source = '' + source;
})

.then(function () {
  log('waitForPageSource VARS.page_source');
  return $browser.wait(function() {
    return $browser.getPageSource(); })
  .then(function (source) {
    return source == VARS.page_source;
  }, DefaultTimeout);
})

.then(function () {
  log('verifyPageSource VARS.page_source');
  return $browser.getPageSource(); })
  .then(function (source) {
  if (source != VARS.page_source) {
    console.log('verifyPageSource failed');
    $browser.takeScreenshot();
  }
})

.then(function () {
  log('waitForPageSource !"<!-- --> " + VARS.page_source');
  return $browser.wait(function() {
    return $browser.getPageSource(); })
  .then(function (source) {
    return source != "<!-- --> " + VARS.page_source;
  }, DefaultTimeout);
})

.then(function () {
  log('verifyPageSource !"<!-- --> " + VARS.page_source');
  return $browser.getPageSource(); })
  .then(function (source) {
  if (source == "<!-- --> " + VARS.page_source) {
    console.log('!verifyPageSource failed');
    $browser.takeScreenshot();
  }
})

.then(function () {
  log('assertPageSource VARS.page_source');
  return $browser.getPageSource(); })
  .then(function (source) {
    assert.equal(source, VARS.page_source, 'assertPageSource failed');
})

.then(function () {
  log('assertPageSource !"<!-- --> " + VARS.page_source');
  return $browser.getPageSource(); })
  .then(function (source) {
    assert.notEqual(source, "<!-- --> " + VARS.page_source, '!assertPageSource failed');
})

.then(function () {
  log('addCookie test_cookie, this-is-a-cookie');
  $browser.manage().addCookie('test_cookie', 'this-is-a-cookie');
})

.then(function () {
  log('storeCookiePresent VARS.cookie_is_present');
  $browser.manage().getCookie("test_cookie").then(function (bool) { VARS.cookie_is_present = bool; });
})

.then(function () {
  log('storeCookieByName VARS.cookie');
  return $browser.manage().getCookie("test_cookie"); })
  .then(function (cookie) {
  VARS.cookie = '' + cookie;
})

.then(function () { log('VARS.cookie + ";"'); })

.then(function () {
  log('waitForCookiePresent "test_cookie"');
  $browser.wait(function () {
     return $browser.manage().getCookie("test_cookie").then(function (bool) { return bool; });
  }, DefaultTimeout);
})

.then(function () {
  log('verifyCookiePresent "test_cookie"');
  $browser.manage().getCookie("test_cookie").then(function (bool) {
    if (!bool) {
      log('verifyCookiePresent failed');
      $browser.takeScreenshot();
    }
  });
})

.then(function () {
  log('assertCookiePresent "test_cookie"');
  $browser.manage().getCookie("test_cookie").then(function (bool) {
    assert.ok((bool), 'assertCookiePresent failed');
  });
})

.then(function () {
  log('waitForCookieByName VARS.cookie');
  return $browser.wait(function() {
    return $browser.manage().getCookie("test_cookie"); })
  .then(function (cookie) {
    return cookie == VARS.cookie;
  }, DefaultTimeout);
})

.then(function () {
  log('verifyCookieByName VARS.cookie');
  return $browser.manage().getCookie("test_cookie"); })
  .then(function (cookie) {
  if (cookie != VARS.cookie) {
    console.log('verifyCookieByName failed');
    $browser.takeScreenshot();
  }
})

.then(function () {
  log('waitForCookieByName !"not " + VARS.cookie');
  return $browser.wait(function() {
    return $browser.manage().getCookie("test_cookie"); })
  .then(function (cookie) {
    return cookie != "not " + VARS.cookie;
  }, DefaultTimeout);
})

.then(function () {
  log('verifyCookieByName !"not " + VARS.cookie');
  return $browser.manage().getCookie("test_cookie"); })
  .then(function (cookie) {
  if (cookie == "not " + VARS.cookie) {
    console.log('!verifyCookieByName failed');
    $browser.takeScreenshot();
  }
})

.then(function () {
  log('assertCookieByName VARS.cookie');
  return $browser.manage().getCookie("test_cookie"); })
  .then(function (cookie) {
    assert.equal(cookie, VARS.cookie, 'assertCookieByName failed');
})

.then(function () {
  log('assertCookieByName !"not " + VARS.cookie');
  return $browser.manage().getCookie("test_cookie"); })
  .then(function (cookie) {
    assert.notEqual(cookie, "not " + VARS.cookie, '!assertCookieByName failed');
})

.then(function() {
  log('$browser.manage().deleteCookie("test_cookie")');
  return $browser.manage().deleteCookie("test_cookie");
})

.then(function () {
  log('waitForCookiePresent !"test_cookie"');
  $browser.wait(function () {
     return $browser.manage().getCookie("test_cookie").then(function (bool) { return !bool; });
  }, DefaultTimeout);
})

.then(function () {
  log('verifyCookiePresent !"test_cookie"');
  $browser.manage().getCookie("test_cookie").then(function (bool) {
    if (bool) {
      log('!verifyCookiePresent failed');
      $browser.takeScreenshot();
    }
  });
})

.then(function () {
  log('assertCookiePresent !"test_cookie"');
  $browser.manage().getCookie("test_cookie").then(function (bool) {
    assert.ok((!bool), 'assertCookiePresent failed');
  });
})

.then(function() {
  log('$browser.navigate().refresh()');
  return $browser.navigate().refresh();
})

.then(function() {
  log('$browser.navigate().back()');
  return $browser.navigate().back();
})

.then(function() {
  log('$browser.navigate().forward()');
  return $browser.navigate().forward();
})

.then(function() {
  log('$browser.navigate().back()');
  return $browser.navigate().back();
})

.then(function () {
  log('waitForTextPresent "comments"');
  $browser.wait(function () {
     return isTextPresent("comments").then(function (bool) { return bool; });
  }, DefaultTimeout);
})

.then(function() {
  log('$browser.takeScreenshot()');
  return $browser.takeScreenshot();
})

.then(function () { log('"this is some debug text"'); })

.then(function () {
  log('storeElementSelected VARS.element_is_selected');
  isElementSelected(By.id("unchecked_checkbox")).then(function (bool) { VARS.element_is_selected = bool; });
})

.then(function () {
  log('setElementSelected "unchecked_checkbox"');
  return $browser.waitForAndFindElement(By.id("unchecked_checkbox"), DefaultTimeout); })
.then(function(el) { return el.isSelected(); })
.then(function(bool) { if (!bool) { $browser.actions().click($browser.findElement(By.id("unchecked_checkbox"))).perform(); } })

.then(function () {
  log('waitForElementSelected "unchecked_checkbox"');
  $browser.wait(function () {
     return isElementSelected(By.id("unchecked_checkbox")).then(function (bool) { return bool; });
  }, DefaultTimeout);
})

.then(function () {
  log('verifyElementSelected "unchecked_checkbox"');
  isElementSelected(By.id("unchecked_checkbox")).then(function (bool) {
    if (!bool) {
      log('verifyElementSelected failed');
      $browser.takeScreenshot();
    }
  });
})

.then(function () {
  log('assertElementSelected "unchecked_checkbox"');
  isElementSelected(By.id("unchecked_checkbox")).then(function (bool) {
    assert.ok((bool), 'assertElementSelected failed');
  });
})

.then(function () {
  log('setElementNotSelected "unchecked_checkbox"');
  return $browser.waitForAndFindElement(By.id("unchecked_checkbox"), DefaultTimeout); })
.then(function(el) { return el.isSelected(); })
.then(function(bool) { if (bool) { $browser.actions().click($browser.findElement(By.id("unchecked_checkbox"))).perform(); } })

.then(function () {
  log('verifyElementSelected !"unchecked_checkbox"');
  isElementSelected(By.id("unchecked_checkbox")).then(function (bool) {
    if (bool) {
      log('!verifyElementSelected failed');
      $browser.takeScreenshot();
    }
  });
})

.then(function () {
  log('assertElementSelected !"unchecked_checkbox"');
  isElementSelected(By.id("unchecked_checkbox")).then(function (bool) {
    assert.ok((!bool), 'assertElementSelected failed');
  });
})

.then(function () {
  log('storeElementAttribute VARS.link_href');
  return $browser.findElement($driver.By.linkText("i am a link")); })
  .then(function (el) { return el.getAttribute("href"); })
  .then(function (value) {
  VARS.link_href = '' + value;
})

.then(function () {
  log('waitForElementAttribute VARS.link_href');
  return $browser.wait(function() {
    return $browser.findElement($driver.By.linkText("i am a link")); })
  .then(function (el) { return el.getAttribute("href"); })
  .then(function (value) {
    return value == VARS.link_href;
  }, DefaultTimeout);
})

.then(function () {
  log('verifyElementAttribute VARS.link_href');
  return $browser.findElement($driver.By.linkText("i am a link")); })
  .then(function (el) { return el.getAttribute("href"); })
  .then(function (value) {
  if (value != VARS.link_href) {
    console.log('verifyElementAttribute failed');
    $browser.takeScreenshot();
  }
})

.then(function () {
  log('assertElementAttribute VARS.link_href');
  return $browser.findElement($driver.By.linkText("i am a link")); })
  .then(function (el) { return el.getAttribute("href"); })
  .then(function (value) {
    assert.equal(value, VARS.link_href, 'assertElementAttribute failed');
})

.then(function () {
  log('sendKeysToElement "comments"');
  return $browser.waitForAndFindElement(By.id("comments"), DefaultTimeout); })
.then(function (el) { el.sendKeys("w00t"); })

.then(function () {
  log('waitForElementAttribute !"not " + VARS.link_href');
  return $browser.wait(function() {
    return $browser.findElement($driver.By.linkText("i am a link")); })
  .then(function (el) { return el.getAttribute("href"); })
  .then(function (value) {
    return value != "not " + VARS.link_href;
  }, DefaultTimeout);
})

.then(function () {
  log('verifyElementAttribute !"not " + VARS.link_href');
  return $browser.findElement($driver.By.linkText("i am a link")); })
  .then(function (el) { return el.getAttribute("href"); })
  .then(function (value) {
  if (value == "not " + VARS.link_href) {
    console.log('!verifyElementAttribute failed');
    $browser.takeScreenshot();
  }
})

.then(function () {
  log('assertElementAttribute !"not " + VARS.link_href');
  return $browser.findElement($driver.By.linkText("i am a link")); })
  .then(function (el) { return el.getAttribute("href"); })
  .then(function (value) {
    assert.notEqual(value, "not " + VARS.link_href, '!assertElementAttribute failed');
})

.then(function () {
  log('storeElementValue VARS.comments');
  return $browser.findElement($driver.By.id("comments")); })
  .then(function (el) { return el.getAttribute('value'); })
  .then(function (value) {
  VARS.comments = '' + value;
})

.then(function () {
  log('waitForElementValue "w00t"');
  return $browser.wait(function() {
    return $browser.findElement($driver.By.id("comments")); })
  .then(function (el) { return el.getAttribute('value'); })
  .then(function (value) {
    return value == "w00t";
  }, DefaultTimeout);
})

.then(function () {
  log('verifyElementValue "w00t"');
  return $browser.findElement($driver.By.id("comments")); })
  .then(function (el) { return el.getAttribute('value'); })
  .then(function (value) {
  if (value != "w00t") {
    console.log('verifyElementValue failed');
    $browser.takeScreenshot();
  }
})

.then(function () {
  log('assertElementValue "w00t"');
  return $browser.findElement($driver.By.id("comments")); })
  .then(function (el) { return el.getAttribute('value'); })
  .then(function (value) {
    assert.equal(value, "w00t", 'assertElementValue failed');
})

.then(function () {
  log('waitForElementValue !"not w00t"');
  return $browser.wait(function() {
    return $browser.findElement($driver.By.id("comments")); })
  .then(function (el) { return el.getAttribute('value'); })
  .then(function (value) {
    return value != "not w00t";
  }, DefaultTimeout);
})

.then(function () {
  log('verifyElementValue !"not w00t"');
  return $browser.findElement($driver.By.id("comments")); })
  .then(function (el) { return el.getAttribute('value'); })
  .then(function (value) {
  if (value == "not w00t") {
    console.log('!verifyElementValue failed');
    $browser.takeScreenshot();
  }
})

.then(function () {
  log('assertElementValue !"not w00t"');
  return $browser.findElement($driver.By.id("comments")); })
  .then(function (el) { return el.getAttribute('value'); })
  .then(function (value) {
    assert.notEqual(value, "not w00t", '!assertElementValue failed');
})

.then(function () {
  log('submitElement "comments"');
  return $browser.waitForAndFindElement(By.id("comments"), DefaultTimeout); })
.then(function (el) { el.submit(); })

.then(function () {
  log('verifyTextPresent "w00t"');
  isTextPresent("w00t").then(function (bool) {
    if (!bool) {
      log('verifyTextPresent failed');
      $browser.takeScreenshot();
    }
  });
})

.then(function() {
  log('Browser script execution SUCCEEDED.');
}, function(err) {
  log ('Browser script execution FAILED.');
  throw(err);
});

/** END OF SCRIPT **/