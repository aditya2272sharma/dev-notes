'use strict';

angular.module('buySmaartApp')
  .service('Metainformation', function Metainformation() {
    // AngularJS will instantiate a singleton by calling "new" on this function
  });
