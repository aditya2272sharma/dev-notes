'use strict';

angular.module('buySmaartApp')
  .service('Timerangepicker', ["$cookieStore",function Timerangepicker(cookieStore) {
      var selectedtimerange;
      selectedtimerange = cookieStore.get('selectedtimerange') ? cookieStore.get('selectedtimerange') : {
              duration: moment.duration(1, 'week'),
              id: 1,
              interval: 'day',
              format: '%e',
              time: '1w'
      }
      return {
        fetchtimeRanges: function () {
          var timeranges;
          return timeranges = [
            {
              duration: moment.duration(1, 'week'),
              id: 1,
              interval: 'day',
              format: '%e',
              time: '1w'
            },
            {
              duration: moment.duration(1, 'month'),
              id: 2,
              interval: 'day',
              format: '%e',
              time: '1m'
            },
            {
              duration: moment.duration(3, 'month'),
              id: 3,
              interval: 'week',
              format: '%b',
              time: '3m'
            },
            {
              duration: moment.duration(6, 'month'),
              id: 4,
              interval: 'week',
              format: '%b',
              time: '6m'
            },
            {
              duration: moment.duration(1, 'year'),
              id: 5,
              interval: 'month',
              format: '%b',
              time: '1y'
            },
            {
              duration: moment.duration(2, 'year'),
              id: 6,
              interval: 'month',
              format: '%b',
              time: '2y'
            }
          ];
        },
        setselectedtimerange: function (timerange) {
          selectedtimerange = timerange;
          return cookieStore.put('selectedtimerange', selectedtimerange);
        },
        getselectedtimerange: function () {
          if (selectedtimerange) {
            return selectedtimerange;
          } else {
            return this.fetchtimeRanges()[0];
          }
        }
      
    }}]);
