'use strict';
/*
** @brief: this is a meta extractor, created with the intention of making a common provider of facts across the app
** At the time of writing, it was meant for updating navigation-bar-links and footer-seo-metadata-links
**
 */

angular.module('buySmaartApp')
.service('Meta', [
  '$rootScope',
  '$location',
  '$route',
  'Api',
  '$q',
function($rootScope, $location, route, Api, $q) {

  return {
    getGenreMetadata: function(){
      if( $rootScope.config.genreMetadata ){
        return $q.when( $rootScope.config.genreMetadata );
      } else {
        var domainId = this.getDomainID();
        var categoryId = this.getCategoryID();
        return $q.when({}); //no fallback
      }
    },


    getTopBrands: function(){
      // if the response already exists
      // and the category din't change
      if($rootScope.topBrands && $rootScope.topOSs && (!$rootScope.didCategoryChange) ){
        return $q.when({
          "filterDetailMap": [ $rootScope.topBrands, $rootScope.topOSs ]
        });
      } else {
        var domainId = this.getDomainID();
        var categoryId = this.getCategoryID();
        return Api.getPopularBrand(domainId,categoryId);
      }
    },


    getPopularComparisons: function(){
      // if the response already exists
      // and the category din't change
      if($rootScope.compareList && (!$rootScope.didCategoryChange)){
        return $q.when( $rootScope.compareList );
      } else {
        var domainId = this.getDomainID();
        var categoryId = this.getCategoryID();
        return Api.fetchPopularComparisons(domainId, categoryId);
      }
    },


    getCategoryName: function(){
      var domainIndex = _.get($rootScope, 'NLPFilters.domainIndex', 0);
      // var categoryId = parseInt ( _.get($rootScope, 'NLPFilters.categoryId', 1), 10);
      var categoryId = parseInt ( _.get($rootScope, 'categoryId', 1), 10);
      var categories = angular.copy( $rootScope.categories );

      var categoriesPath = _.template("domain[${domainIndex}].categories")({
        "domainIndex": domainIndex
      });

      var categoriesInDomain = _.get($rootScope, categoriesPath, {});
      var category = _.find(categoriesInDomain, {
        "categoryId": categoryId
      });

      var fallbackCategoryName = _.get(category, "categoryName", "");

      return _.get(route, "current.params.categoryName", fallbackCategoryName);
    },


    getDomainID: function(){
      return _.get($rootScope, "config.domainId", "smartphone");
    },


    getDomainIndex: function(){
      var fallbackIndex = _.get( $rootScope, "NLPFilters.domainIndex", 0);
      var categoryName = this.getCategoryName();
      var categories = angular.copy ( $rootScope.categories );
      var temp = _.find(categories, { categoryName: categoryName });
      var domainId = _.get(temp, "domainId", 0);
      domainId = domainId >= 0 ? domainId - 1 : 0;
      var domainIndex = domainId || fallbackIndex;

      return domainIndex;
    },

    getCategoryID: function(){

      var categories = angular.copy ( $rootScope.categories );
      var categoryName = this.getCategoryName();
      var fallbackCategoryID = 1;

      var temp = _.find(categories, { categoryName: categoryName });
      var categoryId = _.get(temp, "categoryId", fallbackCategoryID)
      
      return categoryId;

      // return _.get($rootScope, "config.categoryId", fallbackCategoryID);
    },


    getNormalizedPriceList: function(response){
      //method for buy-from-seller-pop-up that returns normalized prices among different sellers
      var priceList = _.get(response, 'data.priceList', null);
      var normalizedPriceList = {};
      if(!priceList){
        return normalizedPriceList;
      }
      _.each(priceList, function(item, index){
        var sellerId = _.get(item, "seller.id");
        item.price = parseInt(item.price, 10);
        if(normalizedPriceList[sellerId]){
          //if seller already exists, compare the prices & keep the less priced one
          var existingItemPrice = normalizedPriceList[sellerId]['price'];
          var newPrice = item.price;
          if (newPrice < existingItemPrice) {
            normalizedPriceList[sellerId] = item;
          }
        } else {
          normalizedPriceList[sellerId] = item;
        }
      });
      return normalizedPriceList;
    },


    getNewArrivals: function(){
      if( $rootScope.newArrivals && (!$rootScope.didCategoryChange)){
        return $q.when( $rootScope.newArrivals )
      } else {
        var productDetails = this.getProductDetails();
        var domainId = this.getDomainID();
        var categoryId = this.getCategoryID();
        return Api.fetchNewArrivals(domainId, categoryId, productDetails);
      }
    },


    getProductDetails: function(){
      var params = {};
      params.aspectMetadata = {};
      var aspects = $rootScope.config.aspects;
      for (var k in aspects){
          if(k != 'undefined') {
              params.aspectMetadata[aspects[k].aspectId] = {};
              params.aspectMetadata[aspects[k].aspectId].value = 3;
              params.aspectMetadata[aspects[k].aspectId].metadataId = aspects[k].metadataId;
          }
      }
      return params;
    },


    getRatingCriteriaFromURL: function(){
      var ratingCriteria = _.get(route, "current.params.ratingCriteria", null);
      if(ratingCriteria){
        ratingCriteria = JSON.parse( ratingCriteria );
        return ratingCriteria;
      } else {
        return null;
      }
    },


    getFilterMetadataIdMap: function () {
      var filters = _.get($rootScope, "config.filters", []);
      filters = _.filter(filters, {
        "filterLocation": "GLOBAL"
      });
      var metadataIdMap = _.map(filters, function(item){
        return {
          "metadataId": item.metadataId
        }
      });
      return metadataIdMap;
    },


    getFilterMetadataStr: function () {
      //return value signature: filterMetadataString={"metadatas":[{"metadataId":1},{"metadataId":4}]}"
      return {
        "metadatas": this.getFilterMetadataIdMap()
      };
    },


    getPricesForCategory: function( categoryNameOrId ){
      var pricesMetadata = {};
      var _categoryNameOrId = categoryNameOrId || this.getCategoryID();
      switch (_categoryNameOrId) {
        case 4:
        case "Air Conditioners":
        case "Air%20Conditioners":
        pricesMetadata = {
          "PriceMinValue": 20000,
          "PriceMaxValue": 50000,
        }
        break;
        
        case 3:
        case "Laptops":
        pricesMetadata = {
          "PriceMinValue": 15000,
          "PriceMaxValue": 75000,
        }
        break;

        case 5:
        case "Televisions":
        pricesMetadata = {
          "PriceMinValue": 25000,
          "PriceMaxValue": 80000,
        }
        break;


        default:
        case 1:
        case "Smartphones":
        case 2:
        case "Tablets":
        pricesMetadata = {
          "PriceMinValue": 5000,
          "PriceMaxValue": 40000,
        }
        break;

      }

      return pricesMetadata;
    },

    getBudgetAmountListForCategory: function( categoryNameOrId ){
      var _categoryNameOrId = categoryNameOrId || this.getCategoryID();
      switch (_categoryNameOrId) {
        case 4:
        case "Air Conditioners":
        case "Air%20Conditioners":
        return [20000, 25000, 30000, 35000, 40000, 45000, 50000, 55000, 60000, 65000, 70000, 75000, 80000, 85000, 90000, 95000, 100000];
        break;

        case 3:
        case "Laptops":
        return [15000, 20000, 25000, 30000, 35000, 40000, 45000, 50000, 55000, 60000, 65000, 70000, 75000, 80000, 85000, 90000, 115000, 140000, 165000, 190000, 215000, 240000, 265000, 300000];
        break;

        case 5:
        case "Televisions":
        return [10000, 15000, 20000, 25000, 30000, 35000, 40000, 45000, 50000, 55000, 60000, 65000, 70000, 75000, 80000, 85000, 90000, 115000, 140000, 165000, 190000, 215000, 240000, 265000, 300000];
        break;


        default:
        case 1:
        case "Smartphones":
        case 2:
        case "Tablets":
        return [5000, 10000, 15000, 20000, 25000, 30000, 35000, 40000, 45000, 50000, 55000, 60000, 65000, 70000, 75000, 80000, 85000, 90000];
        break;

      }
    },


    getTimeSortOptions: function ( categoryNameOrId ) {
      var _categoryNameOrId = categoryNameOrId || this.getCategoryID();
      switch (_categoryNameOrId) {
        case 1:
        case "Smartphones":
        case 2:
        case "Tablets":
        return [
          {name: "Newest First", key:"desc", sortBy: 'Date'},
          {name: "Oldest First", key:"asc", sortBy: 'Date'}
        ];
        break;

        default:
        return [];
      }
    }
  };
}]);
