'use strict';

angular.module('buySmaartApp')
  .service('Priceretailercolors', function Priceretailercolors() {
    var colorMap = {
        "amazon India":{
            "color":"#fc9326",
            "imageURL":"/images/ignore/amazon-pricegraph.png"
        },
        "flipkart":{
            "color":"#157fd3",
            "imageURL":"/images/ignore/flipkart-pricegraph.png"
        },
        "Naaptol":{
            "color":"#16ac18",
            "imageURL":"/images/ignore/naaptol-pricegraph.png"
        },
        "snapdeal":{
            "color":"#c53632",
            "imageURL":"/images/ignore/snapdeal-pricegraph.png"
        },
        "Croma Retail":{
            "color":"#4bd2de",
            "imageURL":"/images/ignore/croma-pricegraph.png"  
        },
        "Reliance Digital":{
            "color":"#003085",
            "imageURL":"/images/ignore/reliance-pricegraph.png"  
        },
        "Infibeam":{
            "color":"#e15a0b",
            "imageURL":"/images/ignore/infibeam-pricegraph.png"
        }
    }
    return{
        getRetailerColorMap:function(){
            return colorMap;
        }

    }
  });
