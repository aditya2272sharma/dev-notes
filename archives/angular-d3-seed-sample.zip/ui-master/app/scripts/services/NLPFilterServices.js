'use strict';

angular
.module('buySmaartApp')
.service("NLPFilterServices", [
  "$rootScope",
  "$location",
  "Meta",
function ( $rootScope, $location, Meta ) {
  var params = {};
  var domainIndex = 0;
  function generateURLParams ( NLPFilters, isConfigAvaliable) {
    params = {};
    domainIndex = isConfigAvaliable ? NLPFilters.domainIndex : 0;
    params.filters = [];
    $rootScope.newParams = "?";
    params.aspects = NLPFilters.aspects;
      var prefix = "";
      var aspectVals = "";
      for(var aspect in params.aspects){
          aspectVals = aspectVals + prefix;
          aspectVals = aspectVals + params.aspects[aspect].name + "=" + params.aspects[aspect].value;
          prefix = "&"; 
      }
      $rootScope.newParams = $rootScope.newParams + aspectVals;
    for(var i in NLPFilters.filters) {
      params.filters[i] = {};
      params.filters[i].filterId = NLPFilters.filters[i].filterId;
      params.filters[i].metadataId = NLPFilters.filters[i].metadataId;
      params.filters[i].selectedFilters = NLPFilters.filters[i].selectedFilters;
      prefix = "";
      var selectedFiltersParam = "";
      if(params.filters[i].selectedFilters){
        if ( !NLPFilters.filters[i].allFilters ) {
          return;
        }
          if(params.filters[i].selectedFilters.length != 0){
              for(var myFilter in params.filters[i].selectedFilters){
                  selectedFiltersParam = selectedFiltersParam + prefix;
                  selectedFiltersParam = selectedFiltersParam + params.filters[i].selectedFilters[myFilter];
                  prefix = ",";
              }
              $rootScope.newParams = $rootScope.newParams + "&" + params.filters[i].filterId + "=" + selectedFiltersParam;
          }
      }
      else{
        params.filters[i].selectedFilters = [];
      }
    }
    params.SentimentWeight = NLPFilters.SentimentWeight;
    $rootScope.newParams = $rootScope.newParams + "&Sentiment=" + params.SentimentWeight;
    params.SpecificationWeight = NLPFilters.SpecificationWeight;
    $rootScope.newParams = $rootScope.newParams + "&Specification=" + params.SpecificationWeight;
    params.PriceMinValue = NLPFilters.PriceMinValue;
    $rootScope.newParams = $rootScope.newParams + "&PriceMinValue=" + params.PriceMinValue;
    params.PriceMaxValue = NLPFilters.PriceMaxValue;
    $rootScope.newParams = $rootScope.newParams + "&PriceMaxValue=" + params.PriceMaxValue;
    params.TimeSort = NLPFilters.TimeSort;
    if(params.TimeSort != null){
        $rootScope.newParams = $rootScope.newParams + "&TimeSort=" + params.TimeSort;
    }
    params.PriceSort = NLPFilters.PriceSort;
    if(params.PriceSort != null){
        $rootScope.newParams = $rootScope.newParams + "&PriceSort=" + params.PriceSort;  
    }
    params.ScoreSort = NLPFilters.ScoreSort;
    if(params.ScoreSort != null){
        $rootScope.newParams = $rootScope.newParams + "&ScoreSort=" + params.ScoreSort;
    }
    if(isConfigAvaliable){
      domainIndex = NLPFilters.domainIndex;
      params.categoryId =  Meta.getCategoryID();
    }
    params.allProducts = NLPFilters.allProducts;
    $rootScope.newParams = $rootScope.newParams + "&AllProducts=" + params.allProducts;
    // return params;
    return params;
  }

  $rootScope.$on("categoryConfigUpdated", function(){
    domainIndex = $rootScope.NLPFilters.domainIndex;
    params.categoryId = Meta.getCategoryID();
  });

  function getParams(){
    var NLPFilters = angular.copy($rootScope.NLPFilters);
    return generateURLParams( NLPFilters, $rootScope.isConfigAvaliable );
  }
  return {
    openDashboardPage: function(){
      // Alias for $rootScope.openDashboardPage
      $rootScope.myParams = getParams();
      var categoryName = Meta.getCategoryName();
      $location.url("/"+categoryName+"/DiscoveryDashboard" + $rootScope.newParams);
    },
    openSmartView: function(){
      // Alias for $rootScope.openSmartView
      var _params = JSON.stringify(getParams());
      var categoryName = Meta.getCategoryName();
      $location.url("/"+categoryName+"/SmaartView/" + _params);
    },
    showModelsWithFilters: function( baseURL, index, filters ){
      // Alias for globalheader.directive > scope > showModelsWithFilters
      var NLPFilters = angular.copy($rootScope.NLPFilters);
      for(var i in NLPFilters.aspects) {
        NLPFilters.aspects[i].value = 3;
      }
      for(var i in NLPFilters.filters) {
        NLPFilters.filters[i].selectedFilters = [];
      }
      $rootScope.budgetAmountsList = Meta.getBudgetAmountListForCategory();
      NLPFilters.PriceMinValue = $rootScope.budgetAmountsList[0];
      NLPFilters.PriceMaxValue = $rootScope.budgetAmountsList[$rootScope.budgetAmountsList.length-1];
      NLPFilters.filters[index].selectedFilters.push(filters);
      NLPFilters.allProducts = false;
      $rootScope.myParams = generateURLParams( NLPFilters, $rootScope.isConfigAvaliable );
      for(var i in $rootScope.myParams.filters){
            $rootScope.myParams.filters[i].selectedFilters = [];
      }
      //var params = getParams();
      // return $location.host() + baseURL + _params;
      return baseURL + $rootScope.newParams;
    },
    searchWithGenre: function( baseURL, genreData ){
      // Alias for globalheader.directive > scope > searchWithGenre
      var NLPFilters = angular.copy($rootScope.NLPFilters);
      for(var i in NLPFilters.aspects) {
        NLPFilters.aspects[i].value = genreData['metadataVal'+ NLPFilters.aspects[i].metadataId];
      }
      for(var i in NLPFilters.filters) {
        NLPFilters.filters[i].selectedFilters = [];
      }
      $rootScope.budgetAmountsList = Meta.getBudgetAmountListForCategory();
      NLPFilters.PriceMinValue = $rootScope.budgetAmountsList[0];
      NLPFilters.PriceMaxValue = $rootScope.budgetAmountsList[$rootScope.budgetAmountsList.length-1];
      NLPFilters.allProducts = false;
      $rootScope.myParams = generateURLParams( NLPFilters, $rootScope.isConfigAvaliable );
      for(var i in $rootScope.myParams.filters){
            $rootScope.myParams.filters[i].selectedFilters = [];
      }
      //var params = getParams();
      return baseURL + genreData.dispMarker+ $rootScope.newParams;
    },
    openSeoSearch: function(baseURL, seoMetadata) {
        var NLPFilters = angular.copy($rootScope.NLPFilters);
        NLPFilters.PriceMinValue = seoMetadata.minPrice;
        NLPFilters.PriceMaxValue = seoMetadata.maxPrice;
        for(var i in NLPFilters.filters) {
          NLPFilters.filters[i].selectedFilters = [];
          if(NLPFilters.filters[i].metadataId == seoMetadata.categoryMetadataId) {
            NLPFilters.filters[i].selectedFilters.push(seoMetadata.filter);
          }
        }
        for(var i in NLPFilters.aspects) {
          NLPFilters.aspects[i].value = seoMetadata['colVal'+NLPFilters.aspects[i].metadataId];
        }
        NLPFilters.allProducts = false;
        $rootScope.myParams = generateURLParams( NLPFilters, $rootScope.isConfigAvaliable );
        for(var i in $rootScope.myParams.filters){
            $rootScope.myParams.filters[i].selectedFilters = [];
        }
        //var params = getParams();
        return baseURL + seoMetadata.dispMarker+ $rootScope.newParams;
    },

    // Legacy Parsing Method
    parseDomainConfig: function( domainConfig ){
      // Normalizing Domain Config into an array of Domains e.g. Electronics
      // And, nesting all categories in an array under respective domains
      var domain = [];
      _.each(domainConfig, function(domainItem, index) {

        var categories = [];
        _.each(domainItem["categoryMetadata"], function(categoryItem, index){
          categories[index] = _.pick(categoryItem, ['categoryId', 'categoryName']);
        });

        domain[index] = _.pick( domainItem, ["domainId", "displayName"]);

        _.extend( domain[index], {
          "categories": categories
        });

      });

      return domain;
    },


    normalizeConfig: function ( domainConfig ) {
      var categories = [];

      _.each(domainConfig, function(domainItem, index) {
        var categoryMetadata = "categoryMetadata" in domainItem ? domainItem["categoryMetadata"] : domainItem["categories"] ;
        var domainId = _.get( domainItem, "domainId", 0);
        domainId = parseInt( domainId );

        _.each( categoryMetadata, function(categoryItem, index){
          var categoryId = parseInt ( categoryItem['categoryId'], 10 );
          var item = _.extend({}, {
            'domainId': domainId,
            'categoryId': categoryItem['categoryId'],
            'categoryName': categoryItem['categoryName']
          });
          categories.push( item );
        });

      });

      return categories;
    }

  };
}]);
