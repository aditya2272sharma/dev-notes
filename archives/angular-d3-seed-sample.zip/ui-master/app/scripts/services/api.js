'use strict';

angular.module('buySmaartApp')
  .service('Api',["Restangular", '$rootScope', '$http', function Api(Restangular, $rootScope, $http) {
    return {
        fetchNewArrivals:function(domainID, categoryId, productDetail){
         var newArrivals = Restangular.one("product/newArrivals/"+domainID);
         return newArrivals.get({
            categoryId : categoryId,
            productDetail : productDetail
         });
        },
        fetchPopularComparisons:function(domainID, categoryId){
         var popularComparison = Restangular.one("product/popularComparisons/"+domainID);
         return popularComparison.get({
            "categoryId":categoryId
         });
        },
        fetchSmaartpulseData:function(categoryId, productID){
         var SmaartpulseData = Restangular.one("sentimentmap/category/"+categoryId+"/product/"+productID);
         return SmaartpulseData.get();
        },

        fetchIndividualReviews:function(categoryId, productID,treemapName,aspectID){
         var ReviewData = Restangular.one("review/category/"+categoryId+"/product/"+productID+"/treemap/"+treemapName+"/aspect/"+aspectID);
         return ReviewData.get();
        },
        fetchPriceGraphData:function(productId,start,end,interval){
         var ProductDetails = Restangular.all("product/priceTrends/smartphone");
         return ProductDetails.get(productId,{
            start:start,
            end:end,
            by:interval
         });
        },
        fetchAutocompleteDetails:function(value, categoryId){
            return Restangular.one("product/search/smartphone/product/").getList(value,{
                "categoryId":categoryId,
                "maxRecords":6});
        },
        fetchDomainConfiguration:function(){
            return Restangular.one("config/domains").get();
        },
        fetchConfigarations: function(domainId, categoryId){
        	return Restangular.all("config").get(domainId, {
                categoryId:categoryId
            });
        },
		getProductsByRatingCriteria:function(domainId, ratingCriteria, page, maxRecords, category){
			var ProductDetails = Restangular.all("products");
			return ProductDetails.get(domainId,{
				page:page,
				maxRecords:maxRecords,
                category:category,
				ratingCriteria:ratingCriteria
			});
		},

        getRecommendedProductsByRatingCriteria: function(domainId, productId,ratingCriteria, categoryId) {
            var ProductDetails = Restangular.one("/product/similar/" + domainId + "/" + productId);
			return ProductDetails.get({
                "categoryId" : categoryId,
                "ratingCriteria" : ratingCriteria
            });
        },

		getProductsCountByRatingCriteria:function(domainId, ratingCriteria, categoryId){
			var ProductDetails = Restangular.all(domainId + "/products");
			return ProductDetails.get("count",{
                category:categoryId,
				ratingCriteria:ratingCriteria
			});
		},
		getFilterOptions:function(domainId, type, categoryId){
			var ProductDetails = Restangular.all("product/search/" + domainId);
			return ProductDetails.get(type,{
                categoryId:categoryId
            });
		},

        getProductReviewsCountByAspects:function(domainId,productid,aspectsString){
            var reviewsCount = Restangular.one(domainId+"/product/"+productid+"/reviews/count/user");
            return reviewsCount.get({"aspects":aspectsString})
        },

		getProductPriceAnalytics:function(domainId, id){
			//var ProductDetails = Restangular.all("product/priceAnalytics/" + domainId);
			//return ProductDetails.get(id);
			var path = $rootScope.serverUrl + "/product/priceAnalytics/" +domainId+"/"+id;
        	return $http.get(path);
		},

		getProductSpecification: function(domainId, id, categoryName){
			var ProductDetails = Restangular.all(domainId + "/product/" + id) ;
			return ProductDetails.get("specification", {
                categoryName: categoryName
            });
		},

		getProduct: function(domainId, id, productDetail, categoryId){
			var ProductDetails = Restangular.all("product/" + domainId);
			return ProductDetails.get(id, {
                categoryId: categoryId,
                productDetail: productDetail
            });
		},

        createUserNotification: function(details) {
            var ProductDetails = Restangular.all("user/subscribe/1/");
			return ProductDetails.post(details);
        },

        getVideoReviews : function(domainId, productId) {
            var ProductDetails = Restangular.all('reviews/video/'+ domainId) ;
            return ProductDetails.get(productId);
        },

        //api/v0.1/user/1/wishlist/
        getWishListItems: function(domainId) {
        	var path = $rootScope.serverUrl + "/user/" + $rootScope.user_id + "/wishlist/";
        	return $http({
			    url: path,
			    method: "GET"
			 });
        },

        // /api/v0.1/user/{userId}/wishlist/{domainId}/{productId}
        removeFromWishlist: function(id){
        	var path = $rootScope.serverUrl + "/user/" + $rootScope.user_id + "/wishlist/"+id;
        	return $http({
			    url: path,
			    method: "DELETE"
			 });
        },

         addProductToWishlist: function(data){
         	var path = $rootScope.serverUrl + "/user/" + $rootScope.user_id + "/wishlist/";
			return $http.post(path, data);
        },

        // /smartphone/feedback
        submitteFeedBack:function(domainId, data){
        	var path = $rootScope.serverUrl +"/"+ domainId +"/feedback";
        	return $http.post(path, data);
        },

        //http://staging.aithinq.com/api/v0.1/smartphone/contact
        submitteContact: function(domainId, data) {
        	var path = $rootScope.serverUrl +"/"+ domainId +"/contact";
        	return $http.post(path, data);
        },

        getUserInformationAfterSocialLogin: function(token, provider) {
        	var path = $rootScope.authserverUrl + "/auth/user/" +token+"/"+provider;
        	return $http.get(path);
        },

        /**
	     * Google analytics track event function
	     * @param eventCategory category of the event
	     * @param action event
	     * @param label information label
	     */
	    gaTrackEvent : function(eventCategory,action,label) {
	    	ga('send', 'event',eventCategory, action,label, {'nonInteraction': 1});
	    },

        getPopularBrand : function(domainId, categoryId, filterMetadataStr) {
            var popularBrands = Restangular.one('/domain/'+domainId+'/topfilters');
            return popularBrands.get({
                categoryId : categoryId,
                filterMetadataString: filterMetadataStr
            });
        },

        // @RequestMapping(value="/domain/{domainId}/product/{productId}/summary", method=RequestMethod.GET)
        getProductSummary : function(domainId, productId) {
            return Restangular.one("/product/" + domainId + "/" + productId + "/summary").get();
        },

      getPlaceholderForFutureMethod : function(unknown, params) {
        var popularBrands = Restangular.one('/domain/'+unknown+'/topfilters/'+params);
        return popularBrands.get({
          "foo": "bar"
        });
      }
    };
  }]);
