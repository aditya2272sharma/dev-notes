'use strict';

angular
.module('buySmaartApp')
.directive('categoryDropdown', [
  '$rootScope',
  '$location',
  '$route',
  'Api',
  'NLPFilterServices',
  'Meta',
  function($rootScope, $location, route, Api, NLPFilterServices, Meta) {
    return {
      templateUrl: "views/categoryDropdown.html",
      link: function($scope, element, attrs){
        function updateFiltersAndAspectsForCategory ( config ) {
            var aspects = config.aspects;
            var filters = config.filters;
            var lastGlobalIndex = 0;
            var lastListingIndex = 0;
            $rootScope.NLPFilters.filters = [];
            for(var i = 0, iLen = filters.length; i < iLen; i++){
                var allItems = filters[i].filterableItems;
                $rootScope.NLPFilters.filters[i] = {};
                $rootScope.NLPFilters.filters[i].filterId = filters[i].filterId;
                $rootScope.NLPFilters.filters[i].metadataId = filters[i].metadataId;
                $rootScope.NLPFilters.filters[i].allFilters = allItems;
                $rootScope.NLPFilters.filters[i].filterLocation = filters[i].filterLocation;
                if(filters[i].filterLocation == "GLOBAL"){
                  lastGlobalIndex = i;
                }
                if(filters[i].filterLocation == "LISTING"){
                  lastListingIndex = i;
                }
                // $rootScope.nplFilterText = scope.nplFilterText;
            }
            if(lastListingIndex < lastGlobalIndex) {
              var temp = $rootScope.NLPFilters.filters[lastGlobalIndex];
              $rootScope.NLPFilters.filters[lastGlobalIndex] = $rootScope.NLPFilters.filters[lastListingIndex];
              $rootScope.NLPFilters.filters[lastListingIndex] = temp;
            }
            $rootScope.NLPFilters.aspects = {};
            for (var key in aspects) {
                $rootScope.NLPFilters.aspects[aspects[key].aspectId] = angular.copy($rootScope.arrayOfAspectTips[2]);
                $rootScope.NLPFilters.aspects[aspects[key].aspectId].name = aspects[key].aspectId;
                $rootScope.NLPFilters.aspects[aspects[key].aspectId].metadataId = aspects[key].metadataId;
            }
        }
        $scope.onClickCategories = function(selectedIndex) {
          Api.gaTrackEvent('(' +$scope.categoryName +') ' + $scope.currentPage + ' Page', $scope.categories[selectedIndex].categoryName + ' Category Selected' , 'Navigate to Home Page');

          var categoryId = $scope.categories[selectedIndex].categoryId;
          var domainId = $scope.categories[selectedIndex].domainId;
          $rootScope.NLPFilters.domainIndex = (domainId * 1) - 1;
          $rootScope.categoryId = categoryId;
          $scope.selectedCategory = $scope.categories[selectedIndex].categoryName;

          $rootScope.compareItems = [];
          $scope.compareItems = [];
          $scope.showCategoryOptions = false;
          $rootScope.isConfigAvaliable = false;

          $scope.selectedTextForSort = "";
          $scope.sortBy = "";
          $rootScope.NLPFilters.TimeSort = null;
          $rootScope.NLPFilters.PriceSort = null;
          $rootScope.NLPFilters.ScoreSort = null;

          Api.fetchConfigarations("smartphone", categoryId).then(function(config) {
            $rootScope.config = config;
            $rootScope.NLPFilters.domainId = config.domainId;
            $rootScope.categoryId = categoryId;
            $rootScope.isConfigAvaliable = true;
            updateFiltersAndAspectsForCategory(config);
            $rootScope.$broadcast("categoryConfigUpdated");
          });
          // $location.url("/" + "category/" + $scope.selectedCategory);
          $location.url("/");
        };
        $(function(){
          $("body").on("click", function( event ){
            var $target = $(event.target);
            var parentsLength = $target.parents(".cat-drop").length;
            var parents2Length = $target.parents(".cat-opener").length;
            if( !parentsLength && !parents2Length ){
              $scope.showCategoryOptions = false;
            }
          })
        })
      }
    }
  }]);
