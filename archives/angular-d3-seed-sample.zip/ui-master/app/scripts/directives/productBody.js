'use strict';

angular.module('buySmaartApp').directive('productBody', [function() {
	return {
		templateUrl : 'views/productDetailsBody.html',
		restrict : 'E',
		link : function postLink(scope, element, attrs) {

		}
	};
}]);
