'use strict';

angular.module('buySmaartApp').directive('navBar', ['$rootScope', 'Meta', function($rootScope, Meta) {
	return {
		templateUrl : 'views/navigationBar.html',
		restrict : 'E',
		link : function postLink(scope, element, attrs) {
			scope.categoryName = Meta.getCategoryName();
		}
	};
}]).run(['$rootScope', '$location', 'NLPFilterServices', 'Meta', function($rootScope, $location, NLPFilterServices, Meta) {

		$rootScope.openDashboardPage = NLPFilterServices.openDashboardPage; //In dashboard need not to do anything
		$rootScope.openSmartView = NLPFilterServices.openSmartView;

		$rootScope.openComparePage = function() {
			var categoryName = Meta.getCategoryName();
		  	var path = "/"+categoryName+"/Compare";
		  	if($rootScope.compareItems.length > 1){
			  	var name = $rootScope.compareItems[0].displayName.replace(/ /g,"-");
			  	var productIds = $rootScope.compareItems[0].productId;
			  	for(var i = 1, iLen=$rootScope.compareItems.length; i < iLen; i++){
			  		productIds = productIds + "-" + $rootScope.compareItems[i].productId;
			  		name = name + "-vs-" + $rootScope.compareItems[i].displayName.replace(/ /g,"-");
			  		name = encodeURIComponent (name);
			  	}
			  	path = path+"/"+productIds+"/"+name;
			  	path = encodeURI(path);
		  		$location.url(path);
		  	} else {
		  		for(var i = 0, iLen=$rootScope.compareItems.length; i < iLen; i++){
			  		path= path + "/" + $rootScope.compareItems[i].productId;
			  	}
			  	path = encodeURI(path);
			  	$location.url(path);
		  	}
		};

		$rootScope.openComparePageForTwo = function(id1, id2, name1, name2) {
			$rootScope.compareItems = [];
			var categoryName = Meta.getCategoryName();
		  	var path = "/"+categoryName+"/Compare";
		  	var name = name1.replace(/ /g,"-") + "-vs-" + name2.replace(/ /g,"-");
		  	name = encodeURIComponent ( name );
		  	var productIds = id1 + "-" + id2;
		  	path = path+"/"+productIds+"/"+name;
		  	path = encodeURI (path);
		  	$location.url(path);
		};

		$rootScope.openWishlistPage = function(){
	    	$location.url("/WishList");
		};

	}
]);
