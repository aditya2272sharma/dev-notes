'use strict';

angular.module('buySmaartApp').directive('readMore', [function() {
	return {
		scope : {
			isimpose : '='
		},
		restrict : 'E',
		link : function postLink(scope, element, attrs) {
			var init = function() {
				if (element.find(".item_name").innerHeight() >= 70) {
					if (scope.isimpose) {
						element.find(".item_name").height(70);
						element.find(".more_link").show();
					} else {
						element.find(".item_name").height("auto");
					}
				} else {
					element.find(".more_link").hide();
				}
			};

			scope.$watch(function(scope) {
				return element.find(".item_name").innerHeight();
			}, function(newval, oldval) {
				init();
			});
			scope.$watch(function(scope) {
				return scope.isimpose
			}, function(newval, oldval) {
				init();
			});
			init();
		}
	};
}]);
