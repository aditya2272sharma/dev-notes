'use strict';

angular.module('buySmaartApp').directive('nlpFilters', ['$rootScope', 'Api', 'Meta', function($rootScope, Api, Meta) {
	return {
		templateUrl : 'views/NLPfilters.html',
		restrict : 'E',
		replace: true,
		link : function postLink(scope, element, attrs) {
  			scope.arrayOfAspectTips = [
	            {
	                "display":"is most important",
	                "value":5
	            },
	            {
	                "display":"is very important",
	                "value":4
	            },
	            {
	                "display":"is moderately important",
	                "value":3
	            },
	            {
	                "display":"is unimportant",
	                "value":2
	            },
	            {
	                "display":"is least important",
	                "value":1
	            }
	        ];
	        
	        scope.showAdvPref = function(){
          angular.element('.addi-pref-main').css({"position":"absolute", width : '95%'}).hide('slide', {direction: 'left'}, 500);
          angular.element('.addi-pref').css({"position":"absolute"}).show('slide', {direction: 'right'}, 500, function() {
            angular.element('.addi-pref').css("position","relative");
            angular.element('.addi-pref-main').css("position","relative");
            angular.element('.header-content').css("height","auto");

          });
        }
	        
      function setPricesInfo(){
        var pricesInfoForCategory = Meta.getPricesForCategory();
        $rootScope.NLPFilters.PriceMinValue = pricesInfoForCategory.PriceMinValue;
        $rootScope.NLPFilters.PriceMaxValue = pricesInfoForCategory.PriceMaxValue;
        scope.lowerAmount = Number($rootScope.NLPFilters.PriceMinValue) - (Number($rootScope.NLPFilters.PriceMinValue) % 5000);
        scope.higherAmount = Number($rootScope.NLPFilters.PriceMaxValue) - (Number($rootScope.NLPFilters.PriceMaxValue) % 5000);
        setPriceList();
      }
      setPricesInfo();
	      
  			
  			scope.lowerAmount = (scope.lowerAmount < $rootScope.budgetAmountsList[0])? $rootScope.budgetAmountsList[0] : scope.lowerAmount;
  			scope.higherAmount = (scope.higherAmount > $rootScope.budgetAmountsList[$rootScope.budgetAmountsList.length - 1])? $rootScope.budgetAmountsList[$rootScope.budgetAmountsList.length - 1] : scope.higherAmount;
  			
  			
  			var bodyClick = function(){
				angular.element('body').click(function(event) {
					if(! angular.element(event.target).parents('.element_part_dropdown').length) {
						scope.nlphideAllOverlays();
						scope.nlpundoFiltersState();
						scope.$apply();
						angular.element('.displayDropDownBody,.displayDropDownTip,.performanceDropDownBody,.performanceDropDownTip,.cameraDropDownBody,.cameraDropDownTip,.batteryDropDownBody,.batteryDropDownTip').hide();
					}	
				});
			};
  			bodyClick();
  			
  			scope.nlpundoFiltersState = function(){
				scope.interNLPSelectedFilters = angular.copy(scope.nlpFilters);
				scope.selectAllFilter = new Array();
				for(var i in scope.interNLPSelectedFilters) {
					if(scope.interNLPSelectedFilters[i].length == scope.allFilterItems[i].length)
						scope.selectAllFilter[i] = true;
					else
						scope.selectAllFilter[i] = false;
				}
			};
  			
  			/*** Hide overlaays ***/
			scope.nlphideAllOverlays = function() {
				for(var i in scope.showFilterList) {
					scope.showFilterList[i] = false;
				}
				scope.showlowestPricePanel = false;
				scope.showHighestPricePanel = false;
				for(var i in scope.showAspectList) {
					scope.showAspectList[i] = false;
				}
			};
			
			var nlpsendInitialCalls = function(){
				// var response = scope.config;
           		// scope.aspects = response.aspects;
           		scope.categoryName = Meta.getCategoryName();
           		scope.showFilterList = new Array();
           		scope.showAspectList = new Array();
           		scope.nlpFilters = new Array();
           		scope.selectAllFilter = [];
           		scope.nlpFilterNames = new Array();
           		scope.allFilterItems = new Array();
              scope.GLOBAL_filters = _.filter( $rootScope.NLPFilters.filters, {
                "filterLocation": "GLOBAL"
              });
              scope.LISTING_filters = _.filter( $rootScope.NLPFilters.filters, {
                "filterLocation": "LISTING"
              });
           		scope.nplFilterText = new Array();
           		scope.interNLPSelectedFilters = []
           		for(var i = 0, iLen = scope.GLOBAL_filters.length; i < iLen; i++){
           			scope.nlpFilterNames[i] = scope.GLOBAL_filters[i].filterId;
	        		var filterItems = new Array();
	        		var allItems = scope.GLOBAL_filters[i].allFilters;
	        		scope.allFilterItems[i] = allItems;
	        		for(var j=0;j<allItems.length;j++) {
	        			filterItems.push(allItems[j].itemId);
	        		}
	        		scope.nlpFilters[i] = filterItems;
	        		if(filterItems.length == 0 || filterItems.length == allItems.length) {
	        			scope.nplFilterText[i] = 'Any'+'\u00A0'+ scope.nlpFilterNames[i];
	        			scope.selectAllFilter[i] = true;
	        			scope.interNLPSelectedFilters[i] = [];
	        			for(var j in allItems) {
	        				scope.interNLPSelectedFilters[i].push(allItems[j].itemId);
	        			}
	        		}
	        		scope.showFilterList[i] = false;
            	}
	            scope.aspects = [];
	            scope.aspectDisplayName = {};
  				for (var key in $rootScope.NLPFilters.aspects) {
  					var aspect = {};
  					scope.showAspectList[key] = false;
  					aspect.aspectId = key;
  					aspect.displayName = key;
  					aspect.display = $rootScope.NLPFilters.aspects[key].display;
  					aspect.value = $rootScope.NLPFilters.aspects[key].value;
  					scope.aspects[scope.aspects.length] = aspect;
  					scope.aspectDisplayName[key] = $rootScope.NLPFilters.aspects[key].display;
	  			}
	  			var allFilterItemsLength = _.get(scope, 'allFilterItems[0].length', 5);
	  			scope.columnLimit = Math.ceil(allFilterItemsLength/5);
	  			setPricesInfo();
	     	};

	     	$rootScope.$on("categoryConfigUpdated",nlpsendInitialCalls);
	     	if($rootScope.isConfigAvaliable){
	     	  nlpsendInitialCalls();
	     	}

	     	scope.nlpclickOnSelectAllFilters = function(index){
	     		scope.interNLPSelectedFilters[index] = new Array();
	     		scope.selectAllFilter[index] = !(scope.selectAllFilter[index]);
	     		if(scope.selectAllFilter[index]) {
	     			var allitems = scope.allFilterItems[index];
	     			for(var i in allitems) {
	     				scope.interNLPSelectedFilters[index].push(allitems[i].itemId);
	     			}
	     		}
				
	        };
	        
	        scope.filtersClicked = function(index) {
	        	var event = scope.nlpFilterNames[index] +' Filters Clicked';
	        	Api.gaTrackEvent('(' +scope.categoryName +') ' + scope.currentPage + ' Page', event, event);
	        };
	        
	        scope.showMeThePhones = function() {
	        	Api.gaTrackEvent('(' +scope.categoryName +') ' + scope.currentPage + ' Page', 'Show Me The '+scope.categoryName +' Clicked', 'show Me The '+scope.categoryName +' Clicked');
	        };
	       scope.nlpFilterUpdated = function(index, key) {
	       		if(scope.interNLPSelectedFilters[index].indexOf(key) == -1) {
	       			scope.interNLPSelectedFilters[index].push(key);
	       		} else {
	       			var keyIndex = scope.interNLPSelectedFilters[index].indexOf(key);
	       			if(keyIndex > -1) {
	       				scope.interNLPSelectedFilters[index].splice(keyIndex, 1);
	       			}
	       		}
	       		if(scope.interNLPSelectedFilters[index].length == scope.allFilterItems[index].length)
	       			scope.selectAllFilter[index] = true;
	       		else
	       			scope.selectAllFilter[index] = false;
			};
			
			/*** Done button on filters ***/
			scope.nlpfiltersDoneButtonClicked = function(index) {
				if(scope.interNLPSelectedFilters[index].length == 0 || scope.interNLPSelectedFilters[index].length == scope.allFilterItems[index].length) {
					scope.nplFilterText[index] = 'Any ' + scope.nlpFilterNames[index];
					$rootScope.NLPFilters.filters[index].selectedFilters = new Array();
				} else {
					scope.nplFilterText[index] = scope.interNLPSelectedFilters[index].length + ' ' +scope.nlpFilterNames[index] + (scope.interNLPSelectedFilters[index].length > 1 ? 's':'');
					$rootScope.NLPFilters.filters[index].selectedFilters = angular.copy(scope.interNLPSelectedFilters[index]);
				}
				scope.nlphideAllOverlays();
			};
			
			/*** budgetFilters ***/
	     function setPriceList() {
	     		scope.budgetLowestAmountsList = $rootScope.budgetAmountsList.slice(0, $rootScope.budgetAmountsList.indexOf(scope.higherAmount));
	     		scope.budgetHighestAmountsList = $rootScope.budgetAmountsList.slice($rootScope.budgetAmountsList.indexOf(scope.lowerAmount) + 1, $rootScope.budgetAmountsList.length);
	     	};
	     setPriceList();
	        
	       	scope.updateLowBudgeteValues = function(item){
	       		scope.showlowestPricePanel = false; 
	       		scope.lowerAmount = item;
	       		$rootScope.NLPFilters.PriceMinValue = angular.copy(scope.lowerAmount);
	       		setPriceList();
	       	};
	       	scope.updateHighBudgeteValues = function(item){
	       		scope.showHighestPricePanel = false; 
	       		scope.higherAmount = item; 
	       		$rootScope.NLPFilters.PriceMaxValue = angular.copy(scope.higherAmount); 
	       		setPriceList();
	       	};
	       	
	       	/*** Aspect values ***/
	       	scope.nlpupdateApectValue = function(key, item){
	       		Api.gaTrackEvent('(' +scope.categoryName +') ' + $rootScope.currentPage + ' Page', key+ ' Aspect Selected', item.display);
	       		scope.aspectDisplayName[key] = item.display;
	       		$rootScope.NLPFilters.aspects[key].value = item.value;
	       		$rootScope.NLPFilters.aspects[key].display = item.display;
	       		scope.nlphideAllOverlays();
	       	};
	       	
	       	$(document).ready(function(){
    				$(".displayBtn").click(function(){
        		$(".displayDropDownBody, .displayDropDownTip").toggle();
        		$(".performanceDropDownBody,.performanceDropDownTip,.cameraDropDownBody,.cameraDropDownTip,.batteryDropDownBody,.batteryDropDownTip").hide();
    			});
    				$(".performanceBtn").click(function(){
        		$(".performanceDropDownBody, .performanceDropDownTip").toggle();
        		$(".displayDropDownBody, .displayDropDownTip,.cameraDropDownBody,.cameraDropDownTip,.batteryDropDownBody,.batteryDropDownTip").hide();
    			});
    				$(".cameraBtn").click(function(){
        		$(".cameraDropDownBody, .cameraDropDownTip").toggle();
        		$(".displayDropDownBody, .displayDropDownTip,.performanceDropDownBody,.performanceDropDownTip,.batteryDropDownBody,.batteryDropDownTip").hide();
    			});
    				$(".batteryBtn").click(function(){
        		$(".batteryDropDownBody, .batteryDropDownTip").toggle();
        		$(".displayDropDownBody, .displayDropDownTip,.performanceDropDownBody,.performanceDropDownTip,.cameraDropDownBody,.cameraDropDownTip").hide();
    			});
  			});
		}
	};
}]);
