'use strict';

angular.module('buySmaartApp')
	.directive('popoverPosition', ['$timeout', '$window', function ($timeout, $window) {
		return {
			restrict: 'A',
			scope: {
				triggerPoint: '=triggerPoint'
			},
  			link: function postLink(scope, element, attrs) {
  				
  				var popUpRef = angular.element(element).find(".popover-position-body");
  				var popUpArrowRef = angular.element(element).find(".popover-position-arrow");
  				
  				var reftobody = (attrs.reftobody != null && attrs.reftobody != undefined)? attrs.reftobody : false;
  				var attachdefaultTip = (attrs.attachdefaultTip != null && attrs.attachdefaultTip != undefined)? attrs.attachdefaultTip : true;
  				attachdefaultTip = attachdefaultTip == "false"? false: true;
  				var floorRef =  Math.floor;
				var windowElement = (reftobody)? angular.element(".body") : $window;
				var windowWidth;
				var windowHeight;
  				
  				var popUPHeight;
				var popUPWidth;
				var refContainer = angular.element(element);
				var refContainerOffSet;
				var refContainerTop;
				var refContainerLeft;
				var refContainerHeight;
				var refContainerWidth;
  				
  				var finalPosition = null;
				var finalTop = null;
				var finalLeft = null;
  				
  				scope.updatePosition = function(){
  					if(scope.triggerPoint) {
  						setPosition();
  					}
  				};
				scope.$watch(function(scope) { return scope.triggerPoint}, function(newval, oldval){
					windowWidth = windowElement.innerWidth - 1; //Here 1 is the error threshold
					windowHeight = windowElement.innerHeight - 1; //Here 1 is the error threshold
					$timeout(function() {
				       scope.updatePosition();
				    }, 1);
					
				});
				
				var setPosition = function(){
					popUPWidth = popUpRef.outerWidth();
					popUPHeight = popUpRef.outerHeight();
					refContainerOffSet = refContainer.offset();
					refContainerTop = refContainerOffSet.top - $window.pageYOffset;
					refContainerLeft = refContainerOffSet.left - $window.pageXOffset;
					refContainerHeight = refContainer.outerHeight();
					refContainerWidth = refContainer.outerWidth();
					
					
					
					switch(attrs.popoverPosition.toUpperCase()) {
						case "TOP":
							popUPHeight = popUPHeight + 10; //Here 10 is the icon height
							isTopViolation();
							checkHorizontalPositionForArrow();
						break;
						case "BOTTOM":
							popUPHeight = popUPHeight + 10; //Here 10 is the icon height
							isBottomViolation();
							checkHorizontalPositionForArrow();
						break;
						case "LEFT":
							popUPWidth = popUPWidth + 10; //Here 10 is the icon width
							isLeftViolation();
							checkVerticalPositionForArrow();
						break;
						case "RIGHT":
							popUPWidth = popUPWidth + 10; //Here 10 is the icon width
							isRightViolation();
							checkVerticalPositionForArrow();
						break;
					}
					
					if(!attachdefaultTip)
						finalTop = finalTop - 1;
					
					//setting the final position to popOver
					popUpRef.css({ top: finalTop+"px", left: finalLeft+"px"});
					popUpArrowRef.removeClass("popOver_topArrow popOver_bottomArrow popOver_leftArrow popOver_rightArrow");
					switch(finalPosition) {
						case "TOP":
							var arrowTop = -11;
							var arrowLeft = floorRef(refContainerWidth/2) - 10; // 4 is the half of the width of icon. Full is 9
							if(attachdefaultTip)
								popUpArrowRef.addClass("popOver_topArrow");
						break;
						case "BOTTOM":
							var arrowTop = refContainerHeight - 6;
							var arrowLeft = floorRef(refContainerWidth/2) - 10; // 4 is the half of the width of icon. Full is 9
							if(attachdefaultTip) 
								popUpArrowRef.addClass("popOver_bottomArrow");
						break;
						case "LEFT":
							var arrowTop = floorRef(refContainerHeight/2) - 10; // 4 is the half of the height of icon. Full is 9
							var arrowLeft = -12;
							if(attachdefaultTip)
								popUpArrowRef.addClass("popOver_leftArrow");
						break;
						case "RIGHT":
							var arrowTop = floorRef(refContainerHeight/2) - 10; // 4 is the half of the height of icon. Full is 9
							var arrowLeft = refContainerWidth - 3;
							if(attachdefaultTip)
								popUpArrowRef.addClass("popOver_rightArrow");
						break;
					}
					
					//setting the final position to popOver
					popUpArrowRef.css({top: arrowTop +"px", left: arrowLeft + "px"});
					
				};
				
				
				/**
				 *Setting the possible position of popOver on Horizontal axis
				 */
				var checkHorizontalPositionForArrow = function() {
					if(refContainerLeft + floorRef(refContainerWidth/2) > floorRef(popUPWidth/2)) { //checking whether there is a possible space on left or not
						if(windowWidth - (refContainerLeft + floorRef(refContainerWidth/2)) > floorRef(popUPWidth/2)) { //checking whether there is a possible space on right or not
							// making popOver horizontally middle
							finalLeft = - floorRef(popUPWidth/2 - refContainerWidth/2);
						} else {
							finalLeft = (windowWidth - popUPWidth) - refContainerLeft -20;
						}
					} else {
						finalLeft = -10; // Here 10 is the margin.
					}
				};
				
				/**
				 *Setting the possible position of popOver on Vertical axis 
				 */
				var checkVerticalPositionForArrow = function() {
					if(refContainerTop + floorRef(refContainerHeight/2) > floorRef(popUPHeight/2)) { //checking whether there is a possible space on top or not
						if(windowHeight - (refContainerTop + floorRef(refContainerHeight/2)) > floorRef(popUPHeight/2)) { //checking whether there is a possible space on bottom or not
							// making popOver vertically middle
							finalTop = - floorRef(popUPHeight/2 - refContainerHeight/2);
						} else {
							finalTop = (windowHeight - popUPHeight) - refContainerTop - 20;
						}
					} else {
						finalTop = -10; // Here 10 is the margin.
					}
				};
				
				
				/**
				 *verifying  whether popover is possible to fit at the top for the refContainerDiv or not 
				 */
				var isTopViolation = function() {
					if(refContainerTop < popUPHeight) {
						finalPosition = "BOTTOM";
						finalTop = refContainerHeight + 10;
					} else {
						finalPosition = "TOP";
						finalTop = - popUPHeight;
					}
				};
				
				/**
				 *verifying  whether popover is possible to fit at the bottom for the refContainerDiv or not 
				 */
				var isBottomViolation = function() {
					if(windowHeight - (refContainerTop + refContainerHeight) < popUPHeight) {
						finalPosition = "TOP";
						finalTop = - popUPHeight;
					} else {
						finalPosition = "BOTTOM";
						finalTop = refContainerHeight + 10;
					}
				};
				
				/**
				 *verifying  whether popover is possible to fit at the left for the refContainerDiv or not 
				 */
				var isLeftViolation = function() {
					if(refContainerLeft < popUPWidth) {
						finalPosition = "RIGHT";
						finalLeft = refContainerWidth + 10;
					} else {
						finalPosition = "LEFT";
						finalLeft = - popUPWidth;
					}
				};
				
				
				/**
				 *verifying  whether popover is possible to fit at the Right for the refContainerDiv or not 
				 */
				var isRightViolation = function() {
					if(windowWidth - (refContainerLeft + refContainerWidth) < popUPWidth) {
						finalPosition = "LEFT";
						finalLeft = - popUPWidth;
					} else {
						finalPosition = "RIGHT";
						finalLeft = refContainerWidth + 10;
					}
				};
				
  			}
    	};
  	}
]);