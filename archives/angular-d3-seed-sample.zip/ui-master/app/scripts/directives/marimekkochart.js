'use strict';

angular.module('buySmaartApp')
  .directive('marimekkoChart', function () {
    return {
      restrict: 'E',
      link: function postLink(scope, element, attrs) {
        var data,margin = {top: 0, right: 0, bottom: 0, left: 0},
        width = element.parent().width() - margin.left - margin.right,
        height = element.parent().height() - margin.top - margin.bottom,
        color = {"positive":"#e1ffef","neutral":"#fff8d8","negative":"#ffeaea"},
        n = d3.format("f")
        var iterator = 0
        var svg = d3.select(element[0]).append("svg")
                    .attr("width", width)
                    .attr("height", height)
                    .append("g")
                    .attr("transform", "translate(" + margin.left + "," + margin.top + ")")
        var nest = d3.nest()
                    .key(function(d) { return d.nodeOrientation; })
                    .key(function(d) { return d.treemap; });


        function chart(selection) {
                  var treemap = d3.layout.treemap()
                          .round(true)
                          .mode("slice-dice")
                          .value(function(d){
                            return d.value;
                          })
                          .size([width, height])
                          .children(function(d) {
                            return d.values;
                          })
                          .sort(function(b,a){
                            return b.value-a.value
                          });
                  iterator++;
                  selection.each(function() {
                    var cell = d3.select(this).selectAll("g.cell")
                        .data(treemap.nodes);

                    var cellEnter = cell.enter().append("g")
                        .attr("class", "cell")
                        .attr("transform", function(d) {
                          return "translate(" + d.x + "," + d.y + ")";
                        })
                        .on("click",function(node){
                          scope.getNodeReviews.call(this, node);
                        })
                    cellEnter.append("rect")
                        .style("fill", function(d) {
                          return color[d.sentimentType];
                        })
                        .attr("class","TreemapNodes")

                    cellEnter.append("text")
                      .text(function(d){
                        return d.treemap+"("+n(d.value)+")";
                      })
                      .attr("transform", function(d) {
                        return "translate(30,"+d.dy/2 + ")";
                      });

                    cell
                    .attr("transform", function(d) {
                      var _x = Math.min(d.x, width/2 );
                      // return "translate(" + d.x + "," + d.y + ")";
                      return "translate(" + _x + "," + d.y + ")";
                    })
                    .select("rect")
                      .style("fill", function(d) {
                        return color[d.sentimentType];
                      })
                      .attr("width", function(d) {
                        // return d.dx;
                        return Math.floor(width/2)
                      })
                      .attr("height", function(d) {
                        if(d.treemap) {
                          return Math.max( 30, d.dy );
                        } else {
                          return 0;
                        }
                        // return d.dy;
                      })
                    cell.select('text')
                      .text(function(d){
                        if(d.treemap) {
                          return d.treemap+"("+n(d.value)+")";
                        } else {
                          return "";
                        }
                      })
                      .attr("transform", function(d) {
                        return "translate(30,"+d.dy/2 + ")";
                      });
                    cell.exit().remove()

                });
        }
        scope.$watch("SmaartPulseData",function(oldValue,newValue){
            data = scope.SmaartPulseData
            if(data){
                angular.forEach(data,function(d,index){
                    if(index%2==0)
                      d.nodeOrientation = "left"
                    else
                      d.nodeOrientation = "right"
                  })
                svg.datum({values: nest.entries(data)})
                    .call(chart);

                 // chart func end
            } //if(data) end
        }) //watch end
    }//link func end
    };
  });
