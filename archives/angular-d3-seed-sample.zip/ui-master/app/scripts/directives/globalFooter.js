'use strict';

angular.module('buySmaartApp').directive('globalFooter', [function() {
	return {
		templateUrl : 'views/footer2.html',
		restrict : 'E',
		link : function postLink(scope, element, attrs) {
      scope.pressReleases = [
        {
          "url": "http://startuphyderabad.com/heart-heart-chat-buysmaarts-giri-devanathan",
          "imageUrl": "/images/ignore/startup-hyderabad-logo.png",
          "title": "Startup Hyderabad"
        },
        {
          "url": "http://www.btvin.com/videos/watch/15656/the-science-behind-buying-a-phone",
          "imageUrl": "/images/ignore/bloomberg-logo.png",
          "title": "Bloomberg",
        },
        {
          "url": "http://www.thehindubusinessline.com/info-tech/mobiles-tablets/enixta-launches-new-portal-for-buying-phones/article7176022.ece",
          "imageUrl": "/images/ignore/logo01.png",
          "title": "Business Line"
        },
        {
          "url": "http://yourstory.com/2015/05/buysmaart-com-artificial-intelligence/",
          "imageUrl": "/images/ignore/logo02.png",
          "title": "Your Story"
        },
        {
          "url": "https://www.techinasia.com/startup-artificial-intelligence-buy-phone/",
          "imageUrl": "/images/ignore/logo03.png",
          "title": "Tech in Asia"
        },
        {
          "url": "http://www.business-standard.com/article/companies/enixta-launches-online-product-discovery-platform-buysmaart-com-115050600524_1.html",
          "imageUrl": "/images/ignore/logo04.png",
          "title": "Business Standard"
        },
        {
          "url": "http://www.telegraphindia.com/external/display.jsp?id=43655&mode=details",
          "imageUrl": "/images/ignore/logo05.png",
          "title": "The Telegraph"
        }
      ]
		}
	};
}]);
