'use strict';

angular.module('buySmaartApp').directive('globalSteps', [function() {
	return {
		templateUrl : 'views/globalSteps.html',
		restrict : 'E',
		link : function postLink(scope, element, attrs) {
		}
	};
}]);
