'use strict';

angular.module('buySmaartApp').directive('searchResults', ["$rootScope","$location", "Meta", function($rootScope, $location, Meta) {
	return {
		templateUrl : 'views/searchResults.html',
		restrict : 'E',
		replace: true,
		link : function postLink(scope, element, attrs) {
			scope.defaultImageURL = _.template('/images/ignore/${categoryName}_default.jpg')({
				"categoryName": Meta.getCategoryName()
			});
			scope.SwitchToProductView = function($item){
				var categoryName, displayName, url;
				categoryName = Meta.getCategoryName();
				displayName = scope.safeEscapeDisplayName($item.displayName);
				url = "/"+categoryName+"/productdetails/"+$item.id+"/"+ $item.brand+ "-" + displayName ;
				url = encodeURI( url );
				$location.url(url);
				ga('send', 'event','(' +categoryName +')', ' Search Button Clicked' , 'Selected (' +$item.brand +') '+$item.displayName);
			};
		}
	};
}]);
