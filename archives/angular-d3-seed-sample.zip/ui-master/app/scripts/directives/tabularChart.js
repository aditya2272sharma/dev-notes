'use strict';

angular.module('buySmaartApp')
  .directive('tabularChart', function () {
    return {
      restrict: 'E',
      link: function postLink(scope, element, attrs) {
        var
          data,
          margin = {
            top: 0,
            right: 0,
            bottom: 0,
            left: 0
          },
          width = element.parent().width() - margin.left - margin.right,
          height = element.parent().height() - margin.top - margin.bottom,
          borderThickness = 2,
          borderColor = "#FFF",
          margin = 0,
          fontSize = 15,
          color = {
            "positive": "#e1ffef",
            "neutral": "#fff8d8",
            "negative": "#ffeaea"
          },
          highlight = {
            "positive": "#67D299",
            "neutral": "#E6CB4E",
            "negative": "#C77878"
          },
          transformX = {
            "positive": 0,
            "negative": (width/2),
          },
          n = d3.format("f"),
          iterator = {
            "positive": 0,
            "negative": 0
          },
          count = {
            "positive": 0,
            "negative": 0
          },
          cellHeight = {
            "positive": 0,
            "negative": 0
          },
          svg = null,
          cellEnter = null,
          cellUpdateSelection = null
          ;

        svg = d3.select(element[0])
        .append("svg")
        .attr("width", width)
        .attr("height", height);

        function chart() {
          svg.selectAll("*").remove();
          var count = {
            "positive": _.filter(data, { "sentimentType": "positive" }).length,
            "negative": _.filter(data, { "sentimentType": "negative" }).length,
          }
          
          var dataLength = Math.max(count.positive, count.negative);
          var unitCellHeight = (height/dataLength);
          cellHeight.positive = (height/count.positive);
          cellHeight.negative = (height/count.negative);

          var unitCellWidth;
          if(count.positive == 0 || count.negative == 0){
            unitCellWidth = (width) - (borderThickness + margin);
            if(count.positive == 0){
              transformX["negative"] = 0;
            }
          } else {
            unitCellWidth = (width/2) - (borderThickness + margin);
            transformX["negative"] = width/2;
          }
          
          // console.log( arguments );

          cellUpdateSelection = svg.selectAll("g").data( data ); //update selection is preserved for exit() calls
          cellEnter = cellUpdateSelection.enter().append("g").attr("class", "cell");

          iterator = {
            "positive": 0,
            "negative": 0
          };
          cellEnter
            .append("rect")
            .attr("height", unitCellHeight)
            .attr("height", function(d){
              return cellHeight[d.sentimentType];
            })
            .attr("width", unitCellWidth)
            .style("fill", function(d) {
              return color[d.sentimentType];
            })
            .style("stroke", borderColor)
            .style("stroke-width", borderThickness)
            .style("cursor", "pointer")
            .attr("transform", function(d) {
              
              var X = transformX[d.sentimentType];
              var Y = cellHeight[d.sentimentType] * iterator[d.sentimentType];
              Y = Y + (borderThickness + margin);
              var translate = "translate(" + X + "," + Y + ")";
              
              iterator[d.sentimentType]++;
              return translate;
            })
            .on("click", _rectClickHandler);


            iterator = {
              "positive": 0,
              "negative": 0
            };
            cellEnter
              .append("text")
              .attr("font-family", "proxima-nova, sans-serif;")
              .attr("font-size", fontSize + "px")
              .attr("color", "#3D3D3D")
              .text(function(d){ 
                // console.log( d );
                return d.treemap + "("+n(d.value)+")"; // do not use html(), safari 8.0 doesn't allow invalid markup insertion using html()
              })
              .on("click", function(d) {
                var rect = $(this).parent().find("rect")[0];
                _rectClickHandler.call(rect, d);
              })
              .attr("transform", function(d) {
                var rect = this.getBoundingClientRect();
                var X = transformX[d.sentimentType];
                var Y = cellHeight[d.sentimentType] * iterator[d.sentimentType];
                X = X + (unitCellWidth/2) - (rect.width/2);
                Y = Y + (cellHeight[d.sentimentType] + fontSize + margin + borderThickness)/2 - 2; //2px adjustment
                var translate = "translate(" + X + "," + Y + ")";
                
                iterator[d.sentimentType]++;
                return translate;
              })
              .append("span")
              .attr("class", "human")
            ;

            cellUpdateSelection.exit().remove();

            function _rectClickHandler( d ) {
              var THIS = this;
              (function(rect){
                d3.select(rect)
                .transition()
                .style("fill", highlight[d.sentimentType])
                .duration(500);

                //ref: http://blog.visual.ly/creating-animations-and-transitions-with-d3-js/

                setTimeout(function(){ 
                  d3.select(rect)
                  .transition()
                  .duration(500)
                  .delay(500)
                  .style("fill", color[d.sentimentType]);
                }, 2000);
              })(THIS)
              scope.getNodeReviews.call(this, d);
            }
        }


        scope.$watch("tabularChartData",function(oldValue,newValue){
            if(scope.tabularChartData){

              // it's pointless to have this code here but it serves as a reminder that,
              // we have a 'sentimentType' called "neutral" too
              // if(data.neutral && data.neutral.length>0){
              //   angular.forEach(data.neutral,function(d,index){
              //     return (d.sentimentType == "neutral") && (d.sentimentType = "positive");
              //   });
              // }

              
              data = _.groupBy(scope.tabularChartData,"sentimentType");
              //limiting the max no. of sorted-clusters to 9 on each side
              data.positive = _.sortBy(data.positive,function(item){
                return item.value;
              }).reverse().slice(0, 9);
              data.negative = _.sortBy(data.negative,function(item){
                return item.value;
              }).reverse().slice(0, 9);              
              
              data = [].concat.call( data.positive, data.negative );
              svg.datum({
                values: data
              })
              .call(chart);
             // chart func end
            } //if(data) end
        }) //watch end
      }//link func end
    };
  });
