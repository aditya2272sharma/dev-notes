'use strict';

angular.module('buySmaartApp').directive('stickCompare', ['$rootScope',function($rootScope) {
	return {
		templateUrl : 'views/StickyCompare.html',
		restrict : 'E',
		link : function postLink(scope, element, attrs) {
			scope.removeCompareItem = function(index) {
	        	$rootScope.compareItems.splice(index, 1);        
			};
		}
	};
}]);
