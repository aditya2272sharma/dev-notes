'use strict';

angular.module('buySmaartApp').directive('hideuponOnechild', ['$timeout', function($timeout) {
	return {
		restrict : 'A',
		link : function postLink(scope, element, attrs) {
			$timeout(function() {
			if(element.children().length == 1){
				element.hide();
			}
			}, 2);
		}
	};
}]);
