'use strict';

angular
.module('buySmaartApp')
.directive('promotionalBanner', [
  '$compile',
function($compile) {
  return {
    templateUrl: "views/promotionalBanner.html",
    link: function( $scope, element, attr ){

    }
  }
}])