'use strict';

angular.module('buySmaartApp').directive('pricePopup', [function() {
	return {
		templateUrl : 'views/PricePopUp.html',
		restrict : 'E',
		link : function postLink(scope, element, attrs) {
		}
	};
}]);
