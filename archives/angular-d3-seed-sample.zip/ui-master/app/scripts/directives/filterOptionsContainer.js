'use strict';

angular
.module('buySmaartApp')
.directive('filterOptionsContainer', [
  '$compile',
  '$filter',
function($compile, $filter) {
  return {
    restrict: 'E',
    scope: {
      "showfilters": "=",
      "filters": "=",
      "filterindex": "=",
      "cols": "=",
      "interNLPSelectedFilters": "=internlpselectedfilters",
      "nlpFilterUpdated": "&nlpfilterupdated",
      "nlpfilterupdated": "&",
      "done": "&",
      "width": "=",
      "displayName": "="
    },
    templateUrl: "views/filterOptionsContainer.html",
    link: function( $scope, element, attr ){
      // var filters = $scope.allFilterItems[0];
      // $scope.cols = 5;
      var filters = $scope.filters;
      $scope.filters =  $filter('objectToArray')( _.groupBy(filters, 'filterLevel') );
      $scope.listItemWidth = ($scope.width / $scope.cols) - 7;

      var columnItems0 = getItems( $scope.filters[0] );
      var columnItems1 = getItems( $scope.filters[1] );
      // var columnItems = [];
      // columnItems.push( columnItems0 );
      // columnItems.push( columnItems1 );
      $scope.columnItems0 = columnItems0;
      $scope.columnItems1 = columnItems1;

      function getItems (filters, size ){
        if(!filters) {
          return [];
        }
        var csize = Math.round( filters.length / $scope.cols );
        var arr = [];
        var pos = -1;

        _.each(filters, function(item, i){
          if(i % csize == 0){
            pos++;
            arr[pos] = [];
          }
          arr[pos].push( item );
        });

        return arr;
      }

      var flag0 = true, flag1 = true;
      $scope.className0 = flag0? "checked" : "";
      $scope.className1 = flag1? "checked" : "";
      $scope.selectAllFilter0 = function(){
        flag0 = !flag0;
        $scope.className0 = flag0? "checked" : "";
        _.each( $scope.filters[0], function( item ){
          var i = $scope.interNLPSelectedFilters.indexOf(item.itemId);
          if ( i != -1 ){
            $scope.interNLPSelectedFilters.splice(i, 1);
          }
        });
        if (!flag0) {
          return;
        }
        _.each( $scope.filters[0], function( item ){
          if($scope.interNLPSelectedFilters.indexOf(item.itemId) == -1){
            $scope.interNLPSelectedFilters.push(item.itemId);
          }
        });
      }
      $scope.selectAllFilter1 = function(){
        flag1 = !flag1;
        $scope.className1 = flag1? "checked" : "";
        _.each( $scope.filters[1], function( item ){
            var i = $scope.interNLPSelectedFilters.indexOf(item.itemId);
            if ( i != -1 ){
              $scope.interNLPSelectedFilters.splice(i, 1);
            }
          });
        if (!flag1) {
          return;
        }
        _.each( $scope.filters[1], function( item ){
          if($scope.interNLPSelectedFilters.indexOf(item.itemId) == -1){
            $scope.interNLPSelectedFilters.push(item.itemId);
          }
        });
      }

      $scope.filterUpdate0 = function(filterIndex, itemId){
        flag0 = false;
        $scope.className0 = "";
        $scope.nlpfilterupdated({'0': filterIndex, 'itemId': itemId});
      }

      $scope.filterUpdate1 = function(filterIndex, itemId){
        flag1 = false;
        $scope.className1 = "";
        $scope.nlpfilterupdated({'0': filterIndex, 'itemId': itemId});
      }

    }
  }
}]);