'use strict';

angular.module('buySmaartApp').directive('globalHeader', ['$rootScope', '$location', '$route', 'Api', 'NLPFilterServices', 'Meta', '$filter', function($rootScope, $location, route, Api, NLPFilterServices, Meta, $filter) {
	return {
		templateUrl : 'views/globalheader.html',
		restrict : 'E',
		link : function postLink(scope, element, attrs) {
			if($rootScope.topBrands !== undefined)
				scope.topBrands = $rootScope.topBrands;
			if($rootScope.config !== undefined) {
	        	scope.priceRange = $rootScope.config.seoMetadataMap['price'];
	        	scope.topSearches = $rootScope.config.seoMetadataMap['top_searches'];
	        	scope.dashboardSearches = $rootScope.config.seoMetadataMap['dashboard'];
	        }
	        if($rootScope.compareList !== undefined)
	        	scope.compareList = $rootScope.compareList;
	        if($rootScope.genreMetadata != undefined)
	        	scope.genreMetadata = $rootScope.genreMetadata;
	        	scope.categoryName = Meta.getCategoryName();

		    if(scope.aspects === undefined && scope.selectedFilter == undefined && 
		    	$rootScope.NLPFilters.filters !== undefined && $rootScope.NLPFilters.aspects !== undefined)
		    	nlpsendInitialCalls();
		    var eventCategoryName = '(' +scope.categoryName +') ' + $rootScope.currentPage + ' Page';
		    scope.TopBrandsClicked = function(value){
		    	Api.gaTrackEvent(eventCategoryName, ' Top Brands Clicked' , value.brand);
		    	var win = window.open(value.href,'_self');
          win.focus();
		    }
		    scope.NewArrivalsClicked = function(value){
		    	Api.gaTrackEvent(eventCategoryName, ' New Arrivals Clicked' , value.displayName);
		    	var win = window.open(scope.categoryName+'/productdetails/'+value.productId+'/'+$rootScope.safeEscapeDisplayName(value.displayName), '_self');
      win.focus();
		    }
		    scope.TopSearches = function(value){
		    	Api.gaTrackEvent(eventCategoryName, ' Top Searches Clicked' , value.dispName);
		    	var win = window.open(value.href,'_self');
          win.focus();
		    }
		    scope.PopularComparisionsClicked = function(value){
		    	Api.gaTrackEvent(eventCategoryName, ' Popular Comparisions Clicked' , value.productName +' -vs- '+ value.associatedProductName);
		    }
		    scope.PriceRangeClicked = function(value){
		    	Api.gaTrackEvent(eventCategoryName, ' Price Range Clicked' , value.minPrice +' To '+ value.maxPrice);
		    	var win = window.open(value.href,'_self');
          win.focus();
		    }
		    scope.SellProductClicked = function(){
		    	Api.gaTrackEvent(eventCategoryName, 'Sell Your Product Clicked' , 'Sell Your Product Clicked');
		    }
		    scope.footerLinkClicked = function(value,url){
		    	Api.gaTrackEvent(eventCategoryName, ' Footer Link Clicked' , value);
		    	var win = window.open(url, '_self');
			    win.focus();
		    }

			function nlpsendInitialCalls(){
				// var response = scope.config;
           		// scope.aspects = response.aspects;
           		scope.categoryName = Meta.getCategoryName();
           		scope.showFilterList = new Array();
           		scope.showAspectList = new Array();
           		scope.nlpFilters = new Array();
           		scope.selectAllFilter = [];
           		scope.nlpFilterNames = new Array();
           		scope.allFilterItems = new Array();
           		scope.nplFilterText = new Array();
           		scope.interNLPSelectedFilters = [];
           		scope.GLOBAL_filters = _.filter( $rootScope.NLPFilters.filters, {
           			"filterLocation": "GLOBAL"
           		});
           		scope.LISTING_filters = _.filter( $rootScope.NLPFilters.filters, {
           			"filterLocation": "LISTING"
           		});
           		for(var i = 0, iLen = scope.GLOBAL_filters.length; i < iLen; i++){
           			scope.nlpFilterNames[i] = scope.GLOBAL_filters[i].filterId;
	        		var filterItems = new Array();
	        		var allItems = scope.GLOBAL_filters[i].allFilters;
	        		scope.allFilterItems[i] = allItems;
	        		for(var j=0;j<allItems.length;j++) {
	        			filterItems.push(allItems[j].itemId);
	        		}
	        		scope.nlpFilters[i] = filterItems;
	        		if(filterItems.length == 0 || filterItems.length == allItems.length) {
	        			scope.nplFilterText[i] = 'Any ' + scope.nlpFilterNames[i];
	        			scope.selectAllFilter[i] = true;
	        			scope.interNLPSelectedFilters[i] = [];
	        			for(var j in allItems) {
	        				scope.interNLPSelectedFilters[i].push(allItems[j].itemId);
	        			}
	        		}
	        		scope.showFilterList[i] = false;
            	}
	            scope.aspects = [];
	            scope.aspectDisplayName = {};
  				for (var key in $rootScope.NLPFilters.aspects) {
  					var aspect = {};
  					scope.showAspectList[key] = false;
  					aspect.aspectId = key;
  					aspect.displayName = key;
  					aspect.display = $rootScope.NLPFilters.aspects[key].display;
  					aspect.value = $rootScope.NLPFilters.aspects[key].value;
  					scope.aspects[scope.aspects.length] = aspect;
  					scope.aspectDisplayName[key] = $rootScope.NLPFilters.aspects[key].display;
	  			}
	     	}

			scope.openSeoSearch = function(seoMetadata) {
		      $rootScope.NLPFilters.PriceMinValue = seoMetadata.minPrice;
		      $rootScope.NLPFilters.PriceMaxValue = seoMetadata.maxPrice;
		      for(var i in $rootScope.NLPFilters.filters) {
		        $rootScope.NLPFilters.filters[i].selectedFilters = [];
		        if($rootScope.NLPFilters.filters[i].metadataId == seoMetadata.categoryMetadataId) {
		          $rootScope.NLPFilters.filters[i].selectedFilters.push(seoMetadata.filter);
		        }
		      }
		      for(var i in $rootScope.NLPFilters.aspects) {
		        $rootScope.NLPFilters.aspects[i].value = seoMetadata['colVal'+$rootScope.NLPFilters.aspects[i].metadataId];
		      }
		      $rootScope.NLPFilters.allProducts = false;
		      $location.url("/"+scope.categoryName+"/DiscoveryDashboard/"+seoMetadata.id+'/'+seoMetadata.id);
		    }

		    scope.searchWithGenre = function(genreData) {
				for(var i in $rootScope.NLPFilters.aspects) {
					$rootScope.NLPFilters.aspects[i].value = genreData['metadataVal'+$rootScope.NLPFilters.aspects[i].metadataId];
				}
				$rootScope.NLPFilters.allProducts = false;
          		scope.openDashboardPage();
        	}

		    scope.showModelsWithFilters = function(index, filter) {

	          for(var i in $rootScope.NLPFilters.aspects) {
	            $rootScope.NLPFilters.aspects[i].value = 3;
	          }
		      for(var i in $rootScope.NLPFilters.filters) {
		        $rootScope.NLPFilters.filters[i].selectedFilters = [];
		      }
		      $rootScope.NLPFilters.filters[index].selectedFilters.push(filter);
		      $rootScope.NLPFilters.allProducts = false;
		      $rootScope.openDashboardPage();
		    }

			function getProductDetails() {
			    var params = {};
			    params.aspectMetadata = {};
			    var aspects = $rootScope.config.aspects;
			    for (var k in aspects){
			        if(k != 'undefined') {
			            params.aspectMetadata[aspects[k].aspectId] = {};
			            params.aspectMetadata[aspects[k].aspectId].value = 3;
			            params.aspectMetadata[aspects[k].aspectId].metadataId = aspects[k].metadataId;
			        }
			    }
			    return params;
			}

	      function updatedPopularBrands() {
	        var domainId = $rootScope.NLPFilters.domainId;
	        var categoryId = _.get( $rootScope, 'categoryId', 1);
	        scope.categoryName = Meta.getCategoryName();
	        scope.categories = angular.copy( $rootScope.categories );
	        scope.genreMetadata = _.map(scope.config.genreMetadata, function(data){
	          return _.extend(data, {
	            "href": NLPFilterServices.searchWithGenre("/"+scope.categoryName+"/DiscoveryDashboard/",  data) //added href property to all values in genreMetadata collection
	          });
	        });
	        $rootScope.genreMetadata = scope.genreMetadata;
		    Api.fetchNewArrivals(domainId, categoryId, getProductDetails()).then(function(newArrivals){
            _.each(newArrivals, function(item, index){
              var validURL = false;
              var categoryName = Meta.getCategoryName();
              var defaultURL = '/images/ignore/'+ categoryName +'_default.jpg';

              validURL = $filter('validateNgsrc')(item.primaryImage);
              item.primaryImage = validURL ? item.primaryImage : defaultURL;
            });
		        scope.newArrivalsALL = newArrivals;
		        scope.newArrivals = newArrivals.slice(0,2);
          		$rootScope.newArrivals = newArrivals;
		    });
		    var filterMetadataStr = Meta.getFilterMetadataStr();
	        Api.getPopularBrand(domainId,categoryId, filterMetadataStr).then(function(response) {
	            var filterMetadataIdMap = Meta.getFilterMetadataIdMap();
	            var metadataIdMap = _.pluck(filterMetadataIdMap, 'metadataId');
	            var topBrandsIndex = metadataIdMap[0];
	            var topOSIndex = metadataIdMap[1];
	            scope.topBrands = _.map(response.filterDetailMap[ topBrandsIndex ], function(prod){
	              return _.extend(prod, {
	                "href": NLPFilterServices.showModelsWithFilters("/"+scope.categoryName+"/DiscoveryDashboard/", 0, prod.brand) //added href property to all values in topBrands
	              });
	            });
	            scope.topOSs = _.map(response.filterDetailMap[ topOSIndex ], function(prod){
	              return _.extend(prod, {
	                "href": NLPFilterServices.showModelsWithFilters("/"+scope.categoryName+"/DiscoveryDashboard/", 1, prod.brand) //added href property to all values in topOSs collection
	              });
	            });
	            $rootScope.topBrands = scope.topBrands;
	            $rootScope.topOSs = scope.topOSs;
	            var fallBackFilterDisplayName1 = _.get($rootScope, 'config.filters[0].displayName', 'Brand');
	            var fallBackFilterDisplayName2 = _.get($rootScope, 'config.filters[1].displayName', 'Os');
	            scope.filterDisplayName1 = $filter('uppercase')( _.get($rootScope, 'NLPFilters.filters[0].filterId', fallBackFilterDisplayName1) );
	            scope.filterDisplayName2 = $filter('uppercase')( _.get($rootScope, 'NLPFilters.filters[1].filterId', fallBackFilterDisplayName2) );
	        });
	        Api.fetchPopularComparisons(domainId, categoryId).then(function(comparisons){
              _.each(comparisons, function(item, index){
                var validURL = false;
                var categoryName = Meta.getCategoryName();
                var defaultURL = '/images/ignore/'+ categoryName +'_default.jpg';

                validURL = $filter('validateNgsrc')(item.productImage);
                item.productImage = validURL ? item.productImage : defaultURL;

                validURL = $filter('validateNgsrc')(item.associatedProductImage);
                item.associatedProductImage = validURL ? item.associatedProductImage : defaultURL;
              });
	            scope.compareListAll = comparisons;
	            scope.compareList = comparisons.slice(0,2);
	            $rootScope.compareList = comparisons;
	        });
	        Api.fetchConfigarations("smartphone", categoryId).then(function(config) {
	          $rootScope.config = config;
	          $rootScope.NLPFilters.domainId = config.domainId;
	          $rootScope.categoryId = categoryId;
	          updateSeoMetadata()
	        });
	      }

	      function updateSeoMetadata() {
	        scope.priceRange = $rootScope.config.seoMetadataMap['price'];
	        scope.priceRange = _.map(scope.priceRange, function(data) {
	        	return _.extend(data, {
	        		"href" : NLPFilterServices.openSeoSearch("/"+scope.categoryName+"/DiscoveryDashboard/", data)
	        	});
	        });
	        $rootScope.priceRange = scope.priceRange;
	        scope.topSearches = $rootScope.config.seoMetadataMap['top_searches'];
	        scope.topSearches = _.map(scope.topSearches, function(data) {
	        	return _.extend(data, {
	        		"href" : NLPFilterServices.openSeoSearch("/"+scope.categoryName+"/DiscoveryDashboard/", data)
	        	});
	        });
	        $rootScope.topSearches = scope.topSearches;
	        scope.dashboardSearches = $rootScope.config.seoMetadataMap['dashboard'];
	        scope.dashboardSearches = _.map(scope.dashboardSearches, function(data) {
	        	return _.extend(data, {
	        		"href" : NLPFilterServices.openSeoSearch("/"+scope.categoryName+"/DiscoveryDashboard/", data),
	        		"dispText" : data.dispName.substring(data.dispName.indexOf(" "))
	        	});
	        });
	        $rootScope.dashboardSearches = scope.dashboardSearches;
	      }

		  $rootScope.$on("categoryConfigUpdated",updatedPopularBrands);
	      if($rootScope.isConfigAvaliable){
	        updatedPopularBrands();
	      }

			function sendInitialCalls(){
				if(scope.isConfigAvaliable) {
					var domainId = $rootScope.NLPFilters.domainId;
					updatedPopularBrands();
					var categoryId = _.get( $rootScope, "categoryId", 1 );
				    Api.fetchPopularComparisons(domainId, categoryId).then(function(comparisons){
				        scope.compareListAll = comparisons;
				        scope.compareList = comparisons.slice(0,2);
				        $rootScope.compareList = comparisons;
				    });
				}
			};
	     	$rootScope.$on("configUpdated",sendInitialCalls);

      //hover dropdown
      $(function(){
        $('.dropdown').hover(function() {
            $(this).addClass('open');
          },
          function() {
            $(this).removeClass('open');
          });
        $(document).on("_reglobe_widget_loaded",_sampleBind);
        _sampleBind();
        function _sampleBind(){
          $(".logobox").click(function(e){
            e.preventDefault();
            $.reglobew.showPopup("128001","Unique Product Id","Unique Category Id");
            return false;
          });
        }
      });
		}


	};
}]);
