'use strict';

angular
.module('buySmaartApp')
.directive('brandsFilterContainer', ['$compile', '$rootScope', function($compile, $rootScope) {
  return {
    restrict: 'E',
    scope: true,
    templateUrl: "views/brandsFilterContainer.html",
    link: function($scope, element, attrs) {
      
      $rootScope.$on("categoryConfigUpdated", Initialize);


      function Initialize(){
        var allFilterItemsLength = _.get($scope, 'selectedFilter[0].allFilters.length', 5);
        $scope.columnLimit = Math.ceil(allFilterItemsLength/5);
      };
      Initialize();
    }
  }
}]);