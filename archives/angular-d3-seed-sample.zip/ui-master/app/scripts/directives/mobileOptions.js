'use strict';

angular.module('buySmaartApp').directive('mobileOptions', ['Api', '$location', '$timeout', '$rootScope', 'Meta',
	function(Api, $location, $timeout, $rootScope, Meta) {
	return {
		templateUrl : 'views/mobileOptions.html',
		restrict : 'E',
		link : function postLink(scope, element, attrs) {
			var oldFilters = angular.copy($rootScope.NLPFilters);
			scope.searchSuggestions = [];
      scope.defaultImageURL = _.template('/images/ignore/${categoryName}_default.jpg')({
        "categoryName": Meta.getCategoryName()
      });
			scope.updateSearchResults= function(newValue){
				var categoryId = Meta.getCategoryID();
		        if(newValue && newValue != ""){
		            Api.fetchAutocompleteDetails(newValue, categoryId).then(function(response){
            			for(var i = 0, iLen = response.length; i < iLen; i++){
            				var splitedString = response[i].displayName.split(" ");
		            		response[i].brand = splitedString[0];
		            		response[i].displayName = splitedString[1];
		            		for(var j = 2, jLen = splitedString.length; j < jLen; j++){
		            			response[i].displayName = response[i].displayName + " " + splitedString[j];
		            		}
		            	}
		                scope.searchSuggestions = response;
		                $timeout(function() {
			  				angular.element(".results_holder").animate({
								height : 141
							}, "slow");
			  			}, 2);
		               
		            });
		        } else {
		        	angular.element(".results_holder").animate({
						height : 0
					}, "fast");
					scope.searchSuggestions = [];
		        }
		    };
		    scope.SwitchToProductView = function($item){
		    	var categoryName = Meta.getCategoryName();
          var url = "/"+categoryName+"/productdetails/"+$item.id+"/"+ $item.brand+ "-" +scope.safeEscapeDisplayName($item.displayName);
          url = encodeURI( url );
	        $location.url(url);
	    	};
	    	
	    	// div is some selected element
	    		
	    		var div = angular.element(".priceMaxField, .priceMinField, .mobileSearchField");
                var f = function(event) {
                    $timeout(function() { // angular way, setTimeout is OK
                        event.target.focus();
                        event.preventDefault();
                    });
                };
                var mobile = false;
                div.on('click', function(event) {
                    if(mobile) return;
                    f(event);
                });

                div.on('touchstart', function(event) {
                    mobile = true;
                    f(event);
                });

                div.on('touchend', function(event) {
                    event.preventDefault();
                    event.stopPropagation();
                });
				scope.closeSortPopUP = function(event){
					if(!angular.element(event.target).parents('.sortBody').length && !angular.element(event.target).hasClass('sortBody')){
						scope.showSortPopOver = ! scope.showSortPopOver;
						scope.showFiltersPopOver = false;
						scope.showSearchTip = false;
						$(".filtersBody, .filtersTip").css({'visibility': 'hidden'});
					}
				};
	    	scope.closeNLPFiltersPopUP = function(event){
            if(!angular.element(event.target).parents('.modifySearchHolderNLP').length && !angular.element(event.target).hasClass('modifySearchHolderNLP')){
                scope.showMobileModifySearchPopup = ! scope.showMobileModifySearchPopup;
                scope.showSearchTip = false;
            }
        };
		    scope.closeSearchPopUP = function(event){
		            if(! angular.element(event.target).parents('.searchBody').length && !angular.element(event.target).hasClass('searchBody')){
		                scope.showSearchTip = ! scope.showSearchTip;
		                scope.showMobileModifySearchPopup = false;
		                scope.showFiltersPopOver = false;
		                scope.showSortPopOver = false;
		                $(".filtersBody, .filtersTip").css({'visibility': 'hidden'});
		            }
		        };
		     $(".filters320").click(function(){
            $(".filtersBody, .filtersTip").css({'visibility': 'visible'});
            scope.showSortPopOver = false;
            scope.showSearchTip = false;
         });
         $(".header-section, .content_wrapper").click(function(){
            $(".filtersBody, .filtersTip").css({'visibility': 'hidden'});
            scope.showSearchTip = false;
         });
         $('.smartview_mobile_options .filters320').click(function(){
         	$(".filtersBody, .filtersTip").toggle();
         });
         
	    	var bodyClick = function(){
				$('body').bind('click', function(event) {
					if(!angular.element(event.target).parents('.searchby320').length && !angular.element(event.target).hasClass('searchby320')){
						scope.showSearchTip = false;
						scope.selected = "";
						angular.element(".results_holder").css({height : 0});
						scope.$apply();
					}
					
					if(! angular.element(event.target).parents('.modifyby320').length && !angular.element(event.target).hasClass('modifyby320')){
		            	if(scope.showMobileModifySearchPopup){
		            		$rootScope.NLPFilters = angular.copy(oldFilters);
		            	}
		            	scope.showMobileModifySearchPopup = false;
		            	scope.$apply();
		            }
				});
			};
			bodyClick();
		}
	};
}]);
