'use strict';

angular.module('buySmaartApp')
  .directive('lineGraph', ["Priceretailercolors",function (Priceretailercolors) {
    return {
      restrict: 'E',
      link: function postLink(scope, element, attrs) {
        var actualheight, actualwidth, bottom, chart, color, div, height, legend, marginbottom, marginleft, marginright, margintop, summaryType, tickFormat, units, width, x, y, ymetric,dottedlinesOuter,dottedlinesInner;
        width = attrs.width;
        var linegraphcardinal = 0;
        height = attrs.height;
        margintop = attrs.marginTop;
        marginright = attrs.marginRight;
        marginleft = attrs.marginLeft;
        marginbottom = attrs.marginBottom;
        actualwidth = width - marginleft - marginright;
        actualheight = height - margintop - marginbottom;
        summaryType = attrs.summaryType;
        units = attrs.units ? attrs.units : '';
        bottom = attrs.bottom === 'bottom' ? true : false;
        ymetric = attrs.ymetric;
        var now = moment()
        x = d3.time.scale().range([
          marginleft,
          actualwidth
        ]);
        y = d3.scale.linear().range([
          actualheight,
          0
        ]);
        tickFormat = function (d) {
          var truncwithgiga, truncwithkilo, truncwithmega;
          truncwithkilo = d / 1000;
          truncwithmega = truncwithkilo / 1000;
          truncwithgiga = truncwithmega / 1000;
          if (truncwithgiga >= 1) {
            d = Math.round(truncwithmega / 1000) + 'G';
          } else if (truncwithmega >= 1) {
            d = Math.round(truncwithkilo / 1000) + 'M';
          } else if (truncwithkilo >= 1) {
            d = Math.round(d / 1000) + 'K';
          }
          return d;
        };
        if (ymetric === 'time') {
          tickFormat = function (d) {
            var truncwithhours, truncwithmins, truncwithsecs;
            truncwithsecs = d / 1000;
            truncwithmins = truncwithsecs / 60;
            truncwithhours = truncwithmins / 60;
            if (truncwithhours >= 1) {
              d = Math.round(truncwithhours / 1000) + ' hours';
            } else if (truncwithmins >= 1) {
              d = Math.round(truncwithmins / 1000) + ' mins';
            } else if (truncwithsecs >= 1) {
              d = Math.round(d / 1000) + ' secs';
            } else {
              d = d + ' ' + units;
            }
            return d;
          };
        } else if (ymetric === 'integer') {
          tickFormat = d3.format('d');
        }
        chart = d3.select(element[0]).append('svg:svg').attr('width', width).attr('height', height);
        chart = chart.append('g').attr('transform', 'translate(0,' + margintop + ')');
        chart.append('g').attr('class', 'price-graph-xaxis').attr('transform', 'translate(0,' + actualheight + ')');
        chart.append('g').attr('class', 'price-graph-yaxis').attr('transform', 'translate(' + marginleft + ',0)');
        legend = chart.append('g').attr('class', 'legend').attr('transform', 'translate(' + marginleft + ',0)');
        $('.dashboard-tooltip').hide();
        var line = d3.svg.line()
                  .x(function(d,i) {return x(d.updatedOn);})
                  .y(function(d) {return  y(d.price);})
                  .interpolate("cardinal")
                  .tension(0.85)
        
        div = d3.select('body').append('div').attr('class', 'dashboard-tooltip');
        return scope.$watchCollection('multilinechartdata', function () {
          var appendlegend, appendtext, colors, data, date_format, index, lines, timeframe, xAxis, yAxis, _results;
          data = [];
          date_format = d3.time.format(scope.selectedtimerange.format)
          x.domain([
                String(now.valueOf()-scope.selectedtimerange.duration.asMilliseconds()),
                String(now.valueOf())
              ]);
          linegraphcardinal = 0;
          colors = Priceretailercolors.getRetailerColorMap()
          _results = [];
          var tempArray = []
          for (index in scope.multilinechartdata){
            //concatenating all prices to obtain global max and min. 
            _.pluck(scope.multilinechartdata[index],"price").forEach(function(price){
                tempArray.push(price)
            })
          }
          var min_price = d3.min(tempArray)
          var max_price = d3.max(tempArray)
          var variance = max_price - min_price
          y.domain([min_price-variance,max_price+variance])
          if(scope.selectedtimerange.id==5 || scope.selectedtimerange.id==3)
            xAxis = d3.svg.axis().scale(x).orient('bottom').ticks(d3.time.month,1).tickFormat(d3.time.format("%b")).outerTickSize(0)//.tickFormat(date_format);
          else
            xAxis = d3.svg.axis().scale(x).orient('bottom').ticks(8).tickPadding(20).outerTickSize(0)//.tickFormat(date_format);
          yAxis = d3.svg.axis().scale(y).orient('left').ticks(7).outerTickSize(0)
          for (index in scope.multilinechartdata) {
            //data = scope.multilinechartdata[index];
            data = scope.multilinechartdata[index];
            var concatenatedIndex = index.split(" ").join("")
            if (data && data.length !== 0) {

              data.sort(function (b, a) {
                return b.updatedOn - a.updatedOn;
              }).map(function (d) {
                return d.price;
              });

              data = _.reject(data,function(d){
                return d.updatedOn < String(now.valueOf() - scope.selectedtimerange.duration.asMilliseconds())
              })
              //timeframe = scope.selectedtimerange.time;
              chart.select('.price-graph-xaxis').call(xAxis).selectAll('.tick text').attr('class', 'linechart-small');
              chart.select('.price-graph-yaxis').call(yAxis).selectAll('.tick text').attr('class', 'linechart-small');
              chart.selectAll('.price-graph-xaxis').select('.domain')
                                       .style("stroke","rgb(172,172,172)")
                                       .style("stroke-width","1px")
                                       .style("shape-rendering","crispEdges")
                                       .style("fill","none")
              chart.selectAll('.price-graph-yaxis').select('.domain')
                                       .style("stroke","rgb(172,172,172)")
                                       .style("stroke-width","1px")
                                       .style("shape-rendering","crispEdges")
                                       .style("fill","none")

              chart.selectAll('.price-graph-xaxis').selectAll('.tick text').attr('y',12)
                                            
              if (chart.selectAll('.linegraph' + concatenatedIndex)[0].length > 0) {
                chart.selectAll('.priceline').remove()
                chart.selectAll('.dottedlinewhite').remove()
                chart.selectAll('.dottedlinered').remove()
                
                
              }
              
                
              
                
                //if (chart.selectAll('.linegraph' + index)[0].length === 0) {
                //appendlegend = legend.append('rect').attr('x', 45 + 100 * linegraphcardinal).attr('y', height-60).attr('width', 10).attr('height', 10).style('fill', colors[linegraphcardinal]);
                //appendtext = legend.append('text').attr('x', 65 + 100 * linegraphcardinal).attr('y', height-50).text(index).style('fill', colors[linegraphcardinal]);
                if(colors[index]){
                  lines = chart.append('path').attr('class', 'priceline linegraph' + concatenatedIndex).attr('d', line(data))
                             .attr('fill', 'none').attr('stroke', colors[index].color).attr('stroke-linecap', 'round')
                             
                  dottedlinesOuter = chart.append('path').attr("class","dottedlinewhite dottedlinewhite" + concatenatedIndex).attr('d', line(data))
                             .attr('fill', 'none').attr('stroke', "white").attr('stroke-linecap', 'round')
                             .attr('stroke-dasharray', "1,120")
                             .attr('stroke-width',10)                             
                  dottedlinesInner = chart.append('path').attr("class","dottedlinered dottedlinered" + concatenatedIndex).attr('d', line(data))
                             .attr('fill', 'none').attr('stroke', colors[index].color).attr('stroke-linecap', 'round')
                             .attr('stroke-dasharray', "1,120")
                             .attr('stroke-width',6)
                  }
                /*var outerCircles = chart.selectAll(".points").data(data).enter().append('circle').attr("r",3).attr("cx",function(d){
                  return x(d.updatedOn)
                }).attr("cy",function(d){
                  return y(d.price)
                }).style('fill', "white")
                /*var innercircles = chart.selectAll(".points").data(data).enter().append('circle').attr("r",1).attr("cx",function(d){
                  return x(d.updatedOn)
                }).attr("cy",function(d){
                  return y(d.price)
                }).style('fill', colors[linegraphcardinal])
                */
              /*} else {
                chart.selectAll('.linegraph' + index).remove()
                chart.selectAll('.dottedlinewhite' + index).remove()
                lines = chart.selectAll('.linegraph' + index).data(data).attr('d', line(data)).attr('fill', 'none').attr('stroke', colors[linegraphcardinal]).attr('stroke-linecap', 'round')
                dottedlinesOuter = chart.selectAll('.dottedlinewhite' + index).data(data).attr('d', line(data))
                             .attr('fill', 'none').attr('stroke', "white").attr('stroke-linecap', 'round')
                             .attr('stroke-dasharray', "1,120")
                             .attr('stroke-width',10)
                dottedlinesInner = chart.selectAll('.dottedlinered' + index).data(data).attr('d', line(data))
                             .attr('fill', 'none').attr('stroke', colors[linegraphcardinal]).attr('stroke-linecap', 'round')
                             .attr('stroke-dasharray', "1,120")
                             .attr('stroke-width',6)
              }*/

                linegraphcardinal++;
                /*var totalLength = lines.node().getTotalLength();
                lines.attr('stroke-dasharray', totalLength + " " + totalLength).attr("stroke-dashoffset", totalLength)
                            .transition()
                            .duration(1000)
                            .ease("linear")
                            .attr("stroke-dashoffset", 0);*/
                var curtain = chart.append('rect')
                                .attr('x', -1 * x.range()[1]-marginleft)
                                .attr('y', -1 * y.range()[1]-y.range()[0]+2)
                                .attr('height', actualheight)
                                .attr('width', actualwidth-2)
                                .attr('class', 'curtain')
                                .attr('transform', 'rotate(180)')
                                .style('fill', '#ffffff')
                
            } else {
              _results.push(void 0);
            }
          }
          chart.selectAll('.price-graph-xaxis').selectAll('.tick line')
                                      .attr('class','gridline')
                                      .attr('y1',0)
                                      .attr('y2',y.range()[1]-y.range()[0])
                                      
          chart.selectAll('.price-graph-yaxis').selectAll('.tick line')
                                      .attr('class','gridline')
                                      .attr('x1',0)
                                      .attr('x2',x.range()[1]-marginleft)
          var t = chart.transition()
                      .delay(0)
                      .duration(3000)
                      .ease('linear')
                      
          t.selectAll('rect.curtain').attr('width', 0);
          t.selectAll('rect.curtain').remove()

          return _results;
        });
      }
    };
  }]);
