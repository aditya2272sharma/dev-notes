'use strict';

angular.module('buySmaartApp')
  .controller('CompareResultsCtl',["$scope","$route","Api", "$window","$location", "$rootScope", "NLPFilterServices", "NLPFilters", "Meta",
  						function ($scope, route, Api, $window, $location, $rootScope, NLPFilterServices, NLPFilters, Meta) {

  	$rootScope.currentPage = "Compare";
    var productid = [];
  	var productNames= [];
	$scope.specificationsInfo = [];
  	$scope.categoryGroup = {};
  	$scope.productBasicInfo = [];
  	var callProgressCount = 0;
  	$scope.productPrices = [];
  	$scope.priceGroup = {};
  	$scope.priceList = [];
  	$scope.defultCurrency="\u20b9";
  	$scope.showPricePanel = false;
  	$scope.showScreenBlocker = true;
  	$scope.showPriceTable = false;
  	$scope.emptyListArray = [];
    $scope.defaultImageURL = _.template('/images/ignore/${categoryName}_default.jpg')({
      "categoryName": Meta.getCategoryName()
    });
    $scope.categoryName = Meta.getCategoryName();
  	var catogeryId;
  	$scope.pricePopUpHeight = $window.innerHeight - 184;
	$scope.menubar = true;



							var productid = route.current.params.productids.split("-");
	var productNames = route.current.params.productNames.split("-vs-");
	for(var i = 0, iLen = productNames.length; i < iLen; i++) {
		productNames[i] = productNames[i].replace(/-/g," ");
	}

	var settingMetaTags = function() {
		var name = productNames[0];
		for(var i = 1, iLen = productNames.length; i < iLen; i++) {
			name = name + ' vs ' + productNames[i];
		}
    name = name +" | BuySmaart";
		$rootScope.title = "Compare " + Meta.getCategoryName() + " - " + name;
    __insp.push(['tagSession', "Visited" +$rootScope.title+  "pages"]);
	 	var desc = "Compare " + name +" - Which is best?";
    var keywords = "Compare " + name;
	 	//OLD --> "BuySmaart, " + name +", compare specs, ratings and reviews for " + name;
	 	/*** Setting Data for meta tags ***/
    $rootScope.description = desc;
    $rootScope.keywords = keywords;
	 };
	 settingMetaTags();

	for(var i = 0, iLen = 4 - productid.length; i < iLen; i++) {
		$scope.emptyListArray.push({
            brand: {},
            model: {},
            models: []
        });
	}

  	/*if(route.current.params.productid1 != null && route.current.params.productid1 != undefined) {
  		productid[0] = route.current.params.productid1;
  	} else {
  		$scope.emptyListArray.push({
            brand: {},
            model: {},
            models: []
        });
  	}


 	if(route.current.params.productid2 != null && route.current.params.productid2 != undefined) {
  		productid[1] = route.current.params.productid2;
  	} else {
  		$scope.emptyListArray.push({
            brand: {},
            model: {},
            models: []
        });
  	}
  	if(route.current.params.productid3 != null && route.current.params.productid3 != undefined) {
  		productid[2] = route.current.params.productid3;
  	} else {
  		$scope.emptyListArray.push({
            brand: {},
            model: {},
            models: []
        });
  	}
  	if(route.current.params.productid4 != null && route.current.params.productid4 != undefined) {
  		productid[3] = route.current.params.productid4;
  	} else {
  		$scope.emptyListArray.push({
            brand: {},
            model: {},
            models: []
        });
  	}*/

  	var getInitialInfo = function(){
  		for(var i = 0, ilen = productid.length; i < ilen; i++){
  			getProductInfo(i);
  			getProductInformaation(i);
  			getPriceData(i);
  		}
  	};

    var getProductDetails = function() {
          var params = {};
          params.aspectMetadata = {};
          for (var k in $rootScope.NLPFilters.aspects){
              if(k != 'undefined') {
                  params.aspectMetadata[k] = {};
                  params.aspectMetadata[k].value = $rootScope.NLPFilters.aspects[k].value;
                  params.aspectMetadata[k].metadataId = $rootScope.NLPFilters.aspects[k].metadataId;
              }
          }
          return params;
      }

  	var getProductInfo = function(index){
  		callProgressCount = callProgressCount + 1;
      var categoryId = Meta.getCategoryID();
  		Api.getProduct(catogeryId, productid[index], getProductDetails(), categoryId).then(function(response){
  			response.rank = index;
        	$scope.productBasicInfo[index] = response;
        	$rootScope.compareItems[index] = response;
        	callProgressCount = callProgressCount - 1;
        	processAfterAllCalls();
  		});
  	};

  	var getPriceData = function(index) {
  		callProgressCount = callProgressCount + 1;
	  	Api.getProductPriceAnalytics(catogeryId, productid[index]).then(function(response){
	  		response = response.data;
	  		if(response){
	          	$scope.priceList[index] = {};
	      		$scope.priceList[index].productid = response.productId;
	      		$scope.priceList[index].price = response.minPrice;
	      		$scope.priceList[index].date = response.minPrice;
	        	$scope.productPrices[index] = response.priceList;
	       } else {
	       		$scope.priceList[index] = {};
	      		$scope.priceList[index].productid = 0;
	      		$scope.priceList[index].price = null;
	      		$scope.priceList[index].date = null;
	       		$scope.productPrices[index] = [];
	       }
	        callProgressCount = callProgressCount - 1;
	        processAfterAllCalls();
  		});
  	};

    var getProductInformaation = function(index){
    	callProgressCount = callProgressCount + 1;
      var categoryName = Meta.getCategoryName();
    	Api.getProductSpecification(catogeryId, productid[index], categoryName).then(function(response){
        	$scope.specificationsInfo[index] = response;
        	callProgressCount = callProgressCount - 1;
        	processAfterAllCalls();
  		});
    };

    var processAfterAllCalls = function(){
    	if(callProgressCount == 0){
    		setTheRanks();
    		orderTheCategory();
    		orderThePrice();
    		$scope.showScreenBlocker = false;
    	}
    };

    var setTheRanks = function() {
    	var arrayForRanks = [];
    	for (var i = 0, iLen = $scope.productBasicInfo.length; i < iLen; i++){
    		arrayForRanks.push({
    			"value": $scope.productBasicInfo[i].analytics.overallWeightedScore,
    			"pos": i
    		});
    	}
    	arrayForRanks.sort(function(a, b){return b.value - a.value;});
    	for (var i = 0, iLen = arrayForRanks.length; i < iLen; i++) {
    		var ext = (i + 1 == 1)? "st" : (i + 1 == 2)? "nd" : (i + 1 == 3)? "rd" : "th";
    		$scope.productBasicInfo[arrayForRanks[i].pos].rank = i + 1 + ext;
    	}
    };

    var orderTheCategory = function(){
    	$scope.categoryGroup = {};
    	for(var i = 0, iLen = $scope.specificationsInfo[0].length; i < iLen; i++){
    		var pecificationsInfo = $scope.specificationsInfo[0];
    		if($scope.categoryGroup[pecificationsInfo[i].specCategory] == null || $scope.categoryGroup[pecificationsInfo[i].specCategory] == undefined){
    			$scope.categoryGroup[pecificationsInfo[i].specCategory] = {};
    		}
    		$scope.categoryGroup[pecificationsInfo[i].specCategory][pecificationsInfo[i].specName] = [];
    		for(var j = 0, jLen = $scope.specificationsInfo.length; j < jLen; j++){
    			$scope.categoryGroup[pecificationsInfo[i].specCategory][pecificationsInfo[i].specName].push($scope.specificationsInfo[j][i].specValue);
    		}
    	}
    };

    $scope.hadSubDataData = function(data){
    	for(var i = 0, iLen = data.length; i < iLen; i++) {
    		if(data[i] != null && data[i] != undefined && data[i] != "" ){
    			return true;
    		}
    	}
    	return false;
    };

    var orderThePrice = function() {
    	$scope.priceGroup = {};
    	//$scope.priceGroup
    	for(var i = 0, iLen = $scope.productPrices.length; i < iLen; i++) {
    		if($scope.productPrices[i]) {
	    		for(var j = 0, jLen = $scope.productPrices[i].length; j < jLen; j++){
	    			if($scope.priceGroup[$scope.productPrices[i][j].seller.id] == null || $scope.priceGroup[$scope.productPrices[i][j].seller.id] == undefined) {
	    				$scope.priceGroup[$scope.productPrices[i][j].seller.id] = {
	    					seller: null,
	    					priceArray: []
	    				};
	    				for(var k = 0, kLen = $scope.productPrices.length; k < iLen; k++){
	    					$scope.priceGroup[$scope.productPrices[i][j].seller.id].priceArray[k] = null;
	    				}
	    			}
	    			if($scope.priceGroup[$scope.productPrices[i][j].seller.id].priceArray[i] == null || $scope.priceGroup[$scope.productPrices[i][j].seller.id].priceArray[i] == undefined){
	    				$scope.priceGroup[$scope.productPrices[i][j].seller.id].seller = $scope.productPrices[i][j].seller;
	    				$scope.priceGroup[$scope.productPrices[i][j].seller.id].priceArray[i] = {};
	    				$scope.priceGroup[$scope.productPrices[i][j].seller.id].priceArray[i].price = $scope.productPrices[i][j].price;
	    				$scope.priceGroup[$scope.productPrices[i][j].seller.id].priceArray[i].url = $scope.productPrices[i][j].purchaseURL;
	    			} else if($scope.priceGroup[$scope.productPrices[i][j].seller.id].priceArray[i].price > $scope.productPrices[i][j].price){
	    				$scope.priceGroup[$scope.productPrices[i][j].seller.id].priceArray[i].price = $scope.productPrices[i][j].price;
	    				$scope.priceGroup[$scope.productPrices[i][j].seller.id].priceArray[i].url = $scope.productPrices[i][j].purchaseURL;
	    			}
	    		}
	    	}
	    }
    };



    $scope.closePricePanel = function(event){
		if( angular.element(event.target).hasClass('popup_overlay')){
			$scope.showPricePanel = false;
		}
	};

	$scope.showPriceInformationOverLay = function(index){
		Api.gaTrackEvent('(' +$scope.categoryName +') ' + $scope.currentPage + ' Page', 'Buy Button Clicked', 'Buy Button Clicked');
		$scope.showScreenBlocker = true;
    	var list = $scope.productPrices[index];

    	$scope.productPrice = {};
		for(var i = 0, iLen = list.length; i < iLen; i++){
			if(	$scope.productPrice[list[i].seller.id] == null ||
				$scope.productPrice[list[i].seller.id] == undefined ||
				Number(list[i].price) < Number($scope.productPrice[list[i].seller.id].price)){
				$scope.productPrice[list[i].seller.id] = list[i];
			}
		}

    	$scope.showPricePanel = true;
    	$scope.showScreenBlocker = false;
	};

	var registerScrollEvent = function(){
			angular.element($window).unbind("scroll");
			angular.element($window).bind("scroll", function(e) {
			 		var topHeight	 = angular.element(".header-section").outerHeight( true )
			 						 + (angular.element(".compare_steps_styling").is(':visible') ? angular.element(".compare_steps_styling").outerHeight(true) : 0)
			 						 + (angular.element(".compare_result_mobile_option_holder").is(':visible') ? angular.element(".compare_result_mobile_option_holder").outerHeight(true) : 0 )
			 						 + (angular.element(".compare_headsection_active_styling").is(':visible') ?angular.element(".compare_headsection_active_styling").outerHeight(true) : 0)
			 						 + angular.element(".main_headsection").outerHeight(true)
			 						 + angular.element(".headsection_table_top_notfixed").outerHeight(true)
                                     - 218;//294;
			 		var scrollYVal = this.pageYOffset || this.scrollY;

          var docHeight = $(document).height();
          var scrollHeight = $(document).scrollTop();
          var footerHeight = angular.element("#footer").height();
          var diff = docHeight-footerHeight;
			 		if(scrollYVal > topHeight && scrollHeight < diff-250){
			 			angular.element(".stickey").show();
			 		}else {
			 			angular.element(".stickey").hide();
			 		}
			  });
		};

	$scope.removeProduct = function(index){
		productid.splice(index, 1);
		productNames.splice(index, 1);
		$rootScope.compareItems.splice(index, 1);
		if(productid.length < 1){
			var path = $scope.categoryName + "/Compare";
		  	for(var i = 0, iLen = productid.length; i < iLen; i++){
		  		path= path + "/" + productid[i];
		  	}
		  	$location.path(path, true);
		  	return;
		}
		$scope.productBasicInfo.splice(index, 1);
		$scope.priceList.splice(index, 1);
		$scope.productPrices.splice(index, 1);
		$scope.specificationsInfo.splice(index, 1);
		$scope.emptyListArray.push({
            brand: {},
            model: {},
            models: []
        });
		orderTheCategory();
    	orderThePrice();
    	setTheRanks();
    	updateURL();
	};
    $scope.brands=[];
    var updateBrands = function(){
      var response = NLPFilters.config;
        	catogeryId = response.domainId;
       		for(var i = 0, iLen = response.filters.length; i < iLen; i++){
            	switch(response.filters[i].filterId){
            		case "Brand":
            			$scope.brands = response.filters[i].filterableItems;
            		break;
            	}
        	}
        	getInitialInfo();
    };

    updateBrands();

    $scope.updateModels = function(index, name) {
    	Api.gaTrackEvent('(' +$scope.categoryName +') ' + $scope.currentPage + ' Page', 'Brand Selected', name);
        var text = 'models/'+$scope.emptyListArray[index].brand.itemId;
        var categoryId = Meta.getCategoryID();
        Api.getFilterOptions($rootScope.NLPFilters.domainId, text, categoryId).then(function(response) {
                $scope.emptyListArray[index].models = response;
        });
    };

    $scope.modelSelected = function(index) {
    	Api.gaTrackEvent('(' +$scope.categoryName +') ' + $scope.currentPage + ' Page', 'Model Selected', $scope.emptyListArray[index].model.displayName);
       $scope.showScreenBlocker = true;
       productid.push($scope.emptyListArray[index].model.id);
       productNames.push($scope.emptyListArray[index].model.displayName);
       getProductInfo(productid.length - 1);
       getPriceData(productid.length - 1);
       getProductInformaation(productid.length - 1);
       $scope.emptyListArray.splice(index, 1);
       updateURL();
    };

    var updateURL = function(){
      var categoryName = Meta.getCategoryName();
    	var path = "/"+categoryName+"/Compare";

    	var name = productNames[0].replace(/ /g,"-");
	  	var productIds = productid[0];
	  	for(var i = 1, iLen=productid.length; i < iLen; i++){
	  		productIds = productIds + "-" + productid[i];
	  		name = name + "-vs-" + productNames[i].replace(/ /g,"-");
        name = encodeURIComponent( name );
	  	}
      path = path+"/"+productIds+"/"+name;
      path = encodeURI (path);
	  	$location.path(path, false);
	  	settingMetaTags();
    };

    $scope.openSmartViewForCompre = function() {
      Api.gaTrackEvent('(' +$scope.categoryName +') ' + $scope.currentPage + ' Page', 'Smaart Compare Button Clicked', 'Smaart Compare Button Clicked');
      var categoryName = Meta.getCategoryName();
    	var path = "/"+categoryName+"/SmaartView";
	  	for(var i = 0, iLen = $scope.compareItems.length; i < iLen; i++){
	  		path= path + "/" + $scope.compareItems[i].productId;
	  	}
	  	$location.url(path);
    };

    $scope.resetHeigthOfDiv = function(refDiv){
    	angular.element("."+refDiv).css('height','auto');
    };

    registerScrollEvent();

  }]);
