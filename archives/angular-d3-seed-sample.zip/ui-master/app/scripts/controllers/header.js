'use strict';

angular.module('buySmaartApp')
  .controller('HeaderCtrl',['$scope', '$rootScope', 'Api', '$route', '$cookies', '$location', '$window', 'Meta', 'NLPFilterServices',
  					 function ($scope, $rootScope, Api, route, $cookies, $location, $window, Meta, NLPFilterServices) {
  	$scope.login_options = false;
  	$scope.show_tutorial = false;
    $scope.show_tutorial1 = function(){
      Api.gaTrackEvent('(' +$scope.categoryName +')', ' Tutorial Button Clicked' , 'Tutorial Button clicked');
      $scope.show_tutorial = true
    };

    function storeInitialConfig() {
      $scope.categories = angular.copy($rootScope.categories);
      $scope.selectedCategory = Meta.getCategoryName();
    };
    storeInitialConfig();
    $rootScope.$on("categoryConfigUpdated",storeInitialConfig);

  	$scope.authenticate = function(provider) {
		// $auth.authenticate(provider).then(function() {
  //           $scope.showLoginOptions = false;
		// 	if($auth.isAuthenticated()){
		// 		Api.getUserInformationAfterSocialLogin($auth.getToken(), provider).success( function(data) {
  //                   if(data != undefined) {
  //                       $rootScope.isUserLoggedIn = true;
  //                       $cookies.put('buysmaart_login_username', data.firstName);
  //                       $cookies.put('buysmaart_login_userid', data.userId);
  //                       $rootScope.user_name = data.firstName;
  //                       $rootScope.user_id = data.userId;
  //                       $rootScope.userLoginFunction();
  //                   }

  //               }).error(function (error) {
  //               	alert("login failed" + error);
  //               });
		// 	}else{
		// 		alert("login failed user not logedin");
		// 	}
		// });
	};
	$scope.close_tutorial = function(){
		$scope.show_tutorial = false;
	};
    $scope.logout = function() {
        $rootScope.isUserLoggedIn = false;
        $cookies.put('buysmaart_login_username', '');
        $cookies.put('buysmaart_login_userid', '');
        $rootScope.wishList = [];
        $rootScope.user_name = '';
        $rootScope.user_id = '';
    };
    var bodyClick = function(){
        angular.element('body').click(function(event) {
        	if(! angular.element(event.target).parents('.login-btn').length) {
        		$scope.login_options = false;
        		$scope.$apply();
        	}
            if(! angular.element(event.target).parents('.element_part_dropdown').length) {
                // $scope.showCategoryOptions = true;
                $scope.showLoginOptions = false;
                $scope.$apply();
            }

            if(! angular.element(event.target).parents('.headerSearchHolder').length){
            	$scope.show_searchResults = false;
            	$scope.$apply();
				$scope.selected = "";
            }

            if(! angular.element(event.target).parents('.modifySearchHolder').length){
            	if($scope.showModifySearchPopup){
            		$rootScope.NLPFilters = angular.copy(oldFilters);
            	}
            	$scope.showModifySearchPopup = false;
            	$scope.$apply();
            }
        });
    };
    bodyClick();
    var oldFilters = angular.copy($rootScope.NLPFilters);

    $scope.searchEnable = function(event) {
				angular.element(".headerSearchIconHolder").addClass("searchEnable");
				angular.element(".headerSearchField").animate({
					width : 200
				}, "slow", function(){
					angular.element(".headerSearchField").focus();
				});
	};
	$scope.show_searchResults = false;
   	$scope.updateSearchResults= function(newValue){
      var categoryId = Meta.getCategoryID();
        if(newValue && newValue != ""){
            Api.fetchAutocompleteDetails(newValue, categoryId).then(function(response){
            	for(var i = 0, iLen = response.length; i < iLen; i++){
            		var splitedString = response[i].displayName.split(" ");
            		response[i].brand = splitedString[0];
            		response[i].displayName = splitedString[1];
            		for(var j = 2, jLen = splitedString.length; j < jLen; j++){
            			response[i].displayName = response[i].displayName + " " + splitedString[j];
            		}
            	}
                $scope.searchSuggestions = response;
                $scope.show_searchResults = true;
            });
        } else{
        	$scope.searchSuggestions = [];
        	$scope.show_searchResults = false;
        }
    };
    $scope.showModifySearchPopup = false;

    $scope.loginClickEvent = function(){
    	Api.gaTrackEvent($scope.currentPage + 'LoginClicked', 'LoginClicked', 'LoginClicked');
    };

    $scope.logo_clicked = function() {
    	Api.gaTrackEvent('(' +$scope.categoryName +') ' + $scope.currentPage + ' Page', 'Logo Image Clicked', 'Navigate To HomePage');
        for(var i in $rootScope.NLPFilters.filters) {
          $rootScope.NLPFilters.filters[i].selectedFilters = [];
        }
        for(var i in $rootScope.NLPFilters.aspects) {
            $rootScope.NLPFilters.aspects[i].value = $rootScope.arrayOfAspectTips[2].value;
            $rootScope.NLPFilters.aspects[i].display = $rootScope.arrayOfAspectTips[2].display;
        }

       var pricesInfoForCategory = Meta.getPricesForCategory();
       $rootScope.NLPFilters.PriceMinValue = pricesInfoForCategory.PriceMinValue;
       $rootScope.NLPFilters.PriceMaxValue = pricesInfoForCategory.PriceMaxValue;
       $rootScope.NLPFilters.SpecificationWeight = 3;
       $rootScope.NLPFilters.SentimentWeight = 3;
       $rootScope.NLPFilters.allProducts = false;
       $rootScope.NLPFilters.TimeSort = null;
       $rootScope.NLPFilters.PriceSort = null;
       $rootScope.NLPFilters.ScoreSort = null;
    };
  }]);
