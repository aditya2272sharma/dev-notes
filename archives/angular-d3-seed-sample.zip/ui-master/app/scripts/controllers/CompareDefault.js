'use strict';

angular.module('buySmaartApp')
  .controller('CompareDefaultCtrl',['$scope','Api','Timerangepicker', '$window', '$route' , '$location', '$rootScope', "NLPFilterServices", "NLPFilters", "Meta",
function ($scope,Api,Timerangepicker, $window, route, $location, $rootScope, NLPFilterServices, NLPFilters, Meta) {
	$rootScope.currentPage = "Compare";
	$scope.menubar = true;

	__insp.push(['tagSession', "Visited empty compare pages"]);
    $scope.emptyListArray = [];
    var callProgressCount = 0;
    var productid;
    var productDataExpecting = [];
    $scope.defaultImageURL = _.template('/images/ignore/${categoryName}_default.jpg')({
      "categoryName": Meta.getCategoryName()
    });
    
    var settingMetaTags = function() { 	
	 	var desc = "Compare " + $scope.catogoryForMetaTags + " prices, specifications and reviews on buysmaart. Buysmaart is a fantastic " + $scope.catogoryForMetaTags + " comparison site";
        //OLD -->"Use BuySmaart to compare " + $scope.catogoryForMetaTags + " specs, reviews and prices for your favourite " + $scope.catogoryForMetaTags + " and decide which " + $scope.catogoryForMetaTags + " to buy";
	 	var keywords = "Compare " + $scope.catogoryForMetaTags + " prices in India, compare " + $scope.catogoryForMetaTags + " specs, compare " + $scope.catogoryForMetaTags + " features";
        // OLD -->"Compare " + $scope.catogoryForMetaTags + " specs, compare " + $scope.catogoryForMetaTags + " features, compare " + $scope.catogoryForMetaTags + " reviews, compare " + $scope.catogoryForMetaTags + " prices";
	 	/*** Setting Data for meta tags ***/
         $rootScope.description = desc;
         $rootScope.keywords = keywords;
         $rootScope.title = "Compare " + $scope.catogoryForMetaTags + " prices," + $scope.catogoryForMetaTags + " specifications and reviews | Buysmaart";
	 };
	 settingMetaTags();
    
    angular.element($window).unbind("scroll");
    if(route.current.params.productid != null && route.current.params.productid != undefined) {
  		productid = route.current.params.productid;
  	} else {
  		$scope.emptyListArray.push(0);
  	}
    
    $scope.tweetWindow = function(url, text) {
        var url = location.href;
        window.open( "http://twitter.com/share?url=" + 
        encodeURIComponent(url) + "&text=" + 
        encodeURIComponent(text) + "&count=none/", 
        "tweet", "height=300,width=550,resizable=1" );
	};

	$scope.faceWindow = function(url, title) {
        url = location.href;
        window.open( "http://www.facebook.com/sharer.php?u=" + 
		encodeURIComponent(url) + "&t=" + 
		encodeURIComponent(title), 
		"facebook", "height=300,width=550,resizable=1" );
	};
    
    var getProductDetails = function() {
        var params = {};
        params.aspectMetadata = {};
        for (var k in $rootScope.NLPFilters.aspects){
            if(k != 'undefined') {
                params.aspectMetadata[k] = {};
                params.aspectMetadata[k].value = $rootScope.NLPFilters.aspects[k].value;
                params.aspectMetadata[k].metadataId = $rootScope.NLPFilters.aspects[k].metadataId;
            }
        }
        return params;
    }

    var getProductInfo = function() {
        callProgressCount = callProgressCount + 1;
        var categoryId = Meta.getCategoryID();
  		Api.getProduct($scope.domainId, productid, getProductDetails(), categoryId).then(function(response){
            $scope.selectComparisions[0].model = response;
            $scope.selectComparisions[0].model.image = response.primaryImage;
            
            //now u got the model based on this get the brand details from the brand list
            for(var i=0, len=$scope.brands.length; i<len; i++) {
                if(response.filterableValues.brand == $scope.brands[i].displayName) {
                    $scope.selectComparisions[0].brand=$scope.brands[i];
                    //now get the list of models
                    $scope.updateModels("getModels");
                    
                    
                    break;                    
                }
            }
        	callProgressCount = callProgressCount - 1;
  		});
  	};
    
    $scope.googleWindow = function(url) {
	url = window.location;
		window.open("https://plus.google.com/share?url="+url, "facebook", "height=300,width=550,resizable=1");
	};
    
    $scope.brands= [];
    $scope.models= [];
    $scope.categoryName = Meta.getCategoryName();  
    $scope.selectComparisions= [
        {
            brand: {},
            model: {
                image: "/images/ignore/"+$scope.categoryName+"_default.jpg"
            },
            models: []
        },{
            brand: {},
            model: {
                image: "/images/ignore/"+$scope.categoryName+"_default.jpg"
            },
            models: []
        },{
            brand: {},
            model: {
                image: "/images/ignore/"+$scope.categoryName+"_default.jpg"
            },
            models: []
        },{
            brand: {},
            model: {
                image: "/images/ignore/"+$scope.categoryName+"_default.jpg"
            },
            models: []
        }
    ];
    
    var updateBrands = function(){
            var response = NLPFilters.config;
			var response = NLPFilters.config;
        	$scope.domainId = response.domainId;
            $scope.categoryId = Meta.getCategoryID();
            $scope.categoryName = Meta.getCategoryName();
       		for(var i = 0, iLen = response.filters.length; i < iLen; i++){
            	switch(response.filters[i].filterId){
            		case "Brand":
            			$scope.brands = response.filters[i].filterableItems;
            		break;
            	}
        	}
        	 if(productid) {
		        getProductInfo();
		    }
		    
		    Api.fetchPopularComparisons($scope.domainId, $scope.categoryId).then(function(comparisons){
                $scope.compareList = comparisons;
		        $scope.compareListAll = comparisons;
		    });
		    
    };
    
    
    updateBrands();
    
    
    function modelNameComparator(val1, val2) {
        if(val1.displayName > val2.displayName)
            return 1;
        if(val1.displayName < val2.displayName)
            return -1;
        return 0;
    }

    $scope.updateModels = function(index, brandName) {
    	
        if(index== "getModels") { 
            var text = 'models/'+$scope.selectComparisions[0].brand.itemId;
        }else {
            var text = 'models/'+$scope.selectComparisions[index].brand.itemId;
            Api.gaTrackEvent('(' +$scope.categoryName +') ' + $scope.currentPage + ' Page', 'Brand Selected', $scope.selectComparisions[index].brand.itemId);
            
        }
        Api.getFilterOptions($scope.domainId, text, $scope.categoryId).then(function(response) {
            if(index== "getModels") {
                $scope.selectComparisions[0].models = response;
                //since you got all the models now set the selection to be the one from response
                for(var j=0, jlen=response.length; j<jlen; j++) {
                    if($scope.selectComparisions[0].model.productId == response[j].id) {
                        //wefound the match in the models assign th model accordingly
                        $scope.selectComparisions[0].model = response[j];
                    } 
                }
                $scope.selectComparisions[0].models.sort(modelNameComparator); 
            } else {
                $scope.selectComparisions[index].models = response;
                $scope.selectComparisions[index].models.sort(modelNameComparator);
            }
        });    
    };
    
    $scope.errorTipEnable = false;
    $scope.openCompareResults = function() {
    		$scope.count = 0;
            var categoryName = Meta.getCategoryName();
	    	var path = "/"+categoryName+"/Compare";
	    	var name = '';
			var productIds = '';
		  	for(var i = 0, iLen = $scope.selectComparisions.length; i < iLen; i++){
		  		if($scope.selectComparisions[i].model.id != undefined) {
		  			if(name == ''){
		  				productIds = $scope.selectComparisions[i].model.id;
                        name = $scope.selectComparisions[i].model.displayName.replace(/ /g,"-");
			  			name = encodeURIComponent(name);
		  			} else {
                        productIds = productIds + "-" + $scope.selectComparisions[i].model.id;
		  				name = name + "-vs-" + $scope.selectComparisions[i].model.displayName.replace(/ /g,"-");
			  			name = encodeURIComponent(name);
                        Api.gaTrackEvent('(' +$scope.categoryName +') ' + $scope.currentPage + ' Page', 'Compare '+$scope.categoryName+' Button Clicked', name);
		  			}
		  			$scope.count = $scope.count + 1;
		  		}
		  	}
		  	if($scope.count > 1){
                path = path+"/"+productIds+"/"+name;
                path = encodeURI( path );
		  		$location.url( path );
		  		$scope.errorTipEnable = false;
		  	} else {
		  		$scope.errorTipEnable = true;
                $scope.errorMsg = "Please select at least 2 "+ categoryName +" to compare";
		  	}
		  	
	};
	
	$scope.modelSelected = function(model, index) {
		Api.gaTrackEvent('(' +$scope.categoryName +') ' + $scope.currentPage + ' Page', 'Model Selected', model.displayName);
		productDataExpecting[index] = model.id;
        var categoryId = Meta.getCategoryID();
  		Api.getProduct($scope.domainId, model.id, getProductDetails(), categoryId).then(function(response){
  			if(productDataExpecting[index] == response.productId) {
        		$rootScope.compareItems[index] = response;
        	}
  		});
  	};
  	
  	$scope.twoPhoneCompare = function(phone1, phone2) {
  		Api.gaTrackEvent('(' +$scope.categoryName +') ' + $scope.currentPage + ' Page', 'Popular Comparision Button Clicked', phone1 + "-vs-"+ phone2);
  	};
  	
  	var bodyClick = function(){
		angular.element('body').click(function(event) {
			if(! angular.element(event.target).parents('.compare_button_parent').length) {
				$scope.errorTipEnable = false;
				$scope.$apply();
			}
		});
	};
	
	var current = 0;
	
	var popularcompare2WidthHandling = function(){
		if(angular.element(".desktop_view").is(':visible')) {
			$scope.individualElementWidth = (angular.element('.last-of-type').innerWidth()/3) + 2;
			//Desktop view
		} else if(angular.element(".tablet_view").is(':visible')){
			$scope.individualElementWidth = (angular.element('.last-of-type').innerWidth()/2) + 2;
			//Tablet view
		} else {
			$scope.individualElementWidth = (angular.element('.last-of-type').innerWidth()/1) + 2;
			//Mobile view
		}
		setElementPosition();
	};
	
	$scope.twoCompareSlideToNextItem = function(){
		var sliderCount = 0;
		if(angular.element(".desktop_view").is(':visible')) {
			sliderCount = 3;
			//Desktop view
		} else if(angular.element(".tablet_view").is(':visible')){
			sliderCount = 2;
			//Tablet view
		} else {
			sliderCount = 1;
			//Mobile view
		}
		if(current < $scope.compareListAll.length - sliderCount){
			current = current + 1;
			setElementPosition();
		}
	};
	
	var setElementPosition = function(){
		var finalLeft = -(current * $scope.individualElementWidth);
		angular.element('.popular_2_slide_container').animate({left:  finalLeft + "px"}, "slow");
	};
	
	$scope.twoCompareSlideToPrevItem = function(){
		if(current > 0){
			current = current - 1;
			setElementPosition();
		}
	};
	
	$($window).resize(function(){popularcompare2WidthHandling(); $scope.$apply();});
	popularcompare2WidthHandling();
	bodyClick();

  }]);

