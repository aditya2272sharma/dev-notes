'use strict';

angular.module('buySmaartApp')
  .controller('WishListCtrl',['$scope', 'Api', '$location', '$rootScope', '$window',
	function ($scope, Api, $location, $rootScope, $window) {
		$rootScope.currentPage = "WishLIst";
        __insp.push(['tagSession', "Checked wishlist page"]);
		$scope.productInfo = [];
		var catogeryId;
		$scope.defultCurrency="\u20b9";
		$scope.menubar = true;


		/*Price pop-up related*/
		$scope.pricePopUpHeight = $window.innerHeight - 184;
		$scope.showPricePanel = false;
		$scope.closePricePanel = function(event){
			if( angular.element(event.target).hasClass('popup_overlay')){
				$scope.showPricePanel = false;
			}
		};
		$scope.getPriceInformation = function(id){
			$scope.showScreenBlocker = true;
			Api.getProductPriceAnalytics(catogeryId, id).then(function(response){
				$scope.productPrice = {};
				response = response.data;
				for(var i = 0, iLen = response.priceList.length; i < iLen; i++){
					if(	$scope.productPrice[response.priceList[i].seller.id] == null || 
						$scope.productPrice[response.priceList[i].seller.id] == undefined || 
						Number(response.priceList[i].price) < Number($scope.productPrice[response.priceList[i].seller.id].price)){
						$scope.productPrice[response.priceList[i].seller.id] = response.priceList[i];
					}
				}
            	$scope.showPricePanel = true;
            	$scope.showScreenBlocker = false;
      		});
		};
		/*End of price pop-up related*/
		
		/*Sticky related functions*/
		if(angular.element(".desktop_view").is(':visible')) {
			$scope.maxNumOfComp = 4;
			//Desktop view
		} else if(angular.element(".tablet_view").is(':visible')){
			$scope.maxNumOfComp = 3;
			//Tablet view
		} else {
			$scope.maxNumOfComp = 2;
			//Mobile view
		}
		
		 $scope.selectItemToCompare = function(event, index) {
		 	
		 	//first get the selected product
	        var selectedProduct = $scope.productInfo[index];
		 	
	    	if(!$scope.getIsProductInCompare(selectedProduct.productId) && $scope.compareItems.length == $scope.maxNumOfComp){
	    		angular.element(event.target).attr('checked', false);
	    		alert("You can not select more than " + $scope.maxNumOfComp + " " + $scope.categoryName + " to compare.");
	    		return;
	    	}
	        
	        
	        //now check if the product is available in the selected item list
	         var compareedItemIndex = -1;
	        for(var i = 0, iLen = $scope.compareItems.length; i < iLen; i++){
	        	if(selectedProduct.productId == $scope.compareItems[i].productId){
	        		compareedItemIndex = i;
	        		break;
	        	}
	        }
	        
	        //if present, remove it
	        //else push it to the array
	        if(compareedItemIndex != -1) {
	            $rootScope.compareItems.splice(compareedItemIndex,1);
	        } else  {
	            if($scope.compareItems.length < 4) {
	                $rootScope.compareItems.push(selectedProduct);
	            }
	        }
	    };
	    
	    $scope.getIsProductInCompare = function(productId){
	    	for(var i = 0, iLen = $scope.compareItems.length; i < iLen; i++){
	    		if($scope.compareItems[i].productId == productId){
	    			return true;
	    		}
	    	}
	    	return false;
	    };
		/*end of Sticky related functions*/
		
		
		/*** Functions related to meta tags. ***/
		var getIndividualProductDescriptionTags = function(name){
			return "Explore "+name+" features, "+name+" specs and "+name+" user reviews. Buy "+name+" online";
		};
		
		var getIndividualProductKeyWordsTags = function(name){
			return name+" specs, "+name+" features, "+name+" reviews, "+name+" camera, "+name+" camera reviews, "+name+" Battery, Buy "+name+" online";
		};
		
		$rootScope.description = "Wishlist and buy "+$scope.catogoryForMetaTags+" on buysmaart";
        $rootScope.keywords = "Wishlist and buy "+$scope.catogoryForMetaTags+" on buysmaart.";
		
		
		var setMetaData = function() {
			if(callCount == 0) {
				var desc = getIndividualProductDescriptionTags(nameArray[0]);
				var keywords = getIndividualProductKeyWordsTags(nameArray[0]);
				for(var i = 1, iLen = nameArray.length; i < iLen; i++) {
					desc = desc + ", " + getIndividualProductDescriptionTags(nameArray[i]);
					keywords = keywords + ", " +  getIndividualProductKeyWordsTags(nameArray[i]);
				}
				$rootScope.description = desc;
        		$rootScope.keywords = keywords;
			}
		};
		/*** end of Functions related to meta tags. ***/
		
		
		var getProductDetails = function() {
	        var params = {};
	        params.aspectMetadata = {};
	        for (var k in $rootScope.NLPFilters.aspects){
	            if(k != 'undefined') {
	                params.aspectMetadata[k] = {};
	                params.aspectMetadata[k].value = $rootScope.NLPFilters.aspects[k].value;
	                params.aspectMetadata[k].metadataId = $rootScope.NLPFilters.aspects[k].metadataId;
	            }
	        }
	        return params;
	    }
		
		var nameArray = [];
		var callCount = 0;
		var getProductInfo = function(index){
			callCount = callCount + 1;
			var categoryId = _.get( $rootScope, 'categoryId', 1);
  			Api.getProduct(catogeryId, $scope.wishList[index], getProductDetails(), categoryId).then(function(response){
  				response.noveltyList = '';
				for (var i=0, iLen = response.productNovelty.noveltyList.length; i < iLen; i++){
					response.noveltyList = response.noveltyList + ((response.noveltyList == '')?'':", ") + response.productNovelty.noveltyList[i];
				}
	        	$scope.productInfo[index] = response;
	        	nameArray[index] = response.displayName;
	        	callCount = callCount - 1;
	        	setMetaData();
	  		});
  		};
  		
  		var getProductsForWishList = function(){
  			if(catogeryId != null && catogeryId != undefined) {
	  			for(var i = 0, iLen = $scope.wishList.length; i < iLen; i++) {
	  				getProductInfo(i);
	  			}
	  		}
  		};
  		getProductsForWishList();
  		$rootScope.$on("hasWishListInfo",getProductsForWishList);
		
		var getProductDetails = function() {
		    var params = {};
		    params.aspectMetadata = {};
		    var aspects = $rootScope.config.aspects;
		    for (var k in aspects){
		        if(k != 'undefined') {
		            params.aspectMetadata[k] = {};
		            params.aspectMetadata[k].value = 3;
		            params.aspectMetadata[k].metadataId = aspects[k].metadataId;
		        }
		    }
		    return params;
		}

		var sendInitialCalls = function() {
			if($scope.isConfigAvaliable) {
				var domainId = $scope.config.domainId;
				var categoryId = _.get( $rootScope, 'categoryId', 1);
	    		// Api.fetchNewArrivals(domainId, categoryId, getProductDetails()).then(function(newArrivals){
			    //     $scope.newArrivals = newArrivals;
			    // });
			    // Api.fetchPopularComparisons(domainId, categoryId).then(function(comparisons){
			    //     $scope.compareList = comparisons;
			    // });
			    if($scope.isUserLoggedIn){
			    	getProductsForWishList();
			    }
  			}
  		};
  		$rootScope.$on("configUpdated",sendInitialCalls);
  		sendInitialCalls();
  		
  		var wishlistItemRemove = function(event, args) {
  			$scope.productInfo.splice(args.keyIndex, 1);
  			nameArray.splice(args.keyIndex, 1);
  			setMetaData();
  		};
  		$rootScope.$on("wishlistItemRemove",wishlistItemRemove);
  		
  		
  		var registerScrollEvent = function(){
			angular.element($window).unbind("scroll");
			angular.element($window).bind("scroll", function(e) {
			 		var topHeight = angular.element(".bs-header").outerHeight() + angular.element(".bs-stepcontainer").outerHeight();
			 		var scrollYVal = this.pageYOffset || this.scrollY;
			 		if(scrollYVal > topHeight){
			 			angular.element(".nav-container").addClass("fixed-nav-container");
			 			angular.element(".wishlist_sticky_compare").addClass("fixed-topsection");
                        //angular.element(".sortbyWrapper").addClass("activeLeft");
			 		} else {
			 			angular.element(".nav-container").removeClass("fixed-nav-container");
			 			angular.element(".wishlist_sticky_compare").removeClass("fixed-topsection");
                        //angular.element(".sortbyWrapper").removeClass("activeLeft");
			 		}
			  });
		};
		
		registerScrollEvent();
  		
  		  			
  			$scope.openSelfiLovers = function() {
  				Api.gaTrackEvent($scope.currentPage + 'CatogorySelected', 'SelfiLovers', 'SelfiLovers');
  				$rootScope.NLPFilters = angular.copy($rootScope.NLPFiltersDefaults);
  				$rootScope.NLPFilters.AspectValues["camera"] = 5;
  				$rootScope.NLPFilters.AspectValues["display"] = 3;
  				$rootScope.NLPFilters.AspectValues["battery"] = 3;
  				$rootScope.NLPFilters.AspectValues["performance"] = 3;
  				$scope.openDashboardPage();
  			};
  			
  			$scope.openBusinessTravelers = function() {
  				Api.gaTrackEvent($scope.currentPage + 'CatogorySelected', 'BusinessTravelers', 'BusinessTravelers');
  				$rootScope.NLPFilters = angular.copy($rootScope.NLPFiltersDefaults);
  				$rootScope.NLPFilters.AspectValues["camera"] = 3;
  				$rootScope.NLPFilters.AspectValues["display"] = 3;
  				$rootScope.NLPFilters.AspectValues["battery"] = 5;
  				$rootScope.NLPFilters.AspectValues["performance"] = 5;
  				$scope.openDashboardPage();
  			};
  			
  			$scope.openVideoAddicts = function() {
  				Api.gaTrackEvent($scope.currentPage + 'CatogorySelected', 'VideoAddicts', 'VideoAddicts');
  				$rootScope.NLPFilters = angular.copy($rootScope.NLPFiltersDefaults);
  				$rootScope.NLPFilters.AspectValues["camera"] = 3;
  				$rootScope.NLPFilters.AspectValues["display"] = 5;
  				$rootScope.NLPFilters.AspectValues["battery"] = 5;
  				$rootScope.NLPFilters.AspectValues["performance"] = 4;
  				$scope.openDashboardPage();
  			};
  			
  			$scope.openAvidGamers = function() {
  				Api.gaTrackEvent($scope.currentPage + 'CatogorySelected', 'AvidGamers', 'AvidGamers');
  				$rootScope.NLPFilters = angular.copy($rootScope.NLPFiltersDefaults);
  				$rootScope.NLPFilters.AspectValues["camera"] = 3;
  				$rootScope.NLPFilters.AspectValues["display"] = 3;
  				$rootScope.NLPFilters.AspectValues["battery"] = 5;
  				$rootScope.NLPFilters.AspectValues["performance"] = 5;
  				$scope.openDashboardPage();
  			};
  			
  			$scope.openWindowsPhone = function() {
  				Api.gaTrackEvent($scope.currentPage + 'CatogorySelected', 'WindowsPhone', 'WindowsPhone');
  				$rootScope.NLPFilters = angular.copy($rootScope.NLPFiltersDefaults);
  				$rootScope.NLPFilters.AspectValues["camera"] = 3;
  				$rootScope.NLPFilters.AspectValues["display"] = 3;
  				$rootScope.NLPFilters.AspectValues["battery"] = 3;
  				$rootScope.NLPFilters.AspectValues["performance"] = 3;
  				$rootScope.NLPFilters.PriceMaxValue = 10000;
  				$rootScope.NLPFilters.SelectedOsFilters.push('Windows');
  				$scope.openDashboardPage();
  			};
  			
  			$scope.openAndroidPhone = function() {
  				Api.gaTrackEvent($scope.currentPage + 'CatogorySelected', 'AndroidPhone', 'AndroidPhone');
  				$rootScope.NLPFilters = angular.copy($rootScope.NLPFiltersDefaults);
  				$rootScope.NLPFilters.AspectValues["camera"] = 3;
  				$rootScope.NLPFilters.AspectValues["display"] = 3;
  				$rootScope.NLPFilters.AspectValues["battery"] = 3;
  				$rootScope.NLPFilters.AspectValues["performance"] = 3;
  				$rootScope.NLPFilters.PriceMaxValue = 10000;
  				$rootScope.NLPFilters.SelectedOsFilters.push('Android');
  				$scope.openDashboardPage();
  			};
		    


        /*** Carousel for availab ***/
        $scope.direction = 'left';
        $scope.currentIndexForArivales = 0;

        $scope.isCurrentSlideIndexForArrivals = function (index) {
            return $scope.currentIndexForArivales === index;
        };

        $scope.prevSlideForArrivals = function () {
            $scope.direction = 'left';
            $scope.currentIndexForArivales = ($scope.currentIndexForArivales < $scope.newArrivals.length - 1) ? ++$scope.currentIndexForArivales : 0;
        };

        $scope.nextSlideForArrivals = function () {
            $scope.direction = 'right';
            $scope.currentIndexForArivales = ($scope.currentIndexForArivales > 0) ? --$scope.currentIndexForArivales : $scope.newArrivals.length - 1;
        };

        /*** Carousel for compare ***/
        $scope.currentIndexForCompare = 0;

        $scope.isCurrentSlideIndex = function (index) {
            return $scope.currentIndexForCompare === index;
        };

        $scope.prevSlide = function () {
            $scope.direction = 'left';
            $scope.currentIndexForCompare = ($scope.currentIndexForCompare < $scope.compareList.length - 1) ? ++$scope.currentIndexForCompare : 0;
        };

        $scope.nextSlide = function () {
            $scope.direction = 'right';
            $scope.currentIndexForCompare = ($scope.currentIndexForCompare > 0) ? --$scope.currentIndexForCompare : $scope.compareList.length - 1;
        };
  }]).run(["Api", '$rootScope', function(Api, $rootScope) {
  		$rootScope.wishList = [];
		var wishListObj = [];
	 	$rootScope.userLoginFunction = function(){
	 		if($rootScope.isUserLoggedIn) {
	    		Api.getWishListItems().then(function(response){
	    			$rootScope.wishList = [];
					var tempwishListObj = response.data;
					for(var i = 0, iLen = tempwishListObj.length; i < iLen; i++){
						if($rootScope.wishList.indexOf(tempwishListObj[i].productId + "") == -1) {
							$rootScope.wishList.push(tempwishListObj[i].productId + "");
							wishListObj.push(tempwishListObj[i]);
						}
					}
					$rootScope.$broadcast("hasWishListInfo");
				});
			}
	 	};
	 	$rootScope.userLoginFunction();
	 	
	 	$rootScope.updateWishList = function(id){
			var keyIndex = $rootScope.wishList.indexOf(id);
			if(keyIndex != -1){
				Api.removeFromWishlist(wishListObj[keyIndex].wishListId).then(function(response){
					$rootScope.wishList.splice(keyIndex, 1);
					wishListObj.splice(keyIndex, 1);
					$rootScope.$broadcast("wishlistItemRemove", {keyIndex: keyIndex});
				});
			} else {
				var pp = {
					productId: id
				};
				Api.addProductToWishlist(pp).then(function(response){
					$rootScope.wishList.push(response.data[0].productId + "");
					wishListObj.push(response.data[0]);
				});
			}
		};
	 	
  }]);
