'use strict';

angular.module('buySmaartApp')
  .controller('ProductPageCtrl',["$scope","$route","Api","Timerangepicker","$anchorScroll","$location", '$window', '$rootScope', '$sce','NLPFilterServices', 'Meta',
  					function ($scope,route,Api,Timerangepicker,anchorScroll,location, $window, $rootScope, $sce, NLPFilterServices, Meta) {
  		 $rootScope.showProductPageLoader = true;
       $scope.menubar = false;
	   $scope.innerMenubar = true;
	   $scope.altHeader = true;
     $scope.hideCroma = true;


       $scope.defaultImageURL = _.template('/images/ignore/${categoryName}_default.jpg')({
          "categoryName": Meta.getCategoryName()
        });
  		 $scope.delayBeforeLoad = 1;
  		 $scope.timeranges = Timerangepicker.fetchtimeRanges();
	     var selectedtimerangeindex = Timerangepicker.getselectedtimerange().id;
	     $scope.selectedtimerange = _.findWhere($scope.timeranges,{id:selectedtimerangeindex});
	     $rootScope.currentPage = "Product";
  		 $scope.delayBeforeLoad = 1;
		 $scope.defultCurrency="\u20b9";
  		 $scope.productid = route.current.params.productid;
       $scope.productCategoryName = route.current.params.productname;
       $scope.productCategory = route.current.params.productname.replace(/-/g," ").split(' ')[0];
  		 $scope.displayName = route.current.params.productname.replace(/-/g," ");

  		 // OLD --> $rootScope.title = $scope.displayName + " Price, Specifications, Sentiment, Reviews in India";
  		 $rootScope.settingProductMetaTags = function() {
  		 	__insp.push(['tagSession', "viewed"+$scope.displayName+"page"]);
  		 	var desc = $scope.displayName+" Price in India is "+$rootScope.minPrice+", Explore "+$scope.displayName+"Reviews and Specifications on buysmaart";
  		 	//var desc = "Explore  "+$scope.displayName+" features,  "+$scope.displayName+" specs and  "+$scope.displayName+" user reviews. Buy  "+$scope.displayName+" online.";
  		 	var keywords = $scope.displayName+" Price in India,"+$scope.displayName+" Specifications,"+$scope.displayName+" reviews, "+$scope.displayName+"online";
  		 	var title = $scope.displayName + " Price in India, Specifications and Reviews | Buysmaart";
  		 	// OLD --> $scope.displayName+" specs, "+$scope.displayName+" features,  "+$scope.displayName+" reviews, "
  		 	//+$scope.displayName+" camera, "+$scope.displayName+" camera reviews, "+$scope.displayName+" Battery, Buy "+$scope.displayName+" online";
  		 	/*** Setting Data for meta tags ***/
	         $rootScope.description = desc;
	         $rootScope.keywords = keywords;
	         $rootScope.title = title;

  		 };

		$scope.domainId = "smartphone";


		if(angular.element(".desktop_view").is(':visible')) {
			$scope.maxNumOfComp = 4;
			//Desktop view
		} else if(angular.element(".tablet_view").is(':visible')){
			$scope.maxNumOfComp = 3;
			//Tablet view
		} else {
			$scope.maxNumOfComp = 2;
			//Mobile view
		}

		
		 $scope.getIsProductInCompare = function(product123){
	    	for(var i = 0, iLen = $scope.compareItems.length; i < iLen; i++){
	    		if($scope.compareItems[i].productId == product123){
	    			return true;
	    		}
	    	}
	    	return false;
	    };

	    /*Price pop-up related*/
		$scope.pricePopUpHeight = $window.innerHeight - 184;
		$scope.showPricePanel = false;
		$scope.closePricePanel = function(event){
			if( angular.element(event.target).hasClass('popup_overlay')){
				$scope.showPricePanel = false;
			}
		};
		$scope.getPriceInformation = function(){
			Api.gaTrackEvent('('+$scope.categoryName+') ' + $scope.currentPage + ' Page', 'Buy Button Clicked', $scope.displayName);
			$scope.showPricePanel = true;
		};

		function createProductCategoryLink() {
			if($rootScope.isConfigAvaliable && $scope.productCategory !== undefined) {
		       var categoryName = Meta.getCategoryName();
		       $scope.productCategoryHref = NLPFilterServices.showModelsWithFilters("/"+categoryName+"/DiscoveryDashboard/", 0, $scope.productCategory);
		   }
		}

		$rootScope.$on('categoryConfigUpdated',createProductCategoryLink);
		createProductCategoryLink();

}]);

angular.module('buySmaartApp')
  .controller('ProductCtrl',["$scope","Api","Timerangepicker","$anchorScroll","$location", '$window', '$rootScope', '$sce',"Priceretailercolors", '$compile', "$q", "Meta",
  					function ($scope,Api,Timerangepicker,anchorScroll,location, $window, $rootScope, $sce,Priceretailercolors, $compile, $q, Meta) {

	$scope.timeranges = Timerangepicker.fetchtimeRanges()
    $scope.openCategories = {}
    $scope.sentimentReviews ={}
    $scope.RetailColorMap = Priceretailercolors.getRetailerColorMap()
    $scope.openCategories.opened = false
    var selectedtimerangeindex = Timerangepicker.getselectedtimerange().id
    $scope.selectedtimerange = _.findWhere($scope.timeranges,{id:selectedtimerangeindex})
    $scope.productSummary = { "showSummary": false };
	//This time out is to facilitate animation smooth;
	setTimeout(function() {
		var allReviews;
	    $scope.productDetailsTab = 2;
	    $scope.productDetailsSubTab = 1;

		$scope.leftPadding = 0;
	    $scope.showMore = false;
	    $scope.recommendations = [{}];
	    var reviewsHolder = [];
	    var categoryId = _.get( $rootScope, 'categoryId', 1);
	    Api.fetchSmaartpulseData(categoryId, $scope.productid).then(function(reviewCollection){
	        $scope.reviewCollection = reviewCollection
	        if(reviewCollection){
	            allReviews = _.flatten(_.pluck(reviewCollection.children,"children"))
	            reviewCollection.children.forEach(function(reviews){
	                reviews.children.forEach(function(review){
	                    review.categoryID= reviews.categoryAspectId
	                })

	                if(reviews.name =="Others"){
	                    reviewsHolder.push(reviews.children)
	                }
	                else {
	                    var sortedChild = _.sortBy(reviews.children,function(review){
	                        return review.count
	                    })
	                    reviewsHolder.push(sortedChild.reverse()[0])
	                }
	            })


	        }

	        var temp = _.flatten(reviewsHolder)
          if(temp.length > 0) {
            $scope.productDetailsTab = 2;
          } else {
            $scope.productDetailsTab = 1;
          }
	        if(temp.length>12)
	            $scope.SmaartPulseData = temp.slice(0,12)
	        else
	            $scope.SmaartPulseData = temp
	        resolvePrerequisites();
          getReviewCount(_.flatten(reviewsHolder));
	    })

      Api
      .getProductSummary($scope.domainId, $scope.productid)
      .then(function(response){
        var desc = _.get(response, "summary.summaryText[0].text", ""); //desc is a concatenation of 2 summary texts
        desc    += " ";
        desc    += _.get(response, "summary.summaryText[1].text", "");
        var pros = _.get(response, "summary.pros", []);
        var cons = _.get(response, "summary.cons", []);

        $scope.productSummary = {
          "desc": desc,
          "pros": pros,
          "cons": cons,
        };
        $scope.productSummary.showSummary = desc.length > 5 ? true : false; // if there is no text for summary, do not show anything
        $scope.productSummary.showPros = pros && pros.length > 0 ? true : false; // do not show pros/cons section if there is no data
        $scope.productSummary.showCons = cons && cons.length > 0 ? true : false;
      });

	    if($(".gallerythubHolder").css("left")=="auto"){
	        $(".gallerythubHolder").css("left",0);
	    }


		$scope.selectSmaartPulseAspect=function(aspect){
			Api.gaTrackEvent('('+$scope.categoryName+') ' + $scope.currentPage + ' Page', 'Smaart Pulse Tab', aspect+' Selected');
	        $scope.selectedSpec=aspect
	        if(aspect=="All"){
	            var temp = _.flatten(reviewsHolder)
	            if(temp) {
                $scope.SmaartPulseData = temp.slice(0,12);
                getReviewCount(temp);
	            }

	        }
	        else{
	            var temp = _.findWhere($scope.reviewCollection.children,{"name":aspect})
	            if(temp) {
                $scope.SmaartPulseData = temp.children.slice(0,12);
                getReviewCount(temp.children);
	            }
	        }
          var max = _.max($scope.SmaartPulseData, 'value');
          $scope.getNodeReviews( max );
	   };

      function getReviewCount(reviewNodes){
        $scope.reviewsByType = _.groupBy(reviewNodes,"sentimentType");
        var data = _.groupBy(reviewNodes,"sentimentType");

        //limiting the max no. of sorted-clusters to 9 on each side
        data.positive = _.sortBy(data.positive,function(item){
          return item.value;
        }).reverse().slice(0, 9);
        data.negative = _.sortBy(data.negative,function(item){
          return item.value;
        }).reverse().slice(0, 9);

        var positiveReviewCount = _.reduce(data.positive, function(result, obj, key) {
          return result + obj.value;
        }, 0);
        var negativeReviewCount = _.reduce(data.negative, function(result, obj, key) {
          return result + obj.value;
        }, 0);
        $scope.sentimentReviews.positiveReviewCount = {
          type: "positive",
          value: positiveReviewCount
        };
        $scope.sentimentReviews.negativeReviewCount = {
          type: "negative",
          value: negativeReviewCount
        };

        $scope.tabularChartData = [].concat.call( data.positive, data.negative );
      }

	   function getAspectsForScope() {
	   		var aspects = [];
	   		var count = 0;
			for(var i in $rootScope.NLPFilters.aspects) {
				aspects[count] = $rootScope.NLPFilters.aspects[i];
				count += 1;
			}
			return aspects;
	   }

	   $scope.aspects = getAspectsForScope();

	   $scope.selectedAspect = function(name) {
	   	Api.gaTrackEvent('('+$scope.categoryName+') ' + $scope.currentPage + ' Page', 'Technical Specification Tab', name);};
      $scope.getNodeReviews=function(node){
        $(".treemap-container").height("auto")
        $scope.reviews = {};
        if( $scope.loadingReviews != true ) {
          $scope.loadingReviews = true;
          Api
          .fetchIndividualReviews(categoryId, $scope.productid,encodeURIComponent(node.treemap),node.categoryID)
          .then(function(reviews){
            $scope.loadingReviews = false;
            reviews.forEach(function(review){
              review.sentimentType = node.sentimentType
            });
            $scope.reviews = reviews.slice(0,6);
            $scope.$$postDigest(function() {
              var element = $("body");
              if( location.path().indexOf("/DiscoveryDashboard") >= 0 ) {
                element = $("product-body");
              }
                $scope.loadingReviews = false;
            });
          });
        }
      };
      if( location.path().indexOf("/DiscoveryDashboard") >= 0 ) {
      $('#smaartpulselabel').click(function() {
         $('product-body').animate({
         scrollTop: ( $(".SmaartContent-section").offset().top)
        }, 500);
      });
      $('#specslabel').click(function() {
         $('product-body').animate({
         scrollTop: ( $(".Technicalcontent-section").offset().top)
      }, 500);
     });
    } else {
      $('#smaartpulselabel').click(function() {
         $('html,body').animate({
         scrollTop: ( $(".SmaartContent-section").offset().top)
        }, 500);
      });
      $('#specslabel').click(function() {
         $('html,body').animate({
         scrollTop: ( $(".Technicalcontent-section").offset().top)
      }, 500);
     });
    }
      $scope.scrollToTop = function(){
			angular.element('body,html').animate({scrollTop: 0}, "slow");
		};
		$(window).scroll(function() {
    if ($(window).scrollTop() > 500) {
        angular.element(".top_icon_wrapper").show();
    }
    else {
        angular.element(".top_icon_wrapper").hide();
    }
});

	    $scope.getProductReviewsCountByAspects = function(){
	        if($scope.config){
	            var aspectsString = "";
	            angular.forEach($scope.config.aspects, function(aspect, index){
	                aspectsString += aspect.aspectId;
	                if(index !== ($scope.config.aspects.length - 1)){
	                    aspectsString += ",";
	                }
	            });
	            Api.getProductReviewsCountByAspects("smartphone",$scope.productid,aspectsString).then(function(reviewCounts){
	                $scope.aspectReviewCount = reviewCounts;
	            });
	        }

	    };
	            $scope.getProductReviewsCountByAspects();

		$scope.setProductDetailsTab = function (tabId, tabName) {
			Api.gaTrackEvent('('+$scope.categoryName+') ' + $scope.currentPage + ' Page', 'Product Details Tab Selected', tabName);
			$scope.productDetailsTab = tabId;
			resolvePrerequisites( tabId, tabName );
		};
    $scope.setProductDetailsSubTab = function (tabId, tabName) {
     Api.gaTrackEvent('('+$scope.categoryName+') ' + $scope.currentPage + ' Page', 'Price Graph Tab', tabName);
     $scope.productDetailsSubTab = tabId;
    };
    $scope.similarProductClicked = function(value) {
    	Api.gaTrackEvent('('+$scope.categoryName+') ' + $scope.currentPage + ' Page', 'Similar Product Clicked', value);
    }
    $scope.movenext = function() {
      var imageCount = $scope.userSelectedProduct.images.length; // thumbnail window dimension 175x37px (WxH)
      var thumbnailWidth = $(".thumbHolder").outerWidth(); // mini-thumbnail dimension 37x39px (WxH)
      var thumbnailWidowWidth = $(".gallerythumbWrapper").width();

      var totalWidth = imageCount * thumbnailWidth;
      var maxLeft = Math.min(totalWidth, Math.abs(totalWidth - thumbnailWidowWidth));
      var currentLeft = $(".gallerythubHolder").css("left").split("px")[0];
        if(Math.abs(currentLeft) < maxLeft){
          $(".gallerythubHolder").css("left",parseInt(currentLeft)-$(".thumbHolder").width()+"px");
        }
	   };
    $scope.moveprev = function() {
      var currentLeft = $(".gallerythubHolder").css("left").split("px")[0];
        if(Math.round(currentLeft) < 0){
          $(".gallerythubHolder").css("left",parseInt(currentLeft)+$(".thumbHolder").width()+"px");
        }
	    };
		$scope.isProductDetailsTabSet = function (tabId) {
			return $scope.productDetailsTab === tabId;
		};
    $scope.isProductDetailsSubTabSet = function (tabId) {
     return $scope.productDetailsSubTab === tabId;
    };
		$scope.buyNowClicked = function(sellerName, ProductName,url) {
			Api.gaTrackEvent('('+$scope.categoryName+') ' + $scope.currentPage + ' Page', 'Buy Now Clicked', sellerName + ', ' + ProductName+ 'Clicked');
			var win = window.open(url, '_blank');
			win.focus();
		}
	    $scope.tabNavigation = function (flag) {
			if(flag == 'next') {
				$scope.productDetailsTab < 3 ? $scope.productDetailsTab++ : $scope.productDetailsTab = 3;
			} else {
				$scope.productDetailsTab > 0 ? $scope.productDetailsTab-- : $scope.productDetailsTab = 0;
			}
			$scope.leftPadding = $scope.productDetailsTab * (-120) + 'px';
		};

	    $scope.changeTimerange = function(timerange){
	    	Api.gaTrackEvent('(' +$scope.categoryName +') ' + $scope.currentPage + ' Page', 'Price Graph Time Range Changed', timerange.time);
	        $scope.selectedtimerange = timerange
	        Timerangepicker.setselectedtimerange($scope.selectedtimerange)
	        getRealPriceGraphData()
	    };
	    var getRealPriceGraphData = function(){
	        if($scope.selectedtimerange){
	        	var end = moment()
		        var formattedEndTime = end.format("YYYY-MM-DD")
		        var start = end.subtract($scope.selectedtimerange.duration)
		        var formattedStartTime = start.format("YYYY-MM-DD")
		        Api.fetchPriceGraphData($scope.productid,formattedStartTime,formattedEndTime,$scope.selectedtimerange.interval).then(function(response){
		            if($.isEmptyObject(response.sellerPricePointMap)){
		                $scope.PriceGraphDataUnavailable = true
		            }else{
		            	$scope.PriceGraphDataUnavailable = false
		                $scope.multilinechartdata = response.sellerPricePointMap
		            }
		        })
		    }
	    }
	    var getProductDetails = function() {
			var params = {};
			params.aspectMetadata = {};
			for (var k in $rootScope.NLPFilters.aspects){
				if(k != 'undefined') {
					params.aspectMetadata[k] = {};
					params.aspectMetadata[k].value = $rootScope.NLPFilters.aspects[k].value;
					params.aspectMetadata[k].metadataId = $rootScope.NLPFilters.aspects[k].metadataId;
				}
			}
			return params;
		}

	    var productDetailParams = getProductDetails();
	    var categoryId = _.get( $rootScope, 'categoryId', 1 );
	    Api.getProduct("smartphone",$scope.productid, productDetailParams, categoryId).then(function(response){
	        if(response){
              var smaartPulseDataLength;
	            response.productNovelty.noveltyList = _.uniq(_.get(response,"productNovelty.noveltyList",[]));
              $scope.userSelectedProduct = response;
              smaartPulseDataLength = _.get( $scope,'SmaartPulseData.length', 0);
	            if(!$scope.userSelectedProduct.priceAnalytics) {
                if(smaartPulseDataLength > 0) {
                  $scope.productDetailsTab = 2;
                } else {
	            	  $scope.productDetailsTab = 1;
                }
	            }
	            _.uniq($scope.userSelectedProduct.images)
	            if(response.priceAnalytics){
	                var pricesUpdated =  _.map(_.pluck(response.priceAnalytics.priceList,"updatedOn"),function(date){return moment(date)})
	                $scope.lastupdated = _.max(pricesUpdated);
	                response.data = response.priceAnalytics;
	            	var productPrice = Meta.getNormalizedPriceList(response);
	            	$scope.vendorList = _.map(productPrice, 'seller.name');
	            }
	            $scope.generateGraph('overallWeightedScore');
	            getRealPriceGraphData();
	            $rootScope.showProductPageLoader = false;
	            $rootScope.minPrice = _.get($scope, 'userSelectedProduct.priceAnalytics.minPrice', 5000);
	            $scope.maxPrice = _.get($scope, 'userSelectedProduct.priceAnalytics.maxPrice', 10000);

	   			if(response.analytics){
	   				var sortedAnalytics = _.sortBy(response.analytics.aspectScores, 'overallWeightedScore');
	   				$scope.sortedAspects = _.map(sortedAnalytics.reverse(), 'aspectId');
	   			}
	     		$scope.currency = response.currency;
	     		$scope.displayName = response.displayName;

	        }
	        if($rootScope.settingProductMetaTags){
	        	$rootScope.settingProductMetaTags();
	        }
	        setSEOFriendlyData();
	    });

	    function setSEOFriendlyData() {
	    	$scope.metaInformationList = {};
	    	if($rootScope.minPrice && $scope.lastupdated){
	    		$scope.maxPrice = Math.ceil($scope.minPrice/1000)*1000;
	    		$scope.metaInformationList.time = "The latest price of " + $scope.displayName + " was updated on " + $scope.lastupdated.format('LLLL');
	    		$scope.metaInformationList.price = "The best price of " + $scope.displayName + " is " + $scope.currency + " " + $rootScope.minPrice.split('.')[0];
	    		$scope.metaInformationList.vendors = "Buy " + $scope.displayName + " online in India for the lowest price. " + $scope.displayName + " is available online at " + $scope.vendorList;
	    		$scope.metaInformationList.ceiling = "The " + $scope.displayName + " is a good " + $scope.categoryName.slice(0, -1)+ " under " + $scope.currency + " " + $scope.maxPrice;
	    	}
	    	$scope.metaInformationList.specs = "The highest rated feature of " + $scope.displayName + " is ";

	    	var appender = "";
	    	for(var aspect in $scope.sortedAspects){
	    		$scope.metaInformationList.specs = $scope.metaInformationList.specs + appender;
	    		$scope.metaInformationList.specs = $scope.metaInformationList.specs + $scope.sortedAspects[aspect];
	    		appender = ", followed by ";
	    	}
	    }


	    $scope.generateGraph = function(type) {
	        var rectFill = "#ffffff";
	        var rectStroke = "#f4f4f4";
	        var lineStroke = "#f87700";
	        var barFill = "#3346b4";
	        var bodyFill = "#000";

	        if(type === "weightedSentimentScore"){
	            if(!$scope.userSelectedProduct.analytics.weightedSentimentScore){
	                return;
	            }
	        }
          $scope.viewingGraph = type;
	        if (type === 'overallWeightedScore') {
	            rectFill = "#ffffff";
	            rectStroke = "#f4f4f4";
	            lineStroke = "#1f5cd8";
	            barFill = "#49cc88";
	            bodyFill = "#000";
	        }

	        angular.element("#barChart").empty();
	        var input = $scope.getScoreGraphInput(type);
	        // Declare Variables
	        var margin = {
	                top: 25,
	                right: 20,
	                bottom: 30,
	                left: 30
	            },
	            barSpace = 25,
	            w = angular.element("#barChart").width() - margin.left - margin.right,
	            h = angular.element("#barChart").height() - 40;
	        //Create X Scale for bar graph
	        var xScale = d3.scale.ordinal()
	            .domain(input.map(function(d) {
	                return d.aspectId.toLowerCase();
	            }))
	            .rangeRoundBands([0, w], 0.09);
	        //Create Y Scale for bar graph
	        var yScale = d3.scale.linear()
	            .domain([0, 100])
	            .range([h, 0]);

	        var getSentimentNegativeRelativeScore = function(d){
	             var reviewCountObject = $scope.aspectReviewCount[d.aspectId];
               reviewCountObject.positive = parseInt(reviewCountObject.positive, 10); // without parseInt, we'll get NaN when we do a division
               reviewCountObject.negative = parseInt(reviewCountObject.negative, 10);
	             var totalReviews = reviewCountObject.positive + reviewCountObject.negative;
	             if(reviewCountObject.negative){
                if(totalReviews == 0){
                  return 0;
                }
	                 return (reviewCountObject.negative * d.score)/totalReviews;
	             }
	             return 0;
	        };

	        var getSentimentGraphBarColor = function(d){
	            var reviewCountObject = $scope.aspectReviewCount[d.aspectId];
	            var totalReviews = reviewCountObject.positive + reviewCountObject.negative;
	            var barColor = "#f98f2b";
	            if(totalReviews){
	                barColor = "#88dd77";
	            }
	            return barColor;
	       };

	        //Create X Axis
	        var xAxis = d3.svg.axis()
	            .scale(xScale)
	            .orient("bottom");

	        //Create Y Axis
	        var yAxis = d3.svg.axis()
	            .scale(yScale)
	            .tickValues([0, 25, 50, 75, 100])
	            .orient('left');

	        //Create SVG element
	        var svg = d3.select("#barChart")
	            .append("svg")
	            .attr("width", w + margin.left + margin.right)
	            .attr("height", h + margin.top + margin.bottom + 10)
	            .append('g')
	            .attr("transform", "translate(" + 40 + "," + margin.top + ")");

	        // creating rect for graph background
	        svg.append("rect")
	            .attr("width", w + 10)
	            .attr("height", h + margin.top)
	            .attr("fill", rectFill)
	            .attr("stroke", rectStroke)
	            .attr("transform", "translate(0," + (-margin.top) + ")")
	            .attr("class", "legendBar");
	        var windowWidth = $(window).width();
	        var XAxixTranslateX = -28;
	        if(windowWidth < 480){
	            XAxixTranslateX = -13;
	        } else if (windowWidth > 768) {
	            XAxixTranslateX = -20;
	        }

	        //Create X axis
	        svg.append("g")
	            .attr("class", "axis xAxis")
	            .attr("transform", "translate("+ XAxixTranslateX+ "," + h + ")")
	            .call(xAxis);

	        //Create Y axis
	        svg.append("g")
	            .attr("class", "axis yAxis")
	            .call(yAxis);

	        //Add rectangles
	        if(type === "weightedSentimentScore"){
	            svg.selectAll(".bar")
	                .data(input)
	                .enter()
	                .append("rect")
	                .attr("class", "bar")
	                .attr("x", function(d) {
	                    return xScale(d.lable) + barSpace;
	                })
	                .attr("y", 140)
	                .attr("height", 0)
	                .attr("width", 15)
	                .style("fill", function(d) {
	                    return getSentimentGraphBarColor(d);
	                })
	                .on("mouseover", function (d) { $scope.showSentimentPopover.call(this, d, 'positive'); })
	                .on("mouseout", function (d) { $scope.removePopovers(); })
	                .on("click", function (d) { $scope.sentimentBarClickHandler(d); })
	                .transition()
	                .delay(function(d, i) {
	                    return i * 100;
	                })
	                .attr("height", function(d) {
	                    return h - yScale(d.score);
	                })
	                .attr("y", function(d) {
	                    return yScale(d.score);
	                });

	            svg.selectAll(".negativebar")
	                .data(input)
	                .enter()
	                .append("rect")
	                .attr("class", "negativebar")
	                .attr("x", function(d) {
	                    return xScale(d.lable) + barSpace;
	                })
	                .attr("y", 140)
	                .attr("height", 0)
	                .attr("width", 15)
	                .style("fill", "#ff8877")
	                .on("mouseover", function (d) { $scope.showSentimentPopover.call(this, d, 'negative'); })
	                .on("mouseout", function (d) { $scope.removePopovers(); })
	                .on("click", function (d) { $scope.sentimentBarClickHandler(d); })
	                .transition()
	                .delay(function(d, i) {
	                    return i * 100;
	                })
	                .attr("height", function(d) {
	                    return h - yScale(getSentimentNegativeRelativeScore(d));
	                })
	                .attr("y", function(d) {
	                    return yScale(d.score);
	                });

	        } else {
	             svg.selectAll(".bar")
	                .data(input)
	                .enter()
	                .append("rect")
	                .attr("class", "bar")
	                .attr("x", function(d) {
	                    return xScale(d.lable) + barSpace;
	                })
	                .attr("y", 140)
	                .attr("height", 0)
	                .attr("width", 15)
	                .style("fill", barFill)
	                .transition()
	                .delay(function(d, i) {
	                    return i * 100;
	                })
	                .attr("height", function(d) {
	                    return h - yScale(d.score);
	                })
	                .attr("y", function(d) {
	                    return yScale(d.score);
	                });
	        }

	        svg.selectAll("body")
	            .data(input)
	            .enter()
	            .append("text")
	            .text(function(d) {
	                return d.score.toFixed(0);
	            })
	            .attr("text-anchor", "middle")
	            .attr("x", function(d, i) {
	                return (xScale(d.lable) + barSpace)+7;
	            })
	            .attr("y", function(d) {
	                return yScale(d.score + 5);
	            })
	            .attr("font-size", "0")
	            .transition()
	            .delay(function(d, i) {
	                return i * 100;
	            })
	            .attr("font-family", "sans-serif")
	            .attr("font-size", "10px")
	            .attr("fill", bodyFill);


	        svg.selectAll(".xAxis text").remove();

	        var aspectIcons = svg.selectAll(".xAxis g")
	                    .append("svg:image")
	                    .attr("xlink:href", function (d) {
                        var categoryName = "";
                        if(d == "display"){
                          categoryName = "_" + $scope.categoryName;
                        }
                        return "/images/ignore/"+d+"_icon"+ categoryName +".png" ;
                      })
	                    .attr("data-title", function (d) { return d; })
	                    .attr("x", -1)
	                    .attr("y", 4)
	                    .attr("height", 30)
	                    .attr("width", 30)
	                    .attr("class", "aspectIcon")
	                    .on("mouseover", function (d) { $scope.showPopover.call(this, d); })
	                    .on("mouseout", function (d) { $scope.removePopovers(); });

	    };
	    $scope.showPopover = function (d) {
	        $(this).popover({
	          placement: 'auto bottom',
	          container: 'body',
	          trigger: 'manual',
	          html : true,
	          title : '',
	          content: function() {
	            return $compile("<div class='iconTooltip' data-i18n=\"msg.smartphone.aspect."+d+"\">" + d +"</div>")($scope);
	          }
	        });
	        $(this).popover('show');
	    };
	    $scope.removePopovers = function() {
	        $('.popover').each(function() {
	          $(this).remove();
	        });
	    };
	    $scope.setSelectedGraph = function(selectedGraph) {
	        $scope.selectedGraph = selectedGraph;
	    };

	    $scope.getSelectedGraph = function() {
	        return $scope.selectedGraph;
	    };
	    $scope.getScoreGraphInput = function(type) {
	        $scope.setSelectedGraph(type);
	        $scope.scoreGraphInput = [];
	        angular.forEach($scope.userSelectedProduct.analytics.aspectScores, function(aspectScores) {
	            var scoreInput = {
	                score: 0,
	                lable: "",
	                aspectId:""
	            };
	            //populating $scope.config from rootScop in app.js
	            var configAspect = _.findWhere($scope.config.aspects, {
	                aspectId: aspectScores.aspectId
	            });
	            scoreInput.lable = _.get(configAspect, 'displayName', '').toLowerCase();
	            scoreInput.aspectId = configAspect.aspectId;
	            switch (type) {
	                case "overallWeightedScore":
	                    scoreInput.score = aspectScores.overallWeightedScore;
	                    $scope.scoreType = "BuySmaart"
	                    break;
	                case "weightedSentimentScore":
	                    scoreInput.score = aspectScores.weightedSentimentScore;
	                    $scope.scoreType = "SmaartPulse";
	                    break;
	                case "weightedSpecificationScore":
	                    scoreInput.score = aspectScores.weightedSpecificationScore;
	                    $scope.scoreType = "Specification";
	                    break;
	                default:
	                    break;
	            }
	            $scope.scoreGraphInput.push(scoreInput);
	        });
	        return $scope.scoreGraphInput;
	    };
	      $scope.notifyPriceFallSubscribe = function() {
	        //get the email ID
	        //alert($scope.notifyEmail);
	        //post the email to the backend
	        Api.createUserNotification({
	            email: $scope.notifyEmail
	        }).then(function(response) {
	            alert("response")
	        })
	      };
	      $scope.ratingCriteria = getProductDetails();
	      var categoryId = _.get( $rootScope, 'categoryId', 1 );
	      Api.getRecommendedProductsByRatingCriteria($scope.domainId, $scope.productid,$scope.ratingCriteria, categoryId).then(function(response) {
	          $scope.recommendations = response;
	      });
        var categoryName = Meta.getCategoryName();
	      Api.getProductSpecification($scope.domainId, $scope.productid, categoryName).then(function(response) {
	          $scope.technicalSpecs = response;
	          $scope.categorisedSpecs = {};
	          categoriseSpecs();
	      });
	      $scope.videoReviews=[];
	      $scope.slectedReview={};
	      Api.getVideoReviews($scope.domainId, $scope.productid).then(function(response) {
          if(!response || response.length == 0) {
            return;
          }
	          $scope.videoReviews = response;
	          $scope.slectedReview = $scope.videoReviews[0];
	           $scope.slectedReview.reviewURL = $sce.trustAsResourceUrl($scope.slectedReview.reviewURL.replace('/watch?v=', '/embed/').replace('https:','http:'));
	      });
	      $scope.changeSelectedReview=function(index, videoTitle) {
	      	Api.gaTrackEvent('(' +$scope.categoryName +') ' + $scope.currentPage + ' Page', 'video Selected', videoTitle);
	        $scope.slectedReview=$scope.videoReviews[index];
	        $scope.slectedReview.reviewURL = $sce.trustAsResourceUrl($scope.slectedReview.reviewURL.replace('/watch?v=', '/embed/').replace('https:','http:'));
	        if($scope.delayBeforeLoad == 1) {
	        	angular.element('body,html').animate({scrollTop:  angular.element(".Video-Mainsection").position().top}, "slow");

	        } else {
	        	angular.element('.Container_productdetails').animate({scrollTop:  angular.element(".Video-Mainsection").position().top}, "slow");

	        }
	      };


	   	$scope.resetHeigthOfDiv = function(refDiv){
	    	angular.element("."+refDiv).css('height','auto');
	    };


	      var categoriseSpecs = function() {
	        //now we neeed to categorise the specs
	        for(var i=0, ilen=$scope.technicalSpecs.length; i<ilen; i++) {
	            //check for the specCategory and push into the array
	            if($scope.categorisedSpecs[$scope.technicalSpecs[i].specCategory]) {
	                $scope.categorisedSpecs[$scope.technicalSpecs[i].specCategory].push($scope.technicalSpecs[i])
	            } else {
	                $scope.categorisedSpecs[$scope.technicalSpecs[i].specCategory] = []
	                $scope.categorisedSpecs[$scope.technicalSpecs[i].specCategory].push($scope.technicalSpecs[i])
	            }
	        }
		};

		/*Sticky related functions*/


			 $scope.selectItemToCompare = function(event, index) {
			 	//first get the selected product
		        var selectedProduct = (index == 0)? $scope.userSelectedProduct: $scope.recommendations[index - 1];

		    	if(!$scope.getIsProductInCompare(selectedProduct.productId) && $scope.compareItems.length == $scope.maxNumOfComp){
		    		angular.element(event.target).attr('checked', false);
		    		alert("You can not select more than " + $scope.maxNumOfComp +" " + $scope.categoryName +" to compare.");
		    		return;
		    	}

		        //now check if the product is available in the selected item list

		        var compareedItemIndex = -1;
		        for(var i = 0, iLen = $scope.compareItems.length; i < iLen; i++){
		        	if(selectedProduct.productId == $scope.compareItems[i].productId){
		        		compareedItemIndex = i;
		        		break;
		        	}
		        }

		        //var compareedItemIndex = $scope.compareItems.indexOf(selectedProduct);
		        //if present, remove it
		        //else push it to the array
		        if(compareedItemIndex != -1) {
		        		Api.gaTrackEvent('('+$scope.categoryName+') ' + $scope.currentPage + ' Page', 'Removed From Compare', selectedProduct.displayName);
		            $rootScope.compareItems.splice(compareedItemIndex,1);
		        } else  {
		            if($scope.compareItems.length < 4) {
		            	Api.gaTrackEvent('('+$scope.categoryName+') ' + $scope.currentPage + ' Page', 'Added To Compare', selectedProduct.displayName);
		                $rootScope.compareItems.push(selectedProduct);
		            }
		        }
		    };

		    $scope.getObjectLength = function(obj){
		    	return (obj)?Object.keys(obj).length : 0;
		    };

        function resolvePrerequisites ( tabId, tabName ) {
          var tabName = tabName || "";
          switch ( tabName ) {
            // case "": //enable this line for case when SmaartPulse is selected by default
            case "Smaart Pulse":
              if( _.isEmpty($scope.SmaartPulseData) ){
                return;
              }
              var max = _.max($scope.SmaartPulseData, 'value');
              $scope.getNodeReviews( max );
            break;

            case "Price Graph":
              $scope.showScreenBlocker = true;
              Api.getProductPriceAnalytics($scope.domainId, $scope.productid)
              .then(function(response) {
                var priceList = Meta.getNormalizedPriceList(response);
                $scope.productPrice = priceList;
                $scope.showScreenBlocker = false;
                var croma = _.filter(priceList, {
                  "seller": {
                    "name": "Croma Retail"
                  }
                });
                if( !!(croma && croma[0]) ) { // if croma is available, show croma
                  croma = croma[0];
                  $scope.hideCroma = false;
                  $scope.buyFromCroma = croma;
                } else {
                  $scope.hideCroma = true;
                  $scope.productDetailsSubTab = 0;  // set the retailers tab active
                }
              });
            break;

            default:
            break;
          }
        }
			/*end of Sticky related functions*/
		}, $scope.delayBeforeLoad);

  }]);
