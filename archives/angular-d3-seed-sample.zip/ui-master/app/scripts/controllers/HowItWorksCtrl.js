'use strict';

angular
  .module('buySmaartApp')
  .controller('HowItWorksCtrl', [
    '$scope',
    '$rootScope',
    'Api',
    '$route',
    '$location',
    'Meta',
  function ($scope, $rootScope, Api, $route, $location, Meta) {
    var PageConfig = {
      "categorywiseIconImages": {
        "Smartphones": "mobiles.svg",
        "Tablets": "mobiles.svg"
      }
    };
    var categoryName = Meta.getCategoryName();
    $scope.currentCategoryIcon = PageConfig.categorywiseIconImages[ categoryName ];
  }]);
