'use strict';

angular.module('buySmaartApp')
  .controller('MainCtrl',['$scope','$window','Api','Timerangepicker','$location', '$rootScope', 'Meta',
  				function ($scope,$window,Api,Timerangepicker,location, $rootScope, Meta) {


        var catogoryForMetaTags;

        /*** Code from Divami***/
	       	$rootScope.currentPage = "Home";
	       	$scope.show_searchResults = false;
  			$scope.showScreen = "DEFAULT";
  			$scope.defultCurrency="\u20b9";
  			// $rootScope.NLPFilters = angular.copy($rootScope.NLPFiltersDefaults);

        $scope.homeHeader = true;
        $scope.altHeader = false;
        $scope.menubar = true;
        $scope.defaultImageURL = _.template('/images/ignore/${categoryName}_default.jpg')({
          "categoryName": Meta.getCategoryName()
        });
  			//$rootScope.NLPFilters = angular.copy($rootScope.NLPFiltersDefaults);

        var categoryName = Meta.getCategoryName();
			$scope.openNextPage = function() {
				Api.gaTrackEvent($scope.currentPage + 'GetStartedClicked', 'GetStartedClicked', 'GetStartedClicked');
  				angular.element('.header-content').height(angular.element('.header-content').height() + "px");
  				angular.element('.visual-holder').css({"position":"absolute", width : '95%'}).hide('slide', {direction: 'left'}, 500);
  				angular.element('.start-holder').css({"position":"absolute", width : '97%'}).show('slide', {direction: 'right'}, 500, function() {
   					angular.element('.start-holder').css("position","relative");
   					angular.element('.visual-holder').css("position","relative");
   					angular.element('.header-content').css("height","auto");

  				});

  			};

      /*** Setting Data for meta tags ***/
      function setMetaTagsMain(){
        $rootScope.keywords = "BuySmaart, Search "+ $scope.catogoryForMetaTags + " specs, "+ $scope.catogoryForMetaTags + " reviews and ratings, compare "+ $scope.catogoryForMetaTags + " prices in India";
        // OLD --> "BuySmaart, Search " + $scope.catogoryForMetaTags + ", Compare " + $scope.catogoryForMetaTags +" prices, Buy " + $scope.catogoryForMetaTags + ", Best Android " + $scope.catogoryForMetaTags + ", Best Windows " + $scope.catogoryForMetaTags + ", Samsung " + $scope.catogoryForMetaTags + ", Micromax " + $scope.catogoryForMetaTags + ", Nokia " + $scope.catogoryForMetaTags + ", Apple IPhone Prices, Smartphone Prices, Phone reviews.";
        $rootScope.description = "BuySmaart helps you search " + $scope.catogoryForMetaTags + " and compare " + $scope.catogoryForMetaTags + " using Artificial Intelligence";
        // OLD --> "BuySmaart helps you search " + $scope.catogoryForMetaTags + " and compare " + $scope.catogoryForMetaTags + " using Artificial Intelligence";
        $rootScope.title = catogoryForMetaTags + " recommendations using Artificial Intelligence | Buysmaart";
      }


  			var bodyClick = function(){
				angular.element('body').click(function(event) {
					if(! angular.element(event.target).parents('.element_part_dropdown').length) {
						$scope.hideAllOverlays();
						$scope.$apply();
					}
				});
			};
  			bodyClick();

    $rootScope.$on("categoryConfigUpdated",function(){
      catogoryForMetaTags = Meta.getCategoryName();
      setMetaTagsMain();
    });

		/*** Hide overlaays ***/
		$scope.hideAllOverlays = function() {
			$scope.show_searchResults = false;
		};

       	/*** Search functionality ***/
       	$scope.updateSearchResults= function(newValue){
	        if(newValue && newValue != ""){
            var categoryId = _.get($rootScope, "categoryId", 1);
	            Api.fetchAutocompleteDetails(newValue, categoryId).then(function(response){
	            	for(var i = 0, iLen = response.length; i < iLen; i++){
	            		var splitedString = response[i].displayName.split(" ");
	            		response[i].brand = splitedString[0];
	            		response[i].displayName = splitedString[1];
	            		for(var j = 2, jLen = splitedString.length; j < jLen; j++){
	            			response[i].displayName = response[i].displayName + " " + splitedString[j];
	            		}
	            	}
	                $scope.searchSuggestions = response;
	                $scope.show_searchResults = true;
	            });
	        } else{
	        	$scope.searchSuggestions = [];
	        	$scope.show_searchResults = false;
	        }
	    };

  	/*** Code Ended from Divami***/

    //$scope.newArrivals=[{"id":1,"src":"img04.jpg","details":{"name":"Apple iPhone 6 Plus","min_price":"51,875"}},{"id":2,"src":"img03.jpg","details":{"name":"Samsung Ace Plus","min_price":"31,875"}}];
  	//$scope.compareList = [1,2,3,4];


    /*** Carousel for availab ***/
    $scope.direction = 'left';
    $scope.currentIndexForArivales = 0;

    $scope.isCurrentSlideIndexForArrivals = function (index) {
        return $scope.currentIndexForArivales === index;
    };

    $scope.prevSlideForArrivals = function () {
        updateNewArrivals();
        $scope.direction = 'left';
        $scope.currentIndexForArivales = ($scope.currentIndexForArivales < $scope.newArrivals.length - 1) ? ++$scope.currentIndexForArivales : 0;
    };

    $scope.nextSlideForArrivals = function () {
        updateNewArrivals();
        $scope.direction = 'right';
        $scope.currentIndexForArivales = ($scope.currentIndexForArivales > 0) ? --$scope.currentIndexForArivales : $scope.newArrivals.length - 1;
    };
    
    $scope.newArrivalClicked = function() {
      var index = $scope.currentIndexForArivales;
      Api.gaTrackEvent(eventCategoryName,'New Arrival Button Clicked' , $scope.newArrivals[index].displayName);
      var win = window.open($scope.categoryName+'/productdetails/'+$scope.newArrivals[index].productId+'/'+$rootScope.safeEscapeDisplayName($scope.newArrivals[index].displayName), '_self');
      win.focus();
    }

    function updateNewArrivals(){
      var lengthNewArrivalsALL = _.get($scope, "newArrivalsALL.length", 0);
      var lengthNewArrivals = _.get($scope, "newArrivals.length", 0);
      if( lengthNewArrivals != lengthNewArrivalsALL) {
        $scope.newArrivals = $scope.newArrivalsALL;
      }
    }

    $scope.searchDropDownClicked = function(ev) {
    	angular.element(".inputFieldFocus").focus();
    	ev.preventDefault();
		Api.gaTrackEvent($scope.currentPage + 'SearchClicked', 'SearchClicked', 'SearchClicked');
	};

    /*** Carousel for compare ***/
    $scope.currentIndexForCompare = 0;

    $scope.isCurrentSlideIndex = function (index) {
        return $scope.currentIndexForCompare === index;
    };

    $scope.prevSlide = function () {
        updateCompareList();
        $scope.direction = 'left';
        $scope.currentIndexForCompare = ($scope.currentIndexForCompare < $scope.compareList.length - 1) ? ++$scope.currentIndexForCompare : 0;
    };

    $scope.nextSlide = function () {
        updateCompareList();
        $scope.direction = 'right';
        $scope.currentIndexForCompare = ($scope.currentIndexForCompare > 0) ? --$scope.currentIndexForCompare : $scope.compareList.length - 1;
    };

    function updateCompareList () {
      var lengthCompareListAll = _.get($scope, "compareListAll.length", 0);
      var lengthCompareList = _.get($scope, "compareList.length", 0);
      if( lengthCompareList != lengthCompareListAll) {
        $scope.compareList = $scope.compareListAll;
      }
    }
    var eventCategoryName = '(' +categoryName +') ' + $scope.currentPage + ' Page';
    $scope.genreLinkClicked = function(data) {
      Api.gaTrackEvent(eventCategoryName,'Genre Link Clicked' , data.displayName);
      var win = window.open(data.href, '_self');
      win.focus();
    }
    $scope.googlePlayClicked = function() {
      Api.gaTrackEvent(eventCategoryName,'Google Play Link Clicked' , 'Google Play Link Clicked');
      var win = window.open('https://play.google.com/store/apps/details?id=cnbitstols.com.buysmaart&utm_source=global_co&utm_medium=prtnr&utm_content=Mar2515&utm_campaign=PartBadge&pcampaignid=MKT-Other-global-all-co-prtnr-py-PartBadge-Mar2515-1', '_blank');
      win.focus(); 
    }

    $scope.userComments = [	{ name: "Susmitha Tyagi", role: "Software Engineer", imageUrl: "images/ignore/img07.jpg", comment:"I am not too tech savvy, but I wanted to have the latest and best phone with top camera and display. Buysmaart helped me find this phone in a jiffy - using smaartview."},
    						{ name: "Sumalatha", role: "Student", imageUrl: "images/ignore/img08.jpg", comment:"I am a college-goer. I wanted a phone that could fit into my budget. I used buysmaart to find my phone. My earlier idea was to buy the Moto G. In found that the Moto E had the same buysmaart score and is 5K cheaper. Buysmaart helped me save time and money."},
    						{ name: "G.Devanathan", role: "Retired Accountant", imageUrl: "images/ignore/img09.jpg", comment:"I wanted a simple phone with Skype, a large display, and good quality speakers. At buysmaart, I was able to find my phone easily and get the same kind of guidance that any tech-savvy youngster would give me."},
    						{ name: "Subrahmanyam", role: "Doctor", imageUrl: "images/ignore/img10.jpg", comment:"Being a doctor means being on call 24 by 7. It also means travelling to conferences. I wanted the best phone for busy travellers. Buysmaart helped me find the right one."}];

  	$scope.commentIndex = 0;
  	$scope.updateUserComment = function(index){
		$scope.commentIndex = index;
	};

    $scope.openNewWindowForReaders = function(link, title) {
        $window.open(link, title, 'directories=no,titlebar=no,toolbar=no,location=no,status=no,menubar=no','width:100%');
    };


  }]).animation('.slide-animation', function () {
        return {
            beforeAddClass: function (element, className, done) {
                var scope = element.scope();

                if (className == 'ng-hide') {
                    var finishPoint = element.parent().width();
                    if(scope.direction !== 'right') {
                        finishPoint = -finishPoint;
                    }
                    TweenMax.to(element, 0.5, {left: finishPoint, onComplete: done });
                }
                else {
                    done();
                }
            },
            removeClass: function (element, className, done) {
                var scope = element.scope();

                if (className == 'ng-hide') {
                    element.removeClass('ng-hide');

                    var startPoint = element.parent().width();
                    if(scope.direction === 'right') {
                        startPoint = -startPoint;
                    }

                    TweenMax.fromTo(element, 0.5, { left: startPoint }, {left: 0, onComplete: done });
                }
                else {
                    done();
                }
            }
        };
   });
