'use strict';

angular.module('buySmaartApp')
  .controller('DiscoveryDashboardCtrl',['$scope','Api','Timerangepicker', '$window', '$location', '$route', '$rootScope','$timeout','$interval', '$compile', 'Meta', 'NLPFilterServices',
  								function ($scope,Api,Timerangepicker, $window, $location, route, $rootScope, $timeout, $interval, $compile, Meta, NLPFilterServices) {
      	$scope.menubar = true;
      	$scope.changeInFilters = false;
      	$scope.homeHeader = true;
	  	$scope.innerMenubar = false;
      	$rootScope.currentPage = "DiscoveryDashboard";
		__insp.push(['tagSession', "visited DiscoveryDashboard"]);
		$scope.showFiltersPopOver = false;
		var cast = function (value){
    		if (value === "undefined") return undefined;
    		if (value === "null") return null;
    		if (value === "true") return true;
    		if (value === "false") return false;
    		var v = Number (value);
    		return isNaN (v) ? value : v;
		};
		var domainId;
		var categoryId;
		var arrayOfAspectTips = ["Is least important","Is unimportant", "Is moderately important","Is very important","Is most important"];
		var optionsStringFromURL = {};
		var categoryName = Meta.getCategoryName();
		// var optionsStringFromURL = route.current.params.options;
		if(route.current.params.ratingCriteria){
			optionsStringFromURL = JSON.parse(route.current.params.ratingCriteria);
		}
		else{
			optionsStringFromURL = $rootScope.myParams;
			for(var key in route.current.params){
				if (route.current.params.hasOwnProperty(key)) {
					var iterables = null;
					if(typeof route.current.params[key] == "string"){
						iterables = route.current.params[key].split(',');
					}
					else{
						iterables = route.current.params[key];
					}
    				route.current.params[key] = cast(route.current.params[key]);
    				var path = $rootScope.lookup[categoryName][key];
    				var foo = _.get(optionsStringFromURL, path, "ignore");
    				if(Object.prototype.toString.call( foo ) === '[object Array]'){
    					foo = [];
    					for(var iterable in iterables){
    						foo.push(iterables[iterable]);
    					}
    					_.set(optionsStringFromURL, path, foo);	
    				}
    				else{
    					if(foo != "ignore")
    					_.set(optionsStringFromURL, path, route.current.params[key]);
    				}
  				}
			}
		}
		categoryId = Meta.getCategoryID();
		var metadataString = route.current.params.metadataString
		$scope.pricePopUpHeight = $window.innerHeight - 184;

		$scope.selectedTextForTime="";
		$scope.selectedTextForPrice="";
		$scope.selectedTextForScore="";

		var updateDiscoveryDashBoardUrl = function() {
	    $rootScope.openDashboardPage();
	  };

		var timeSort = null;
		var priceSort = null;
		var scoreSort = null;
		var optionsFromURL = {};
		if(optionsStringFromURL != null && optionsStringFromURL != undefined) {
			try {
				optionsFromURL = optionsStringFromURL;
				categoryId = optionsFromURL.categoryId;
				timeSort = optionsFromURL.TimeSort;
				$scope.timeSort = optionsFromURL.TimeSort;
				priceSort = optionsFromURL.PriceSort;
				$scope.priceSort = optionsFromURL.PriceSort;
				scoreSort = optionsFromURL.ScoreSort;
				$scope.scoreSort = optionsFromURL.ScoreSort;
				$scope.priceMinValue = "\u20b9 " + angular.copy(optionsFromURL.PriceMinValue);
				$scope.priceMinValueForCompare = angular.copy(optionsFromURL.PriceMinValue);
				$scope.priceMaxValueForCompare = angular.copy(optionsFromURL.PriceMaxValue);
				$scope.priceMaxValue = "\u20b9 " + angular.copy(optionsFromURL.PriceMaxValue);
				$scope.allProducts = angular.copy(optionsFromURL.allProducts);
				$scope.specificationWeight = angular.copy(optionsFromURL.SpecificationWeight);
				$scope.sentimentWeight = angular.copy(optionsFromURL.SentimentWeight);
				$scope.selectedFilter = [];
				for(var i in optionsFromURL.filters) {
					var selectedFilter = {};
					selectedFilter.filterId = optionsFromURL.filters[i].filterId;
					selectedFilter.metadataId = optionsFromURL.filters[i].metadataId;
					selectedFilter.selectedFilters = [];
					for(var j in optionsFromURL.filters[i].selectedFilters) {
						selectedFilter.selectedFilters.push(optionsFromURL.filters[i].selectedFilters[j])
					}
					$scope.selectedFilter.push(selectedFilter);
				}
				$scope.aspects = angular.copy(optionsFromURL.aspects);
			}
			catch(err) {
			    updateDiscoveryDashBoardUrl();
			}
		} else {
			updateDiscoveryDashBoardUrl();
		}

		if(angular.element(".desktop_view").is(':visible')) {
			$scope.maxNumOfComp = 4;
			//Desktop view
		} else if(angular.element(".tablet_view").is(':visible')){
			$scope.maxNumOfComp = 3;
			//Tablet view
		} else {
			$scope.maxNumOfComp = 2;
			//Mobile view
		}


		$scope.defultCurrency="\u20b9";
		$scope.showPricePanel = false;
		var page = 0;
		var pageSize = 12;
		$scope.totalProductCountForSearch = 0;
		$scope.showScreenBlocker = true;
		$scope.showPaginationLoader = false;
		var isCallInProgress = true;
		var fetchConfigarationsCallInProgress= true;
		$scope.timeSortOptions = Meta.getTimeSortOptions();
		$scope.priceSortOptions = [
			{name: "Low to High", key:"asc", sortBy: 'Price'},
			{name: "High to Low", key:"desc", sortBy: 'Price'}
		];

		$scope.scoreSortOptions = [
			{name: "Low to High", key:"asc", sortBy: 'Score'},
			{name: "High to Low", key:"desc", sortBy: 'Score'}
		];

		$scope.selectedTextForTime  = _.filter($scope.timeSortOptions,  { "key": optionsFromURL.TimeSort  });
		$scope.selectedTextForScore = _.filter($scope.scoreSortOptions, { "key": optionsFromURL.ScoreSort });
		$scope.selectedTextForPrice = _.filter($scope.priceSortOptions, { "key": optionsFromURL.PriceSort });
		if($scope.selectedTextForTime.length > 0){
			$scope.selectedTextForSort = _.pluck($scope.selectedTextForTime, "name");
			$scope.sortBy = _.pluck($scope.selectedTextForTime, "sortBy");
		}
		if($scope.selectedTextForScore.length > 0){
			$scope.selectedTextForSort = _.pluck($scope.selectedTextForScore, "name");
			$scope.sortBy = _.pluck($scope.selectedTextForScore, "sortBy");
		}
		if($scope.selectedTextForPrice.length > 0){
			$scope.selectedTextForSort = _.pluck($scope.selectedTextForPrice, "name");
			$scope.sortBy = _.pluck($scope.selectedTextForPrice, "sortBy");
		}

		$scope.scrollToTop = function(){
			angular.element('body,html').animate({scrollTop: 0}, "slow");
			//$window.scrollTo(0, 0);
		};

		$scope.closePricePanel = function(event){
			if( angular.element(event.target).hasClass('popup_overlay')){
				$scope.showPricePanel = false;
			}
		};

		$scope.priceRangeChanged = function() {
			Api.gaTrackEvent('(' +$scope.categoryName +') ' + $scope.currentPage + ' Page', 'Show From This Range Button Clicked', $scope.priceMinValue + " To " + $scope.priceMaxValue);
		};


		$scope.screenFilterUpdated = function(key){
			var keyIndex = selectedScreenFilter.indexOf(key);
			if(keyIndex == -1){
				selectedScreenFilter.push(key);
			} else{
				selectedScreenFilter.splice(keyIndex,1);
			}
				updateProducts();
		};

		$scope.getCheckState = function( filterIndex, $index ) {
			// var keyIndex = selectedScreenFilter.indexOf(key);
			// if(keyIndex == -1){
			// 	return false;
			// } else{
			// 	return true;
			// }
			if( $scope.selectAllFilter[filterIndex] ) { // if everything is selected, or nothing is selected, we've a zero state
				return false;
			} else {
				return $scope.showTickFilter[filterIndex][$index];
			}
		};

		$scope.getPriceInformation = function(id, name){
			Api.gaTrackEvent('('+$scope.categoryName+') ' + $scope.currentPage + ' Page', 'Buy Button Clicked', name);
			$scope.showScreenBlocker = true;
			Api.getProductPriceAnalytics(domainId, id).then(function(response){
				$scope.productPrice = Meta.getNormalizedPriceList(response);
            	$scope.showPricePanel = true;
            	$scope.showScreenBlocker = false;
      		});
		};

		$scope.dontShowThisBrand = function(key){
			if(excludedBrandList.indexOf(key) == -1){
				excludedBrandList.push(key);
			}
			updateProducts();
		};

		$scope.brandFilterUpdated = function(key, isSelected) {
			if(isSelected){
				interSelectedBrandFilters.push(key);
			} else {
				var index = interSelectedBrandFilters.indexOf(key);
				if (index > -1) {
				    interSelectedBrandFilters.splice(index, 1);
				}
			}

			if(interSelectedBrandFilters.length == $scope.allBrands.length) {
				$scope.selectAllBrand = true;
			} else {
				$scope.selectAllBrand = false;
			}
		};


		$scope.$watchGroup([
			'sentimentWeight',
			'specificationWeight',
			'priceMaxValue',
			'priceMinValue',
			'allProducts',
			'timeSort',
			'priceSort',
			'scoreSort',
			'aspects',
			'selectedFilter'
		], function(newValues, oldValues, scope) {
			$scope.changeInFilters = true;
		});
		var verifyChangeInFilters = function() {
			if($scope.changeInFilters == true) {
				return true;
			}
			if(	$rootScope.NLPFilters.SentimentWeight != $scope.sentimentWeight ||
				$rootScope.NLPFilters.SpecificationWeight != $scope.specificationWeight ||
				$rootScope.NLPFilters.PriceMaxValue != ( $scope.priceMaxValue.split(" "))[1] ||
				$rootScope.NLPFilters.PriceMinValue != ( $scope.priceMinValue.split(" "))[1] ||
				$rootScope.NLPFilters.TimeSort != timeSort ||
				$rootScope.NLPFilters.PriceSort != priceSort ||
				$rootScope.NLPFilters.ScoreSort != scoreSort ||
				$rootScope.NLPFilters.allProducts != $scope.allProducts ){
				return true;
			}

			for(var key in $scope.aspects){
				if($scope.aspects[key].value != $rootScope.NLPFilters.aspects[key].value){
					return true;
				}
			}

			for(var i in $scope.selectedFilter){
				if($scope.selectedFilter[i].selectedFilters.length == $scope.selectedFilter[i].allFilters.length){
					$scope.selectedFilterselectedFilter[i].selectedFilters = [];
				}
				if($rootScope.NLPFilters.filters[i].selectedFilters){
					if($rootScope.NLPFilters.filters[i].selectedFilters.length == $rootScope.NLPFilters.filters[i].allFilters.length){
						$rootScope.NLPFilters.filters[i].selectedFilters = [];
					}
					if($scope.selectedFilter[i].selectedFilters.length == $rootScope.NLPFilters.filters[i].selectedFilters.length){
						for(var key in $scope.selectedFilter[i].selectedFilters){
							if($rootScope.NLPFilters.filters[i].selectedFilters.indexOf($scope.selectedFilter[i].selectedFilters[key]) == -1){
								return true;
							}
						}
					} else {
						return true;
					}
				}
				else{
					return true;
				}
			}
			/*
			if(excludedBrandList.length == $rootScope.NLPFilters.ExcludedBrandList.length){
				for(var i = 0, iLen = excludedBrandList.length; i < iLen; i++){
					if ($rootScope.NLPFilters.ExcludedBrandList.indexOf(excludedBrandList[i]) == -1) {
					    return true;
					}
				}
			} else {
				return true;
			}

			if(selectedScreenFilter.length == $rootScope.NLPFilters.SelectedScreenFilter.length){
				for(var i = 0, iLen = selectedScreenFilter.length; i < iLen; i++){
					if ($rootScope.NLPFilters.SelectedScreenFilter.indexOf(selectedScreenFilter[i]) == -1) {
					    return true;
					}
				}
			} else {
				return true;
			}
			*/

			return false;
		};
		$scope.filtersDoneButtonClicked = function() {
			updateProducts();
			var sFilters = "";
			for(var i in $scope.selectedFilter) {
				if($scope.selectedFilter[i].selectedFilters.length == 0){
					$scope.nplFilterText[i] = 'Select '+ $scope.selectedFilter[i].filterId;
				} else
				if($scope.selectedFilter[i].selectedFilters.length == $scope.selectedFilter[i].allFilters.length) {
					$scope.nplFilterText[i] = 'Any '+ $scope.selectedFilter[i].filterId;
				} else {
					$scope.nplFilterText[i] = $scope.selectedFilter[i].selectedFilters.length+' '+$scope.selectedFilter[i].filterId + ($scope.selectedFilter[i].selectedFilters.length > 1 ? 's':'');
				}
			}
			// if($scope.selectedFilter[].length == 0 || $scope.selectedBrandFilters.length == $scope.allBrands.length){
			// 	$scope.brandText = "Any Brand";
			// } else {
			// 	$scope.brandText = $scope.selectedBrandFilters.length + (($scope.selectedBrandFilters.length == 1)? " Brand" : " Brands");
			// }
			// if($scope.selectedOsFilters.length == 0 || $scope.selectedOsFilters.length == $scope.allOs.length){
			// 	$scope.osText = "Any Phone";
			// } else {
			// 	$scope.osText = $scope.selectedOsFilters.length + (($scope.selectedOsFilters.length == 1)? " OS" : " OS's");
			// }
		};

		$scope.filtersUpdated = function(index, key, isSelected) {
			if(isSelected){
				$scope.selectedFilter[index].selectedFilters.push(key);
			} else {
				var keyIndex = $scope.selectedFilter[index].selectedFilters.indexOf(key);
				if (keyIndex > -1) {
				    $scope.selectedFilter[index].selectedFilters.splice(keyIndex, 1);
				}
			}

			if($scope.selectedFilter[index].selectedFilters.length == $scope.selectedFilter[index].allFilters.length) {
				$scope.selectAllFilter[index] = true;
			} else {
				$scope.selectAllFilter[index] = false;
			}
		};

		var bodyClick = function(){
			angular.element('body').click(function(event) {
				if(! angular.element(event.target).hasClass('bs-downarrow')){
					angular.element(".bs-downarrow").removeClass("dropdownactive");
				}
				if(! angular.element(event.target).parents('.element_part_dropdown').length) {
					for(var i in $scope.showFilterList) {
						$scope.showFilterList[i] = false;
					}
					// undoFiltersState();
					$scope.$apply();
				}
				if(!angular.element(event.target).parents('.filters320').length && !angular.element(event.target).hasClass('filters320')){
					$scope.showFiltersPopOver = false;
					$scope.$apply();
				}
				if(!angular.element(event.target).parents('.sortby320').length && !angular.element(event.target).hasClass('sortby320')){
					$scope.showSortPopOver = false;
					$scope.$apply();
				}
			});
		};

		var undoFiltersState = function(){

			var selectedFilters = $scope.selectedFilter;
			for(var i in selectedFilters) {
				for(var j in selectedFilters[i].allFilters) {
					if(selectedFilters[i].selectedFilters.length == 0 || selectedFilters[i].selectedFilters.length == selectedFilters[i].allFilters.length)
						$scope.showTickFilter[i][j] = true;
					else
						$scope.showTickFilter[i][j] = ((selectedFilters[i].selectedFilters.indexOf(selectedFilters[i].allFilters[j]) == -1) ? false:true);
				}
			}

			for(var i in selectedFilters) {
				if(selectedFilters[i].selectedFilters.length == 0 || selectedFilters[i].selectedFilters.length == selectedFilters[i].allFilters)
					$scope.selectAllFilter[i] = true;
				else
					$scope.selectAllFilter[i] = false;
			}
		};

		$scope.clearActive = function(event){
			angular.element(".bs-downarrow").removeClass("dropdownactive");
			if(! angular.element(event.currentTarget).parent().hasClass("open")){
				angular.element(event.currentTarget).find(".bs-downarrow").addClass("dropdownactive");
			}
		};



		var registerScrollEvent = function(){
			angular.element($window).unbind("scroll");
			angular.element($window).bind("scroll", function(e) {
			 		var topHeight	 = angular.element(".header-section").outerHeight( true )
			 						 + (angular.element(".discovery_dashboard_steps_styling").is(':visible') ? angular.element(".discovery_dashboard_steps_styling").outerHeight(true) : 0)
			 						 + (angular.element(".headeroptionsbar").is(':visible') ? angular.element(".headeroptionsbar").outerHeight(true) : 0 )
			 						 + (angular.element(".discovery_dashboard_headsection_active_styling").is(':visible') ?angular.element(".discovery_dashboard_headsection_active_styling").outerHeight(true) : 0)
			 						 + angular.element(".topsection").outerHeight(true)
			 						 - (($scope.compareItems.length)? 166 : 67);//67 //166
			 		var scrollYVal = this.pageYOffset || this.scrollY;

          var docHeight = $(document).height();
          var scrollHeight = $(document).scrollTop();
          var footerHeight = angular.element("#footer").height();
          var diff = docHeight-footerHeight;

			 		if(scrollYVal > topHeight && scrollHeight < diff-150){
			 			angular.element(".stickey").show();
                        angular.element(".top_icon_wrapper").show();
			 		} else {
			 			angular.element(".stickey").hide();
                       	angular.element(".top_icon_wrapper").hide();
			 		}
			  });
		};

		$scope.loadMoreRecords = function(){
			Api.gaTrackEvent('('+$scope.categoryName+') ' + $scope.currentPage + ' Page', 'Load More Button Clicked', 'Load More Button Clicked');
			if(!isCallInProgress && $scope.products.length < $scope.totalProductCountForSearch) {
				isCallInProgress = true;
				$scope.showPaginationLoader = true;
				page = page + 1;
				getProductsByRatingCriteria(buildFilterInfo());
			}
		};

		var metadataDescForBrand = function(name) {
			return "explore "+ name +" phone specs and features" ;
		};
		var metadataKeywordsForBrand = function(name) {
			return "best " + name +" "+ $scope.catogoryForMetaTags + ", "+ name + " " + $scope.catogoryForMetaTags + " specs ratings reviews and prices" ;
		};

		var metadataDescForOs = function(name) {
			return "best " + name + " "+$scope.catogoryForMetaTags;
		};
		var metadataKeywordsForOs = function(name) {
			return "best " + name +" "+ $scope.catogoryForMetaTags;
		};

		var metadataDescForOsCurrency = function(name) {
			return "best "+ name +" "+ $scope.catogoryForMetaTags +" under " + ( $scope.priceMaxValue.split(" "))[1];
		};

		function setMetaDataForDashoad(highestAspect) {
			var d = new Date();
			var month = new Array();
			month[0] = "January";
			month[1] = "February";
			month[2] = "March";
			month[3] = "April";
			month[4] = "May";
			month[5] = "June";
			month[6] = "July";
			month[7] = "August";
			month[8] = "September";
			month[9] = "October";
			month[10] = "November";
			month[11] = "December";
			var list = "";
			var desc = "";
			var keywords = "";
			var title = "";
			for(var filter in $scope.selectedFilter){
				if($scope.selectedFilter[filter].selectedFilters.length == 1 && !list){
					list = list + $scope.selectedFilter[filter].selectedFilters[0];
				}
			}
			if(route.current.params.options){
				title = "Best " + list + " " + highestAspect.name + " " + $scope.catogoryForMetaTags + " under " + $scope.priceMaxValue + " | Buysmaart";
				keywords = "Best " + list + " " + highestAspect.name + " " + $scope.categoryForMetaTags + " under " + $scope.priceMaxValue + ", Best " + list + " " + highestAspect.name + " " + $scope.categoryForMetaTags + ", Best "+ highestAspect.name + " "+ $scope.categoryForMetaTags + " under "+ $scope.priceMaxValue;
				desc = "Discover, compare and buy the best "+ list +" "+ highestAspect.name +" "+ $scope.catogoryForMetaTags +" online under "+ $scope.priceMaxValue +" using Buysmaart.";
			}
			else{
				if(list){
					var _month = month[d.getMonth()];
					var _year = d.getFullYear();
					title = list + " " + $scope.catogoryForMetaTags +" Price List in India "+ _month + " " + _year +" | Buysmaart";
					keywords = list + " " + $scope.catogoryForMetaTags + " price in India, "+ list + " " + $scope.catogoryForMetaTags + " price list, " +list + " " + $scope.catogoryForMetaTags + " list";
					desc = "Find all " + list + " " + $scope.catogoryForMetaTags + " prices online in India, Find " + list + " " + $scope.catogoryForMetaTags + " specifications and reviews in India on Buysmaart";
				}
				else{
					title = "Best "+ $scope.catogoryForMetaTags +" under " + $scope.priceMaxValue +" | Buysmaart";
					keywords = "Best "+ $scope.catogoryForMetaTags +" under "+ $scope.priceMaxValue +" in India";
					desc = "Discover, compare and buy the best "+ $scope.catogoryForMetaTags +" under "+ $scope.priceMaxValue +" on Buysmaart";
				}
			}

	/*		if($scope.selectedBrandFilters.length == 0 || $scope.selectedBrandFilters.length == $scope.allBrands.length) {
				// desc = desc + ', ' + metadataDescForBrand("Apple");
				// desc = desc + ', ' + metadataDescForBrand("Samsung");
				// desc = desc + ', ' + metadataDescForBrand("Nokia");
				// desc = desc + ', ' + metadataDescForBrand("Micromax");
//
				// keywords = keywords + ', ' + metadataKeywordsForBrand("Apple");
				// keywords = keywords + ', ' + metadataKeywordsForBrand("Samsung");
				// keywords = keywords + ', ' + metadataKeywordsForBrand("Nokia");
				// keywords = keywords + ', ' + metadataKeywordsForBrand("Micromax");
			} else {
				for(var i = 0, iLen = $scope.selectedBrandFilters.length; i < iLen; i++){
					desc = desc + ', ' + metadataDescForBrand($scope.selectedBrandFilters[i]);
					keywords = keywords + ', ' + metadataKeywordsForBrand($scope.selectedBrandFilters[i]);
				}
			}

			if($scope.selectedOsFilters.length == 0 || $scope.selectedOsFilters.length == $scope.allOs.length) {
				desc = desc + ', ' + metadataDescForOs("Android");
				desc = desc + ', ' + metadataDescForOs("iOS");
				desc = desc + ', ' + metadataDescForOs("Windows");

				keywords = keywords + ', ' + metadataKeywordsForOs("Android");
				keywords = keywords + ', ' + metadataKeywordsForOs("iOS");
				keywords = keywords + ', ' + metadataKeywordsForOs("Windows");
			} else {
				for(var i = 0, iLen = $scope.selectedOsFilters.length; i < iLen; i++){
					desc = desc + ', ' + metadataDescForOs($scope.selectedOsFilters[i]);
					keywords = keywords + ', ' + metadataKeywordsForOs($scope.selectedOsFilters[i]);
				}
			}

			for (var k in $scope.aspectValues){
				if($scope.aspectValues[k] == 5) {
					desc = desc + '. Find best ' + k +" "+ $scope.catogoryForMetaTags;
					keywords = keywords + ', Best ' + k +" "+ $scope.catogoryForMetaTags;
				}
			}

			desc = desc + '. Use BuySmaart to discover and explore best '+ $scope.catogoryForMetaTags +' under' + ( $scope.priceMaxValue.split(" "))[1];
			keywords = keywords + ', ' + "best phones "+ $scope.catogoryForMetaTags +" "+ ( $scope.priceMaxValue.split(" "))[1];
			if($scope.selectedOsFilters.length == 0 || $scope.selectedOsFilters.length == $scope.allOs.length) {
				desc = desc + ', ' + metadataDescForOsCurrency("Android");
				desc = desc + ', ' + metadataDescForOsCurrency("iOS");
				desc = desc + ', ' + metadataDescForOsCurrency("Windows");

				keywords = keywords + ', ' + metadataDescForOsCurrency("Android");
				keywords = keywords + ', ' + metadataDescForOsCurrency("iOS");
				keywords = keywords + ', ' + metadataDescForOsCurrency("Windows");
			} else {
				for(var i = 0, iLen = $scope.selectedOsFilters.length; i < iLen; i++){
					desc = desc + ', ' + metadataDescForOsCurrency($scope.selectedOsFilters[i]);
					keywords = keywords + ', ' + metadataDescForOsCurrency($scope.selectedOsFilters[i]);
				}
			}
			*/
			$rootScope.description = desc;
        	$rootScope.keywords = keywords;
        	$rootScope.title = title;
		};

		function buildMetaInfo(){
			var params = {};
			params.aspectMetadata = {};
			var highestAspect = null;
			var value = 0;
			for (var k in $scope.aspects){
				// if(k != 'undefined') {
					params.aspectMetadata[k] = {};
					params.aspectMetadata[k].value = $scope.aspects[k].value;
					params.aspectMetadata[k].metadataId = $scope.aspects[k].metadataId;
					if(value < $scope.aspects[k].value){
						highestAspect = $scope.aspects[k];
						value = highestAspect.value;
					}
				// }
			}
			setMetaDataForDashoad(highestAspect);
		}
		buildMetaInfo();

		var buildFilterInfo = function() {
			var params = {};
			params.aspectMetadata = {};
			for (var k in $scope.aspects){
				// if(k != 'undefined') {
					params.aspectMetadata[k] = {};
					params.aspectMetadata[k].value = $scope.aspects[k].value;
					params.aspectMetadata[k].metadataId = $scope.aspects[k].metadataId;
				// }
			}

			params.sortOrder = {};
			params.applicableFilters = [];
			var currentFilterEntity = [];
			var _subFilterableItems = [];
			for(var i in $scope.selectedFilter) {
				params.applicableFilters[i] = {};
				params.applicableFilters[i].filterId = $scope.selectedFilter[i].filterId;
				params.applicableFilters[i].metadataId = $scope.selectedFilter[i].metadataId;
				params.applicableFilters[i].filterType = 'listFilter';
				params.applicableFilters[i].filterableItems = [];
				if($scope.selectedFilter[i].selectedFilters.length != 0) {
					_.each($scope.selectedFilter[i].selectedFilters, function(filterItem){
						currentFilterEntity = _.find($scope.selectedFilter[i].allFilters, {
							"displayName": filterItem
						});
						if(currentFilterEntity){
							_subFilterableItems = _subFilterableItems.concat(_.get(currentFilterEntity, "subFilterableItems", null));
						}
					})

					if(_.get(_subFilterableItems, "length", false)){
						_.each(_subFilterableItems, function(item, key){
							params.applicableFilters[i].filterableItems.push({
								itemId: item.itemId,
								operation: 'INCLUDE'
							})
						})
					} else {
					for(var j in $scope.selectedFilter[i].selectedFilters) {
						params.applicableFilters[i].filterableItems.push({
							itemId: $scope.selectedFilter[i].selectedFilters[j],
							operation: 'INCLUDE'
						});
					}
					}

				}
			}
			var listFilterLength = params.applicableFilters.length;
			params.applicableFilters[listFilterLength] = {};
			params.applicableFilters[listFilterLength].filterId = "price";
			params.applicableFilters[listFilterLength].filterType="rangeFilter";
			params.applicableFilters[listFilterLength].maxValue = ( $scope.priceMaxValue.split(" "))[1];
			params.applicableFilters[listFilterLength].minValue = ( $scope.priceMinValue.split(" "))[1];

			params.sentimentWeight = $scope.sentimentWeight;
			params.specificationWeight = $scope.specificationWeight;
			if(timeSort != null){
				params.sortOrder.time = timeSort;
			}
			if(priceSort != null){
				params.sortOrder.price = priceSort;
			}
			if(scoreSort != null){
				params.sortOrder.bsScore = scoreSort;
			}
			if(params.sortOrder.time === undefined && params.sortOrder.price === undefined && params.sortOrder.bsScore === undefined) {
				params.sortOrder.bsScore = "desc";
			}

			params.allProducts = $scope.allProducts;

			var paramsString = JSON.stringify(params);

			return paramsString;
		};

		var getProductsCountByRatingCriteria = function(pp) {
			var categoryId = Meta.getCategoryID();
			Api.getProductsCountByRatingCriteria(domainId, pp, categoryId).then(function(response){
				if(response == undefined){
					$scope.totalProductCountForSearch = "No";
					return;
				}
            	$scope.totalProductCountForSearch = response;
      		});
		};

		var getProductsByRatingCriteria = function(pp) {
			var categoryId = Meta.getCategoryID();
			Api.getProductsByRatingCriteria(domainId, pp, page, pageSize, categoryId).then(function(response){
				if(response == undefined){
					$scope.showScreenBlocker = false;
	            	$scope.showPaginationLoader = false;
	            	isCallInProgress = false;
	            	$scope.showFiltersPopOver = false;
					return;
				}
				$scope.products = $scope.products.concat(response);
            	$scope.showScreenBlocker = false;
            	$scope.showPaginationLoader = false;
            	isCallInProgress = false;
            	$scope.showFiltersPopOver = false;
            	$scope.categoryName = route.current.params.categoryName;
            	$scope.defaultImageSrc = getDefaultImageSrc($scope.categoryName);
            	$timeout(function(){
            		$scope.$apply();
            	},0)

      		});
		};

    function getDefaultImageSrc( categoryName ){
      var src = '';
      switch( categoryName ) {
        case 'Smartphones':
        src = '/images/ignore/Mobiles_default.jpg';
        break;

        case 'Tablet':
        case 'Tablets':
        src = '/images/ignore/Tablets_default.png';
        break;
        
        case 'Laptops':
        src = '/images/ignore/Laptops_default.jpg';
        break;

        case 'Televisions':
        src = '/images/ignore/Televisions_default.jpg';
        break;

        case 'AirConditioners':
        case 'Air Conditioners':
        src = '/images/ignore/Air Conditioners_default.jpg';
        break;

        default:
        src = '/images/ignore/_default.jpg';
        break;
      }
      return src;
    }
    $scope.getDefaultImageSrc = getDefaultImageSrc;


		var updateProducts = function() {
			if(verifyChangeInFilters()){
				$rootScope.NLPFilters.aspects = angular.copy($scope.aspects);
				$rootScope.NLPFilters.SentimentWeight = angular.copy($scope.sentimentWeight);
				$rootScope.NLPFilters.SpecificationWeight = angular.copy($scope.specificationWeight);
				$rootScope.NLPFilters.PriceMinValue = angular.copy(( $scope.priceMinValue.split(" "))[1] ? ( $scope.priceMinValue.split(" "))[1] : ( $scope.priceMinValue.split(" "))[0]);
				$rootScope.NLPFilters.PriceMaxValue = angular.copy(( $scope.priceMaxValue.split(" "))[1] ? ( $scope.priceMaxValue.split(" "))[1] : ( $scope.priceMaxValue.split(" "))[0]);
				$rootScope.NLPFilters.TimeSort = angular.copy(timeSort);
				$rootScope.NLPFilters.PriceSort = angular.copy(priceSort);
				$rootScope.NLPFilters.ScoreSort = angular.copy(scoreSort);
				$rootScope.NLPFilters.filters= angular.copy($scope.selectedFilter);
				$rootScope.NLPFilters.allProducts = angular.copy($scope.allProducts);
				$rootScope.nplFilterText = angular.copy($scope.nplFilterText);
				updateDiscoveryDashBoardUrl();

				page = 0;
				isCallInProgress = true;
			}
		};

		$scope.updateProducts = function(){
			Api.gaTrackEvent('('+$scope.categoryName+') ' + $scope.currentPage + ' Page', 'Include out of stock checkbox clicked', 'Include out of stock checkbox clicked');
			updateProducts();
		};

		var sendInitialCalls = function(){
			if($scope.isConfigAvaliable) {
            	domainId = $rootScope.NLPFilters.domainId;
            	$scope.showFilterList = new Array();
            	$scope.showTickFilter = new Array();
            	$scope.selectAllFilter = new Array();
            	$scope.nplFilterText = [];
				for(var i in $scope.selectedFilter) {
					$scope.showFilterList[i] = false;
					$scope.showTickFilter[i] = new Array();
					var allFiltersPath = _.template('NLPFilters.filters[${i}].allFilters')({ i: i }); // legacy: ignore
					var allFilters = _.get($rootScope, allFiltersPath, {}); // legacy: ignore
					allFilters = _.find($rootScope.NLPFilters.filters, {
						filterId: $scope.selectedFilter[i].filterId
					});
					allFilters = allFilters ? allFilters['allFilters'] : [];
					$scope.selectedFilter[i].allFilters = allFilters;
					if($scope.selectedFilter[i].selectedFilters.length ==  0
						|| $scope.selectedFilter[i].selectedFilters.length == $scope.selectedFilter[i].allFilters.length) {
							if($scope.selectedFilter[i].selectedFilters.length ==  0){
								$scope.nplFilterText[i] = 'Select ' + $scope.selectedFilter[i].filterId;
								for(var j in $scope.selectedFilter[i].allFilters) {
									$scope.showTickFilter[i][j] = false;
								}
								$scope.selectAllFilter[i] = true;
							} else {
								$scope.nplFilterText[i] = 'Any ' + $scope.selectedFilter[i].filterId;
								for(var j in $scope.selectedFilter[i].allFilters) {
									$scope.showTickFilter[i][j] = true;
								}
								$scope.selectAllFilter[i] = false;
							}
					}
					else {
						$scope.nplFilterText[i] = $scope.selectedFilter[i].selectedFilters.length + ' '+$scope.selectedFilter[i].filterId + ($scope.selectedFilter[i].selectedFilters.length > 1 ? 's':'');
						$scope.selectAllFilter[i] = false;
						for(var j in $scope.selectedFilter[i].allFilters) {
							$scope.showTickFilter[i][j] = (($scope.selectedFilter[i].selectedFilters
								.indexOf($rootScope.NLPFilters.filters[i].allFilters[j].itemId) == -1) ? false:true);
						}
					}
				}
            	fetchConfigarationsCallInProgress = false;
            	getProductsAfterAllCalls();
			}
     	};

        $rootScope.$on("categoryConfigUpdated",sendInitialCalls);


        $scope.clickOnSelectAllFilter = function(index){
        	$scope.selectedFilter[index].selectedFilters = [];
			if(!$scope.selectAllFilter[index]) {
				for(var i = 0, iLen = $scope.showTickFilter[index].length; i < iLen; i++){
					$scope.showTickFilter[index][i] = false;
				}
			} else {
				for(var i in  $scope.selectedFilter[index].allFilters){
					$scope.selectedFilter[index].selectedFilters.push($scope.selectedFilter[index].allFilters[i].itemId);
				}
				for(var i = 0, iLen = $scope.showTickFilter[index].length; i < iLen; i++){
					$scope.showTickFilter[index][i] = true;
				}
			}
			$scope.selectAllFilter[index] = !($scope.selectAllFilter[index]);
        };


        var getProductsAfterAllCalls = function(){
			if(!fetchConfigarationsCallInProgress){
				page = 0;
				$scope.products = [];
				isCallInProgress = true;
            	$scope.showScreenBlocker = true;
				var pp = buildFilterInfo();
				getProductsByRatingCriteria(pp);
				getProductsCountByRatingCriteria(pp);
				$rootScope.catogoryForMetaTags = Meta.getCategoryName();
				buildMetaInfo();
			}
		};

		$scope.verifyPriceMinValue = function(value){
			$scope.priceMinValueForCompare = value;
			if(parseInt($scope.priceMinValueForCompare) > parseInt($scope.priceMaxValueForCompare)){
				angular.element(".price_popup_body").show();
			} else {
				angular.element(".price_popup_body").hide();
			}

		};

		$scope.verifyPriceMaxValue = function(value){
			$scope.priceMaxValueForCompare = value;
			if(parseInt($scope.priceMinValueForCompare) > parseInt($scope.priceMaxValueForCompare)){
				angular.element(".price_popup_body").show();
			} else {
				angular.element(".price_popup_body").hide();
			}
		};

       $scope.minPriceInputFocusIn = function(value){
       		$scope.priceMinValue = (value.split(" "))[1];
       };
       $scope.maxPriceInputFocusIn = function(value){
       		$scope.priceMaxValue = (value.split(" "))[1];
       };
       $scope.minPriceInputBlur = function(value){
       		angular.element(".price_popup_body").hide();
       		if(parseInt(value)< parseInt($scope.priceMaxValueForCompare) && value != ''){
       			$scope.priceMinValueForCompare = value;
       			$scope.priceMinValue = "\u20b9 " + value;
       		} else {
       			$scope.priceMinValue = "\u20b9 " + angular.copy($rootScope.NLPFilters.PriceMinValue);
				$scope.priceMinValueForCompare = angular.copy($rootScope.NLPFilters.PriceMinValue);
       		}
       };

		$scope.maxPriceInputBlur = function(value){
			angular.element(".price_popup_body").hide();
			if(parseInt(value) > parseInt($scope.priceMinValueForCompare) && value != ''){
				$scope.priceMaxValueForCompare = value;
       			$scope.priceMaxValue = "\u20b9 " + value;
	       	} else {
	       		$scope.priceMaxValue = "\u20b9 " + angular.copy($rootScope.NLPFilters.PriceMaxValue);
				$scope.priceMaxValueForCompare = angular.copy($rootScope.NLPFilters.PriceMaxValue);
	       	}
       };

		$scope.sliderChanged = function(index){
			angular.element(".tipBody_" + index).css({"display":"block"}).html(arrayOfAspectTips[$scope.aspects[index].value - 1]);
			setTipPosition($scope.aspects[index].value,  angular.element(".tipHead_" + index).css({"display":"block"}));
		};

		$scope.sentimentSliderChanged = function(index){
			angular.element(".tipBody_" + index).css({"display":"block"}).html(arrayOfAspectTips[$scope.sentimentWeight - 1]);
			setTipPosition($scope.sentimentWeight, angular.element(".tipHead_" + index).css({"display":"block"}));
		};
		$scope.specificationSliderChanged = function(index){
			angular.element(".tipBody_" + index).css({"display":"block"}).html(arrayOfAspectTips[$scope.specificationWeight - 1]);
			setTipPosition($scope.specificationWeight, angular.element(".tipHead_" + index).css({"display":"block"}));
		};

		var setTipPosition = function(value, element) {
			switch(value - 1){
				case 0:
					element.css({"left": "-5px"});
				break;
				case 1:
					element.css({"left": "22%"});
				break;
				case 2:
					element.css({"left": "47%"});
				break;
				case 3:
					element.css({"left": "73%"});
				break;
				case 4:
					element.css({"left": "96%"});
				break;
			}
		};

		$scope.sliderUpdated = function(index, value){
			Api.gaTrackEvent('('+$scope.categoryName+') ' + $scope.currentPage + ' Page', index +' Aspect Slider Changed', value);
			angular.element(".tipBody_" + index).css({"display":"none"});
			angular.element(".tipHead_" + index).css({"display":"none"});
			updateProducts();
		};

		$scope.timeSortChanged = function(key, name, sortBy) {
			Api.gaTrackEvent('('+$scope.categoryName+') ' + $scope.currentPage + ' Page', 'Date Sort Clicked', name);
			$scope.selectedTextForPrice = "";
			$scope.selectedTextForScore = "";
			priceSort = null;
			scoreSort = null;
			timeSort = key;
			//$scope.selectedTextForTime=name;
      $scope.selectedTextForSort = name;
      $scope.sortBy = sortBy;
			updateProducts();
		};
		$scope.priceSortChanged = function(key, name, sortBy) {
			Api.gaTrackEvent('('+$scope.categoryName+') ' + $scope.currentPage + ' Page', 'Price Sort Clicked', name);
			$scope.selectedTextForTime = "";
			$scope.selectedTextForScore = "";
			scoreSort = null;
			timeSort = null;
			priceSort = key;
			//$scope.selectedTextForPrice=name;
      $scope.selectedTextForSort = name;
      $scope.sortBy = sortBy;
			updateProducts();
		};
		$scope.scoreSortChanged = function(key, name, sortBy) {
			Api.gaTrackEvent('('+$scope.categoryName+') ' + $scope.currentPage + ' Page', 'Score Sort Clicked', name);
			$scope.selectedTextForTime = "";
			$scope.selectedTextForPrice = "";
			priceSort = null;
			timeSort = null;
			scoreSort = key;
			//$scope.selectedTextForScore=name;
      $scope.selectedTextForSort = name;
      $scope.sortBy = sortBy;
			updateProducts();
		};

  if( $location.path().indexOf("DiscoveryDashboard") >= 0 ) {
    ( $rootScope.isConfigAvaliable && sendInitialCalls() );
  } else {
    //Placeholder for new implementation
    ( $rootScope.isConfigAvaliable && sendInitialCalls() ); //allowing to pass through temporarily
    Api.getPlaceholderForFutureMethod("foo","bar")
  }
  registerScrollEvent();
  bodyClick();



    $scope.selectItemToCompare = function(event, index) {
    	//first get the selected product
        var selectedProduct = $scope.products[index];
    	if(!$scope.getIsProductInCompare(selectedProduct.productId) && $scope.compareItems.length == $scope.maxNumOfComp){
    		angular.element(event.target).attr('checked', false);
    		alert("You can not select more than " + $scope.maxNumOfComp + " " + $scope.categoryName + " to compare.");
    		return;
    	}



        //now check if the product is available in the selected item list
         var compareedItemIndex = -1;
        for(var i = 0, iLen = $scope.compareItems.length; i < iLen; i++){
        	if(selectedProduct.productId == $scope.compareItems[i].productId){
        		compareedItemIndex = i;
        		break;
        	}
        }

        //if present, remove it
        //else push it to the array
        if(compareedItemIndex != -1) {
        	Api.gaTrackEvent('('+$scope.categoryName+') ' + $scope.currentPage + ' Page', 'Removed From Compare', selectedProduct.displayName);
            $rootScope.compareItems.splice(compareedItemIndex,1);
        } else  {
        	Api.gaTrackEvent('('+$scope.categoryName+') ' + $scope.currentPage + ' Page', 'Added To Compare', selectedProduct.displayName);
            if($scope.compareItems.length < 4) {
                $rootScope.compareItems.push(selectedProduct);
            }
        }
    };


	  $scope.getIsProductInCompare = function(productId){
    	for(var i = 0, iLen = $scope.compareItems.length; i < iLen; i++){
    		if($scope.compareItems[i].productId == productId){
    			return true;
    		}
    	}
    	return false;
    };
    $scope.filtersClicked = function(name) {
    	Api.gaTrackEvent('('+$scope.categoryName+') ' + $scope.currentPage + ' Page', 'Filters Clicked' , name+' Filters Clicked');
    }
    $scope.genreLinkClicked = function (data) {
    	Api.gaTrackEvent('('+$scope.categoryName+') ' + $scope.currentPage + ' Page','Genre Link Clicked' , data.displayName);
    }
    /*** tile related functions ***/

  			$scope.openSelfiLovers = function() {
  				Api.gaTrackEvent($scope.currentPage + 'CatogorySelected', 'SelfiLovers', 'SelfiLovers');
  				// $rootScope.NLPFilters = angular.copy($rootScope.NLPFiltersDefaults);
  				// $rootScope.NLPFilters.AspectValues["camera"] = 5;
  				// $rootScope.NLPFilters.AspectValues["display"] = 3;
  				// $rootScope.NLPFilters.AspectValues["battery"] = 3;
  				// $rootScope.NLPFilters.AspectValues["performance"] = 3;
  				$scope.openDashboardPage();
  			};

  			$scope.openBusinessTravelers = function() {
  				Api.gaTrackEvent($scope.currentPage + 'CatogorySelected', 'BusinessTravelers', 'BusinessTravelers');
  				// $rootScope.NLPFilters = angular.copy($rootScope.NLPFiltersDefaults);
  				// $rootScope.NLPFilters.AspectValues["camera"] = 3;
  				// $rootScope.NLPFilters.AspectValues["display"] = 3;
  				// $rootScope.NLPFilters.AspectValues["battery"] = 5;
  				// $rootScope.NLPFilters.AspectValues["performance"] = 5;
  				$scope.openDashboardPage();
  			};

  			$scope.openVideoAddicts = function() {
  				Api.gaTrackEvent($scope.currentPage + 'CatogorySelected', 'VideoAddicts', 'VideoAddicts');
  				// $rootScope.NLPFilters = angular.copy($rootScope.NLPFiltersDefaults);
  				// $rootScope.NLPFilters.AspectValues["camera"] = 3;
  				// $rootScope.NLPFilters.AspectValues["display"] = 5;
  				// $rootScope.NLPFilters.AspectValues["battery"] = 5;
  				// $rootScope.NLPFilters.AspectValues["performance"] = 4;
  				$scope.openDashboardPage();
  			};

  			$scope.openAvidGamers = function() {
  				Api.gaTrackEvent($scope.currentPage + 'CatogorySelected', 'AvidGamers', 'AvidGamers');
  				// $rootScope.NLPFilters = angular.copy($rootScope.NLPFiltersDefaults);
  				// $rootScope.NLPFilters.AspectValues["camera"] = 3;
  				// $rootScope.NLPFilters.AspectValues["display"] = 3;
  				// $rootScope.NLPFilters.AspectValues["battery"] = 5;
  				// $rootScope.NLPFilters.AspectValues["performance"] = 5;
  				$scope.openDashboardPage();
  			};

  			$scope.openWindowsPhone = function() {
  				Api.gaTrackEvent($scope.currentPage + 'CatogorySelected', 'WindowsPhone', 'WindowsPhone');
  				// $rootScope.NLPFilters = angular.copy($rootScope.NLPFiltersDefaults);
  				// $rootScope.NLPFilters.AspectValues["camera"] = 3;
  				// $rootScope.NLPFilters.AspectValues["display"] = 3;
  				// $rootScope.NLPFilters.AspectValues["battery"] = 3;
  				// $rootScope.NLPFilters.AspectValues["performance"] = 3;
  				// $rootScope.NLPFilters.PriceMaxValue = 10000;
  				// $rootScope.NLPFilters.SelectedOsFilters.push('Windows');
  				$scope.openDashboardPage();
  			};

  			$scope.openAndroidPhone = function() {
  				Api.gaTrackEvent($scope.currentPage + 'CatogorySelected', 'AndroidPhone', 'AndroidPhone');
  				// $rootScope.NLPFilters = angular.copy($rootScope.NLPFiltersDefaults);
  				// $rootScope.NLPFilters.AspectValues["camera"] = 3;
  				// $rootScope.NLPFilters.AspectValues["display"] = 3;
  				// $rootScope.NLPFilters.AspectValues["battery"] = 3;
  				// $rootScope.NLPFilters.AspectValues["performance"] = 3;
  				// $rootScope.NLPFilters.PriceMaxValue = 10000;
  				// $rootScope.NLPFilters.SelectedOsFilters.push('Android');
  				$scope.openDashboardPage();
  			};

  			var scrollTop = 0;
  			$scope.openProductOverlay = function(productid, name){
  				Api.gaTrackEvent('('+$scope.categoryName+') ' + $scope.currentPage + ' Page','Details Button Clicked' , name);
  				if(angular.element(".desktop_view").is(':visible')) {
  					$rootScope.showProductPageLoader = true;
  					$rootScope.currentPage = "ProductOverlay";
  					$scope.heightValue = $window.innerHeight;
  					$scope.productid = productid;
  					$scope.domainId = domainId;
  					Api.getProductPriceAnalytics($scope.domainId, $scope.productid).then(function(response){
					$scope.productPrice = {};
					response = response.data;
			        if(response){
			    		for(var i = 0, iLen = response.priceList.length; i < iLen; i++){
				    			if(	$scope.productPrice[response.priceList[i].seller.id] == null ||
				    				$scope.productPrice[response.priceList[i].seller.id] == undefined ||
				    				Number(response.priceList[i].price) < Number($scope.productPrice[response.priceList[i].seller.id].price)){
				    				$scope.productPrice[response.priceList[i].seller.id] = response.priceList[i];
				    			}
				    		}
				        }

				    	angular.element('body').height($scope.heightValue).css('overflow-y', 'hidden');
				    	$scope.showProductOverlay = true;
				    	scrollTop = $(document).scrollTop();
						$timeout(function() {
					        $scope.showScreenBlocker = false;
					       	$scope.showProductOverlayInner = true;
					       	$timeout(function() {
			  					angular.element('.close_overlay').show();
			  				}, 600);
					    }, 1);
					});
  				} else {
  					var path = "/"+$scope.categoryName+"/productdetails/" + productid + "/" + $scope.safeEscapeDisplayName(name);
  					$location.url(path);
  				}

  			};

  			$scope.delayBeforeLoad = 750;
  			$scope.showProductOverlay = false;
  			$scope.showProductOverlayInner = false;
  			$scope.closeProductoverlay = function(){
  				$rootScope.currentPage = "DiscoveryDashboard";
  				angular.element('.close_overlay').hide();
  				$scope.showProductOverlayInner = false;
  				$timeout(function() {
  					$scope.showProductOverlay = false;
  					angular.element('body').css('height', 'auto').css('overflow-y', 'auto');
  				}, 600);
  			};

       /* feedback popups */
       $scope.showFeedbackPopup = false;
       $scope.showFeedbackFormPopup = false;
       $scope.showFeedbackFbSharePopup = false;
       $scope.showFeedbackMsgPopup = false;
       var feedbackPopup = localStorage.getItem('feedbackPopup');

       $scope.idleEndTime = 0;
       angular.element('body').on('mousemove keydown DOMMouseScroll mousewheel mousedown touchstart',
         function(){
           $scope.idleEndTime = 0;
         });
          var id = $interval(function(){
            $scope.idleEndTime = $scope.idleEndTime+1;
            //console.log("form $timeout"+$scope.idleEndTime);
            if($scope.idleEndTime > 45){
              if(feedbackPopup == null){
                localStorage.setItem('feedbackPopup', 1)
                $scope.showFeedbackPopup = true;
                $scope.idleEndTime = 0;
                $interval.cancel(id);
              }else{
                $interval.cancel(id);
              }
            }
          }, 1000);

       $scope.clickedNoButton = function(){
         $scope.showFeedbackPopup = false;
         $scope.showFeedbackFormPopup = true;
       }
       $scope.clickedYesButton = function(){
         $scope.showFeedbackPopup = false;
         $scope.showFeedbackFbSharePopup = true;
       }
       $scope.closeFeedbackPopup = function(index) {
         switch(index){
           case 1:
             $scope.showFeedbackPopup = false;
             break;
           case 2:
             $scope.showFeedbackFbSharePopup = false;
             break;
           case 3:
             $scope.showFeedbackFormPopup = false;
             break;
           case 4:
             $scope.showFeedbackMsgPopup = false;
             break;
           default:
        }
       };
       $scope.submitFeedbackForm = function(){
         $scope.showFeedbackMsgPopup = true;
         $scope.showFeedbackFormPopup = false;
       }

     /* end of popups*/


  }]).animation('.popupoverlaySlide', function () {
        return {
            beforeAddClass: function (element, className, done) {
                var scope = element.scope();

                if (className == 'ng-hide') {
                    var finishPoint = element.parent().width();
                    TweenMax.to(element, 0.5, {left: finishPoint, onComplete: done });
                }
                else {
                    done();
                }
            },
            removeClass: function (element, className, done) {
                var scope = element.scope();

                if (className == 'ng-hide') {
                    element.removeClass('ng-hide');

                    var startPoint = element.parent().width();

                    TweenMax.fromTo(element, 0.5, { left: startPoint }, {left: 0, onComplete: done });
                }
                else {
                    done();
                }
            }
        };
   });;
