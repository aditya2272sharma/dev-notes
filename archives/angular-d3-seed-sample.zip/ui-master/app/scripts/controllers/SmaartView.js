'use strict';

angular.module('buySmaartApp')
  .controller('SmaartViewCtrl',['$scope', 'Api', '$location', '$rootScope', '$route', '$compile', '$filter', '$window','$timeout', 'Meta',
	function ($scope, Api, $location, $rootScope, route, $compile, $filter, $window, $timeout, Meta) {
        $rootScope.currentPage = "SmaartView";
        __insp.push(['tagSession', "SmaartView"]);
        var strokeTickness = 10;
		$scope.menubar = true;
        /***Code related to filters***/
       	angular.element($window).unbind("scroll");
       	var domainId;
       	var categoryId;
		var arrayOfAspectTips = ["Is least important","Is unimportant", "Is moderately important","Is very important","Is most important"];
		$scope.highlightedProducts = [];
		var optionsStringFromURL = route.current.params.options;
       	$scope.showDropDownOK = true;
        $scope.pricePopUpHeight = $window.innerHeight - 184;
        var updateDiscoveryDashBoardUrl = function() {
      //   	JSON.stringify($rootScope.NLPFilters);
	    	// $location.path("/SmaartView/" + JSON.stringify($rootScope.NLPFilters), false);
	    };

	    var setMetaDataForDashoad = function() {
			var desc = "Use SmaartView's phone spec comparison charts and find the best phones. ";
			var keywords = 'SmaartView, Phone spec comparison chart, best phone specs, ';

			if($scope.graphAxisInfo && $scope.graphAxisInfo.yAxis) {
				keywords = keywords + " Best " + $scope.graphAxisInfo.yAxis + " phone specs, ";
				if($scope.graphAxisInfo.xAxis) {
					keywords = keywords + " Best " + $scope.graphAxisInfo.xAxis + " phone specs";
					desc = desc + "Compare "+ $scope.graphAxisInfo.yAxis +" and "+ $scope.graphAxisInfo.xAxis +" and find best mobile phones, ";
				} else{
					desc = desc + "Compare and find best mobile phones, ";
				}
			} else{
				desc = desc + "Compare and find best mobile phones, ";
			}

			for(var i = 0, iLen = $scope.canvasColorFilters.length; i < iLen; i++) {
				desc = desc + "best "+ $scope.canvasColorFilters[i]  +((i == iLen -1)?" phones." : " phones, " );
				keywords = keywords + ", best "+ $scope.canvasColorFilters[i] +" phone specs";
			}

			$rootScope.description = desc;
        	$rootScope.keywords = keywords;

		};

		$scope.showListPopup = function() {
			$scope.showDropDownOK = true;
		};

		var bodyClick = function(){
			angular.element('body').click(function(event) {
				if(! angular.element(event.target).parents('.element_part_dropdown').length) {
					if(angular.element(".mobile_view").is(':visible')){
						$scope.showDropDownOK = false;
					}
					$scope.$apply();
				}
				//&& (!angular.element(event.target).parents('.bubbleRef').length) && ((!angular.element(event.target).hasClass('bubbleRef')))
				if((!angular.element(event.target).parents('.popover').length)){
					$('.popover').each(function() {
	                  $(this).remove();
	                });
				}

				if(!angular.element(event.target).parents('.filters320').length && !angular.element(event.target).hasClass('filters320')){
					$scope.showFiltersPopOver = false;
					$scope.$apply();
				}
			});
		};
		bodyClick();
		var totalWidth = ($window.innerWidth < 1180)? $window.innerWidth : 1180;
		var leftpanelWidth = angular.element(".smaartview_leftpanel").outerWidth(true);
		var rightpanelWidth = angular.element(".ProductSelection").outerWidth(true);
		var finalWidth = totalWidth;
		var finalHeight = totalWidth;
		if(angular.element(".desktop_view").is(':visible')) {
			finalWidth = totalWidth - leftpanelWidth - rightpanelWidth - 100;
			finalHeight = finalWidth;
			$scope.maxNumOfComp = 4;
			//Desktop view
		} else if(angular.element(".tablet_view").is(':visible')){
			finalWidth = totalWidth - leftpanelWidth - rightpanelWidth - 100;
			finalHeight = finalWidth;
			$scope.maxNumOfComp = 3;
			//Tablet view
		} else {
			finalWidth = totalWidth - 32;
			$scope.showDropDownOK = false;
			finalHeight = 450;
			$scope.maxNumOfComp = 2;
			//Mobile view
		}
		angular.element("#canvas_graph").css({width: finalWidth + "px", height: finalHeight + "px"});


		var productidList = [];
		// if(isNaN(optionsStringFromURL)) {
		// 	$scope.isFullLength = true;
		// 	if(optionsStringFromURL != null && optionsStringFromURL != undefined) {
		// 		try {
		// 			var optionsFromURL = JSON.parse(optionsStringFromURL);
		// 			// $rootScope.NLPFilters = optionsFromURL;
		// 		}
		// 		catch(err) {
		// 		    updateDiscoveryDashBoardUrl();
		// 		}
		// 	} else {
		// 		updateDiscoveryDashBoardUrl();
		// 	}
		// } else {
		// 	$scope.isFullLength = false;
		// 	productidList[0] = optionsStringFromURL;
		// 	if(route.current.params.productid2 != null && route.current.params.productid2 != undefined) {
		//   		productidList[1] = route.current.params.productid2;
		//   	}
		//   	if(route.current.params.productid3 != null && route.current.params.productid3 != undefined) {
		//   		productidList[2] = route.current.params.productid3;
		//   	}
		//   	if(route.current.params.productid4 != null && route.current.params.productid4 != undefined) {
		//   		productidList[3] = route.current.params.productid4;
		//   	}
		// }

		if(isNaN(optionsStringFromURL)) {
			if(optionsStringFromURL != null && optionsStringFromURL != undefined) {
				$scope.isFullLength = true;
				try {
					var optionsFromURL = JSON.parse(optionsStringFromURL);
					categoryId = optionsFromURL.categoryId;
					$scope.priceMinValue = "\u20b9 " + angular.copy(optionsFromURL.PriceMinValue);
					$scope.priceMinValueForCompare = angular.copy(optionsFromURL.PriceMinValue);
					$scope.priceMaxValueForCompare = angular.copy(optionsFromURL.PriceMaxValue);
					$scope.priceMaxValue = "\u20b9 " + angular.copy(optionsFromURL.PriceMaxValue);
					$scope.allProducts = angular.copy(optionsFromURL.allProducts);
					$scope.specificationWeight = angular.copy(optionsFromURL.SpecificationWeight);
					$scope.sentimentWeight = angular.copy(optionsFromURL.SentimentWeight);
					$scope.selectedFilter = [];
					for(var i in optionsFromURL.filters) {
						var selectedFilter = {};
						selectedFilter.filterId = optionsFromURL.filters[i].filterId;
						selectedFilter.metadataId = optionsFromURL.filters[i].metadataId;
						selectedFilter.selectedFilters = [];
						for(var j in optionsFromURL.filters[i].selectedFilters) {
							selectedFilter.selectedFilters.push(optionsFromURL.filters[i].selectedFilters[j])
						}
						$scope.selectedFilter.push(selectedFilter);
					}
					$scope.aspects = optionsFromURL.aspects;
				}
				catch(err) {
				    updateDiscoveryDashBoardUrl();
				}
			}else{
				updateDiscoveryDashBoardUrl();
			}
		} else {
			$scope.isFullLength = false;
			productidList[0] = optionsStringFromURL;
			if(route.current.params.productid2 != null && route.current.params.productid2 != undefined) {
		  		productidList[1] = route.current.params.productid2;
		  	}
		  	if(route.current.params.productid3 != null && route.current.params.productid3 != undefined) {
		  		productidList[2] = route.current.params.productid3;
		  	}
		  	if(route.current.params.productid4 != null && route.current.params.productid4 != undefined) {
		  		productidList[3] = route.current.params.productid4;
		  	}
		}


		$scope.showFiltersPopOver = true;

		// $scope.priceMinValue = "\u20b9 " + angular.copy($rootScope.NLPFilters.PriceMinValue);
		// $scope.priceMinValueForCompare = angular.copy($rootScope.NLPFilters.PriceMinValue);
		// $scope.priceMaxValue = "\u20b9 " + angular.copy($rootScope.NLPFilters.PriceMaxValue);
		var timeSort = angular.copy($rootScope.NLPFilters.TimeSort);
		var priceSort = angular.copy($rootScope.NLPFilters.PriceSort);
		var scoreSort = angular.copy($rootScope.NLPFilters.ScoreSort);
		// $scope.selectedFilter = angular.copy($rootScope.NLPFilters.filters);
		// $scope.allProducts = angular.copy($rootScope.NLPFilters.allProducts);
		// $scope.specificationWeight = angular.copy($rootScope.NLPFilters.SpecificationWeight);
		// $scope.sentimentWeight = angular.copy($rootScope.NLPFilters.SentimentWeight);
		// $scope.nplFilterText = angular.copy($rootScope.nplFilterText);

		$scope.defultCurrency="\u20b9";

		var page = 0;
		var maxRecordsOnCanvas = 30;
		$scope.totalProductCountForSearch = 0;
		$scope.showScreenBlocker = true;

		 $scope.screenIsCheck = [];
		 $scope.screenFilterUpdated = function(key, index){
			$scope.screenIsCheck[index] = !$scope.screenIsCheck[index];
			var keyIndex = selectedScreenFilter.indexOf(key);
			if(keyIndex == -1){
				selectedScreenFilter.push(key);
			} else{
				selectedScreenFilter.splice(keyIndex,1);
			}
			updateProducts();
		};

		var verifyChangeInFilters = function() {
			if($rootScope.NLPFilters.AspectValues != null){
				var inloop = false;
				for (var k in $rootScope.NLPFilters.AspectValues){
					inloop = true;
					if($scope.aspectValues[k] != $rootScope.NLPFilters.AspectValues[k]){
						return true;
					}
				}
				if(!inloop){
					return true;
				}
			} else {
				return true;
			}

			if(	$rootScope.NLPFilters.SentimentWeight != $scope.sentimentWeight ||
				$rootScope.NLPFilters.SpecificationWeight != $scope.specificationWeight ||
				$rootScope.NLPFilters.PriceMaxValue != ( $scope.priceMaxValue.split(" "))[1] ||
				$rootScope.NLPFilters.PriceMinValue != ( $scope.priceMinValue.split(" "))[1] ||
				$rootScope.NLPFilters.allProducts != $scope.allProducts ){
				return true;
			}

			if(selectedScreenFilter.length == $rootScope.NLPFilters.SelectedScreenFilter.length){
				for(var i = 0, iLen = selectedScreenFilter.length; i < iLen; i++){
					if ($rootScope.NLPFilters.SelectedScreenFilter.indexOf(selectedScreenFilter[i]) == -1) {
					    return true;
					}
				}
			} else {
				return true;
			}

			return false;
		};

		$scope.verifyPriceMinValue = function(value){
			$scope.priceMinValueForCompare = parseInt(value, 10);
			$scope.priceMaxValueForCompare = parseInt($scope.priceMaxValueForCompare, 10);
			if($scope.priceMinValueForCompare > $scope.priceMaxValueForCompare){
				angular.element(".price_popup_body").show();
			} else {
				angular.element(".price_popup_body").hide();
			}
		};

		$scope.verifyPriceMaxValue = function(value){
			$scope.priceMaxValueForCompare = parseInt(value, 10);
			$scope.priceMinValueForCompare = parseInt($scope.priceMinValueForCompare, 10);
			if($scope.priceMinValueForCompare > $scope.priceMaxValueForCompare){
				angular.element(".price_popup_body").show();
			} else {
				angular.element(".price_popup_body").hide();
			}
		};

       $scope.minPriceInputFocusIn = function(value){
       		$scope.priceMinValue = (value.split(" "))[1];
       };
       $scope.maxPriceInputFocusIn = function(value){
       		$scope.priceMaxValue = (value.split(" "))[1];
       };
       $scope.minPriceInputBlur = function(value){
       		angular.element(".price_popup_body").hide();
       		if(value < $scope.priceMaxValueForCompare && value != ''){
       			$scope.priceMinValueForCompare = value;
       			$scope.priceMinValue = "\u20b9 " + value;
       		} else {
       			$scope.priceMinValue = "\u20b9 " + angular.copy($rootScope.NLPFilters.PriceMinValue);
				$scope.priceMinValueForCompare = angular.copy($rootScope.NLPFilters.PriceMinValue);
       		}
       };

		$scope.maxPriceInputBlur = function(value){
			angular.element(".price_popup_body").hide();
			if(value > $scope.priceMinValueForCompare && value != ''){
				$scope.priceMaxValueForCompare = value;
       			$scope.priceMaxValue = "\u20b9 " + value;
	       	} else {
	       		$scope.priceMaxValue = "\u20b9 " + angular.copy($rootScope.NLPFilters.PriceMaxValue);
				$scope.priceMaxValueForCompare = angular.copy($rootScope.NLPFilters.PriceMaxValue);
	       	}
       };;

		var updateProducts = function() {
			if(verifyChangeInFilters()){
				$rootScope.NLPFilters.AspectValues = angular.copy($scope.aspectValues);
				$rootScope.NLPFilters.SentimentWeight = angular.copy($scope.sentimentWeight);
				$rootScope.NLPFilters.SpecificationWeight = angular.copy($scope.specificationWeight);
				$rootScope.NLPFilters.PriceMinValue = angular.copy(( $scope.priceMinValue.split(" "))[1]);
				$rootScope.NLPFilters.PriceMaxValue = angular.copy(( $scope.priceMaxValue.split(" "))[1]);
				$rootScope.NLPFilters.filters = angular.copy($scope.selectedFilter);
				$rootScope.NLPFilters.allProducts = angular.copy($scope.allProducts);
				updateDiscoveryDashBoardUrl();

				page = 0;
				$scope.productResponse = [];
            	$scope.showScreenBlocker = true;
				var pp = buildFilterInfo();
				getProductsByRatingCriteria(pp);
			}
		};

		$scope.updateProducts = function(){
			updateProducts();
		};

		$scope.priceRangeChanged = function() {
			Api.gaTrackEvent($scope.currentPage + 'ShowFromThisRangeClicked', 'ShowFromThisRangeClicked', $scope.priceMinValue + " to " + $scope.priceMaxValue);
		};

		$scope.getCheckState = function(key){
			var keyIndex = selectedScreenFilter.indexOf(key);
			if(keyIndex == -1){
				return false;
			} else{
				return true;
			}
		};

		$scope.sliderChanged = function(index){
			angular.element(".tipBody_" + index).css({"display":"block"}).html(arrayOfAspectTips[$scope.aspects[index] - 1]);
			setTipPosition($scope.aspects[index],  angular.element(".tipHead_" + index).css({"display":"block"}));
		};

		$scope.sentimentSliderChanged = function(index){
			angular.element(".tipBody_" + index).css({"display":"block"}).html(arrayOfAspectTips[$scope.sentimentWeight - 1]);
			setTipPosition($scope.sentimentWeight, angular.element(".tipHead_" + index).css({"display":"block"}));
		};
		$scope.specificationSliderChanged = function(index){
			angular.element(".tipBody_" + index).css({"display":"block"}).html(arrayOfAspectTips[$scope.specificationWeight - 1]);
			setTipPosition($scope.specificationWeight, angular.element(".tipHead_" + index).css({"display":"block"}));
		};

		var setTipPosition = function(value, element) {
			switch(value - 1){
				case 0:
					element.css({"left": "-5px"});
				break;
				case 1:
					element.css({"left": "22%"});
				break;
				case 2:
					element.css({"left": "47%"});
				break;
				case 3:
					element.css({"left": "73%"});
				break;
				case 4:
					element.css({"left": "96%"});
				break;
			}
		};

		$scope.sliderUpdated = function(index, value){
			Api.gaTrackEvent($scope.currentPage + 'AspectSliderChanged', index+ '_AspectSliderChanged', value);
			angular.element(".tipBody_" + index).css({"display":"none"});
			angular.element(".tipHead_" + index).css({"display":"none"});
			updateProducts();
		};

		var buildFilterInfo = function() {
			var params = {};
			params.aspectMetadata = {};

			for (var k in $scope.aspects){
					params.aspectMetadata[k] = {};
					params.aspectMetadata[k].value = $scope.aspects[k].value;
					params.aspectMetadata[k].metadataId = $scope.aspects[k].metadataId;
			}

			params.sortOrder = {};
			params.applicableFilters = [];
			for(var i in $scope.selectedFilter) {
				params.applicableFilters[i] = {};
				params.applicableFilters[i].filterId = $scope.selectedFilter[i].filterId;
				params.applicableFilters[i].metadataId = $scope.selectedFilter[i].metadataId;
				params.applicableFilters[i].filterType = 'listFilter';
				params.applicableFilters[i].filterableItems = [];
				if($scope.selectedFilter[i].selectedFilters.length != 0) {
					for(var j in $scope.selectedFilter[i].selectedFilters) {
						params.applicableFilters[i].filterableItems.push({
							itemId: $scope.selectedFilter[i].selectedFilters[j],
							operation: 'INCLUDE'
						});
					}
				}
			}

			var listFilterLength = params.applicableFilters.length;
			params.applicableFilters[listFilterLength] = {};
			params.applicableFilters[listFilterLength].filterId = "price";
			params.applicableFilters[listFilterLength].filterType="rangeFilter";
			params.applicableFilters[listFilterLength].maxValue = ( $scope.priceMaxValue.split(" "))[1];
			params.applicableFilters[listFilterLength].minValue = ( $scope.priceMinValue.split(" "))[1];

			params.sentimentWeight = $scope.sentimentWeight;
			params.specificationWeight = $scope.specificationWeight;
			params.allProducts = $scope.allProducts;

			var paramsString = JSON.stringify(params);
			return paramsString;
		};

		var page = 0;
		var pageSize = 30;

		var getProductsByRatingCriteria = function(pp) {
			$scope.highlightedProducts = [];
			Api.getProductsByRatingCriteria(domainId, pp, page, pageSize, categoryId).then(function(response){
				if(response != undefined){
					$scope.showScreenBlocker = false;
					$scope.productResponse = response;
		            $scope.productResponse = $scope.getGraphProductList($scope.productResponse);
		            $scope.generateGraph();
		            setMetaDataForDashoad();
				}
				$scope.showFiltersPopOver = false;
				$scope.showScreenBlocker = false;
      		});
		};

		var getProductsAfterAllCalls = function(){
			if($scope.isFullLength){
				var pp = buildFilterInfo();
				getProductsByRatingCriteria(pp);
			} else {
				getInitialProductInfo();
			}
		};

		var callProgressCount = 0;
		var getInitialProductInfo = function(){
	  		for(var i = 0, ilen = productidList.length; i < ilen; i++){
	  			getProductInfo(i);
	  		}
	  	};

		var getProductDetails = function() {
	        var params = {};
	        params.aspectMetadata = {};
	        for (var k in $scope.aspects){
	            if(k != 'undefined') {
	                params.aspectMetadata[k] = {};
	                params.aspectMetadata[k].value = $scope.aspects[k].value;
	                params.aspectMetadata[k].metadataId = $scope.aspects[k].metadataId;
	            }
	        }
	        return params;
	    }

	  	var getProductInfo = function(index){
	  		callProgressCount = callProgressCount + 1;
			var categoryId = _.get( $rootScope, "categoryId", 1);

	  		Api.getProduct(domainId, productidList[index], getProductDetails(), categoryId).then(function(response){
	        	$scope.productResponse[index] = response;
	        	callProgressCount = callProgressCount - 1;
	        	processAfterAllCallsForInfo();
	  		});
	  	};
	  	var processAfterAllCallsForInfo = function() {
	  		if(callProgressCount == 0) {
		    	$scope.productResponse = $scope.getGraphProductList($scope.productResponse);
		    	$scope.generateGraph();
		   		$scope.showFiltersPopOver = false;
				$scope.showScreenBlocker = false;
			}
	  	};

		var sendInitialCalls = function(){
			if($scope.isConfigAvaliable) {
            	domainId = $rootScope.NLPFilters.domainId;
           		// $scope.aspects = angular.copy($rootScope.NLPFilters.aspects);
            	if($scope.isUserLoggedIn) {
            		Api.getWishListItems(domainId).then(function(response){
        				$scope.wishList = response;
  					});
  				}
  				if(! $scope.isFullLength) {
	  				$scope.aspects = $rootScope.NLPFilters.aspects;
	  				$scope.selectedFilter = [];
	  				for(var k in $rootScope.NLPFilters.filters) {
	  					var selectedFilter = {};
	  					selectedFilter.selectedFilters = [];
	  					selectedFilter.filterId = $rootScope.NLPFilters.filters[k].filterId;
	  					$scope.selectedFilter.push(selectedFilter);
	  				}
	  			}
				getProductsAfterAllCalls();
			}
     	};
        $rootScope.$on("categoryConfigUpdated",sendInitialCalls);
      	sendInitialCalls();


        $scope.graphAxisInfo = {
            "xAxis"	:"",
            "yAxis"	:""
        };
        $scope.selectAllColorFilter = {};
        $scope.maxRecordsOnCanvas = 30;
        $scope.productResponse= [];
        $scope.svgLeftBottomPadding = 0;

        var colorArray  = ["#77CC33", "#FF6600", "#0066CC", "#EA4C88", "#993399", "#663399", "#333399", "#CC0000", "#0099CC", "#66CCCC", "#660000", "#669900", "#336600", "#666600", "#CCCC33", "#F9EC1D", "#FFCC33", "#FF9900", "#990000", "#CC6633", "#996633", "#663300", "#EA4CB8", "#BD1F8B", "#980B6B", "#A96F6F", "#C66F6F", "#E36F6F", "#F39ABC", "#C68CC6", "#898CC6", "#44AA55", "#6F89E3", "#6FC6E3", "#A9E3E3", "#B2E38C", "#89C66F", "#8CA96F", "#A9A96F", "#E3E38C", "#FBF480", "#FFE38C", "#FFC66F", "#FFA96F", "#E3A98C"];
        var outerCircle = ["#BBE599", "#CC7F7F", "#7FB2E5", "#F4A5C3", "#CC99CC", "#B299CC", "#9999CC", "#E57F7F", "#7FCCE5", "#B2E5E5", "#B27F7F", "#B2CC7F", "#99B27F", "#B2B27F", "#E5E599", "#FCF58E", "#FFE599", "#FFCC7F", "#cc7f7f", "#E5B299", "#CCB299", "#B2997F", "#F4A5DB", "#DE8FC5", "#CB85B5", "#D8BEBE", "#E5BDBD", "#F2BDBD", "#F9D1E0"," #E5CA35", "#B299CC", "#9999CC", "#7FB2E5", "#7FCCE5", "#B2E5E5", "#BBE599", "#B2CC7F", "#99B27F", "#B2B27F", "#E5E599", "#FCF58E", "#FF3599", "#FFCC7F", "#FFB27F", "#E5D299"];

        $scope.canvasColorFiltersColors = colorArray;
        $scope.canvasColorFilters = [];
        if($scope.isFullLength) {
        	$scope.selectedColorFilter = 0;
       } else {
       		$scope.selectedColorFilter = 0;
       }
        $scope.gridLabel = [["","",""], ["","",""], ["","",""]];
        $scope.selectAllColorFilter[$scope.selectedColorFilter] = true;
        $scope.isCanvasAxisSelected = function (){
            return $scope.graphAxisInfo.xAxis;
        };

        $scope.isColorFilterSelected = function (canvasColorFilter){
            return $scope.canvasColorFiltersSelction[canvasColorFilter];
        };
        $scope.isAspectSelectedOnYAxis = function (){
        	if(angular.element(".mobile_view").is(':visible')){
				return false;
			}
			return $scope.graphAxisInfo.yAxis;

        };

        $scope.isAspectSelectedOnXAxis = function (){
            return $scope.graphAxisInfo.xAxis;
        };

        $scope.getYAxisArchOpened = function (){
            return $scope.yAxisArchOpened;
        };
        $scope.getXAxisArchOpened = function (){
            return $scope.xAxisArchOpened;
        };


        $scope.setYAxisArchOpened = function (yAxisArchOpened){
            $scope.yAxisArchOpened = yAxisArchOpened;
        };


        $scope.setXAxisArchOpened = function (xAxisArchOpened){
            $scope.xAxisArchOpened = xAxisArchOpened;
        };

        $scope.openXAxisArch = function (){
            $("#xAxisNav").toggleClass('active');
            if( $("#xAxisNav").hasClass('active')){
                $scope.collapseYArch();
                $scope.expandXArch();
            }else{
                $scope.collapseXArch();
            }
            $("#xAxisNav").parent(".xaxisSelectTap").toggleClass('active');
        };



        /**
         * Function to open Y axis aspect arch
         */
        $scope.openYAxisArch = function (){
            $("#yAxisNav").toggleClass('active');
            if( $("#yAxisNav").hasClass('active')){
                $scope.collapseXArch();
                $scope.expandYArch();
            }else{
                $scope.collapseYArch();
            }
            $("#yAxisNav").parent(".xaxisSelectTap").toggleClass('active');
            $scope.yAxisArchOpenedOnce = true;
//            Storage.set('yAxisArchOpenedOnce', $scope.yAxisArchOpenedOnce);
        };

        /**
         * Expands X axis arch
         */
        $scope.expandXArch = function () {
            var li=$("#xAxisNav li .iconwrap"),i=li.length,n=i-1,r=160;
            $scope.setXAxisArchOpened(true);
            for(var a=0;a<5;a++){
                $("#xAxisNav li .iconwrap").eq(a).animate({
                    'left':-(r*Math.cos(90/n*a*(Math.PI/180))),
                    'top':-(r*Math.sin(90/n*a*(Math.PI/180)))
                },200);
            }
			if($scope.isAspectSelectedOnXAxis() != null && $scope.isAspectSelectedOnXAxis() != undefined && $scope.isAspectSelectedOnXAxis() != "") {
				$(".xaxisSelectTap .innerWrap").css({'bottom':"-87px", right: "-80px"});
			} else {
				$(".xaxisSelectTap .innerWrap").css({'bottom':"-110px", right: "-62px"});
			}
            $(".xaxisSelectTap .innerWrap").css("z-index","1");
            $(".xaxisSelectTap .innerWrap").animate({
                opacity: 1
            },800);
        };

        /**
         * Expands Y axis arch
         */
        $scope.expandYArch = function () {
            var li=$("#yAxisNav li .iconwrap"),i=li.length,n=i-1,r=150;
            $scope.setYAxisArchOpened(true);
            for(var a=0;a<5;a++){
                $("#yAxisNav li .iconwrap").eq(a).animate({
                    'left':(r*Math.cos(90/n*a*(Math.PI/180))),
                    'top':(r*Math.sin(90/n*a*(Math.PI/180)))
                },200);
            }
            $(".yaxisSelectTap .innerWrap").css("z-index","1");
            $(".yaxisSelectTap .innerWrap").animate({
                opacity:1
            },800);
        };

        /**
         * Collapse X axis arch
         */
        $scope.collapseXArch = function () {
            for(var a=0;a<5;a++){
                $("#xAxisNav li .iconwrap").eq(a).animate({
                    'left':0,
                    'top':0
                },200);
            }
            $scope.setXAxisArchOpened(false);
            $(".xaxisSelectTap .innerWrap").animate({
                opacity: 0
            },150,function(){
                $(".xaxisSelectTap .innerWrap").css("z-index","-1");
            });
        };

        /**
         * Collapse Y axis arch
         */
        $scope.collapseYArch = function () {
            for(var a=0;a<5;a++){
                $("#yAxisNav li .iconwrap").eq(a).animate({
                    'left':0,
                    'top':0
                },200);
            }
            $(".yaxisSelectTap .innerWrap").animate({
                opacity: 0
            },150,function(){
                $(".yaxisSelectTap .innerWrap").css("z-index","-1");
            });
            window.setTimeout(function(){
                $scope.setYAxisArchOpened(false);
            }, 200);
        };

        $scope.bounceToX = function() {
        	if(!angular.element(".mobile_view").is(':visible')){
	        	var scrollYVal = angular.element($window).scrollTop();
	        	//angular.element($window).pageYOffset || angular.element($window).scrollY;
	        	angular.element('body,html').animate({scrollTop: 250}, "slow", function(){
	        		//angular.element("body").animate({scrollTop:scrollYVal}, "slow");
	        	});
	        }
        };

        /**
         * Y axis aspect click handler.
         * @param {String} aspectId
         */
        $scope.selectYAxisAspect = function (aspectId){
        	Api.gaTrackEvent($scope.currentPage + 'aspectSelected', 'yAxisAspectSelected', aspectId);
        	$scope.hide_wrapper = true;
            if($scope.graphAxisInfo.yAxis === aspectId || $scope.graphAxisInfo.xAxis === aspectId ){
                return;
            }
            $scope.graphAxisInfo.yAxis = aspectId;
//            DataFactory.gaTrackEvent('smaartViewYAxisAspectSelection', 'yAxisAspectSelected', aspectId);
            var varname = "";
            if($scope.graphAxisInfo.yAxis == ""){
                varname = "all";
            } else if ($scope.graphAxisInfo.xAxis == "") {
                varname = $scope.graphAxisInfo.yAxis;
            } else {
                varname = "xyAxis";
            }
            $scope.isCanvasGotItClicked = true;
//            Storage.set('isCanvasGotItClicked', $scope.isCanvasGotItClicked);
            $("#canvasYAxisGotIt").slideUp(0);
//            Storage.set('graphAxisInfo', $scope.graphAxisInfo);
//            MetaInformationFactory.setMetaInformation();
            $scope.generateXAxis();
            $scope.generateYAxis();
            $scope.draw(varname);
        };

        /**
         * X axis aspect click handler.
         * @param {String} aspectId
         */
        $scope.selectXAxisAspect = function (aspectId){
        	Api.gaTrackEvent($scope.currentPage + 'aspectSelected', 'xAxisAspectSelected', aspectId);
            if($scope.graphAxisInfo.yAxis === aspectId || $scope.graphAxisInfo.xAxis === aspectId ){
                return;
            }
            $scope.graphAxisInfo.xAxis = aspectId;
//            DataFactory.gaTrackEvent('smaartViewXAxisAspectSelection', 'xAxisAspectSelected', aspectId);
            var varname = "";
            if($scope.graphAxisInfo.yAxis == ""){
                varname = "all";
            } else if ($scope.graphAxisInfo.xAxis == "") {
                varname = $scope.graphAxisInfo.yAxis;
            } else {
                varname = "xyAxis";
            }
//            Storage.set('graphAxisInfo', $scope.graphAxisInfo);
//            MetaInformationFactory.setMetaInformation();
            $scope.generateXAxis();
            $scope.generateYAxis();
            $scope.draw(varname);
        };

        $scope.generateGraph = function() {
            $scope.generateCanvasColorFiltersColors($scope.selectedColorFilter);

            //get the dom element and attach it a svg.
            var width = angular.element("#canvas_graph").width() - $scope.svgLeftBottomPadding;
            var height = angular.element("#canvas_graph").height() - $scope.svgLeftBottomPadding;

            var minBSSCore = d3.min(_.pluck($scope.productResponse, 'buysmaartScore'));
            var maxBSSCore = d3.max(_.pluck($scope.productResponse, 'buysmaartScore'));;

			angular.element("#canvas_graph").html("");

            var svg = d3.select("#canvas_graph").append("svg")
               .attr("width", angular.element("#canvas_graph").width())
               .attr("height", angular.element("#canvas_graph").height());
            var scale = d3.scale.linear()
               .domain([minBSSCore,maxBSSCore])
               .range([12,25]);
			for (var j = 0; j < $scope.productResponse.length; j++) {
                $scope.productResponse[j].radius = +scale($scope.productResponse[j].buysmaartScore);
                $scope.productResponse[j].x = Math.random() * width;
                $scope.productResponse[j].y = Math.random() * height;
            }


            $scope.padding = 2;
            $scope.maxRadius = 50;

            $scope.force = d3.layout.force();

            var varname = "";
            var xAxis = $scope.graphAxisInfo.xAxis;
            var yAxis = $scope.graphAxisInfo.yAxis;
            if(yAxis == ""){
                varname = "all";
            } else if (xAxis == "") {
              varname = yAxis;
            } else {
               varname = "xyAxis";
            }
            $scope.generateGridBlock();
            $scope.generateXYAxisAndGrid();
            //add xAxis
            $scope.generateYAxis();
            //add YAxis
            $scope.generateXAxis();
            //append the bubbles
            $scope.appendCircles();
            $scope.draw(varname);

        };
        $scope.getGraphProductList = function (products){
            var productListForGraph = [];
            $scope.aspectMinMaxScore = {};

            angular.forEach($scope.aspects, function(aspect){
                var totalSingleAspectsScores = _.chain(products).pluck("analytics").flatten().pluck("aspectScores").flatten().where({aspectId: aspect.name}).pluck("overallWeightedScore").unique().value();
                var singleAspectMax = d3.max(totalSingleAspectsScores);
                var singleAspectMin = d3.min(totalSingleAspectsScores);
                $scope.aspectMinMaxScore[aspect.name] = {
                    "min":singleAspectMin,
                    "max":singleAspectMax,
                    "step":parseInt((singleAspectMax - singleAspectMin)/3)
                };
            });
            for(var productIndex = 0, iLen = products.length; productIndex < iLen; productIndex++){
                var product = products[productIndex];
                if ( Object.keys(product.filterableValues).length < 2 ) {
                  product.filterableValues.filler = " ";
                  // temporary workaround to prevent errors
                  // BE fixes needed for this
                }
                var productforGraph = {
                    "productId" : product.productId,
                    "manufacturer" : product.manufacturer,
                    "buysmaartScore" : product.analytics.overallWeightedScore,
                    "sentimentScore" : product.analytics.weightedSentimentScore,
                    "specificationScore" : product.analytics.weightedSpecificationScore,
                    "displayName" : product.displayName.replace(/ /g,"_"),
                    "brand" : (product.filterableValues)? (product.filterableValues[Object.keys(product.filterableValues)[0]]).replace(/\s+/g,'') : "",
                    "star rating" : (product.filterableValues)? (product.filterableValues[Object.keys(product.filterableValues)[1]]) : "",
                    "screen size" : (product.filterableValues)? (product.filterableValues[Object.keys(product.filterableValues)[1]]) : "",
                    "os" : (product.filterableValues)? (product.filterableValues[Object.keys(product.filterableValues)[1]]).replace(/\s+/g,'') : "",
                    "analytics" : product.analytics,
                    "topSpecs": product.topSpecs,
                    "priceAnalytics": product.priceAnalytics,
                    "releaseDate" : product.releaseDate,
                    "primaryImage": product.primaryImage
                };
                angular.forEach($scope.aspects, function(aspect){
                    var productAspectScores = _.findWhere(product.analytics.aspectScores, {aspectId: aspect.name});
                    if(productAspectScores.overallWeightedScore <= ($scope.aspectMinMaxScore[aspect.name].min + $scope.aspectMinMaxScore[aspect.name].step)){
                        productforGraph[aspect.name] = 1;
                    } else if (productAspectScores.overallWeightedScore <= ($scope.aspectMinMaxScore[aspect.name].min + ($scope.aspectMinMaxScore[aspect.name].step*2))){
                        productforGraph[aspect.name] = 2;
                    } else {
                        productforGraph[aspect.name] = 3;
                    }
                });
                productListForGraph.push(productforGraph);
            }

            return productListForGraph;
        };

        $scope.generateGridBlock = function (){
            var width = angular.element("#canvas_graph").width()-$scope.svgLeftBottomPadding;
            var height = angular.element("#canvas_graph").height()-$scope.svgLeftBottomPadding;
            var svg = d3.select("svg");
            // Appending Blocks...

            if(angular.element(".mobile_view").is(':visible')){
            	svg.append("rect").attr("class", "block31").attr("x", $scope.svgLeftBottomPadding).attr("y", 0).attr("width", width).attr("height", height/3).style("fill", "#ffffff");
            	svg.append("rect").attr("class", "block21").attr("x", $scope.svgLeftBottomPadding).attr("y", height/3).attr("width", width).attr("height", height/3).style("fill", "#ffffff");
            	svg.append("rect").attr("class", "block11").attr("x", $scope.svgLeftBottomPadding).attr("y", (height/3)*2).attr("width", width).attr("height", height/3).style("fill", "#ffffff");
           } else {
           		svg.append("rect").attr("class", "block31").attr("x", $scope.svgLeftBottomPadding).attr("y", 0).attr("width", width/3).attr("height", height/3).style("fill", "#ffffff");
	            svg.append("rect").attr("class", "block32").attr("x", width/3 + $scope.svgLeftBottomPadding).attr("y", 0).attr("width", width/3).attr("height", height/3).style("fill", "#ffffff");
	            svg.append("rect").attr("class", "block33").attr("x", (width/3)*2 + $scope.svgLeftBottomPadding).attr("y", 0).attr("width", width/3).attr("height", height/3).style("fill", "#ffffff");

	            svg.append("rect").attr("class", "block21").attr("x", $scope.svgLeftBottomPadding).attr("y", height/3).attr("width", width/3).attr("height", height/3).style("fill", "#ffffff");
	            svg.append("rect").attr("class", "block22").attr("x", width/3 + $scope.svgLeftBottomPadding).attr("y", height/3).attr("width", width/3).attr("height", height/3).style("fill", "#ffffff");
	            svg.append("rect").attr("class", "block23").attr("x", (width/3)*2 + $scope.svgLeftBottomPadding).attr("y", height/3).attr("width", width/3).attr("height", height/3).style("fill", "#ffffff");

	            svg.append("rect").attr("class", "block11").attr("x", $scope.svgLeftBottomPadding).attr("y", (height/3)*2).attr("width", width/3).attr("height", height/3).style("fill", "#ffffff");
	            svg.append("rect").attr("class", "block12").attr("x", width/3 + $scope.svgLeftBottomPadding).attr("y", (height/3)*2).attr("width", width/3).attr("height", height/3).style("fill", "#ffffff");
	            svg.append("rect").attr("class", "block13").attr("x", (width/3)*2 + $scope.svgLeftBottomPadding).attr("y", (height/3)*2).attr("width", width/3).attr("height", height/3).style("fill", "#ffffff");
           }

            // Appending Labels...
                svg.append("rect").attr("x", $scope.svgLeftBottomPadding).attr("y", (height/3)*2).attr("width", 96).attr("height", 20).attr("visibility", "hidden").attr("class", "rect11");
                svg.append("text") .attr("font-size", "11px").attr("x", 5).attr("y", ((height/3)*2) +10).attr("dy", ".35em").attr("class", "text11").attr("visibility", "hidden");

                svg.append("rect").attr("x", (width/3) + $scope.svgLeftBottomPadding).attr("y", (height/3)*2).attr("width", 100).attr("height", 20).attr("visibility", "hidden").attr("class", "rect12");
                svg.append("text") .attr("font-size", "11px").attr("x", (width/3) + 5).attr("y", ((height/3)*2) + 10).attr("dy", ".35em").attr("class", "text12").attr("visibility", "hidden");

                svg.append("rect").attr("x", ((width/3)*2) + $scope.svgLeftBottomPadding).attr("y", (height/3)*2).attr("width", 100).attr("height", 20).attr("visibility", "hidden").attr("class", "rect13");
                svg.append("text") .attr("font-size", "11px").attr("x", ((width/3)*2) + 5).attr("y", ((height/3)*2) + 10).attr("dy", ".35em").attr("class", "text13").attr("visibility", "hidden");

                svg.append("rect").attr("x", $scope.svgLeftBottomPadding).attr("y", height/3).attr("width", 100).attr("height", 20).attr("visibility", "hidden").attr("class", "rect21");
                svg.append("text") .attr("font-size", "11px").attr("x", 5).attr("y", height/3 + 10).attr("dy", ".35em").attr("class", "text21").attr("visibility", "hidden");

                svg.append("rect").attr("x", width/3).attr("y", height/3).attr("width", 100).attr("height", 20).attr("visibility", "hidden").attr("class", "rect22");
                svg.append("text") .attr("font-size", "11px").attr("x", width/3 + 5).attr("y", (height/3) + 10).attr("dy", ".35em").attr("class", "text22").attr("visibility", "hidden");

                svg.append("rect").attr("x", ((width/3)*2) + $scope.svgLeftBottomPadding).attr("y", height/3).attr("width", 100).attr("height", 20).attr("visibility", "hidden").attr("class", "rect23");
                svg.append("text") .attr("font-size", "11px").attr("x", ((width/3)*2) + 5).attr("y", height/3 + 10).attr("dy", ".35em").attr("class", "text23").attr("visibility", "hidden");

                svg.append("rect").attr("x", $scope.svgLeftBottomPadding).attr("y", 0).attr("width", 100).attr("height", 20).attr("visibility", "hidden").attr("class", "rect31");
                svg.append("text") .attr("font-size", "11px").attr("x", 5).attr("y", 10).attr("dy", ".35em").attr("class", "text31").attr("visibility", "hidden");

                svg.append("rect").attr("x", (width/3) + $scope.svgLeftBottomPadding).attr("y", 0).attr("width", 100).attr("height", 20).attr("visibility", "hidden").attr("class", "rect32");
                svg.append("text") .attr("font-size", "11px").attr("x", (width/3) + 3).attr("y", 10).attr("dy", ".35em").attr("class", "text32").attr("visibility", "hidden");

                svg.append("rect").attr("x", ((width/3)*2) + $scope.svgLeftBottomPadding).attr("y", 0).attr("width", 100).attr("height", 20).attr("visibility", "hidden").attr("class", "rect33");
                svg.append("text") .attr("font-size", "11px").attr("x", ((width/3)*2) + 5).attr("y", 10).attr("dy", ".35em").attr("class", "text33").attr("visibility", "hidden");
        };

        $scope.generateXYAxisAndGrid = function (){
            var svg = d3.select("svg");
            var width = angular.element("#canvas_graph").width()-$scope.svgLeftBottomPadding;
            var height = angular.element("#canvas_graph").height()-$scope.svgLeftBottomPadding;
             if(! angular.element(".mobile_view").is(':visible')){
	            /*vertical lines in grid*/
	            svg.append("line")
	                .attr("class", "gridLines verticalLine1")
	                .attr("x1", (width/3)+$scope.svgLeftBottomPadding)
	                .attr("y1", 0)
	                .attr("x2", (width/3)+$scope.svgLeftBottomPadding)
	                .attr("y2", height)
	                .attr("stroke-width", 1)
	                .attr("stroke", "#efefef");

	            svg.append("line")
	                .attr("class", "gridLines verticalLine2")
	                .attr("x1", ((width/3)*2)+$scope.svgLeftBottomPadding)
	                .attr("y1", 0)
	                .attr("x2", ((width/3)*2)+$scope.svgLeftBottomPadding)
	                .attr("y2", height)
	                .attr("stroke-width", 1)
	                .attr("stroke", "#efefef");
	        }

            /*horizontal lines in grid*/
            svg.append("line")
                .attr("class", "gridLines horizentalLine1")
                .attr("x1", $scope.svgLeftBottomPadding)
                .attr("y1", height/3)
                .attr("x2", width+$scope.svgLeftBottomPadding)
                .attr("y2", height/3)
                .attr("stroke-width", 1)
                .attr("stroke", "#efefef");

            svg.append("line")
                .attr("class", "gridLines horizentalLine2")
                .attr("x1", $scope.svgLeftBottomPadding)
                .attr("y1", (height/3)*2)
                .attr("x2", width+$scope.svgLeftBottomPadding)
                .attr("y2", (height/3)*2)
                .attr("stroke-width", 1)
                .attr("stroke", "#efefef");

            /* extreme low box borders */
            svg.append("line")
                .attr("class", "extremeLowBoxBorderLines")
                .attr("x1", ((width/3)+$scope.svgLeftBottomPadding)-1)
                .attr("y1", ((height/3)*2)+1)
                .attr("x2", ((width/3)+$scope.svgLeftBottomPadding)-1)
                .attr("y2", (height)-1);

            svg.append("line")
                .attr("class", "extremeLowBoxBorderLines")
                .attr("x1", $scope.svgLeftBottomPadding+1)
                .attr("y1", ((height/3)*2)+2)
                .attr("x2", ((width/3)+$scope.svgLeftBottomPadding)-1)
                .attr("y2", ((height/3)*2)+2);

            svg.append("line")
                .attr("class", "extremeLowBoxBorderLines")
                .attr("x1", $scope.svgLeftBottomPadding+1)
                .attr("y1", ((height/3)*2)+1)
                .attr("x2", $scope.svgLeftBottomPadding+1)
                .attr("y2", height-1);

            svg.append("line")
                .attr("class", "extremeLowBoxBorderLines")
                .attr("x1", $scope.svgLeftBottomPadding+1)
                .attr("y1", height-1)
                .attr("x2", ((width/3)+$scope.svgLeftBottomPadding)-1)
                .attr("y2", height-1);

            svg.selectAll("line.extremeLowBoxBorderLines").attr("stroke-width", 1);
            svg.selectAll("line.extremeLowBoxBorderLines").attr("stroke", "#ffc1c1");

            /* extreme high box borders */
            svg.append("line")
                .attr("class", "extremeHighBoxBorderLines")
                .attr("x1", ((width/3)*2+$scope.svgLeftBottomPadding)+1)
                .attr("y1", 1)
                .attr("x2", (width+$scope.svgLeftBottomPadding)-1)
                .attr("y2", 1);

            svg.append("line")
                .attr("class", "extremeHighBoxBorderLines")
                .attr("x1", ((width/3)*2+$scope.svgLeftBottomPadding)+1)
                .attr("y1", (height/3)-1)
                .attr("x2", (width+$scope.svgLeftBottomPadding)-1)
                .attr("y2", (height/3)-1);

            svg.append("line")
                .attr("class", "extremeHighBoxBorderLines")
                .attr("x1", ((width/3)*2+$scope.svgLeftBottomPadding)+1)
                .attr("y1", 1)
                .attr("x2", ((width/3)*2+$scope.svgLeftBottomPadding)+1)
                .attr("y2", (height/3)-1);

            svg.append("line")
                .attr("class", "extremeHighBoxBorderLines")
                .attr("x1", (width+$scope.svgLeftBottomPadding)-1)
                .attr("y1", 1)
                .attr("x2", (width+$scope.svgLeftBottomPadding)-1)
                .attr("y2", (height/3)-1);

            svg.selectAll("line.extremeHighBoxBorderLines").attr("stroke-width", 1);
            svg.selectAll("line.extremeHighBoxBorderLines").attr("stroke", "#99e4b0");
        };

        $scope.generateXAxis = function (){
            var svg = d3.select("svg");
            svg.selectAll("line.xaxis").remove();
            svg.selectAll("line.xaxisdivider").remove();
            svg.selectAll("text.xaxistext").remove();
            if($scope.graphAxisInfo.xAxis){
                var width = angular.element("#canvas_graph").width()-$scope.svgLeftBottomPadding;
                var height = angular.element("#canvas_graph").height()-$scope.svgLeftBottomPadding;
                /*x axis*/
                svg.append("line")
                    .attr("class", "xaxis")
                    .attr("x1", 0)
                    .attr("y1", height)
                    .attr("x2", width+$scope.svgLeftBottomPadding)
                    .attr("y2", height)
                    .attr("stroke-width", 1)
                    .attr("stroke", "#cccccc");

                /*x axis dividers*/
                svg.append("line")
                    .attr("class", "xaxisdivider")
                    .attr("x1", (width/3)+$scope.svgLeftBottomPadding)
                    .attr("y1", height-4)
                    .attr("x2", (width/3)+$scope.svgLeftBottomPadding)
                    .attr("y2", height+4)
                    .attr("stroke-width", 2)
                    .attr("stroke", "#ff8800");

                svg.append("line")
                    .attr("class", "xaxisdivider")
                    .attr("x1", ((width/3)*2)+$scope.svgLeftBottomPadding)
                    .attr("y1", height-4)
                    .attr("x2", ((width/3)*2)+$scope.svgLeftBottomPadding)
                    .attr("y2", height+4)
                    .attr("stroke-width", 2)
                    .attr("stroke", "#ff8800");

                svg.append("line")
                    .attr("class", "xaxisdivider")
                    .attr("x1", ((width/3)*3)+$scope.svgLeftBottomPadding-1)
                    .attr("y1", height-4)
                    .attr("x2", ((width/3)*3)+$scope.svgLeftBottomPadding-1)
                    .attr("y2", height+4)
                    .attr("stroke-width", 2)
                    .attr("stroke", "#ff8800");

                /* x axis text */
//    			$scope.generateAxisLabels($scope.aspectMinMaxScore[$scope.graphAxisInfo.xAxis], "X");
            }
        };
        $scope.generateAxisLabels = function (axisInfo, axisType){
            var width = angular.element("#canvas").width()-$scope.svgLeftBottomPadding;
            var height = angular.element("#canvas").height()-$scope.svgLeftBottomPadding;
            var svg = d3.select("svg");
            var labelArray = [];
            labelArray[0] = "Low";
            labelArray[1] = "Medium";
            labelArray[2] = "High";
            if(axisType === "X"){
                svg.selectAll("text.xaxistext").remove();
                for(var k=0; k<labelArray.length; k++){
                    svg.append("text")
                    .attr("x", ((width/3)+(width/3*k))-((width/6)))
                    .attr("y", 660)
                    .text( labelArray[k] )
                    .attr("class", "axistext xaxistext");
                }
                svg.append("text")
                .attr("x", 10)
                .attr("y", 660)
                .text( "0" )
                .attr("class", "axistext xaxistext");
            } else {
                svg.selectAll("text.yaxistext").remove();
                svg.append("text")
                .attr("x", -1 * (((height/3)*2) + height/6))
                .attr("y", 10)
                .text( labelArray[0] )
                .attr("class", "axistext yaxistext")
                .attr("transform", function(d) {
                    return "rotate(-90)";
                });

                svg.append("text")
                .attr("x",  -1 * ((height/3) + height/6))
                .attr("y", 10)
                .text( labelArray[1] )
                .attr("class", "axistext yaxistext")
                .attr("transform", function(d) {
                    return "rotate(-90)";
                });

                svg.append("text")
                .attr("x", -1 * ((height/6) + $scope.svgLeftBottomPadding))
                .attr("y", 10)
                .text( labelArray[2] )
                .attr("class", "axistext yaxistext")
                .attr("transform", function(d) {
                    return "rotate(-90)";
                });
            }

        };

        $scope.generateYAxis = function (){
            var svg = d3.select("svg");
            svg.selectAll("line.yaxis").remove();
            svg.selectAll("line.yaxisdivider").remove();
            svg.selectAll("text.yaxistext").remove();
            if ($scope.graphAxisInfo.yAxis) {
                var width = angular.element("#canvas_graph").width()-$scope.svgLeftBottomPadding;
                var height = angular.element("#canvas_graph").height()-$scope.svgLeftBottomPadding;
                /*y axis*/
                svg.append("line")
                    .attr("class", "yaxis")
                    .attr("x1", $scope.svgLeftBottomPadding)
                    .attr("y1", 0)
                    .attr("x2", $scope.svgLeftBottomPadding)
                    .attr("y2", height+$scope.svgLeftBottomPadding)
                    .attr("stroke-width", 1)
                    .attr("stroke", "#cccccc");

                /*y axis dividers*/
                svg.append("line")
                    .attr("class", "yaxisdivider")
                    .attr("x1", $scope.svgLeftBottomPadding-4)
                    .attr("y1", height/3)
                    .attr("x2", $scope.svgLeftBottomPadding+4)
                    .attr("y2", height/3)
                    .attr("stroke-width", 2)
                    .attr("stroke", "#ff8800");

                svg.append("line")
                    .attr("class", "yaxisdivider")
                    .attr("x1", $scope.svgLeftBottomPadding-4)
                    .attr("y1", (height/3)*2)
                    .attr("x2", $scope.svgLeftBottomPadding+4)
                    .attr("y2", (height/3)*2)
                    .attr("stroke-width", 2)
                    .attr("stroke", "#ff8800");

                svg.append("line")
                    .attr("class", "yaxisdivider")
                    .attr("x1", $scope.svgLeftBottomPadding-4)
                    .attr("y1", 1)
                    .attr("x2", $scope.svgLeftBottomPadding+4)
                    .attr("y2", 1)
                    .attr("stroke-width", 2)
                    .attr("stroke", "#ff8800");

                /* y axis text */
//    			$scope.generateAxisLabels($scope.aspectMinMaxScore[$scope.graphAxisInfo.yAxis], "Y");
            }
        };

        //this method takes care of appending bubbles to the svg graph
        $scope.appendCircles = function (){
            var svg = d3.select("svg");
            $scope.nodes = svg.selectAll(".node")
                .data($scope.productResponse)
                .enter()
                .append('g')
                .attr("class", "node");

            $scope.nodes.append("circle")
                .attr("r", function (d) { return d.radius; })
                .attr("class", function (d) {
                    return d.brand+" "+d.os+" product"+d.productId + " bubbleRef " + d.displayName;
                })
                .style("fill", function (d) {
                    return $scope.canvasColorFiltersColors[d[$scope.selectedFilter[$scope.selectedColorFilter].filterId.toLowerCase()]];
                }).attr('stroke', function (d) {
                    return $scope.canvasColorFiltersStrokeColors[d[$scope.selectedColorFilter]];
                }).attr('stroke-width', 0)
                .on("click", function (d) {
                  d3.event.stopPropagation();
                  $scope.showPopover.call(this, d);
                });

            $scope.nodes.append("text")
                .text(function(d){ return Math.round(d.buysmaartScore);})
                .style("text-anchor", "middle")
                .attr("dy", ".35em")
                .attr("class", function (d) { return d.brand+" "+d.os; })
                .attr("font-family", "RobotoRegular")
                .attr("font-size", "12px")
                .attr("fill", "#ffffff")
                .on("click", function (d) {
                  d3.event.stopPropagation();
                  $scope.showPopover.call(this, d);
                });
        };
        $scope.isAddedToCompare = function(prodId) {
            for(var i = 0, iLen = $scope.compareItems.length; i < iLen; i++){
	        	if(prodId == $scope.compareItems[i].productId){
	        		return true;
	        	}
	        }
	        return false;
        };
        $scope.isolderDate = function(dateString) {
        	var today = new Date();
			var dateObj = new Date(dateString);
			if(today.getTime() < dateObj.getTime()) {
				return false;
			}
			return true;
        };
        $scope.defultCurrency="\u20b9";
        $scope.showPopover = function (d) {
            $('.popover').remove();
            var indexOfProd = $scope.productResponse.indexOf(d);
            var selectedProduct = _.findWhere($scope.productResponse, { productId : d.productId });
            var popupHtml = '<div class="phneSrtDescWrap"><button id="closePopup'+d.productId+'" class="close">Close</button>';
            //title
            popupHtml += '<h3 ng-click="popOverViewDetailsClick(\''+d.productId+'\')" id="productTitle(\''+d.productId+'\')">'+selectedProduct.displayName.replace(/_/g," ")+'</h3>';
            //price
            if(selectedProduct.priceAnalytics && selectedProduct.priceAnalytics.minPrice){
				popupHtml += '<div class="avlePrice"><span >Available From</span> <span class=\"priceList iconBefore\">'+ $scope.defultCurrency+'{{'+selectedProduct.priceAnalytics.minPrice+'| currencyFormat: " "}}/-</span></div>';
            } else {
            	popupHtml += '<div class="avlePrice"><span>{{( '+$scope.isolderDate(selectedProduct.releaseDate) +')? "Price not available" : "Price coming soon"}}</span></div>';
            }
            //scores
            popupHtml += '<div class="progressWrap"><ul>';

            if($scope.graphAxisInfo.yAxis){
                var yAxisSelectedAspectAnalytics =_.findWhere(selectedProduct.analytics.aspectScores,{aspectId:$scope.graphAxisInfo.yAxis});
                if(yAxisSelectedAspectAnalytics.overallWeightedScore){
                    popupHtml += '<li><span class="scoreWrapper"><span class="scoretitle" data-i18n=\"msg.smartphone.aspect.'+yAxisSelectedAspectAnalytics.aspectId+'\">'+ yAxisSelectedAspectAnalytics.aspectId + '</span><span data-i18n=\"msg.smartphone.product.aspect.score\" class="scoretitle">&nbsp;Score</span><span class="scoreCount">'+Math.round(yAxisSelectedAspectAnalytics.overallWeightedScore)+'%</span><div class="progressFull"><div class="progressScore" style="width:'+yAxisSelectedAspectAnalytics.overallWeightedScore+'%"></div></div></li>';
                } else {

                }
            }
            if($scope.graphAxisInfo.xAxis){
                var xAxisSelectedAspectAnalytics =_.findWhere(selectedProduct.analytics.aspectScores, {aspectId:$scope.graphAxisInfo.xAxis});
                if(xAxisSelectedAspectAnalytics.overallWeightedScore){
                    popupHtml += '<li><span class="scoreWrapper"><span class="scoretitle" data-i18n=\"msg.smartphone.aspect.'+xAxisSelectedAspectAnalytics.aspectId+'\">'+xAxisSelectedAspectAnalytics.aspectId+'</span><span data-i18n=\"msg.smartphone.product.aspect.score\" class="scoretitle">&nbsp;Score</span><span class="scoreCount">'+Math.round(xAxisSelectedAspectAnalytics.overallWeightedScore)+'%</span><div class="progressFull"><div class="progressScore" style="width:'+xAxisSelectedAspectAnalytics.overallWeightedScore+'%"></div></div></li>';
                } else {

                }
            }
            popupHtml += '</ul></div>';
            //specs
            popupHtml += '<ul class="phneDescList">';
            angular.forEach(selectedProduct.topSpecs, function(topSpec){
              var specRating = _.get(topSpec, 'specRating', "");
              var specName = _.get(topSpec, 'specName', "");
              var specValue = _.get(topSpec, 'specValue', "");
              var description = _.get(topSpec, 'description', "");
              popupHtml += _.template(
                '<li class="${topSpecClass}">' +
                  '<span>${specName}</span>' +
                  '<div class="itemSpecValue">' +
                    '<span>${specValue}</span>' +
                    '<!--<span class="phneDesclastEle">${description}</span> -->' +
                  '<div>' +
                '</li>'
              )({
                "topSpecClass": $scope.getTopSpecClass(specRating, specName),
                "specRating": specRating,
                "specName": specName,
                "specValue": specValue,
                "description": description
              })            
                
//          popupHtml += ;
            });
            popupHtml += '</ul>';
            popupHtml += '<div class="popupBase clearfix">';


            //buttons
            popupHtml += '<div class="CheckBtn">';

//            checkbox
             popupHtml +='<div class="addTocompareHolder">'

             popupHtml +='<div class="checkboxwrapper">'
             popupHtml +='<label>'
             popupHtml +='<div class="chbxwrapper">'
             popupHtml +='<input type="checkbox" ng-checked="isAddedToCompare(\''+d.productId+'\')" class="addToCompare" inderref="{{'+ indexOfProd +'}}" rel="{{'+ d.productId +'}}" ng-click="selectItemToCompare($event,'+ indexOfProd + ')" ><span class="chkbox"></span>{{isAddedToCompare(\''+d.productId+'\')? "&nbsp;&nbsp;Added" : "&nbsp;&nbsp;Add to compare"}} </input>'
             popupHtml +='</div>'
             popupHtml +='<span class="labeltext"></span>'
             popupHtml +=' </label>'
             popupHtml +='</div>'
             popupHtml +='</div>'
//        checkbox end

//            popupHtml += '<label class="compareCheckbox"><input type="checkBox" name="" id="compare-'+d.productId+'" ng-click="addOrRemoveCompare(\''+d.productId+'\')" ng-model="selectedProductsForCompare[\''+d.productId+'\']" ng-checked="isAddedToCompare(\''+d.productId+'\')"  ng-disabled="isCheckboxReadonly(\''+d.productId+'\')"/>';
//            popupHtml += '<span ng-if="!isAddedToCompare(\''+d.productId+'\') && !isCompareLimitReached()" data-i18n=\"msg.smartphone.compare.button.addtocompare\"></span></label>';
//            popupHtml += '<span class="compareEm" ng-if="!isAddedToCompare(\''+d.productId+'\') && isCompareLimitReached()" ng-click="showCompareLimitReachedWarning()" data-i18n=\"msg.smartphone.compare.button.addtocompare\">Add to Compare</span>';
//            popupHtml += '<span class="compareEm" ng-if="isAddedToCompare(\''+d.productId+'\')" ng-click="goToCompare()" data-i18n=\"msg.smartphone.compare.button.comparenow\"></span>';
//            popupHtml += '<br>';
			
			var categoryName = Meta.getCategoryName();
            popupHtml += _.template('<a ng-href="/${categoryName}/productdetails/${productId}/${displayName}"" data-i18n="msg.smartphone.products.listing.button.viewdetails"><button class="btnWrapper btn-default detailbtn button" ng-click="buybuttonClickRegistered(\'${displayName}\')" id="viewProduct(\'${productId}\')">Details</button></a>')
            ({
              "categoryName": categoryName,
              "productId": d.productId,
              "displayName": d.displayName.replace(/_/g,"-")
            })
            if(selectedProduct.priceAnalytics){
                popupHtml += '<button class="btnWrapper btn-default buybtn button" id="buyProductButton(\''+d.productId+'\')" ng-click="getPriceInformation(\''+d.productId+'\',\''+d.displayName.replace(/_/g," ")+'\')" data-i18n=\"msg.smartphone.products.listing.button.buynow\">Buy</button>';
            }
            popupHtml += '</div>';
            //highlight
            popupHtml += '<div class="highlightSection">';
            popupHtml += '<button class="hilightbtnWrapper btn-default button orgnBodrBtn" id="buyProductButton(\''+d.productId+'\')" ng-click="highlight(\''+d.productId+'\',\''+d.displayName.replace(/_/g," ")+'\')" ng-show="highlightedProducts.indexOf(\''+d.productId+'\') == -1">Highlight</button>';
            popupHtml += '<button class="hilightbtnWrapper btn-default button orgnBodrBtn" id="viewProduct(\''+d.productId+'\')" ng-click="dismissHighLight(\''+d.productId+'\',\''+d.displayName.replace(/_/g," ")+'\')" ng-show="highlightedProducts.indexOf(\''+d.productId+'\') != -1">Remove Highlight</button>';
            popupHtml += '</div></div></div>';

            $(this).popover('destroy');
            $(this).popover({
              placement: 'auto top',
              container: '.canvasWrapper',
              trigger: 'manual',
              html : true,
              content: function() {
                return $compile(popupHtml)($scope);
              }
            });
            $(this).popover('show');
            d3.selectAll(".close").on("click", function () {
                $('.popover').each(function() {
                  $(this).remove();
                });
            });
        };
        /**
        * Reset the canvas view. Removes all the aspect selections from both the axis
         */

        $scope.buybuttonClickRegistered = function (name) {
        Api.gaTrackEvent($scope.currentPage + 'DetailsButtonClicked', 'DetailsButtonClicked', name);};

        $scope.resetCanvasView = function (){
        	$scope.highlightedProducts = [];
            $scope.graphAxisInfo = {
                "xAxis"	:"",
                "yAxis"	:""
            };
            for(var l=0;l<5;l++){
                $("#xAxisNav li .iconwrap").eq(l).css({
                    'left':0,
                    'top':0
                });
                $("#yAxisNav li .iconwrap").eq(l).css({
                    'left':0,
                    'top':0
                });
            }
            $(".axisIcons .innerWrap").css({
                'z-index':-1,
                'opacity': 0
            });
           // Storage.set('graphAxisInfo', $scope.graphAxisInfo);
            //MetaInformationFactory.setMetaInformation();
            $scope.setXAxisArchOpened(false);
            $scope.setYAxisArchOpened(false);
            $("#xAxisNav").removeClass('active');
            $("#yAxisNav").removeClass('active');
            $("#yAxisNav").parent(".yaxisSelectTap").removeClass('active');
            $("#xAxisNav").parent(".xaxisSelectTap").removeClass('active');
            $scope.generateXAxis();
            $scope.generateYAxis();
            d3.selectAll("text").attr("visibility", "visible");
            d3.selectAll("circle").attr("visibility", "visible");
            angular.forEach($scope.canvasColorFilters, function(canvasColorFilter, index){
                $scope.canvasColorFiltersSelction[canvasColorFilter] = true;
            });
            $scope.draw('all');
        };

        $scope.highlight = function(id) {
        	Api.gaTrackEvent($scope.currentPage + 'highightButtonClicked', 'added', 'SelfiLovers');
        	$scope.highlightedProducts.push(id);
        	var element = d3.select("svg").selectAll(".product"+id);
        	var strokeColor = element.style("fill");
        	if(Number(element.attr('stroke-width')) == 0){
        		var circleWidth = Number(element.attr("r")) - strokeTickness + 2;
              element.attr('stroke-width', strokeTickness).attr("r", circleWidth ).attr('stroke', strokeColor).style("stroke-opacity", .5);
            }
        };

        $scope.dismissHighLight = function(id) {
        	Api.gaTrackEvent($scope.currentPage + 'highightButtonClicked', 'removed', 'SelfiLovers');
			var index = $scope.highlightedProducts.indexOf(id);
			if (index > -1) {
			    $scope.highlightedProducts.splice(index, 1);
			}
        	var element = d3.select("svg").selectAll(".product"+id);
        	if(Number(element.attr('stroke-width')) == strokeTickness){
        		var circleWidth = Number(element.attr("r")) + strokeTickness - 2;
            	element.attr('stroke-width', 0).attr("r", circleWidth );
           }
        };

        $scope.getPriceInformation = function(id, name){
        	Api.gaTrackEvent($scope.currentPage + 'buyButtonClicked', 'buyButtonClicked', name);
			$scope.showScreenBlocker = true;
			Api.getProductPriceAnalytics('smartphone', id).then(function(response){
				$scope.productPrice = {};
				response = response.data;
				for(var i = 0, iLen = response.priceList.length; i < iLen; i++){
					if(	$scope.productPrice[response.priceList[i].seller.id] == null ||
						$scope.productPrice[response.priceList[i].seller.id] == undefined ||
						Number(response.priceList[i].price) < Number($scope.productPrice[response.priceList[i].seller.id].price)){
						$scope.productPrice[response.priceList[i].seller.id] = response.priceList[i];
					}
				}
            	$scope.showPricePanel = true;
            	$scope.showScreenBlocker = false;
      		});
		};

        /**
         * Find the top specification class based on the ratings
         * @param {String} specRating
         * @param {String} specName
         * @returns class string
         */
        $scope.getTopSpecClass = function (specRating, specName){
            var specClass = "";
            switch(specRating) {
            case 0:
                specClass = "topSepcGradeBad";
                break;
            case 1:
                specClass = "topSepcGradeBad";
                break;
            case 2:
                specClass = "topSepcGradeOk";
                break;
            case 3:
                specClass = "topSepcGradeGood";
                break;
            default:
                specClass = "topSepcGradeGood";
            };

            var topSpecName = specName.replace(/ /g, '');
            specClass += " " +angular.lowercase(topSpecName);
            return specClass;
        };


        $scope.draw = function (varname){
            var centers = getCenters();
            if(!$scope.productResponse.length){
                return;
            }
            $scope.force.on("tick", tick(centers, varname));
            $scope.force.start();
        };
        /**
         * Product check box click handler. Toggles the visibility of the product bubble
         * @param {String} canvasColorFilter
         */
        $scope.colorFilterToggleHandler = function (canvasColorFilter){

            $scope.canvasColorFiltersSelction[canvasColorFilter] = !$scope.canvasColorFiltersSelction[canvasColorFilter];
            var svg = d3.select("svg");
            if ($scope.canvasColorFiltersSelction[canvasColorFilter]){
                canvasColorFilter = $filter('removeSpaces')(canvasColorFilter);
                svg.selectAll("circle."+canvasColorFilter).attr("visibility", "visible");
                svg.selectAll("text."+canvasColorFilter).attr("visibility", "visible");
            } else {
                canvasColorFilter = $filter('removeSpaces')(canvasColorFilter);
                svg.selectAll("circle."+canvasColorFilter).attr("visibility", "hidden");
                svg.selectAll("text."+canvasColorFilter).attr("visibility", "hidden");
            }

            var selectedColorFilters = _.filter($scope.canvasColorFilters, function(canvasColorFilter){
                return $scope.canvasColorFiltersSelction[canvasColorFilter] === false;
            });
            if(selectedColorFilters.length === $scope.canvasColorFiltersSelction.length){
                $scope.selectAllColorFilter[$scope.selectedColorFilter] = true;
            }else{
                $scope.selectAllColorFilter[$scope.selectedColorFilter] = false;
            }
        };

        /**
         * Brand, OS filter click handler.
         * @param {String} selectedFilter
         */
        $scope.setCanvasColorFilter = function (selectedFilter) {
            if($scope.selectedColorFilter === selectedFilter){
                return;
            }
            $scope.selectedColorFilter = selectedFilter;
//            DataFactory.gaTrackEvent('smaartViewColorFilterSelection', 'colorFilterSelected', selectedFilter);
            $scope.generateCanvasColorFiltersColors(selectedFilter);
            d3.selectAll("circle").each(function(d) {
                d3.select(this).style("fill", $scope.canvasColorFiltersColors[d[$scope.selectedFilter[$scope.selectedColorFilter].filterId.toLowerCase()]]).attr('stroke', function (d) {
                    return $scope.canvasColorFiltersStrokeColors[d[$scope.selectedColorFilter]];
                });
            });
            d3.selectAll("text").attr("visibility", "visible");
            d3.selectAll("circle").attr("visibility", "visible");
            $scope.selectAllColorFilter[selectedFilter] = true;
            setMetaDataForDashoad();
        };

        $scope.isAllColorFilterSelected = function (){
            return $scope.selectAllColorFilter[$scope.selectedColorFilter];
        };

        /**
         * Select All click handler. Toggles the visibility of the all product bubbles
         */
        $scope.toggleSelectAllColorFilter = function(){
            var svg = d3.select("svg");
            if(!$scope.selectAllColorFilter[$scope.selectedColorFilter]){
                angular.forEach($scope.canvasColorFilters, function(canvasColorFilter){
                    $scope.canvasColorFiltersSelction[canvasColorFilter] = true;
                    svg.selectAll("circle."+canvasColorFilter).attr("visibility", "visible");
                    svg.selectAll("text."+canvasColorFilter).attr("visibility", "visible");
                });
                $scope.selectAllColorFilter[$scope.selectedColorFilter] = true;
            }else{
                angular.forEach($scope.canvasColorFilters, function(canvasColorFilter){
                    $scope.canvasColorFiltersSelction[canvasColorFilter] = false;
                    svg.selectAll("circle."+canvasColorFilter).attr("visibility", "hidden");
                    svg.selectAll("text."+canvasColorFilter).attr("visibility", "hidden");
                });
                $scope.selectAllColorFilter[$scope.selectedColorFilter] = false;
            }
        };


        var getCenters = function () {
            var xAxis = $scope.graphAxisInfo.xAxis;
            var yAxis = $scope.graphAxisInfo.yAxis;
            var centers, map;

            var width = angular.element("#canvas_graph").width() - $scope.svgLeftBottomPadding;
            var height = angular.element("#canvas_graph").height() - $scope.svgLeftBottomPadding;
            var svg = d3.select("svg");

            if(yAxis == ""){
                svg.selectAll("line.gridLines").attr("stroke", "#efefef");
                svg.selectAll("rect").style("fill", "#ffffff");

                svg.selectAll("text.text11").attr("visibility","hidden");
                svg.selectAll("text.text21").attr("visibility","hidden");
                svg.selectAll("text.text31").attr("visibility","hidden");
                svg.selectAll("text.text12").attr("visibility","hidden");
                svg.selectAll("text.text22").attr("visibility","hidden");
                svg.selectAll("text.text32").attr("visibility","hidden");
                svg.selectAll("text.text13").attr("visibility","hidden");
                svg.selectAll("text.text23").attr("visibility","hidden");
                svg.selectAll("text.text33").attr("visibility","hidden");

                svg.selectAll("rect.rect11").attr("visibility","hidden");
                svg.selectAll("rect.rect21").attr("visibility","hidden");
                svg.selectAll("rect.rect31").attr("visibility","hidden");
                svg.selectAll("rect.rect12").attr("visibility","hidden");
                svg.selectAll("rect.rect22").attr("visibility","hidden");
                svg.selectAll("rect.rect32").attr("visibility","hidden");
                svg.selectAll("rect.rect13").attr("visibility","hidden");
                svg.selectAll("rect.rect23").attr("visibility","hidden");
                svg.selectAll("rect.rect33").attr("visibility","hidden");

                svg.selectAll("line.extremeLowBoxBorderLines").attr("visibility", "hidden");
                svg.selectAll("line.extremeHighBoxBorderLines").attr("visibility", "hidden");
                centers = _.uniq(_.pluck($scope.productResponse, yAxis)).map(function (d) {
                   return {name: d, value: 1};
                });
            } else if (xAxis == "") {

                svg.selectAll("line.gridLines").attr("stroke", "#ffffff");

                svg.selectAll("rect.block11").style("fill", "#fff3f2");
                svg.selectAll("rect.block12").style("fill", "#fff3f2");
                svg.selectAll("rect.block13").style("fill", "#fff3f2");

                svg.selectAll("rect.block21").style("fill", "#fff9f5");
                svg.selectAll("rect.block22").style("fill", "#fff9f5");
                svg.selectAll("rect.block23").style("fill", "#fff9f5");

                svg.selectAll("rect.block31").style("fill", "#f2faf1");
                svg.selectAll("rect.block32").style("fill", "#f2faf1");
                svg.selectAll("rect.block33").style("fill", "#f2faf1");


                //.style("fill","#D85649")
                //.text(function(d) { return "Poor"; })

                svg.selectAll("text.text11").attr("visibility","visible").text(function(d) { return "Poor"; }).style("fill","#D85649");
                svg.selectAll("text.text21").attr("visibility","visible").text(function(d) { return "Average"; }).style("fill","#DBA926");
                svg.selectAll("text.text31").attr("visibility","visible").text(function(d) { return "Good"; }).style("fill","#389948");
                svg.selectAll("text.text12").attr("visibility","hidden");
                svg.selectAll("text.text22").attr("visibility","hidden");
                svg.selectAll("text.text32").attr("visibility","hidden");
                svg.selectAll("text.text13").attr("visibility","hidden");
                svg.selectAll("text.text23").attr("visibility","hidden");
                svg.selectAll("text.text33").attr("visibility","hidden");

                svg.selectAll("rect.rect11").attr("visibility","visible").style("fill","#FFB7B1");
                svg.selectAll("rect.rect21").attr("visibility","visible").style("fill","#FDECC1");
                svg.selectAll("rect.rect31").attr("visibility","visible").style("fill","#8FE4A0");
                svg.selectAll("rect.rect12").attr("visibility","hidden");
                svg.selectAll("rect.rect22").attr("visibility","hidden");
                svg.selectAll("rect.rect32").attr("visibility","hidden");
                svg.selectAll("rect.rect13").attr("visibility","hidden");
                svg.selectAll("rect.rect23").attr("visibility","hidden");
                svg.selectAll("rect.rect33").attr("visibility","hidden");


                svg.selectAll("line.extremeLowBoxBorderLines").attr("visibility", "hidden");
                svg.selectAll("line.extremeHighBoxBorderLines").attr("visibility", "hidden");

                centers = [
                       {name : "1", value : 1},
                       {name : "2", value : 1},
                       {name : "3", value : 1}
                   ];
            } else {

                svg.selectAll("line.gridLines").attr("stroke", "#ffffff");

                svg.selectAll("rect.block11").style("fill", "#ffddda");
                svg.selectAll("rect.block12").style("fill", "#fff3f2");
                svg.selectAll("rect.block13").style("fill", "#fff9f5");
                svg.selectAll("rect.block21").style("fill", "#fff3f2");
                svg.selectAll("rect.block22").style("fill", "#fff9f5");
                svg.selectAll("rect.block23").style("fill", "#f2faf1");
                svg.selectAll("rect.block31").style("fill", "#fff9f5");
                svg.selectAll("rect.block32").style("fill", "#f2faf1");
                svg.selectAll("rect.block33").style("fill", "#dbf2d7");

                svg.selectAll("text.text11").attr("visibility","visible").text(function(d) { return "Poor"; }).style("fill","#D85649");
                svg.selectAll("text.text21").attr("visibility","visible").text(function(d) { return "Below Average"; }).style("fill","#EC7C71");
                svg.selectAll("text.text31").attr("visibility","visible").text(function(d) { return "Average"; }).style("fill","#DBA926");
                svg.selectAll("text.text12").attr("visibility","visible").text(function(d) { return "Below Average"; }).style("fill","#EC7C71");
                svg.selectAll("text.text22").attr("visibility","visible").text(function(d) { return "Average"; }).style("fill","#DBA926");
                svg.selectAll("text.text32").attr("visibility","visible").text(function(d) { return "Above Average"; }).style("fill","#64B858");
                svg.selectAll("text.text13").attr("visibility","visible").text(function(d) { return "Average"; }).style("fill","#DBA926");
                svg.selectAll("text.text23").attr("visibility","visible").text(function(d) { return "Above Average"; }).style("fill","#64B858");
                svg.selectAll("text.text33").attr("visibility","visible").text(function(d) { return "Good"; }).style("fill","#389948");

                svg.selectAll("rect.rect11").attr("visibility","visible").style("fill","#FFB7B1");
                svg.selectAll("rect.rect21").attr("visibility","visible").style("fill","#FECCC5");
                svg.selectAll("rect.rect31").attr("visibility","visible").style("fill","#FDECC1");
                svg.selectAll("rect.rect12").attr("visibility","visible").style("fill","#FFCDC4");
                svg.selectAll("rect.rect22").attr("visibility","visible").style("fill","#FDECC1");
                svg.selectAll("rect.rect32").attr("visibility","visible").style("fill","#D6F1D0");
                svg.selectAll("rect.rect13").attr("visibility","visible").style("fill","#FDECC1");
                svg.selectAll("rect.rect23").attr("visibility","visible").style("fill","#D6F1D0");
                svg.selectAll("rect.rect33").attr("visibility","visible").style("fill","#8FE4A0");

                svg.selectAll("line.extremeLowBoxBorderLines").attr("visibility", "visible");
                svg.selectAll("line.extremeHighBoxBorderLines").attr("visibility", "visible");

                angular.forEach($scope.productResponse, function(productforGraph){
                    productforGraph.xyAxis = productforGraph[xAxis]+""+productforGraph[yAxis];
                });
                centers = [
                       {name : "11", value : 1},
                       {name : "12", value : 1},
                       {name : "13", value : 1},
                       {name : "21", value : 1},
                       {name : "22", value : 1},
                       {name : "23", value : 1},
                       {name : "31", value : 1},
                       {name : "32", value : 1},
                       {name : "33", value : 1}
                   ];
            }

            map = d3.layout.treemap().size([width, height]).ratio(1/1);
            map.nodes({children: centers});

            // setting dx,dy,x and y for each group
            if(centers.length === 1){
                centers[0].x = $scope.svgLeftBottomPadding;
            } else if(centers.length === 3){
              for (var i = 0; i < centers.length; i++) {
                  centers[i].dx = width;
                  centers[i].dy = height;
                  centers[i].x = $scope.svgLeftBottomPadding;
                  switch(centers[i].name.charAt(0)){
                    case "1":
                        centers[i].y = (height/3);
                        break;
                    case "2":
                        centers[i].y = 0;
                        break;
                    case "3":
                        centers[i].y = (height/3)* -1;
                        break;
                }
              }
            }else if(centers.length == 9) {
              for (var i = 0; i < centers.length; i++) {
                  centers[i].dx = width/3;
                  centers[i].dy = height/3;
                  centers[i].x = ((width/3)*(parseInt(centers[i].name.charAt(0))-1))+$scope.svgLeftBottomPadding;
                  switch(centers[i].name.charAt(1)){
                    case "1":
                        centers[i].y = (height/3)*2;
                        break;
                    case "2":
                        centers[i].y = (height/3)*1;
                        break;
                    case "3":
                        centers[i].y = 0;
                        break;
                  }
              }
            }
            return centers;
        };

        function tick (centers, varname) {
            var foci = {};
            for (var i = 0; i < centers.length; i++) {
              foci[centers[i].name] = centers[i];
            }
            return function (e) {
              for (var i = 0; i < $scope.productResponse.length; i++) {
//                  debugger;
                var o = $scope.productResponse[i];
                var f = foci[o[varname]];
                o.y += ((f.y + (f.dy / 2)) - o.y) * e.alpha;
                o.x += ((f.x + (f.dx / 2)) - o.x) * e.alpha;
              }
              $scope.nodes.each(collide(.11))
                .attr("transform", function(d) {
                	return 'translate(' + [d.x, d.y] + ')';
                });
            };
        }

        function collide(alpha) {
            var quadtree = d3.geom.quadtree($scope.productResponse);
            return function (d) {
              var r = d.radius + $scope.maxRadius + $scope.padding,
                  nx1 = d.x - r,
                  nx2 = d.x + r,
                  ny1 = d.y - r,
                  ny2 = d.y + r;
              quadtree.visit(function(quad, x1, y1, x2, y2) {
                if (quad.point && (quad.point !== d)) {
                  var x = d.x - quad.point.x,
                      y = d.y - quad.point.y,
                      l = Math.sqrt(x * x + y * y),
                      r = d.radius + quad.point.radius + $scope.padding;
                  if (l < r) {
                    l = (l - r) / l * alpha;
                    d.x -= x *= l;
                    d.y -= y *= l;
                    quad.point.x += x;
                    quad.point.y += y;
                  }
                }
                return x1 > nx2 || x2 < nx1 || y1 > ny2 || y2 < ny1;
              });
            };
        }

        $scope.getColorFilterStyle = function (colorFilterId){
            return {'background-color': $scope.canvasColorFiltersColors[colorFilterId]};
        };

        $scope.generateCanvasColorFiltersColors = function (selectedFilterIndex) {

            $scope.canvasColorFilters = [];
            $scope.canvasColorFiltersColors = [];
            $scope.canvasColorFiltersStrokeColors = [];
            $scope.canvasColorFiltersLabels = [];
            // $scope.canvasColorFilters = _.map(_.uniq(_.pluck($scope.productResponse, selectedFilter)), function(value){return value.replace(/\s+/g,'');});
            var selectedFilterForIndex = $scope.selectedFilter[selectedFilterIndex];
            $scope.canvasColorFiltersLabels = _.uniq(_.pluck($scope.productResponse, selectedFilterForIndex.filterId.toLowerCase()));
            if(selectedFilterForIndex.selectedFilters.length > 0)
            	$scope.canvasColorFilters = angular.copy(selectedFilterForIndex.selectedFilters);
            else {
            	for(var i in $scope.canvasColorFiltersLabels) {
            		$scope.canvasColorFilters[i] = $scope.canvasColorFiltersLabels[i];
            	}
            }
            $scope.canvasColorFiltersSelction = [];
            angular.forEach($scope.canvasColorFilters, function(canvasColorFilter, index){
                $scope.canvasColorFiltersColors[canvasColorFilter] = colorArray[index];
                $scope.canvasColorFiltersStrokeColors[canvasColorFilter] = outerCircle[index];
                $scope.canvasColorFiltersSelction[canvasColorFilter] = true;
            });
        };


        $scope.selectItemToCompare = function(event, index) {
        	//first get the selected product
            var selectedProduct = $scope.productResponse[index];
            selectedProduct.currency = "\u20b9";
            if(!$scope.isAddedToCompare(selectedProduct.productId) && $scope.compareItems.length == $scope.maxNumOfComp){
                angular.element(event.target).attr('checked', false);
                alert("You can not select more than " + $scope.maxNumOfComp +" phones to compare.");
                return;
            }


            //now check if the product is available in the selected item list
            var compareedItemIndex = -1;
	        for(var i = 0, iLen = $scope.compareItems.length; i < iLen; i++){
	        	if(selectedProduct.productId == $scope.compareItems[i].productId){
	        		compareedItemIndex = i;
	        		break;
	        	}
	        }

            //if present, remove it
            //else push it to the array
            if(compareedItemIndex != -1) {
                $rootScope.compareItems.splice(compareedItemIndex,1);
            } else  {
                if($scope.compareItems.length < 4) {
                    $rootScope.compareItems.push(selectedProduct);
                }
            }
            //$scope.$digest();
        };

   /***************** start of intro steps ***********/
    $scope.step1Options = {
      steps:[
        {
          element: '#step_0',
          intro: "<div><img src='images/ignore/intro-arrow.png'/>" +
                  "<p>Select the aspect that you <br>wish to compare with another</p>" +
                  "</div>",
          position: 'right',
          tooltipClass: 'transparent-bg'
        }
      ]
    }

    $scope.step2Options = {
      steps:[
        {
          element: '#xAxisNav',
          intro: "<div><img src='images/ignore/intro-arrow-right.png' style='margin-left: 200px'/>" +
          "<p>Choose another aspect here</p>" +
          "</div>",
          position: 'left',
          tooltipClass: 'transparent-bg right-tip'
        }
      ]
    }

    var step1 = localStorage.getItem('step1');

    if (step1 == null) {
      localStorage.setItem('step1', 1);
      $timeout(function(){$scope.CallMe();},200)

    }

    $scope.showIntro = function(){
      var step2 = localStorage.getItem('step2');
      if (step2 == null) {
        localStorage.setItem('step2', 1);
        $timeout(function(){$scope.CallMe2();},200)

      }
    }
  /**************** end of intro steps *****************/

  }]);
