'use strict';

angular.module('buySmaartApp')
  .controller('LoginCtrl', function ($scope) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
    __insp.push(['tagSession', "Viewed Login Page"]);
  });
