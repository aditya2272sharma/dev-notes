'use strict';

angular.module('buySmaartApp')
  .controller('ContactUsCtrl',['$scope', 'Api', '$rootScope',
  					 function ($scope, Api, $rootScope) {
		$rootScope.currentPage = "ContactUs";
        $scope.country_code = "91";                 
        var catogeryId;
		var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		var sendInitialCalls = function(){
			if($scope.isConfigAvaliable) {
				var response = $scope.config;
        		catogeryId = response.domainId;
        	}
        };
     	sendInitialCalls();
     	$rootScope.$on("configUpdated",sendInitialCalls);
     	
     	$scope.isValiedEmail = function(mail) {
            if(mail != '' && mail != null && mail != undefined) {
                if (!filter.test(mail)) {
                    $scope.email_error_text = "Please enter valid Email";
                    return true;
                } else {
                    return false;
                }
            }
            else {
                $scope.email_error_text = "Please enter your Email";
                return true;
            }
     	};
                         
     	$scope.submitButtonClicked = function(){
     		$scope.name_error = ($scope.name)? false: true;
     		$scope.email_error = $scope.isValiedEmail($scope.email);
     		$scope.phone_error = ($scope.phone)? false: true;
     		$scope.message_error = ($scope.message)? false: true;
     		if(!$scope.name_error && !$scope.email_error && !$scope.phone_error && !$scope.message_error){
     			var pp = {
					  "email": $scope.email,
					  "message": $scope.message,
					  "name": $scope.name,
					  "phone_number": $scope.phone
					};
     			Api.submitteContact(catogeryId, pp).then(function(response){
      			});
     		}
     	};
  }]);
