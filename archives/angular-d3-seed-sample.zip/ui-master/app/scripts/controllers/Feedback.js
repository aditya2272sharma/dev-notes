'use strict';

angular.module('buySmaartApp')
  .controller('FeeedbackCtrl',['$scope', '$rootScope', 'Api',
  					 function ($scope, $rootScope, Api) {
  		var rating;
  		var improveSuggestion="";
  		var newFeatures = [];
  		var isUseful;
  		var usefulSuggestion = "";
  		var sources = [];
  		var catogeryId;
  		
  		
                         
                         
                         
		$scope.feedback_screen_number = "3-0";
		$scope.newFeaturesList=["Deals and Coupons", 
							"Price Drop Alerts", 
							"Price Trends", 
							"News and Reviews about Mobiles", 
							"More Retailers on the List", 
							"More Categories in Coverage"];
							
		$scope.sourcesList=["Newspapers - Offline", 
							"Newspapers - Online", 
							"Social Media", 
							"Blog/Gadget Website", 
							"Friends told me about it", 
							"Other"];
							
		
		var sendInitialCalls = function(){
			if($scope.isConfigAvaliable) {
				var response = $scope.config;
        		catogeryId = response.domainId;
        	}
        };
     	sendInitialCalls();
        $rootScope.$on("configUpdated",sendInitialCalls);
						
							
		$scope.ratingOptionSelected = function(value){
			if(value <= 5){
				$scope.feedback_screen_number = "3-1";
			} else {
				$scope.feedback_screen_number = "3-2";
			}
			rating = value;
		};
		$scope.improveSuggestionsSubmitted = function(data){
			improveSuggestion = data;
			$scope.feedback_screen_number = "3-2";
		};
		
		$scope.newFeaturesUpdated = function(item){
			var itemIndex= newFeatures.indexOf(item);
			if(itemIndex == -1){
				newFeatures.push(item);
			} else {
				newFeatures.splice(itemIndex,1);
			}
		};
		
		$scope.newFeaturesNext = function() {
			$scope.feedback_screen_number = "3-3";
		};
		
		$scope.isUsefulSelected = function(state) {
			isUseful = state;
			if(state){
				$scope.feedback_screen_number = "3-5";
			} else {
				$scope.feedback_screen_number = "3-4";
			}
		};
		
		$scope.usefulSuggestionsNext = function(data){
			usefulSuggestion = data;
			$scope.feedback_screen_number = "3-5";
		};
		
		$scope.sourcesUpdate = function(item){
			var itemIndex= sources.indexOf(item);
			if(itemIndex == -1){
				sources.push(item);
			} else {
				sources.splice(itemIndex,1);
			}
		};
		
		$scope.sourcesNext = function(){
			$scope.feedback_screen_number = "3-6";
			var pp={
				improveSuggestion: improveSuggestion,
				isUseful: isUseful,
				newFeatures: newFeatures,
				rating: rating,
				sources: sources,
				usefulSuggestion: usefulSuggestion
			};
			Api.submitteFeedBack(catogeryId, pp).then(function(response){
      		});
		};
		
		
		//submitteFeedBack(domineId, data);
		
  }]).run(['$rootScope', function($rootScope) {
	
		$rootScope.openFeedback = function() {
			$rootScope.showFeedbackPopUp = true;
		};
		$rootScope.closeFeedBack = function() {
			$rootScope.showFeedbackPopUp = false;
		};
	
		$rootScope.overlayClickClose = function(event) {
			if (angular.element(event.target).hasClass('feedback_background')) {
				$rootScope.showFeedbackPopUp = false;
			}
		};
	}
]);
  
  		
