'use strict';

angular.module('buySmaartApp',
	[	'ngCookies',
		'ngResource',
		'ngSanitize',
		'ngRoute',
		'restangular',
		'ui.bootstrap',
		'vr.directives.slider',
		'angular-svg-round-progress',
		'filters.currencyFormat',
		'cycleGallery',
		'ngAnimate',
		'ngTouch',
		// 'satellizer',
		'ngCookies',
        'angular-intro'
	])

	.config(function($routeProvider, RestangularProvider, $locationProvider) {
		/**Facebook client id for app**/
		// $authProvider.facebook({
		// clientId : '297983813658906',
        // url:'/auth/facebook'
		// });
		// $authProvider.google({
		// clientId : '1050076869692-4l4qaha38dmdq769irssi0nbm8cdh674.apps.googleusercontent.com',
        // url:'/auth/google'
		// });

		$locationProvider.html5Mode(true).hashPrefix('!');
		$routeProvider.when('/', {
      templateUrl : 'views/main.html',
      controller : 'MainCtrl',
      title : 'Recommendations using Artificial Intelligence | Buysmaart',
      resolve: {
        NLPFilters: _NLPFiltersResolver
      }
    }).when('/category/:categoryName', {
			templateUrl : 'views/main.html',
			controller : 'MainCtrl',
			title : 'Recommendations using Artificial Intelligence | Buysmaart',
			resolve: {
				NLPFilters: _NLPFiltersResolver
			}
		})
//quarantined
//.when('/main2',{
//templateUrl: 'views/main2.html',
//controller: 'MainCtrl',
//title: 'Mobile phone recommendations using Artificial Intelligence'
//})
    .when('/:categoryName/DiscoveryDashboard', {
			templateUrl : 'views/DiscoveryDashboard.html',
			controller : 'DiscoveryDashboardCtrl',
			title : 'Find the best mobile phones for your needs',
			resolve: {
				NLPFilters: _NLPFiltersResolver
			}
		}).when('/:categoryName/DiscoveryDashboard/:options', {
			templateUrl : 'views/DiscoveryDashboard.html',
			controller : 'DiscoveryDashboardCtrl',
			title : 'Find the best mobile phones for your needs',
			resolve: {
				NLPFilters: _NLPFiltersResolver
			}
		}).when('/:categoryName/Compare', {
			templateUrl : 'views/CompareDefault.html',
			controller : 'CompareDefaultCtrl',
			title : 'Compare smartphone specification, reviews and prices',
			resolve: {
				NLPFilters: _NLPFiltersResolver
			}
		}).when('/:categoryName/Compare/:productid', {
			templateUrl : 'views/CompareDefault.html',
			controller : 'CompareDefaultCtrl',
			title : 'Compare smartphone specification, reviews and prices',
			resolve: {
				NLPFilters: _NLPFiltersResolver
			}
		}).when('/:categoryName/productdetails/:productid/:productname', {
			templateUrl : 'views/productdetails.html',
			controller : 'ProductPageCtrl',
			resolve: {
				NLPFilters: _NLPFiltersResolver
			}
		}).when('/login', {
			templateUrl : 'views/login.html',
			controller : 'LoginCtrl',
			title : 'Login - Buysmaart'
		}).when('/register', {
			templateUrl : 'views/register.html',
			controller : 'RegisterCtrl',
			title : 'Register - Buysmaart'
		}).when('/:categoryName/Compare/:productids/:productNames', {
			templateUrl : 'views/CompareResults.html',
			controller : 'CompareResultsCtl',
			resolve: {
				NLPFilters: _NLPFiltersResolver
			}
		}).when('/WishList', {
			templateUrl : 'views/Wishlist.html',
			controller : 'WishListCtrl',
			title : 'Wishlist your smartphones on BuySmaart'
		}).when('/:categoryName/SmaartView', {
			templateUrl : 'views/SmaartView.html',
			controller : 'SmaartViewCtrl',
			title : 'Smaart View - Smart phone comaprision chart'
		}).when('/:categoryName/SmaartView/:options', {
			templateUrl : 'views/SmaartView.html',
			controller : 'SmaartViewCtrl',
			title : 'Smaart View - Smart phone comaprision chart'
		}).when('/:categoryName/SmaartView/:options/:productid2', {
			templateUrl : 'views/SmaartView.html',
			controller : 'SmaartViewCtrl',
			title : 'Smaart View - Smart phone comaprision chart'
		}).when('/:categoryName/SmaartView/:options/:productid2/:productid3', {
			templateUrl : 'views/SmaartView.html',
			controller : 'SmaartViewCtrl',
			title : 'Smaart View - Smart phone comaprision chart'
		}).when('/:categoryName/SmaartView/:options/:productid2/:productid3/:productid4', {
			templateUrl : 'views/SmaartView.html',
			controller : 'SmaartViewCtrl',
			title : 'Smaart View - Smart phone comaprision chart'
		}).when('/:categoryName/HowItWorks', {
			templateUrl : 'views/howitworks.html',
			controller : 'HowItWorksCtrl',
			title : 'How It Works - Buysmaart'
		})
		/**Static pages**/.when('/HowItsWorks', {
			templateUrl : 'views/howitworks.html',
			title : 'How It Works - Buysmaart'
		}).when('/OurTeam', {
			templateUrl : 'views/ourteam.html',
			title : 'Our Team - Buysmaart'
		}).when('/CopyRight', {
			templateUrl : 'views/copyright.html',
			title : 'Copy Right - Buysmaart'
		}).when('/Disclaimer', {
			templateUrl : 'views/disclaimer.html',
			title : 'Disclaimer - Buysmaart'
		}).when('/Terms', {
			templateUrl : 'views/terms.html',
			controller : 'AccordianInitCtrl',
			title : 'Terms & Conditions - Buysmaart'
		}).when('/PrivacyPolicy', {
			templateUrl : 'views/privacy-policy.html',
			controller : 'AccordianInitCtrl',
			title : 'Privacy Policy - Buysmaart'
		}).when('/ContactUs', {
			templateUrl : 'views/contactUs.html',
			controller : 'ContactUsCtrl',
			title : 'Contact Us - Buysmaart'
		}).when('/:categoryName/DiscoveryDashboard/:metadataString/:options', {
			templateUrl : 'views/DiscoveryDashboard.html',
			controller : 'DiscoveryDashboardCtrl',
			title : 'Put your custom title text here',
			resolve: {
				NLPFilters: _NLPFiltersResolver
			}
		}).when('/style-guide', {
			templateUrl : 'views/style-guide.html',
			controller : 'StyleGuideCtrl',
			title : 'The Universal Style Guide'
		}).otherwise({
			redirectTo : '/404',
			templateUrl : '/404.html'
		});
		RestangularProvider.setBaseUrl('/api/v0.1');

		function _NLPFiltersResolver(Api, $rootScope, NLPFilterServices, Meta) {
			return Api.fetchDomainConfiguration()
			.then(function(domainConfig) {
				$rootScope.domain = NLPFilterServices.parseDomainConfig( domainConfig );
        $rootScope.categories = NLPFilterServices.normalizeConfig( domainConfig );
				var categoryId = Meta.getCategoryID();
				var domainId = "smartphone"; //default forever
				return Api.fetchConfigarations(domainId, categoryId)
				.then(function(config) {
            $rootScope.config = config;
            $rootScope.NLPFilters.domainId = config.domainId;
            $rootScope.categoryId = categoryId;
            $rootScope.updateFiltersAndAspectsForCategory(config);
            $rootScope.isConfigAvaliable = true;
            $rootScope.$broadcast("categoryConfigUpdated");
					return {
						config: config,
						domainId: config.domainId,
						categoryId: categoryId
					};
				});
			});
		}

	})
	.run(['$route', "Api", '$rootScope', '$location', '$window', '$cookies', 'Restangular', 'NLPFilterServices', 'Meta', function($route, Api, $rootScope, $location, $window, $cookies, Restangular, NLPFilterServices, Meta) {
		$rootScope.serverUrl = '/api/v0.1';
		$rootScope.authserverUrl = '';

       $rootScope.budgetAmountsList = Meta.getBudgetAmountListForCategory();

      // $rootScope.NLPFiltersDefaults = angular.copy($rootScope.NLPFilters);

	    var usernameFromCookie = $cookies.get('buysmaart_login_username');
	  	//usernameFromCookie = "Testing";
	    if(usernameFromCookie != null && usernameFromCookie != undefined && usernameFromCookie != '') {
	        $rootScope.user_name = usernameFromCookie;
	    }
	    var useridFromCookie = $cookies.get('buysmaart_login_userid');
	    //useridFromCookie = 60;
	    if(useridFromCookie != null && useridFromCookie != undefined && useridFromCookie != '') {
	        $rootScope.isUserLoggedIn = true;
	        $rootScope.user_id = useridFromCookie;
	    }

    $rootScope.$on("$routeChangeSuccess", function (event, currentRoute, previousRoute) {
      window.scrollTo(0, 0);
    });

    var _lookupTable1 = {
    	"OS" : "filters[1].selectedFilters",
    	"Brand" : "filters[0].selectedFilters",
    	"Star Rating" : "filters[1].selectedFilters",
    	"Install and Service" : "aspects.Install and Service.value",
    	"Ease of Use" : "aspects.Ease of Use.value",
    	"Efficiency" : "aspects.Efficiency.value",
    	"Hygiene" : "aspects.Hygiene.value",
    	"PriceMaxValue" : "PriceMaxValue",
    	"PriceMinValue" : "PriceMinValue",
    	"Battery" : "aspects.Battery.value",
    	"Camera" : "aspects.Camera.value",
    	"Storage" : "aspects.Storage.value",
    	"Display" : "aspects.Display.value",
    	"Performance" : "aspects.Performance.value",
    	"Sentiment" : "SentimentWeight",
    	"Specification" : "SpecificationWeight",
    	"AllProducts" : "allProducts",
    	"TimeSort" : "TimeSort",
    	"PriceSort" : "PriceSort",
    	"ScoreSort" : "ScoreSort",
      	"Capacity in Ton": "filters[2].selectedFilters",
      	"Screen size": "filters[2].selectedFilters",
      	"Size": "filters[2].selectedFilters",
      	"RAM": "filters[2].selectedFilters"
    }

    var _lookupTable2 = _.extend(_lookupTable1, {
    	"Screen Size": "filters[1].selectedFilters",
    	"Connectivity": "aspects.Connectivity.value",
    	"Picture": "aspects.Picture.value",
    	"Smart Features": "aspects.Smart Features.value",
    	"Sound": "aspects.Sound.value",
    	"HD Technology": "filters[2].selectedFilters"
    })

    $rootScope.lookup = {
    	"Smartphones": _lookupTable1,
    	"Tablets": _lookupTable1,
    	"Laptops": _lookupTable1,
    	"Air Conditioners": _lookupTable1,
    	"Televisions": _lookupTable2
    }

		$rootScope.$on('$routeChangeSuccess', function(event, current, previous) {
			$rootScope.title = (current && current.$$route)? current.$$route.title : "";
			__insp.push(["virtualPage"]);
		});

		$rootScope.compareItems = [];
		$rootScope.isConfigAvaliable = false;
        $rootScope.NLPFilters = {
           "PriceMinValue" : 5000,
           "PriceMaxValue" : 40000,
           "SpecificationWeight": 3,
           "SentimentWeight": 3,
           "TimeSort": null,
           "PriceSort": null,
           "ScoreSort": null,
           "allProducts" : false
       };

		$rootScope.arrayOfAspectTips = [
			{
			    "display":"is most important",
			    "value":5
			},
			{
			    "display":"is very important",
			    "value":4
			},
			{
			    "display":"is moderately important",
			    "value":3
			},
			{
			    "display":"is unimportant",
			    "value":2
			},
			{
			    "display":"is least important",
			    "value":1
			}
		];

		Api.fetchDomainConfiguration().then(function(domainConfig) {
			$rootScope.domain = NLPFilterServices.parseDomainConfig( domainConfig );
			$rootScope.categories = NLPFilterServices.normalizeConfig( domainConfig );
			$rootScope.NLPFilters.domainIndex = Meta.getDomainIndex();
			$rootScope.categoryId = Meta.getCategoryID();
			var categoryId = _.get( $rootScope, "categoryId", 1);
	        Api.fetchConfigarations("smartphone", categoryId).then(function(config) {
	          $rootScope.config = config;
	          $rootScope.NLPFilters.domainId = config.domainId;
	          $rootScope.categoryId = categoryId;
	          updateFiltersAndAspectsForCategory(config);
	          $rootScope.isConfigAvaliable = true;
	          $rootScope.$broadcast("categoryConfigUpdated");
	        });
		});

		var updateFiltersAndAspectsForCategory = function(config) {
			var aspects = config.aspects;
			var filters = config.filters;
      var lastGlobalIndex = 0;
      var lastListingIndex = 0;
			$rootScope.NLPFilters.filters = [];
       		for(var i = 0, iLen = filters.length; i < iLen; i++){
       			// scope.nlpFilterNames[i] = filters[i].filterId;
        		// var filterItems = new Array();
        		var allItems = filters[i].filterableItems;
        		// scope.allFilterItems[i] = allItems;
        		// for(var j=0;j<allItems.length;j++) {
        		// 	filterItems.push(allItems[j].itemId);
        		// }
        		// scope.nlpFilters[i] = filterItems;
        		// if(filterItems.length == 0 || filterItems.length == allItems.length) {
        		// 	scope.nplFilterText[i] = 'Any ' + scope.nlpFilterNames[i];
        		// 	scope.selectAllFilter[i] = true;
        		// 	scope.interNLPSelectedFilters[i] = [];
        		// 	for(var j in allItems) {
        		// 		scope.interNLPSelectedFilters[i].push(allItems[j].itemId);
        		// 	}
        		// }
        		// scope.showFilterList[i] = false;
        		$rootScope.NLPFilters.filters[i] = {};
        		$rootScope.NLPFilters.filters[i].filterId = filters[i].filterId;
        		$rootScope.NLPFilters.filters[i].metadataId = filters[i].metadataId;
          $rootScope.NLPFilters.filters[i].allFilters = allItems;
    			$rootScope.NLPFilters.filters[i].filterLocation = filters[i].filterLocation;
          if(filters[i].filterLocation == "GLOBAL"){
            lastGlobalIndex = i;
          }
          if(filters[i].filterLocation == "LISTING"){
            lastListingIndex = i;
          }
    			$rootScope.NLPFilters.filters[i].selectedFilters = [];
    			// $rootScope.nplFilterText = scope.nplFilterText;
        	}
          if(lastListingIndex < lastGlobalIndex) {
            var temp = $rootScope.NLPFilters.filters[lastGlobalIndex];
            $rootScope.NLPFilters.filters[lastGlobalIndex] = $rootScope.NLPFilters.filters[lastListingIndex];
            $rootScope.NLPFilters.filters[lastListingIndex] = temp;
          }
        	$rootScope.NLPFilters.aspects = {};
            // scope.aspectDisplayName = {};
			for (var key in aspects) {
				// scope.aspectDisplayName[scope.aspects[key].aspectId] = scope.arrayOfAspectTips[2].display;
				// scope.showAspectList[scope.aspects[key].aspectId] = false;
				$rootScope.NLPFilters.aspects[aspects[key].aspectId] = angular.copy($rootScope.arrayOfAspectTips[2]);
				$rootScope.NLPFilters.aspects[aspects[key].aspectId].name = aspects[key].aspectId;
				$rootScope.NLPFilters.aspects[aspects[key].aspectId].metadataId = aspects[key].metadataId;
			}
			$rootScope.myParams = $rootScope.NLPFilters;
		}

    $rootScope.updateFiltersAndAspectsForCategory = updateFiltersAndAspectsForCategory;

		var original = $location.path;
		$location.path = function(path, reload) {
			if (reload === false) {
				var lastRoute = $route.current;
				var un = $rootScope.$on('$locationChangeSuccess', function() {
					$route.current = lastRoute;
					un();
				});
			}
			return original.apply($location, [path]);
		};

		/*** social share functions ***/
		$rootScope.tweetWindow = function() {
			var url = $location.absUrl();
			var title = "BuySmaart";
			$window.open("http://twitter.com/share?url=" + encodeURIComponent(url) + "&text=" + encodeURIComponent(title) + "&count=none/", "tweet", "height=300,width=550,resizable=1");
		};

		$rootScope.faceWindow = function() {
			var url = $location.absUrl();
			var title = "BuySmaart";
			$window.open("http://www.facebook.com/sharer.php?u=" + encodeURIComponent(url) + "&media=" + encodeURIComponent("http://lorempixe/400/200/food") + "&t=" + encodeURIComponent(title), "facebook", "height=300,width=550,resizable=1");
		};

		$rootScope.googleWindow = function() {
			var url = $location.absUrl();
			var title = "BuySmaart";
			$window.open("https://plus.google.com/share?url=" + url, "facebook", "height=300,width=550,resizable=1");
		};

		$rootScope.replaceSpaceWithDash = function(name){
			if(name == null || name == undefined || name == '') {
				return '';
			}
			return name.replace(/ /g,"-");
		};

		$rootScope.safeEscapeDisplayName = function(name){
			var _name = $rootScope.replaceSpaceWithDash(name);
			_name = encodeURIComponent( _name );
			return encodeURIComponent( _name );
		};

		$rootScope.OpenInNewTab = function(url,sourcePage,seller,EventCategory) {
			Api.gaTrackEvent('('+EventCategory+') ' + sourcePage + ' Page','Buy Now Button Clicked', seller);
			var win = window.open(url, '_blank');
			win.focus();
		};
	}
]);


$(function() {
    // Check if it is iOS
    var isiOS = (navigator.userAgent.match(/(iPad|iPhone|iPod)/g) ? true : false);
    if(isiOS === true) {

        // Store -webkit-tap-highlight-color as this gets set to rgba(0, 0, 0, 0) in the next part of the code
        var tempCSS = $('a').css('-webkit-tap-highlight-color');

        $('body').css('cursor', 'pointer')                                    // Make iOS honour the click event on body
                 .css('-webkit-tap-highlight-color', 'rgba(0, 0, 0, 0)');     // Stops content flashing when body is clicked

        // Re-apply cached CSS
        $('a').css('-webkit-tap-highlight-color', tempCSS);

    }

});
