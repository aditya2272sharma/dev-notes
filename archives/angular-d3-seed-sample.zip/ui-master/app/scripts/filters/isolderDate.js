'use strict';
angular.module('buySmaartApp').filter('isolderDate', [
function() {
	return function(dateString) {
		var today = new Date();
		var dateObj = new Date(dateString);
		if(today.getTime() < dateObj.getTime()) {
			return false;
		}
		return true;
	};
}]);