'use strict';
angular.module('filters.currencyFormat',[])

.filter('currencyFormat', [
function() {
	return function(value, currencySy) {
		
		function toFixedToOne(value){
			return Math.round(value * 10) / 10;
		};
		
		if(value != 0 && (value == "" || value == undefined || value == null)){
			return '-';
		}
		
		if(isNaN(value)){
			return value;
		}
		
		value = Number(value);
		switch(currencySy) {
		case "\u20b9":
				value = currencySy + ' ' + value.toLocaleString("hi-IN");
			break;
		default:
			value = currencySy + ' ' + value.toLocaleString();
		break;
		}
		return value;
	};
}])

.filter('numberFormat', [
function() {
	return function(value) {
		
		function toFixedToOne(value){
			return Math.round(value * 10) / 10;
		};
		
		if(value != 0 && (value == "" || value == undefined || value == null)){
			return '-';
		}
		
		if(isNaN(value)){
			return value;
		}
		
		value = Number(value);
		value = value.toLocaleString("hi-IN");
		return value;
	};
}])

.filter('validateNgsrc', [
function() {
	return function(value) {
		if(value == "" || value == null || value == undefined) {
			return false;
		}
		var stringArray = value.split("/");
		if(stringArray[stringArray.length -1].indexOf('.') == -1) {
			return false;
		}
		return true;
	};
}
]);