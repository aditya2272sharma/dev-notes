# Category Addition Checklist

## Table of Contents
* Adding new category
  * CSS Check List

* sanity test process


## Adding new category 
### CSS Check List
* image-icons
  * `.{png,jpg,jpeg,gif,webp,svg}`
    * use photoshop to crop/slice the icons from the `.psd` file
    * make sure the `bit depth` is `72 dpi`
    * export images containing transparencies/geometrical shapes in `.png` format
    * export very small images (where image quality is not a concern) in `.gif` format
    * export general large images in `.jpg` format
    * use the **export to web - legacy web** in `photoshop` to export images
    * keep the images in `images/ignore` directory
    * keep the `svg` icons received from Sai in `images/svg` directory for future usages
* font-icons
  * generating `font-icons`
    * use the ico-moon app to generate new fonts
    * https://icomoon.io/
    * use your enixta email to login
    * check the video tutorial on youtube to understand how to use the app
    * upload the existing `svg` font set to get started
    * import the new icons provided to you in svg format (ask Sai for this)
    * make sure that you **do not** alter the sequence of icons as it will lead to overworking
  * **NOTE**:
    * Now onwards fonts have to be uploaded to `Amazon S3` servers into the respective buckets
    * Console URL: https://console.aws.amazon.com/console/home (ask sijin for access)
    * Bucket: `sing-prd-bc-cdn`
    * Folder: "/fonts"
    * As of now
      * It is a `manual process`
      * **Please note** that everytime you update the font-icons, you've to append the URL with a random string to prevent it from getting cached on User's machines
      * Use any MD5 or SHA1 utility or Random Hash functions to come up with random strings
      * `example`:


```css
@font-face {
  font-family: 'font-buysmaart';
  src: url('http://d3gorne2e47xvy.cloudfront.net/fonts/font-buysmaart.ttf?-vo798o') format('truetype');
}
/*
** Here, vo798o is a random string appended after the URL 
** as a query param to prevent it from getting cached.
** Change the number whenever you alter the fonts.
*/
```

* **Why just `ttf`**
  * Currently the effort is manual, increasing the number of copies means increasing the chances of errors
  * Web browsers are expected to comply with the standards and they should support `ttf`
  * Browsers like `IE` have a tendency to download all of the fonts before defaulting to `woff`
  * Slow browsers chose to be always slow despite all our efforts, so extra effort is not worthwhile
  * 
* (css checklist contd.) font-icons
  * using the `font-icons`
    * find the dynamic css class name to be used for the icons
    * refer the `category config` api responses and find the `aspect names` from it
    * use the unicode characters obtained from icomoon app to map class names
* css class names
  * when new categories are added, the category configuration (from api) contains all the relevant information
  * we have to extract the
    * name / display name / id of various properties e.g.
      * aspects
      * genre
      * displayed name on the dashboard icon sets
    * it's location in the response i.e. index in the array
    * (...) and other properties 
  * extract the names, and map them to proper css class names so that the following can be updated
    * category names
    * aspect names
    * genre metadata icons
    * images for dashboard-icons (explore links)




### HTML Check List
* navigation - check URLs for
    * top brands
    * new arrivals
    * top searches
    * popular comparisons
      * check for products containing special characters like '/' and 'dashes'
      * verify if we're getting any 404 or 
    * price ranges
* home page
  * seo metadata links in footer
  * dashboard links (explore-links on home page) translating into proper URLs for DD
  * genre metadata links and icons



* Category Dropdown Icon

Checklist: New Category Addition

### Home Page
#### CSS
* NLP filter section
  * aspect icons
    * map css classes to the name of aspects
    * file: app/styles/main.scss
  * aspect text changes
    * check if the text is exceeding the space
    * if so, alter the width to accomodate
* genre meta icons
  * genre meta font icons
  * genre meta icon colours
* New Arrivals and Popular Comparisons Section
  * Image Sizes
  * Container Sizes


### JS
Aspects setting
Footer Links working
Drop downs
URLs containing ‘/‘ in search and Top Nav drop downs
Text of heading in Footers (by brands / os ) hardcoded
OS/Brand Dropdown values
URL on Dashboard Icon (originally genre, but mislabeled)
Discovery Dashboard

Product Details
CSS
Aspect Raster Icons in Overlay / PDP
Aspect Icons in Vector in Overlay / PDP

Check for API calls for overlay & PDP

### Issues known to occur frequently

Following are the list of issues that occured frequently during previous category additions

#### In Home Page
* incorrect alignment of buttons and container and also, size of images appearing in
  * popular comparison widget
  * new arrivals widget
* aspect icons missing/incorrect in
  * NLP filters
  * discovery dashboard
  * smaart view (& also smaart compare)
  * compare page
  * product details page/overlay
* genre icons incorrect / not updating after category change
* seo metadata links (links in footer)
  * not updating after category change
  * clicking on them doesn't lead to correct url, thereby not giving proper results in DD

#### In Discovery Dashboard & Smaart View
```
clubbed together because both contain identical sets of code and functionalities are almost simialr

```

* search
  * categoryId doesn't update correctly after changint category
    * which may lead to incorrect search / zero search results
* sortBy
  * for some categories `sort by` has limited availability
    * e.g. for Laptops and ACs `release date` is not a proper sorting criteria - there for it should not appear in the list of 'Sort By' filters in DD
  * check if it works properly when selected
  * check if it works when the same filter is selected twice
  * generally, when the same filter is clicked, it doesn't trigger a URL update, sometimes this leads to a hung-state where filter changes verification fails
* aspect sliders
  * While moving to-n-fro between Discovery Dashboard and Smaartview
    * the values on aspect sliders should be retained
    * and, proper results set should be shown
* top global filters in Smaartview
  * global filters e.g. Brands and OSs for Smart Phones, are known not to work in case of ACs
  * verify their functionalities

* description and specs alignment issues in product details page and product details overlay
* novelty list goes missing or doesn't update correctly
* clicking on home button doesn't update the navigation links / aspects / genre metadata / seo metadata links
