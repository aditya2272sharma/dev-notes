# SEO Guidelines

## Pages of importance (ordered in most-to-least)

* Product Details Page
* Compare Page
* Price Range Page (Discovery Dashboard)
* Discover Dashboard


## Look at the site's following properties:
* The canonical URL `<link rel="canonical" href="...">` in the `meta` tag
  * Because of Angular's routing related restriction and constraints in the `Dev` environment, we've been using `relative paths` all across
  * A canonical URL is helpful in such a case, when most of the links in the page are relative
  * By this, bots will understand that whenever we mean '/DiscoveryDashboard', they've to interpret them as 'http://www.buysmaart.com/DiscoveryDashboard'
  * This said understanding could be incorrect
  * Follow these links to get better understanding of it
    * https://moz.com/learn/seo/canonicalization
    * https://support.google.com/webmasters/answer/139066?hl=en
    * https://yoast.com/rel-canonical/
    * https://www.ltnow.com/rel-canonical-seo/
* `sitemap.xml`
  * A sitemap contains all links that a website intends to be crawled by bots
  * It's an excellent entity to look at and understand the priorities of competitors
  * It can be also used for **Scraping Purposes**
  * Competitors have a general tendency to keep `important` products in the sitemap
* Text content available in `View Source` (not with inspect element)
  * ctrl + u (windows)
  * command + option + u (mac)
  * This textual content primarily indicates the text that is readily available for consumption by crawlers by simply doing a `GET` request to the page
  * Unfortunately, JS rich pages that rely on JS based rendering are not compliant with this `GET` mechanism
  * As of now, only Google supports JS based rendering
* To get an idea, how a page looks like to Google crawler
  * Search for any article e.g. `iPhone 5s buysmaart` on google
  * Click on the downward arrow next to the link
  * Choose `View Cached` or `Cached` option in the dropdown
  * The page that will come up gives the glimpse what's visible to Google Crawlers



### smartprix.com analysis

* Product Feautres
  * Make all tech spec information available in the first-rendering cycle
  * Make sure that doesn't get hidden with CSS `display`
  * Objective: 
    * To make our cached page on google better & rich
  * Turn clickable items in anchor elements


### My Smart Price
* Shows a list of `links` to related products
  * `You may also be interested in` (not present yet, similar phones is not the right candidate for this)
* Qualitative Information
  * `Apple iPhone 6S Details` (sort of present in our site, need to fine tune it)
* Variants e.g. 16gb, 32gb are displayed as buttons, but in reality they are all links
* They show reviews in their PDPs
* 
* Price Information
  * All prices are shown in a single shot, without any additional clicks
  * Seller Rating already in place
    * Featured sellers are shown on the top (probably higher comission)
    * They have done a detailed display of Seller's information

  * Helps with
    * Shipping
    * Payment related information (COD / EMI / Return Policy)
    * Warranty 

* h1 for title
* h3 for tech specs header
  * `Detailed Technical Specification of Apple iPhone 6s 64GB`
  

## Key Takeaways
* The `google cached copies` of our product details pages appear to contain far lesser text than expected
  * This is primarily because of `hidden containers` which are usually available by user actions
  * The tech specs mentioned in the page are **not** visible to the google crawler
  * In the new design of PDP, this issue has been resolved, by
    * showing full content of the page at once
    * keeping sticky header to navigate (for better UX)
    * We **must** implement the new design ASAP
    * **Issues** - This can lead to significant performance downfall, as we'll have to wait for all API requests to resolve to ensure good amount of text.
    * Unfortunately, lazy loading is **not** going to help us
    * We'll have to change our backend APIs to fetch us the full information in a single shot
  * This is usually not a problem for pages that are rendered from backend, as a `GET` request to these pages contain enough text to make an interpretation
* **BONUS TIP**: Read about black hat SEO techniques
* `Clickable` items in the pages have to be converted into `Crawlable links` for better SEO
* Inclusion of `h1`, `h2` and similar header tags have to be used in the page
* More relevant links have to be added to page
  * Most of our competitors were observed to have added relevant links
  * In the `aside` section, links for relevant filters were observed
  * In the product details section, similar products were seen to be mentioned as links
