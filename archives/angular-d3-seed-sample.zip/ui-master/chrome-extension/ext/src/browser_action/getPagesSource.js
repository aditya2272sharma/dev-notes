// function DOMtoString(document_root) {
//     var html = '',
//         node = document_root.firstChild;
//     while (node) {
//         switch (node.nodeType) {
//         case Node.ELEMENT_NODE:
//             html += node.outerHTML;
//             break;
//         case Node.TEXT_NODE:
//             html += node.nodeValue;
//             break;
//         case Node.CDATA_SECTION_NODE:
//             html += '<![CDATA[' + node.nodeValue + ']]>';
//             break;
//         case Node.COMMENT_NODE:
//             html += '<!--' + node.nodeValue + '-->';
//             break;
//         case Node.DOCUMENT_TYPE_NODE:
//             // (X)HTML documents are identified by public identifiers
//             html += "<!DOCTYPE " + node.name + (node.publicId ? ' PUBLIC "' + node.publicId + '"' : '') + (!node.publicId && node.systemId ? ' SYSTEM' : '') + (node.systemId ? ' "' + node.systemId + '"' : '') + '>\n';
//             break;
//         }
//         node = node.nextSibling;
//     }
//     return html;
// }

function orIsIt(){
    var insight = {};
    //AMAZON
    // if(document.URL == ""){
    //     insight.product = $('#productTitle').text();
    //     insight.price = $('#priceblock_ourprice').contents().filter(function(){ 
    //                 return this.nodeType == 3; 
    //             })[0].nodeValue
    //     insight.brand = $('#brand').text();
    //     insight.url = document.URL;
    // }

    //FLIPKART
    // if(document.URL == ""){
        insight.product = $($('.product-details .title')[0]).text();
        insight.price = $('.selling-price').text();
        insight.brand = $('.clp-breadcrumb li:nth-last-child(2)').text().trim();
        insight.url = document.URL;       
    // }
    

    return(JSON.stringify(insight));
}


function syncThis(insight){

    chrome.storage.local.get({insights: []}, function (result) {
        // the input argument is ALWAYS an object containing the queried keys
        // so we select the key we need
        var enterInsight = 1;
        var insights = result.insights;
        var insightURL = JSON.parse(insight).url;
        for(var index in insights){
            if(insights[index].key == insightURL){
                enterInsight = 0;
                break;
            }
        }
        if(enterInsight == 1){
            insights.push({insight: insight, key: insightURL});
        }
        // set the new array value to the same key
        chrome.storage.local.set({insights: insights}, function () {
           // you can use strings instead of objects
          // if you don't  want to define default values
           chrome.storage.local.get('insights', function (result) {
               console.log(result.insights);
           });
        });
    });
}

function clearStorage(){
    chrome.storage.local.clear(function() {
        var error = chrome.runtime.lastError;
        if (error) {
           console.error(error);
        }
    });
}

// Inform the background page that 
// this tab should have a page-action

// var domInfo = DOMtoString(document);
var domInfo = orIsIt();
// clearStorage();
if(JSON.parse(domInfo).product){
    syncThis(domInfo);
}

chrome.runtime.sendMessage({
  from:    'content',
  subject: 'showPageAction'
});

// Listen for messages from the popup
chrome.runtime.onMessage.addListener(function (msg, sender, response) {
  // First, validate the message's structure
  if ((msg.from === 'popup') && (msg.subject === 'DOMInfo')) {
    // Collect the necessary data 
    // (For your specific requirements `document.querySelectorAll(...)`
    //  should be equivalent to jquery's `$(...)`)
    //var domInfo = DOMtoString(document);

    // Directly respond to the sender (popup), 
    // through the specified callback */
    response(domInfo);
  }
});