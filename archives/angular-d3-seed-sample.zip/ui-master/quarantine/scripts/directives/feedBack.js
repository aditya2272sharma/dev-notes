'use strict';

angular.module('buySmaartApp').directive('feedBack', [function() {
	return {
		templateUrl : 'views/feedback.html',
		restrict : 'E',
		link : function postLink(scope, element, attrs) {
		}
	};
}]);
